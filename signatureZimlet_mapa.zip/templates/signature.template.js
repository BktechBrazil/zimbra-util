AjxTemplate.register("com_zimbra_signature_zimlet.templates.signature#Main", 
function(name, params, data, buffer) {
	var _hasBuffer = Boolean(buffer);
	data = (typeof data == "string" ? { id: data } : data) || {};
	buffer = buffer || [];
	var _i = buffer.length;

	buffer[_i++] = "<table cellpadding=\"2\" cellspacing=\"0\" border=\"0\" width=\"100%\"><tr><td><b>Nome:</b></td><td><input type=\"text\" name=\"signature_name_prop\" /></td></tr><tr><td><b>Cargo ocupado e/ou função:</b></td><td><input type=\"text\" name=\"signature_occupation_prop\" /></td></tr> <tr><td><b>Departamento / Siglas / Secretaria:</b></td><td><input type=\"text\" name=\"signature_dep_prop\" /></td></tr> <tr><td><b>Telefones:</b></td><td><input type=\"text\" name=\"signature_other_prop\" /></td></tr></table><br><p>Pré-visualização</p><div id=\"signature-preview\"></div>";

	return _hasBuffer ? buffer.length : buffer.join("");
},
{
	"id": "Main"
}, true);
AjxPackage.define("com_zimbra_signature_zimlet.templates.signature");
AjxTemplate.register("com_zimbra_signature_zimlet.templates.signature", AjxTemplate.getTemplate("com_zimbra_signature_zimlet.templates.signature#Main"), AjxTemplate.getParams("com_zimbra_signature_zimlet.templates.signature#Main"));

