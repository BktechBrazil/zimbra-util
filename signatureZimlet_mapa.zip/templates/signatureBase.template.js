AjxTemplate.register("com_zimbra_signature_zimlet.templates.signatureBase#Main", 
function(name, params, data, buffer) {
	var _hasBuffer = Boolean(buffer);
	data = (typeof data == "string" ? { id: data } : data) || {};
	buffer = buffer || [];
	var _i = buffer.length;

	buffer[_i++] = "<div><p style=\"color:rgba(6,60,30,1.00); font-family: 'Trebuchet MS'; font-size: 10pt; font-weight: bold; line-height:3px\">";
	buffer[_i++] = data.name;
	buffer[_i++] = "</p><p style=\"color:rgba(111,100,39,1.00); font-family: 'Trebuchet MS'; font-size: 10pt; line-height:3px\">";
	buffer[_i++] = data.occupation;
	buffer[_i++] = "</p><p style=\"color:rgba(111,100,39,1.00); font-family: 'Trebuchet MS'; font-size: 10pt; line-height:3px\">";
	buffer[_i++] = data.departa;
	buffer[_i++] = "</p><p style=\"color:rgba(111,100,39,1.00); font-family: 'Trebuchet MS'; font-size: 10pt; line-height:3px\">Ministério da Agricultura, Pecuária e Abastecimento</p>";
	buffer[_i++] = "<p style=\"color:rgba(111,100,39,1.00); font-family: 'Trebuchet MS'; font-size: 10pt; line-height:5px\">";
	buffer[_i++] = data.other;
	buffer[_i++] = "</p><div><img src=\"";
	buffer[_i++] =  data.image ;
	buffer[_i++] = "\" alt=\"\"></div></div>";

	return _hasBuffer ? buffer.length : buffer.join("");
},
{
	"id": "Main"
}, true);
AjxPackage.define("com_zimbra_signature_zimlet.templates.signatureBase");
AjxTemplate.register("com_zimbra_signature_zimlet.templates.signatureBase", AjxTemplate.getTemplate("com_zimbra_signature_zimlet.templates.signatureBase#Main"), AjxTemplate.getParams("com_zimbra_signature_zimlet.templates.signatureBase#Main"));

