(window["com_zimbra_connect_classic_jsonp"] = window["com_zimbra_connect_classic_jsonp"] || []).push([ [ 10 ], {
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/components/loading/LoadingAnimation.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        var getUrl = __webpack_require__("./node_modules/css-loader/dist/runtime/getUrl.js");
        var ___CSS_LOADER_URL___0___ = getUrl(__webpack_require__("./src/components/assets/logo-team-noballs.svg"));
        exports.push([ module.i, "._zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce{\n  margin:40px auto;\n  width:128px;\n  height:128px;\n  text-align:center;\n  background-image:url(" + ___CSS_LOADER_URL___0___ + ");\n}\n._zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce ._zextras_team_web_client_release_loading-LoadingAnimation-less_child{\n  margin-top:53px;\n  width:22px;\n  height:22px;\n  background-color:#c1c4c7;\n  border-radius:100%;\n  margin-left:1px;\n  margin-right:1px;\n  display:inline-block;\n  -webkit-animation:_zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce 1.4s ease-in-out 0s infinite both;\n  animation:_zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce 1.4s ease-in-out 0s infinite both;\n}\n._zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce ._zextras_team_web_client_release_loading-LoadingAnimation-less_bounce1{\n  -webkit-animation-delay:-0.32s;\n  animation-delay:-0.32s;\n}\n._zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce ._zextras_team_web_client_release_loading-LoadingAnimation-less_bounce2{\n  -webkit-animation-delay:-0.16s;\n  animation-delay:-0.16s;\n}\n@-webkit-keyframes _zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce{\n  0%,\n  80%,\n  100%{\n    -webkit-transform:scale(0);\n    transform:scale(0);\n  }\n  40%{\n    -webkit-transform:scale(1);\n    transform:scale(1);\n  }\n}\n@keyframes _zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce{\n  0%,\n  80%,\n  100%{\n    -webkit-transform:scale(0);\n    transform:scale(0);\n  }\n  40%{\n    -webkit-transform:scale(1);\n    transform:scale(1);\n  }\n}\n", "", {
            version: 3,
            sources: [ "LoadingAnimation.less" ],
            names: [],
            mappings: "AAUA;EACE,gBAAiB;EACjB,WAAY;EACZ,YAAa;EACb,iBAAkB;EAClB,8CAAsD;AACxD;AACA;EACE,eAAgB;EAChB,UAAW;EACX,WAAY;EACZ,wBAAyB;EACzB,kBAAmB;EACnB,eAAgB;EAChB,gBAAiB;EACjB,oBAAqB;EACrB,8HAAgE;EAChE,sHAAwD;AAC1D;AACA;EACE,8BAA+B;EAC/B,sBAAuB;AACzB;AACA;EACE,8BAA+B;EAC/B,sBAAuB;AACzB;AACA;EACE;;;IAGE,0BAA2B;IAC3B,kBAAmB;EACrB;EACA;IACE,0BAA2B;IAC3B,kBAAmB;EACrB;AACF;AACA;EACE;;;IAGE,0BAA2B;IAC3B,kBAAmB;EACrB;EACA;IACE,0BAA2B;IAC3B,kBAAmB;EACrB;AACF",
            file: "LoadingAnimation.less",
            sourcesContent: [ "/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n.threeBounce {\n  margin: 40px auto;\n  width: 128px;\n  height: 128px;\n  text-align: center;\n  background-image: url(../assets/logo-team-noballs.svg);\n}\n.threeBounce .child {\n  margin-top: 53px;\n  width: 22px;\n  height: 22px;\n  background-color: #c1c4c7;\n  border-radius: 100%;\n  margin-left: 1px;\n  margin-right: 1px;\n  display: inline-block;\n  -webkit-animation: threeBounce 1.4s ease-in-out 0s infinite both;\n  animation: threeBounce 1.4s ease-in-out 0s infinite both;\n}\n.threeBounce .bounce1 {\n  -webkit-animation-delay: -0.32s;\n  animation-delay: -0.32s;\n}\n.threeBounce .bounce2 {\n  -webkit-animation-delay: -0.16s;\n  animation-delay: -0.16s;\n}\n@-webkit-keyframes threeBounce {\n  0%,\n  80%,\n  100% {\n    -webkit-transform: scale(0);\n    transform: scale(0);\n  }\n  40% {\n    -webkit-transform: scale(1);\n    transform: scale(1);\n  }\n}\n@keyframes threeBounce {\n  0%,\n  80%,\n  100% {\n    -webkit-transform: scale(0);\n    transform: scale(0);\n  }\n  40% {\n    -webkit-transform: scale(1);\n    transform: scale(1);\n  }\n}\n" ]
        } ]);
        exports.locals = {
            threeBounce: "_zextras_team_web_client_release_loading-LoadingAnimation-less_threeBounce",
            child: "_zextras_team_web_client_release_loading-LoadingAnimation-less_child",
            bounce1: "_zextras_team_web_client_release_loading-LoadingAnimation-less_bounce1",
            bounce2: "_zextras_team_web_client_release_loading-LoadingAnimation-less_bounce2"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/components/loading/LoadingPage.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.i(__webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./src/components/assets/zextras-icon-font.css"), "");
        exports.push([ module.i, '._zextras_team_web_client_release_loading-LoadingPage-less_ellipsis{\n  white-space:nowrap;\n  overflow:hidden;\n  text-overflow:ellipsis;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_btn{\n  text-align:center;\n  border-radius:2px;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar{\n  position:relative;\n  display:inline-block;\n  margin-right:7px;\n  background-size:cover;\n  background-position:center center;\n  background-repeat:no-repeat;\n  color:#FFF;\n  text-align:center;\n  text-transform:uppercase;\n  pointer-events:inherit;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar > span{\n  display:inline-block;\n  position:relative;\n  top:15%;\n  font-size:16px;\n  font-weight:400;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar ._zextras_team_web_client_release_loading-LoadingPage-less_online{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar ._zextras_team_web_client_release_loading-LoadingPage-less_offline{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n  background-color:#CA1E00;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar ._zextras_team_web_client_release_loading-LoadingPage-less_mobile{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n  background-color:#0088C1;\n  color:#FFF;\n  font-family:"ZeXtras Icons", sans-serif !important;\n  font-weight:400;\n  line-height:0.8;\n  font-size:13px;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar ._zextras_team_web_client_release_loading-LoadingPage-less_mobile:before{\n  content:"\\30150";\n  font-size:6.2px;\n  position:absolute;\n  top:30%;\n  right:20%;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar{\n  position:relative;\n  display:inline-block;\n  margin-right:7px;\n  background-size:cover;\n  background-position:center center;\n  background-repeat:no-repeat;\n  color:#FFF;\n  text-align:center;\n  text-transform:uppercase;\n  pointer-events:inherit;\n  width:140px;\n  height:140px;\n  padding:28px;\n  margin-right:28px;\n  border-radius:50%;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar > span{\n  display:inline-block;\n  position:relative;\n  top:15%;\n  font-size:16px;\n  font-weight:400;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_online{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_offline{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n  background-color:#CA1E00;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_mobile{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n  background-color:#0088C1;\n  color:#FFF;\n  font-family:"ZeXtras Icons", sans-serif !important;\n  font-weight:400;\n  line-height:0.8;\n  font-size:13px;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_mobile:before{\n  content:"\\30150";\n  font-size:6.2px;\n  position:absolute;\n  top:30%;\n  right:20%;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar span{\n  font-size:36px;\n  top:unset;\n  padding-top:25%!important;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar div{\n  position:relative!important;\n  right:-90% !important;\n  line-height:1.5 !important;\n  top:90%!important;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar div:before{\n  font-size:16px !important;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar span ~ div{\n  top:15%!important;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar{\n  position:relative;\n  display:inline-block;\n  margin-right:7px;\n  background-size:cover;\n  background-position:center center;\n  background-repeat:no-repeat;\n  color:#FFF;\n  text-align:center;\n  text-transform:uppercase;\n  pointer-events:inherit;\n  position:absolute;\n  top:5px;\n  left:28px;\n  margin:2.8px 9.8px 2.8px 2.8px;\n  border-radius:4px;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar > span{\n  display:inline-block;\n  position:relative;\n  top:15%;\n  font-size:16px;\n  font-weight:400;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_online{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_offline{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n  background-color:#CA1E00;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_mobile{\n  width:33%;\n  height:33%;\n  border:1px solid #FFF;\n  border-radius:50%;\n  position:absolute;\n  right:-35%;\n  top:70%;\n  background-color:#8DC43E;\n  background-color:#0088C1;\n  color:#FFF;\n  font-family:"ZeXtras Icons", sans-serif !important;\n  font-weight:400;\n  line-height:0.8;\n  font-size:13px;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar ._zextras_team_web_client_release_loading-LoadingPage-less_mobile:before{\n  content:"\\30150";\n  font-size:6.2px;\n  position:absolute;\n  top:30%;\n  right:20%;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar span{\n  color:#FFF !important;\n  margin:unset !important;\n  position:absolute;\n  right:25%;\n  top:30% !important;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_visibilityContainer{\n  width:100%;\n  text-align:center;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-1{\n  background-color:#EF9A9A;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-2{\n  background-color:#F48FB1;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-3{\n  background-color:#CE93D8;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-4{\n  background-color:#B39DDB;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-5{\n  background-color:#9FA8DA;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-6{\n  background-color:#90CAF9;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-7{\n  background-color:#81D4FA;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-8{\n  background-color:#80DEEA;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-9{\n  background-color:#80CBC4;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-10{\n  background-color:#A5D6A7;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-11{\n  background-color:#C5E1A5;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-12{\n  background-color:#E6EE9C;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-13{\n  background-color:#FFE082;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-14{\n  background-color:#FFCC80;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-15{\n  background-color:#FFAB91;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-16{\n  background-color:#BCAAA4;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-17{\n  background-color:#E57373;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-18{\n  background-color:#F06292;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-19{\n  background-color:#BA68C8;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-20{\n  background-color:#9575CD;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-21{\n  background-color:#7986CB;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-22{\n  background-color:#64B5F6;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-23{\n  background-color:#4FC3F7;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-24{\n  background-color:#4DD0E1;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-25{\n  background-color:#4DB6AC;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-26{\n  background-color:#81C784;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-27{\n  background-color:#AED581;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-28{\n  background-color:#DCE775;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-29{\n  background-color:#FFD54F;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-30{\n  background-color:#FFB74D;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-31{\n  background-color:#FF8A65;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-32{\n  background-color:#A1887F;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-33{\n  background-color:#0097A7;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-34{\n  background-color:#EF5350;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-35{\n  background-color:#EC407A;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-36{\n  background-color:#AB47BC;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-37{\n  background-color:#7E57C2;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-38{\n  background-color:#5C6BC0;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-39{\n  background-color:#42A5F5;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-40{\n  background-color:#29B6F6;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-41{\n  background-color:#26C6DA;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-42{\n  background-color:#26A69A;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-43{\n  background-color:#66BB6A;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-44{\n  background-color:#9CCC65;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-45{\n  background-color:#D4E157;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-46{\n  background-color:#FFCA28;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-47{\n  background-color:#FFA726;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-48{\n  background-color:#FF7043;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-49{\n  background-color:#8D6E63;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-50{\n  background-color:#0288D1;\n}\n._zextras_team_web_client_release_loading-LoadingPage-less_container{\n  width:100%;\n  height:100%;\n  background-color:#F2F2F2;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n      -ms-flex-align:center;\n          align-items:center;\n  -webkit-box-pack:center;\n  -webkit-justify-content:center;\n      -ms-flex-pack:center;\n          justify-content:center;\n}\n', "", {
            version: 3,
            sources: [ "LoadingPage.less" ],
            names: [],
            mappings: "AAsBA;EACE,kBAAmB;EACnB,eAAgB;EAChB,sBAAuB;AACzB;AACA;EACE,iBAAkB;EAClB,iBAAkB;AACpB;AACA;EACE,iBAAkB;EAClB,oBAAqB;EACrB,gBAAiB;EACjB,qBAAsB;EACtB,iCAAkC;EAClC,2BAA4B;EAC5B,UAAW;EACX,iBAAkB;EAClB,wBAAyB;EACzB,sBAAuB;AACzB;AACA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,OAAQ;EACR,cAAe;EACf,eAAgB;AAClB;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;AAC3B;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,wBAAyB;AAC3B;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,wBAAyB;EACzB,UAAW;EACX,kDAAmD;EACnD,eAAgB;EAChB,eAAgB;EAChB,cAAe;AACjB;AACA;EACE,gBAAiB;EACjB,eAA4B;EAC5B,iBAAkB;EAClB,OAAQ;EACR,SAAU;AACZ;AAEA;EACE,iBAAkB;EAClB,oBAAqB;EACrB,gBAAiB;EACjB,qBAAsB;EACtB,iCAAkC;EAClC,2BAA4B;EAC5B,UAAW;EACX,iBAAkB;EAClB,wBAAyB;EACzB,sBAAuB;EACvB,WAAY;EACZ,YAAa;EACb,YAAa;EACb,iBAAkB;EAClB,iBAAkB;AACpB;AACA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,OAAQ;EACR,cAAe;EACf,eAAgB;AAClB;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;AAC3B;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,wBAAyB;AAC3B;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,wBAAyB;EACzB,UAAW;EACX,kDAAmD;EACnD,eAAgB;EAChB,eAAgB;EAChB,cAAe;AACjB;AACA;EACE,gBAAiB;EACjB,eAA4B;EAC5B,iBAAkB;EAClB,OAAQ;EACR,SAAU;AACZ;AACA;EACE,cAAe;EACf,SAAU;EACV,yBAA0B;AAC5B;AACA;EACE,2BAA4B;EAC5B,qBAAsB;EACtB,0BAA2B;EAC3B,iBAAkB;AACpB;AACA;EACE,yBAA0B;AAC5B;AACA;EACE,iBAAkB;AACpB;AACA;EACE,iBAAkB;EAClB,oBAAqB;EACrB,gBAAiB;EACjB,qBAAsB;EACtB,iCAAkC;EAClC,2BAA4B;EAC5B,UAAW;EACX,iBAAkB;EAClB,wBAAyB;EACzB,sBAAuB;EACvB,iBAAkB;EAClB,OAAQ;EACR,SAAU;EACV,8BAA+B;EAC/B,iBAAkB;AACpB;AACA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,OAAQ;EACR,cAAe;EACf,eAAgB;AAClB;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;AAC3B;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,wBAAyB;AAC3B;AACA;EACE,SAAU;EACV,UAAW;EACX,qBAAsB;EACtB,iBAAkB;EAClB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,wBAAyB;EACzB,UAAW;EACX,kDAAmD;EACnD,eAAgB;EAChB,eAAgB;EAChB,cAAe;AACjB;AACA;EACE,gBAAiB;EACjB,eAA4B;EAC5B,iBAAkB;EAClB,OAAQ;EACR,SAAU;AACZ;AACA;EACE,qBAAsB;EACtB,uBAAwB;EACxB,iBAAkB;EAClB,SAAU;EACV,kBAAmB;AACrB;AACA;EACE,UAAW;EACX,iBAAkB;AACpB;AAEA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AAMA;EACE,UAAW;EACX,WAAY;EACZ,wBAAyB;EACzB,mBAAa;EAAb,oBAAa;EAAb,mBAAa;EAAb,YAAa;EACb,wBAAmB;EAAnB,0BAAmB;MAAnB,qBAAmB;UAAnB,kBAAmB;EACnB,uBAAuB;EAAvB,8BAAuB;MAAvB,oBAAuB;UAAvB,sBAAuB;AACzB",
            file: "LoadingPage.less",
            sourcesContent: [ '/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n@import \'../assets/zextras-icon-font.css\';\n/* classes */\n.ellipsis {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.btn {\n  text-align: center;\n  border-radius: 2px;\n}\n.avatar {\n  position: relative;\n  display: inline-block;\n  margin-right: 7px;\n  background-size: cover;\n  background-position: center center;\n  background-repeat: no-repeat;\n  color: #FFF;\n  text-align: center;\n  text-transform: uppercase;\n  pointer-events: inherit;\n}\n.avatar > span {\n  display: inline-block;\n  position: relative;\n  top: 15%;\n  font-size: 16px;\n  font-weight: 400;\n}\n.avatar .online {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n}\n.avatar .offline {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n  background-color: #CA1E00;\n}\n.avatar .mobile {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n  background-color: #0088C1;\n  color: #FFF;\n  font-family: "ZeXtras Icons", sans-serif !important;\n  font-weight: 400;\n  line-height: 0.8;\n  font-size: 13px;\n}\n.avatar .mobile:before {\n  content: "\\30150";\n  font-size: calc(9px - 2.8px);\n  position: absolute;\n  top: 30%;\n  right: 20%;\n}\n/* custom classes */\n.infoAvatar {\n  position: relative;\n  display: inline-block;\n  margin-right: 7px;\n  background-size: cover;\n  background-position: center center;\n  background-repeat: no-repeat;\n  color: #FFF;\n  text-align: center;\n  text-transform: uppercase;\n  pointer-events: inherit;\n  width: 140px;\n  height: 140px;\n  padding: 28px;\n  margin-right: 28px;\n  border-radius: 50%;\n}\n.infoAvatar > span {\n  display: inline-block;\n  position: relative;\n  top: 15%;\n  font-size: 16px;\n  font-weight: 400;\n}\n.infoAvatar .online {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n}\n.infoAvatar .offline {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n  background-color: #CA1E00;\n}\n.infoAvatar .mobile {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n  background-color: #0088C1;\n  color: #FFF;\n  font-family: "ZeXtras Icons", sans-serif !important;\n  font-weight: 400;\n  line-height: 0.8;\n  font-size: 13px;\n}\n.infoAvatar .mobile:before {\n  content: "\\30150";\n  font-size: calc(9px - 2.8px);\n  position: absolute;\n  top: 30%;\n  right: 20%;\n}\n.infoAvatar span {\n  font-size: 36px;\n  top: unset;\n  padding-top: 25%!important;\n}\n.infoAvatar div {\n  position: relative!important;\n  right: -90% !important;\n  line-height: 1.5 !important;\n  top: 90%!important;\n}\n.infoAvatar div:before {\n  font-size: 16px !important;\n}\n.infoAvatar span ~ div {\n  top: 15%!important;\n}\n.spaceAvatar {\n  position: relative;\n  display: inline-block;\n  margin-right: 7px;\n  background-size: cover;\n  background-position: center center;\n  background-repeat: no-repeat;\n  color: #FFF;\n  text-align: center;\n  text-transform: uppercase;\n  pointer-events: inherit;\n  position: absolute;\n  top: 5px;\n  left: 28px;\n  margin: 2.8px 9.8px 2.8px 2.8px;\n  border-radius: 4px;\n}\n.spaceAvatar > span {\n  display: inline-block;\n  position: relative;\n  top: 15%;\n  font-size: 16px;\n  font-weight: 400;\n}\n.spaceAvatar .online {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n}\n.spaceAvatar .offline {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n  background-color: #CA1E00;\n}\n.spaceAvatar .mobile {\n  width: 33%;\n  height: 33%;\n  border: 1px solid #FFF;\n  border-radius: 50%;\n  position: absolute;\n  right: -35%;\n  top: 70%;\n  background-color: #8DC43E;\n  background-color: #0088C1;\n  color: #FFF;\n  font-family: "ZeXtras Icons", sans-serif !important;\n  font-weight: 400;\n  line-height: 0.8;\n  font-size: 13px;\n}\n.spaceAvatar .mobile:before {\n  content: "\\30150";\n  font-size: calc(9px - 2.8px);\n  position: absolute;\n  top: 30%;\n  right: 20%;\n}\n.spaceAvatar span {\n  color: #FFF !important;\n  margin: unset !important;\n  position: absolute;\n  right: 25%;\n  top: 30% !important;\n}\n.visibilityContainer {\n  width: 100%;\n  text-align: center;\n}\n/* palette */\n.avatar-bg-color-1 {\n  background-color: #EF9A9A;\n}\n.avatar-bg-color-2 {\n  background-color: #F48FB1;\n}\n.avatar-bg-color-3 {\n  background-color: #CE93D8;\n}\n.avatar-bg-color-4 {\n  background-color: #B39DDB;\n}\n.avatar-bg-color-5 {\n  background-color: #9FA8DA;\n}\n.avatar-bg-color-6 {\n  background-color: #90CAF9;\n}\n.avatar-bg-color-7 {\n  background-color: #81D4FA;\n}\n.avatar-bg-color-8 {\n  background-color: #80DEEA;\n}\n.avatar-bg-color-9 {\n  background-color: #80CBC4;\n}\n.avatar-bg-color-10 {\n  background-color: #A5D6A7;\n}\n.avatar-bg-color-11 {\n  background-color: #C5E1A5;\n}\n.avatar-bg-color-12 {\n  background-color: #E6EE9C;\n}\n.avatar-bg-color-13 {\n  background-color: #FFE082;\n}\n.avatar-bg-color-14 {\n  background-color: #FFCC80;\n}\n.avatar-bg-color-15 {\n  background-color: #FFAB91;\n}\n.avatar-bg-color-16 {\n  background-color: #BCAAA4;\n}\n.avatar-bg-color-17 {\n  background-color: #E57373;\n}\n.avatar-bg-color-18 {\n  background-color: #F06292;\n}\n.avatar-bg-color-19 {\n  background-color: #BA68C8;\n}\n.avatar-bg-color-20 {\n  background-color: #9575CD;\n}\n.avatar-bg-color-21 {\n  background-color: #7986CB;\n}\n.avatar-bg-color-22 {\n  background-color: #64B5F6;\n}\n.avatar-bg-color-23 {\n  background-color: #4FC3F7;\n}\n.avatar-bg-color-24 {\n  background-color: #4DD0E1;\n}\n.avatar-bg-color-25 {\n  background-color: #4DB6AC;\n}\n.avatar-bg-color-26 {\n  background-color: #81C784;\n}\n.avatar-bg-color-27 {\n  background-color: #AED581;\n}\n.avatar-bg-color-28 {\n  background-color: #DCE775;\n}\n.avatar-bg-color-29 {\n  background-color: #FFD54F;\n}\n.avatar-bg-color-30 {\n  background-color: #FFB74D;\n}\n.avatar-bg-color-31 {\n  background-color: #FF8A65;\n}\n.avatar-bg-color-32 {\n  background-color: #A1887F;\n}\n.avatar-bg-color-33 {\n  background-color: #0097A7;\n}\n.avatar-bg-color-34 {\n  background-color: #EF5350;\n}\n.avatar-bg-color-35 {\n  background-color: #EC407A;\n}\n.avatar-bg-color-36 {\n  background-color: #AB47BC;\n}\n.avatar-bg-color-37 {\n  background-color: #7E57C2;\n}\n.avatar-bg-color-38 {\n  background-color: #5C6BC0;\n}\n.avatar-bg-color-39 {\n  background-color: #42A5F5;\n}\n.avatar-bg-color-40 {\n  background-color: #29B6F6;\n}\n.avatar-bg-color-41 {\n  background-color: #26C6DA;\n}\n.avatar-bg-color-42 {\n  background-color: #26A69A;\n}\n.avatar-bg-color-43 {\n  background-color: #66BB6A;\n}\n.avatar-bg-color-44 {\n  background-color: #9CCC65;\n}\n.avatar-bg-color-45 {\n  background-color: #D4E157;\n}\n.avatar-bg-color-46 {\n  background-color: #FFCA28;\n}\n.avatar-bg-color-47 {\n  background-color: #FFA726;\n}\n.avatar-bg-color-48 {\n  background-color: #FF7043;\n}\n.avatar-bg-color-49 {\n  background-color: #8D6E63;\n}\n.avatar-bg-color-50 {\n  background-color: #0288D1;\n}\n/* sizes */\n/* font */\n/* call sizes */\n/* colors */\n/* toaster variables */\n.container {\n  width: 100%;\n  height: 100%;\n  background-color: #F2F2F2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n' ]
        } ]);
        exports.locals = {
            ellipsis: "_zextras_team_web_client_release_loading-LoadingPage-less_ellipsis",
            btn: "_zextras_team_web_client_release_loading-LoadingPage-less_btn",
            avatar: "_zextras_team_web_client_release_loading-LoadingPage-less_avatar",
            online: "_zextras_team_web_client_release_loading-LoadingPage-less_online",
            offline: "_zextras_team_web_client_release_loading-LoadingPage-less_offline",
            mobile: "_zextras_team_web_client_release_loading-LoadingPage-less_mobile",
            infoAvatar: "_zextras_team_web_client_release_loading-LoadingPage-less_infoAvatar",
            spaceAvatar: "_zextras_team_web_client_release_loading-LoadingPage-less_spaceAvatar",
            visibilityContainer: "_zextras_team_web_client_release_loading-LoadingPage-less_visibilityContainer",
            "avatar-bg-color-1": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-1",
            "avatar-bg-color-2": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-2",
            "avatar-bg-color-3": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-3",
            "avatar-bg-color-4": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-4",
            "avatar-bg-color-5": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-5",
            "avatar-bg-color-6": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-6",
            "avatar-bg-color-7": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-7",
            "avatar-bg-color-8": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-8",
            "avatar-bg-color-9": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-9",
            "avatar-bg-color-10": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-10",
            "avatar-bg-color-11": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-11",
            "avatar-bg-color-12": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-12",
            "avatar-bg-color-13": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-13",
            "avatar-bg-color-14": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-14",
            "avatar-bg-color-15": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-15",
            "avatar-bg-color-16": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-16",
            "avatar-bg-color-17": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-17",
            "avatar-bg-color-18": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-18",
            "avatar-bg-color-19": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-19",
            "avatar-bg-color-20": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-20",
            "avatar-bg-color-21": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-21",
            "avatar-bg-color-22": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-22",
            "avatar-bg-color-23": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-23",
            "avatar-bg-color-24": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-24",
            "avatar-bg-color-25": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-25",
            "avatar-bg-color-26": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-26",
            "avatar-bg-color-27": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-27",
            "avatar-bg-color-28": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-28",
            "avatar-bg-color-29": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-29",
            "avatar-bg-color-30": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-30",
            "avatar-bg-color-31": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-31",
            "avatar-bg-color-32": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-32",
            "avatar-bg-color-33": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-33",
            "avatar-bg-color-34": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-34",
            "avatar-bg-color-35": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-35",
            "avatar-bg-color-36": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-36",
            "avatar-bg-color-37": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-37",
            "avatar-bg-color-38": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-38",
            "avatar-bg-color-39": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-39",
            "avatar-bg-color-40": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-40",
            "avatar-bg-color-41": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-41",
            "avatar-bg-color-42": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-42",
            "avatar-bg-color-43": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-43",
            "avatar-bg-color-44": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-44",
            "avatar-bg-color-45": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-45",
            "avatar-bg-color-46": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-46",
            "avatar-bg-color-47": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-47",
            "avatar-bg-color-48": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-48",
            "avatar-bg-color-49": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-49",
            "avatar-bg-color-50": "_zextras_team_web_client_release_loading-LoadingPage-less_avatar-bg-color-50",
            container: "_zextras_team_web_client_release_loading-LoadingPage-less_container"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./src/components/assets/zextras-icon-font.css": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        var getUrl = __webpack_require__("./node_modules/css-loader/dist/runtime/getUrl.js");
        var ___CSS_LOADER_URL___0___ = getUrl(__webpack_require__("./src/components/assets/ZextrasIconFont.woff"));
        var ___CSS_LOADER_URL___1___ = getUrl(__webpack_require__("./src/components/assets/ZextrasIconFont.ttf"));
        var ___CSS_LOADER_URL___2___ = getUrl(__webpack_require__("./src/components/assets/ZextrasIconFont.svg"));
        exports.push([ module.i, "/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n\n@font-face {\n  font-family: 'ZeXtras Icons';\n  font-style: normal;\n  font-weight: 300;\n  src: url(" + ___CSS_LOADER_URL___0___ + ') format("woff"),\n  url(' + ___CSS_LOADER_URL___1___ + ') format("truetype"),\n  url(' + ___CSS_LOADER_URL___2___ + ') format("svg");\n}\n\n._zextras_team_web_client_release_assets_zi, ._zextras_team_web_client_release_assets_Imgzi {\n  -moz-osx-font-smoothing: grayscale;\n  -webkit-font-smoothing: antialiased;\n  display: inline-block;\n  font-style: normal;\n  font-variant: normal;\n  text-rendering: auto;\n  line-height: 1em;\n  font-family: "ZeXtras Icons", sans-serif !important;\n  font-weight: 300;\n  /*position: absolute;\n    left: 12%;*/\n}\n\n._zextras_team_web_client_release_assets_Imgzi {\n  font-size: 16px;\n}\n\n._zextras_team_web_client_release_assets_zi-Activity:before, ._zextras_team_web_client_release_assets_Activity:before {\n  content: "\\30001";\n}\n\n._zextras_team_web_client_release_assets_zi-Attachment:before, ._zextras_team_web_client_release_assets_Attachment:before {\n  content: "\\30002";\n}\n\n._zextras_team_web_client_release_assets_zi-Circle:before, ._zextras_team_web_client_release_assets_Circle:before {\n  content: "\\30003";\n}\n\n._zextras_team_web_client_release_assets_zi-CameraOnBold:before, ._zextras_team_web_client_release_assets_CameraOnBold:before {\n  content: "\\30004";\n}\n\n._zextras_team_web_client_release_assets_zi-CameraOff:before, ._zextras_team_web_client_release_assets_CameraOff:before {\n  content: "\\30005";\n}\n\n._zextras_team_web_client_release_assets_zi-CameraOn:before, ._zextras_team_web_client_release_assets_CameraOn:before {\n  content: "\\30006";\n}\n\n._zextras_team_web_client_release_assets_zi-SpaceLight:before, ._zextras_team_web_client_release_assets_SpaceLight:before {\n  content: "\\30007";\n}\n\n._zextras_team_web_client_release_assets_zi-Close:before, ._zextras_team_web_client_release_assets_Close:before {\n  content: "\\30008";\n}\n\n._zextras_team_web_client_release_assets_zi-Copy:before, ._zextras_team_web_client_release_assets_Copy:before {\n  content: "\\30009";\n}\n\n._zextras_team_web_client_release_assets_zi-DeleteMessage:before, ._zextras_team_web_client_release_assets_DeleteMessage:before {\n  content: "\\30010";\n}\n\n._zextras_team_web_client_release_assets_zi-DeleteLight:before, ._zextras_team_web_client_release_assets_DeleteLight:before {\n  content: "\\30011";\n}\n\n._zextras_team_web_client_release_assets_zi-FileDocs:before, ._zextras_team_web_client_release_assets_FileDocs:before {\n  content: "\\30012";\n}\n\n._zextras_team_web_client_release_assets_zi-DoubleTick:before, ._zextras_team_web_client_release_assets_DoubleTick:before {\n  content: "\\30013";\n}\n\n._zextras_team_web_client_release_assets_zi-Down:before, ._zextras_team_web_client_release_assets_Down:before {\n  content: "\\30014";\n}\n\n._zextras_team_web_client_release_assets_zi-Download:before, ._zextras_team_web_client_release_assets_Download:before {\n  content: "\\30015";\n}\n\n._zextras_team_web_client_release_assets_zi-FileImage:before, ._zextras_team_web_client_release_assets_FileImage:before {\n  content: "\\30016";\n}\n\n._zextras_team_web_client_release_assets_zi-Drive:before, ._zextras_team_web_client_release_assets_Drive:before {\n  content: "\\30017";\n}\n\n._zextras_team_web_client_release_assets_zi-Edit:before, ._zextras_team_web_client_release_assets_Edit:before {\n  content: "\\30018";\n}\n\n._zextras_team_web_client_release_assets_zi-Smile:before, ._zextras_team_web_client_release_assets_Smile:before {\n  content: "\\30019";\n}\n\n._zextras_team_web_client_release_assets_zi-FolderOpen:before, ._zextras_team_web_client_release_assets_FolderOpen:before {\n  content: "\\30020";\n}\n\n._zextras_team_web_client_release_assets_zi-FolderLight:before, ._zextras_team_web_client_release_assets_FolderLight:before {\n  content: "\\30021";\n}\n\n._zextras_team_web_client_release_assets_zi-Grid:before, ._zextras_team_web_client_release_assets_Grid:before {\n  content: "\\30022";\n}\n\n._zextras_team_web_client_release_assets_zi-History:before, ._zextras_team_web_client_release_assets_History:before {\n  content: "\\30023";\n}\n\n._zextras_team_web_client_release_assets_zi-Home:before, ._zextras_team_web_client_release_assets_Home:before {\n  content: "\\30024";\n}\n\n._zextras_team_web_client_release_assets_zi-Image:before, ._zextras_team_web_client_release_assets_Image:before {\n  content: "\\30025";\n}\n\n._zextras_team_web_client_release_assets_zi-Info:before, ._zextras_team_web_client_release_assets_Info:before {\n  content: "\\30026";\n}\n\n._zextras_team_web_client_release_assets_zi-Last:before, ._zextras_team_web_client_release_assets_Last:before {\n  content: "\\30027";\n}\n\n._zextras_team_web_client_release_assets_zi-Leave:before, ._zextras_team_web_client_release_assets_Leave:before {\n  content: "\\30028";\n}\n\n._zextras_team_web_client_release_assets_zi-Less:before, ._zextras_team_web_client_release_assets_Less:before {\n  content: "\\30029";\n}\n\n._zextras_team_web_client_release_assets_zi-Link:before, ._zextras_team_web_client_release_assets_Link:before {\n  content: "\\30030";\n}\n\n._zextras_team_web_client_release_assets_zi-List:before, ._zextras_team_web_client_release_assets_List:before {\n  content: "\\30031";\n}\n\n._zextras_team_web_client_release_assets_zi-Mail:before, ._zextras_team_web_client_release_assets_Mail:before {\n  content: "\\30032";\n}\n\n._zextras_team_web_client_release_assets_zi-MicrophoneOff:before, ._zextras_team_web_client_release_assets_MicrophoneOff:before {\n  content: "\\30033";\n}\n\n._zextras_team_web_client_release_assets_zi-MicrophoneOn:before, ._zextras_team_web_client_release_assets_MicrophoneOn:before {\n  content: "\\30034";\n}\n\n._zextras_team_web_client_release_assets_zi-Move:before, ._zextras_team_web_client_release_assets_Move:before {\n  content: "\\30035";\n}\n\n._zextras_team_web_client_release_assets_zi-NotificationOff:before, ._zextras_team_web_client_release_assets_NotificationOff:before {\n  content: "\\30036";\n}\n\n._zextras_team_web_client_release_assets_zi-NotificationOn:before, ._zextras_team_web_client_release_assets_NotificationOn:before {\n  content: "\\30037";\n}\n\n._zextras_team_web_client_release_assets_zi-Open:before, ._zextras_team_web_client_release_assets_Open:before {\n  content: "\\30038";\n}\n\n._zextras_team_web_client_release_assets_zi-FilePDF:before, ._zextras_team_web_client_release_assets_FilePDF:before {\n  content: "\\30039";\n}\n\n._zextras_team_web_client_release_assets_zi-PhoneOff:before, ._zextras_team_web_client_release_assets_PhoneOff:before {\n  content: "\\30040";\n}\n\n._zextras_team_web_client_release_assets_zi-PhoneOn:before, ._zextras_team_web_client_release_assets_PhoneOn:before {\n  content: "\\30041";\n}\n\n._zextras_team_web_client_release_assets_zi-Plus:before, ._zextras_team_web_client_release_assets_Plus:before {\n  content: "\\30042";\n}\n\n._zextras_team_web_client_release_assets_zi-FilePresentation:before, ._zextras_team_web_client_release_assets_FilePresentation:before {\n  content: "\\30043";\n}\n\n._zextras_team_web_client_release_assets_zi-Print:before, ._zextras_team_web_client_release_assets_Print:before {\n  content: "\\30044";\n}\n\n._zextras_team_web_client_release_assets_zi-Regenerate:before, ._zextras_team_web_client_release_assets_Regenerate:before {\n  content: "\\30045";\n}\n\n._zextras_team_web_client_release_assets_zi-Search:before, ._zextras_team_web_client_release_assets_Search:before {\n  content: "\\30046";\n}\n\n._zextras_team_web_client_release_assets_zi-SharedByMeBold:before, ._zextras_team_web_client_release_assets_SharedByMeBold:before {\n  content: "\\30047";\n}\n\n._zextras_team_web_client_release_assets_zi-SharedByMeLight:before, ._zextras_team_web_client_release_assets_SharedByMeLight:before {\n  content: "\\30048";\n}\n\n._zextras_team_web_client_release_assets_zi-SharedToMeBold:before, ._zextras_team_web_client_release_assets_SharedToMeBold:before {\n  content: "\\30049";\n}\n\n._zextras_team_web_client_release_assets_zi-StarBold:before, ._zextras_team_web_client_release_assets_StarBold:before {\n  content: "\\30050";\n}\n\n._zextras_team_web_client_release_assets_zi-StarLight:before, ._zextras_team_web_client_release_assets_StarLight:before {\n  content: "\\30051";\n}\n\n._zextras_team_web_client_release_assets_zi-Tick:before, ._zextras_team_web_client_release_assets_Tick:before {\n  content: "\\30052";\n}\n\n._zextras_team_web_client_release_assets_zi-Up:before, ._zextras_team_web_client_release_assets_Up:before {\n  content: "\\30053";\n}\n\n._zextras_team_web_client_release_assets_zi-Upload:before, ._zextras_team_web_client_release_assets_Upload:before {\n  content: "\\30054";\n}\n\n._zextras_team_web_client_release_assets_zi-Visualize:before, ._zextras_team_web_client_release_assets_Visualize:before {\n  content: "\\30055";\n}\n\n._zextras_team_web_client_release_assets_zi-VolumeOff:before, ._zextras_team_web_client_release_assets_VolumeOff:before {\n  content: "\\30056";\n}\n\n._zextras_team_web_client_release_assets_zi-VolumeOn:before, ._zextras_team_web_client_release_assets_VolumeOn:before {\n  content: "\\30057";\n}\n\n._zextras_team_web_client_release_assets_zi-FileCalc:before, ._zextras_team_web_client_release_assets_FileCalc:before {\n  content: "\\30058";\n}\n\n._zextras_team_web_client_release_assets_zi-SharedToMeLight:before, ._zextras_team_web_client_release_assets_SharedToMeLight:before {\n  content: "\\30059";\n}\n\n._zextras_team_web_client_release_assets_zi-DeleteBold:before, ._zextras_team_web_client_release_assets_DeleteBold:before {\n  content: "\\30060";\n}\n\n._zextras_team_web_client_release_assets_zi-SpaceBold:before, ._zextras_team_web_client_release_assets_SpaceBold:before {\n  content: "\\30061";\n}\n\n._zextras_team_web_client_release_assets_zi-Accept:before, ._zextras_team_web_client_release_assets_Accept:before {\n  content: "\\30062";\n}\n\n._zextras_team_web_client_release_assets_zi-ScreensharingOff:before, ._zextras_team_web_client_release_assets_ScreensharingOff:before {\n  content: "\\30063";\n}\n\n._zextras_team_web_client_release_assets_zi-ScreensharingOn:before, ._zextras_team_web_client_release_assets_ScreensharingOn:before {\n  content: "\\30064";\n}\n\n._zextras_team_web_client_release_assets_zi-Dots:before, ._zextras_team_web_client_release_assets_Dots:before {\n  content: "\\30065";\n}\n\n._zextras_team_web_client_release_assets_zi-Key:before, ._zextras_team_web_client_release_assets_Key:before {\n  content: "\\30066";\n}\n\n._zextras_team_web_client_release_assets_zi-LockKeyhole:before, ._zextras_team_web_client_release_assets_LockKeyhole:before {\n  content: "\\30067";\n}\n\n._zextras_team_web_client_release_assets_zi-MobileBold:before, ._zextras_team_web_client_release_assets_MobileBold:before {\n  content: "\\30068";\n}\n\n._zextras_team_web_client_release_assets_zi-MobileLight:before, ._zextras_team_web_client_release_assets_MobileLight:before {\n  content: "\\30069";\n}\n\n._zextras_team_web_client_release_assets_zi-MobileRemove:before, ._zextras_team_web_client_release_assets_MobileRemove:before {\n  content: "\\30070";\n}\n\n._zextras_team_web_client_release_assets_zi-Pause:before, ._zextras_team_web_client_release_assets_Pause:before {\n  content: "\\30071";\n}\n\n._zextras_team_web_client_release_assets_zi-Play:before, ._zextras_team_web_client_release_assets_Play:before {\n  content: "\\30072";\n}\n\n._zextras_team_web_client_release_assets_zi-Server:before, ._zextras_team_web_client_release_assets_Server:before {\n  content: "\\30073";\n}\n\n._zextras_team_web_client_release_assets_zi-UserBold:before, ._zextras_team_web_client_release_assets_UserBold:before {\n  content: "\\30074";\n}\n\n._zextras_team_web_client_release_assets_zi-UserLight:before, ._zextras_team_web_client_release_assets_UserLight:before {\n  content: "\\30075";\n}\n\n._zextras_team_web_client_release_assets_zi-Left:before, ._zextras_team_web_client_release_assets_Left:before {\n  content: "\\30076";\n}\n\n._zextras_team_web_client_release_assets_zi-Right:before, ._zextras_team_web_client_release_assets_Right:before {\n  content: "\\30077";\n}\n\n._zextras_team_web_client_release_assets_zi-SquareBold:before, ._zextras_team_web_client_release_assets_SquareBold:before {\n  content: "\\30078";\n}\n\n._zextras_team_web_client_release_assets_zi-SquareCheck:before, ._zextras_team_web_client_release_assets_SquareCheck:before {\n  content: "\\30079";\n}\n\n._zextras_team_web_client_release_assets_zi-SquareLight:before, ._zextras_team_web_client_release_assets_SquareLight:before {\n  content: "\\30080";\n}\n\n._zextras_team_web_client_release_assets_zi-BookmarkBold:before, ._zextras_team_web_client_release_assets_BookmarkBold:before {\n  content: "\\30081";\n}\n\n._zextras_team_web_client_release_assets_zi-BookmarkLight:before, ._zextras_team_web_client_release_assets_BookmarkLight:before {\n  content: "\\30082";\n}\n\n._zextras_team_web_client_release_assets_zi-Bottom:before, ._zextras_team_web_client_release_assets_Bottom:before {\n  content: "\\30083";\n}\n\n._zextras_team_web_client_release_assets_zi-ReorderDown:before, ._zextras_team_web_client_release_assets_ReorderDown:before {\n  content: "\\30084";\n}\n\n._zextras_team_web_client_release_assets_zi-ReorderUp:before, ._zextras_team_web_client_release_assets_ReorderUp:before {\n  content: "\\30085";\n}\n\n._zextras_team_web_client_release_assets_zi-FileAudio:before, ._zextras_team_web_client_release_assets_FileAudio:before {\n  content: "\\30086";\n}\n\n._zextras_team_web_client_release_assets_zi-FileBlank:before, ._zextras_team_web_client_release_assets_FileBlank:before {\n  content: "\\30087";\n}\n\n._zextras_team_web_client_release_assets_zi-FileVideo:before, ._zextras_team_web_client_release_assets_FileVideo:before {\n  content: "\\30088";\n}\n\n._zextras_team_web_client_release_assets_zi-FileZip:before, ._zextras_team_web_client_release_assets_FileZip:before {\n  content: "\\30089";\n}\n\n._zextras_team_web_client_release_assets_zi-FolderBold:before, ._zextras_team_web_client_release_assets_FolderBold:before {\n  content: "\\30090";\n}\n\n._zextras_team_web_client_release_assets_zi-SendBold:before, ._zextras_team_web_client_release_assets_SendBold:before {\n  content: "\\30091";\n}\n\n._zextras_team_web_client_release_assets_zi-SendLight:before, ._zextras_team_web_client_release_assets_SendLight:before {\n  content: "\\30092";\n}\n\n._zextras_team_web_client_release_assets_zi-SettingsBold:before, ._zextras_team_web_client_release_assets_SettingsBold:before {\n  content: "\\30093";\n}\n\n._zextras_team_web_client_release_assets_zi-SettingsLight:before, ._zextras_team_web_client_release_assets_SettingsLight:before {\n  content: "\\30094";\n}\n\n._zextras_team_web_client_release_assets_zi-FileApp:before, ._zextras_team_web_client_release_assets_FileApp:before {\n  content: "\\30095";\n}\n\n._zextras_team_web_client_release_assets_zi-FileVCard:before, ._zextras_team_web_client_release_assets_FileVCard:before {\n  content: "\\30096";\n}\n\n._zextras_team_web_client_release_assets_zi-FileHTML:before, ._zextras_team_web_client_release_assets_FileHTML:before {\n  content: "\\30097";\n}\n\n._zextras_team_web_client_release_assets_zi-FileMessage:before, ._zextras_team_web_client_release_assets_FileMessage:before {\n  content: "\\30098";\n}\n\n._zextras_team_web_client_release_assets_zi-FileSignature:before, ._zextras_team_web_client_release_assets_FileSignature:before {\n  content: "\\30099";\n}\n\n._zextras_team_web_client_release_assets_zi-Restore:before, ._zextras_team_web_client_release_assets_Restore:before {\n  content: "\\30100";\n}\n\n._zextras_team_web_client_release_assets_zi-AlertLight:before, ._zextras_team_web_client_release_assets_AlertLight:before,\n._zextras_team_web_client_release_assets_zi-Alert:before, ._zextras_team_web_client_release_assets_Alert:before {\n  content: "\\30101";\n}\n\n._zextras_team_web_client_release_assets_zi-CircleBold:before, ._zextras_team_web_client_release_assets_CircleBold:before {\n  content: "\\30102";\n}\n\n._zextras_team_web_client_release_assets_zi-OpenAlt:before, ._zextras_team_web_client_release_assets_OpenAlt:before {\n  content: "\\30103";\n}\n\n._zextras_team_web_client_release_assets_zi-AlertBold:before, ._zextras_team_web_client_release_assets_AlertBold:before {\n  content: "\\30104";\n\n}\n\n._zextras_team_web_client_release_assets_zi-Ban:before, ._zextras_team_web_client_release_assets_Ban:before {\n  content: "\\30105";\n}\n\n._zextras_team_web_client_release_assets_zi-CalendarBold:before, ._zextras_team_web_client_release_assets_CalendarBold:before {\n  content: "\\30106";\n}\n\n._zextras_team_web_client_release_assets_zi-CalendarLight:before, ._zextras_team_web_client_release_assets_CalendarLight:before {\n  content: "\\30107";\n}\n\n._zextras_team_web_client_release_assets_zi-CameraOffBold:before, ._zextras_team_web_client_release_assets_CameraOffBold:before {\n  content: "\\30108";\n}\n\n._zextras_team_web_client_release_assets_zi-CameraPlusLight:before, ._zextras_team_web_client_release_assets_CameraPlusLight:before {\n  content: "\\30109";\n}\n\n._zextras_team_web_client_release_assets_zi-ChannelLight:before, ._zextras_team_web_client_release_assets_ChannelLight:before {\n  content: "\\30110";\n}\n\n._zextras_team_web_client_release_assets_zi-ChatBold:before, ._zextras_team_web_client_release_assets_ChatBold:before {\n  content: "\\30111";\n}\n\n._zextras_team_web_client_release_assets_zi-ChatLight:before, ._zextras_team_web_client_release_assets_ChatLight:before {\n  content: "\\30112";\n}\n\n._zextras_team_web_client_release_assets_zi-CrownBold:before, ._zextras_team_web_client_release_assets_CrownBold:before {\n  content: "\\30113";\n}\n\n._zextras_team_web_client_release_assets_zi-CrownLight:before, ._zextras_team_web_client_release_assets_CrownLight:before {\n  content: "\\30114";\n}\n\n._zextras_team_web_client_release_assets_zi-Files:before, ._zextras_team_web_client_release_assets_Files:before {\n  content: "\\30115";\n}\n\n._zextras_team_web_client_release_assets_zi-Folders:before, ._zextras_team_web_client_release_assets_Folders:before {\n  content: "\\30116";\n}\n\n._zextras_team_web_client_release_assets_zi-Items:before, ._zextras_team_web_client_release_assets_Items:before {\n  content: "\\30117";\n}\n\n._zextras_team_web_client_release_assets_zi-NewChatBold:before, ._zextras_team_web_client_release_assets_NewChatBold:before {\n  content: "\\30118";\n}\n\n._zextras_team_web_client_release_assets_zi-NewChatLight:before, ._zextras_team_web_client_release_assets_NewChatLight:before {\n  content: "\\30119";\n}\n\n._zextras_team_web_client_release_assets_zi-NewFolderLight:before, ._zextras_team_web_client_release_assets_NewFolderLight:before {\n  content: "\\30120";\n}\n\n._zextras_team_web_client_release_assets_zi-NewSpaceBold:before, ._zextras_team_web_client_release_assets_NewSpaceBold:before {\n  content: "\\30121";\n}\n\n._zextras_team_web_client_release_assets_zi-NewSpaceLight:before, ._zextras_team_web_client_release_assets_NewSpaceLight:before {\n  content: "\\30122";\n}\n\n._zextras_team_web_client_release_assets_zi-ForwardBold:before, ._zextras_team_web_client_release_assets_ForwardBold:before {\n  content: "\\30123";\n}\n\n._zextras_team_web_client_release_assets_zi-ForwardLight:before, ._zextras_team_web_client_release_assets_ForwardLight:before {\n  content: "\\30124";\n}\n\n._zextras_team_web_client_release_assets_zi-ArchiveLight:before, ._zextras_team_web_client_release_assets_ArchiveLight:before {\n  content: "\\30125";\n}\n\n._zextras_team_web_client_release_assets_zi-ContactBold:before, ._zextras_team_web_client_release_assets_ContactBold:before {\n  content: "\\30126";\n}\n\n._zextras_team_web_client_release_assets_zi-ContactLight:before, ._zextras_team_web_client_release_assets_ContactLight:before {\n  content: "\\30127";\n}\n\n._zextras_team_web_client_release_assets_zi-ContactListLight:before, ._zextras_team_web_client_release_assets_ContactListLight:before {\n  content: "\\30128";\n}\n\n._zextras_team_web_client_release_assets_zi-InboxLight:before, ._zextras_team_web_client_release_assets_InboxLight:before {\n  content: "\\30129";\n}\n\n._zextras_team_web_client_release_assets_zi-MailedContactLight:before, ._zextras_team_web_client_release_assets_MailedContactLight:before {\n  content: "\\30130";\n}\n\n._zextras_team_web_client_release_assets_zi-MinusAlt:before, ._zextras_team_web_client_release_assets_MinusAlt:before {\n  content: "\\30131";\n}\n\n._zextras_team_web_client_release_assets_zi-PhotoLight:before, ._zextras_team_web_client_release_assets_PhotoLight:before {\n  content: "\\30132";\n}\n\n._zextras_team_web_client_release_assets_zi-PlusAlt:before, ._zextras_team_web_client_release_assets_PlusAlt:before {\n  content: "\\30133";\n}\n\n._zextras_team_web_client_release_assets_zi-Repeat:before, ._zextras_team_web_client_release_assets_Repeat:before {\n  content: "\\30134";\n}\n\n._zextras_team_web_client_release_assets_zi-ReplyAllBold:before, ._zextras_team_web_client_release_assets_ReplyAllBold:before {\n  content: "\\30135";\n}\n\n._zextras_team_web_client_release_assets_zi-ReplyAllLight:before, ._zextras_team_web_client_release_assets_ReplyAllLight:before {\n  content: "\\30136";\n}\n\n._zextras_team_web_client_release_assets_zi-ReplyBold:before, ._zextras_team_web_client_release_assets_ReplyBold:before {\n  content: "\\30137";\n}\n\n._zextras_team_web_client_release_assets_zi-ReplyLight:before, ._zextras_team_web_client_release_assets_ReplyLight:before {\n  content: "\\30138";\n}\n\n._zextras_team_web_client_release_assets_zi-X:before, ._zextras_team_web_client_release_assets_X:before {\n  content: "\\30139";\n}\n\n._zextras_team_web_client_release_assets_zi-ViewOff:before, ._zextras_team_web_client_release_assets_ViewOff:before {\n  content: "\\30140";\n}\n\n._zextras_team_web_client_release_assets_zi-HomeBold:before, ._zextras_team_web_client_release_assets_HomeBold:before {\n  content: "\\30141";\n}\n\n._zextras_team_web_client_release_assets_zi-RightDouble:before, ._zextras_team_web_client_release_assets_RightDouble:before {\n  content: "\\30142";\n}\n\n._zextras_team_web_client_release_assets_zi-LeftDouble:before, ._zextras_team_web_client_release_assets_LeftDouble:before {\n  content: "\\30143";\n}\n\n._zextras_team_web_client_release_assets_zi-ZextrasTalk:before, ._zextras_team_web_client_release_assets_ZextrasTalk:before {\n  content: "\\30144";\n}\n\n._zextras_team_web_client_release_assets_zi-ZextrasDrive:before, ._zextras_team_web_client_release_assets_ZextrasDrive:before {\n  content: "\\30145";\n}\n\n._zextras_team_web_client_release_assets_zi-MailBold:before, ._zextras_team_web_client_release_assets_MailBold:before {\n  content: "\\30146";\n}\n\n._zextras_team_web_client_release_assets_zi-CloseLarge:before, ._zextras_team_web_client_release_assets_CloseLarge:before {\n  content: "\\30147";\n}\n\n._zextras_team_web_client_release_assets_zi-DotsVertical:before, ._zextras_team_web_client_release_assets_DotsVertical:before {\n  content: "\\30148";\n}\n\n._zextras_team_web_client_release_assets_zi-InfoBold:before, ._zextras_team_web_client_release_assets_InfoBold:before {\n  content: "\\30149";\n}\n\n._zextras_team_web_client_release_assets_zi-MobileOnlineBold:before, ._zextras_team_web_client_release_assets_MobileOnlineBold:before {\n  content: "\\30150";\n}\n\n._zextras_team_web_client_release_assets_zi-MobileOnlineLight:before, ._zextras_team_web_client_release_assets_MobileOnlineLight:before {\n  content: "\\30151";\n}\n\n._zextras_team_web_client_release_assets_zi-OfflineBold:before, ._zextras_team_web_client_release_assets_OfflineBold:before {\n  content: "\\30152";\n}\n\n._zextras_team_web_client_release_assets_zi-OfflineLight:before, ._zextras_team_web_client_release_assets_OfflineLight:before {\n  content: "\\30153";\n}\n\n._zextras_team_web_client_release_assets_zi-OnlineBold:before, ._zextras_team_web_client_release_assets_OnlineBold:before {\n  content: "\\30154";\n}\n\n._zextras_team_web_client_release_assets_zi-OnlineLight:before, ._zextras_team_web_client_release_assets_OnlineLight:before {\n  content: "\\30155";\n}\n\n._zextras_team_web_client_release_assets_zi-CircleCheckLight:before, ._zextras_team_web_client_release_assets_CircleCheckLight:before {\n  content: "\\30156";\n}\n\n._zextras_team_web_client_release_assets_zi-ZimbraConnect:before, ._zextras_team_web_client_release_assets_ZimbraConnect:before {\n  content: "\\30157";\n}\n\n._zextras_team_web_client_release_assets_zi-SpaceChannelBold:before, ._zextras_team_web_client_release_assets_SpaceChannelBold:before {\n  content: "\\30158";\n}\n\n._zextras_team_web_client_release_assets_zi-SpaceChannelLight:before, ._zextras_team_web_client_release_assets_SpaceChannelLight:before {\n  content: "\\30159";\n}\n\n._zextras_team_web_client_release_assets_zi-ZextrasDocs:before, ._zextras_team_web_client_release_assets_ZextrasDocs:before {\n  content: "\\30160";\n}\n\n._zextras_team_web_client_release_assets_zi-ZimbraDrive:before, ._zextras_team_web_client_release_assets_ZimbraDrive:before {\n  content: "\\30161";\n}\n\n._zextras_team_web_client_release_assets_zi-SmileBold:before, ._zextras_team_web_client_release_assets_SmileBold:before {\n  content: "\\30162";\n}\n\n._zextras_team_web_client_release_assets_zi-SadBold:before, ._zextras_team_web_client_release_assets_SadBold:before {\n  content: "\\30163";\n}\n\n._zextras_team_web_client_release_assets_zi-SadLight:before, ._zextras_team_web_client_release_assets_SadLight:before {\n  content: "\\30164";\n}\n\n._zextras_team_web_client_release_assets_zi-DeadBold:before, ._zextras_team_web_client_release_assets_DeadBold:before {\n  content: "\\30165";\n}\n\n._zextras_team_web_client_release_assets_zi-DeadLight:before, ._zextras_team_web_client_release_assets_DeadLight:before {\n  content: "\\30166";\n}\n\n._zextras_team_web_client_release_assets_zi-AddContactBold:before, ._zextras_team_web_client_release_assets_AddContactBold:before {\n  content: "\\30167";\n}\n\n._zextras_team_web_client_release_assets_zi-AddContactLight:before, ._zextras_team_web_client_release_assets_AddContactLight:before {\n  content: "\\30168";\n}\n\n._zextras_team_web_client_release_assets_zi-FileOffLight:before, ._zextras_team_web_client_release_assets_FileOffLight:before {\n  content: "\\30169";\n}\n\n._zextras_team_web_client_release_assets_zi-FileDocsOffLight:before, ._zextras_team_web_client_release_assets_FileDocsOffLight:before {\n  content: "\\30170";\n}\n\n._zextras_team_web_client_release_assets_zi-FileImageOffLight:before, ._zextras_team_web_client_release_assets_FileImageOffLight:before {\n  content: "\\30171";\n}\n\n._zextras_team_web_client_release_assets_zi-FileCalcOffLight:before, ._zextras_team_web_client_release_assets_FileCalcOffLight:before {\n  content: "\\30172";\n}\n\n._zextras_team_web_client_release_assets_zi-FileZipOffLight:before, ._zextras_team_web_client_release_assets_FileZipOffLight:before {\n  content: "\\30173";\n}\n\n._zextras_team_web_client_release_assets_zi-FileVideoOffLight:before, ._zextras_team_web_client_release_assets_FileVideoOffLight:before {\n  content: "\\30174";\n}\n\n._zextras_team_web_client_release_assets_zi-FilePDFOffLight:before, ._zextras_team_web_client_release_assets_FilePDFOffLight:before {\n  content: "\\30175";\n}\n\n._zextras_team_web_client_release_assets_zi-FilePresentationOffLight:before, ._zextras_team_web_client_release_assets_FilePresentationOffLight:before {\n  content: "\\30176";\n}\n\n._zextras_team_web_client_release_assets_zi-FileHTMLOffLight:before, ._zextras_team_web_client_release_assets_FileHTMLOffLight:before {\n  content: "\\30177";\n}\n\n._zextras_team_web_client_release_assets_zi-FileVCardOffLight:before, ._zextras_team_web_client_release_assets_FileVCardOffLight:before {\n  content: "\\30178";\n}\n\n._zextras_team_web_client_release_assets_zi-FileMessageOffLight:before, ._zextras_team_web_client_release_assets_FileMessageOffLight:before {\n  content: "\\30179";\n}\n\n._zextras_team_web_client_release_assets_zi-FileAppOffLight:before, ._zextras_team_web_client_release_assets_FileAppOffLight:before {\n  content: "\\30180";\n}\n\n._zextras_team_web_client_release_assets_zi-Media:before, ._zextras_team_web_client_release_assets_Media:before {\n  content: "\\30181";\n}\n\n._zextras_team_web_client_release_assets_zi-UploadBold:before, ._zextras_team_web_client_release_assets_UploadBold:before {\n  content: "\\30182";\n}\n\n._zextras_team_web_client_release_assets_zi-UploadLight:before, ._zextras_team_web_client_release_assets_UploadLight:before {\n  content: "\\30183";\n}\n\n._zextras_team_web_client_release_assets_zi-UploadSquareBold:before, ._zextras_team_web_client_release_assets_UploadSquareBold:before {\n  content: "\\30184";\n}\n\n._zextras_team_web_client_release_assets_zi-UploadSquareLight:before, ._zextras_team_web_client_release_assets_UploadSquareLight:before {\n  content: "\\30185";\n}\n\n._zextras_team_web_client_release_assets_zi-MoonBold:before, ._zextras_team_web_client_release_assets_MoonBold:before {\n  content: "\\30186";\n}\n\n._zextras_team_web_client_release_assets_zi-MoonLight:before, ._zextras_team_web_client_release_assets_MoonLight:before {\n  content: "\\30187";\n}\n\n._zextras_team_web_client_release_assets_zi-SunBold:before, ._zextras_team_web_client_release_assets_SunBold:before {\n  content: "\\30188";\n}\n\n._zextras_team_web_client_release_assets_zi-SunLight:before, ._zextras_team_web_client_release_assets_SunLight:before {\n  content: "\\30189";\n}\n\n._zextras_team_web_client_release_assets_zi-DownDoubleLight:before, ._zextras_team_web_client_release_assets_DownDoubleLight:before {\n  content: "\\30190";\n}\n\n', "", {
            version: 3,
            sources: [ "zextras-icon-font.css" ],
            names: [],
            mappings: "AAAA;;;;;;;;;EASE;;AAEF;EACE,4BAA4B;EAC5B,kBAAkB;EAClB,gBAAgB;EAChB;;6CAE0C;AAC5C;;AAEA;EACE,kCAAkC;EAClC,mCAAmC;EACnC,qBAAqB;EACrB,kBAAkB;EAClB,oBAAoB;EACpB,oBAAoB;EACpB,gBAAgB;EAChB,mDAAmD;EACnD,gBAAgB;EAChB;eACa;AACf;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;;EAEE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;;AAEnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,iBAAiB;AACnB",
            file: "zextras-icon-font.css",
            sourcesContent: [ '/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n\n@font-face {\n  font-family: \'ZeXtras Icons\';\n  font-style: normal;\n  font-weight: 300;\n  src: url("./ZextrasIconFont.woff") format("woff"),\n  url("./ZextrasIconFont.ttf") format("truetype"),\n  url("./ZextrasIconFont.svg") format("svg");\n}\n\n.zi, .Imgzi {\n  -moz-osx-font-smoothing: grayscale;\n  -webkit-font-smoothing: antialiased;\n  display: inline-block;\n  font-style: normal;\n  font-variant: normal;\n  text-rendering: auto;\n  line-height: 1em;\n  font-family: "ZeXtras Icons", sans-serif !important;\n  font-weight: 300;\n  /*position: absolute;\n    left: 12%;*/\n}\n\n.Imgzi {\n  font-size: 16px;\n}\n\n.zi-Activity:before, .Activity:before {\n  content: "\\30001";\n}\n\n.zi-Attachment:before, .Attachment:before {\n  content: "\\30002";\n}\n\n.zi-Circle:before, .Circle:before {\n  content: "\\30003";\n}\n\n.zi-CameraOnBold:before, .CameraOnBold:before {\n  content: "\\30004";\n}\n\n.zi-CameraOff:before, .CameraOff:before {\n  content: "\\30005";\n}\n\n.zi-CameraOn:before, .CameraOn:before {\n  content: "\\30006";\n}\n\n.zi-SpaceLight:before, .SpaceLight:before {\n  content: "\\30007";\n}\n\n.zi-Close:before, .Close:before {\n  content: "\\30008";\n}\n\n.zi-Copy:before, .Copy:before {\n  content: "\\30009";\n}\n\n.zi-DeleteMessage:before, .DeleteMessage:before {\n  content: "\\30010";\n}\n\n.zi-DeleteLight:before, .DeleteLight:before {\n  content: "\\30011";\n}\n\n.zi-FileDocs:before, .FileDocs:before {\n  content: "\\30012";\n}\n\n.zi-DoubleTick:before, .DoubleTick:before {\n  content: "\\30013";\n}\n\n.zi-Down:before, .Down:before {\n  content: "\\30014";\n}\n\n.zi-Download:before, .Download:before {\n  content: "\\30015";\n}\n\n.zi-FileImage:before, .FileImage:before {\n  content: "\\30016";\n}\n\n.zi-Drive:before, .Drive:before {\n  content: "\\30017";\n}\n\n.zi-Edit:before, .Edit:before {\n  content: "\\30018";\n}\n\n.zi-Smile:before, .Smile:before {\n  content: "\\30019";\n}\n\n.zi-FolderOpen:before, .FolderOpen:before {\n  content: "\\30020";\n}\n\n.zi-FolderLight:before, .FolderLight:before {\n  content: "\\30021";\n}\n\n.zi-Grid:before, .Grid:before {\n  content: "\\30022";\n}\n\n.zi-History:before, .History:before {\n  content: "\\30023";\n}\n\n.zi-Home:before, .Home:before {\n  content: "\\30024";\n}\n\n.zi-Image:before, .Image:before {\n  content: "\\30025";\n}\n\n.zi-Info:before, .Info:before {\n  content: "\\30026";\n}\n\n.zi-Last:before, .Last:before {\n  content: "\\30027";\n}\n\n.zi-Leave:before, .Leave:before {\n  content: "\\30028";\n}\n\n.zi-Less:before, .Less:before {\n  content: "\\30029";\n}\n\n.zi-Link:before, .Link:before {\n  content: "\\30030";\n}\n\n.zi-List:before, .List:before {\n  content: "\\30031";\n}\n\n.zi-Mail:before, .Mail:before {\n  content: "\\30032";\n}\n\n.zi-MicrophoneOff:before, .MicrophoneOff:before {\n  content: "\\30033";\n}\n\n.zi-MicrophoneOn:before, .MicrophoneOn:before {\n  content: "\\30034";\n}\n\n.zi-Move:before, .Move:before {\n  content: "\\30035";\n}\n\n.zi-NotificationOff:before, .NotificationOff:before {\n  content: "\\30036";\n}\n\n.zi-NotificationOn:before, .NotificationOn:before {\n  content: "\\30037";\n}\n\n.zi-Open:before, .Open:before {\n  content: "\\30038";\n}\n\n.zi-FilePDF:before, .FilePDF:before {\n  content: "\\30039";\n}\n\n.zi-PhoneOff:before, .PhoneOff:before {\n  content: "\\30040";\n}\n\n.zi-PhoneOn:before, .PhoneOn:before {\n  content: "\\30041";\n}\n\n.zi-Plus:before, .Plus:before {\n  content: "\\30042";\n}\n\n.zi-FilePresentation:before, .FilePresentation:before {\n  content: "\\30043";\n}\n\n.zi-Print:before, .Print:before {\n  content: "\\30044";\n}\n\n.zi-Regenerate:before, .Regenerate:before {\n  content: "\\30045";\n}\n\n.zi-Search:before, .Search:before {\n  content: "\\30046";\n}\n\n.zi-SharedByMeBold:before, .SharedByMeBold:before {\n  content: "\\30047";\n}\n\n.zi-SharedByMeLight:before, .SharedByMeLight:before {\n  content: "\\30048";\n}\n\n.zi-SharedToMeBold:before, .SharedToMeBold:before {\n  content: "\\30049";\n}\n\n.zi-StarBold:before, .StarBold:before {\n  content: "\\30050";\n}\n\n.zi-StarLight:before, .StarLight:before {\n  content: "\\30051";\n}\n\n.zi-Tick:before, .Tick:before {\n  content: "\\30052";\n}\n\n.zi-Up:before, .Up:before {\n  content: "\\30053";\n}\n\n.zi-Upload:before, .Upload:before {\n  content: "\\30054";\n}\n\n.zi-Visualize:before, .Visualize:before {\n  content: "\\30055";\n}\n\n.zi-VolumeOff:before, .VolumeOff:before {\n  content: "\\30056";\n}\n\n.zi-VolumeOn:before, .VolumeOn:before {\n  content: "\\30057";\n}\n\n.zi-FileCalc:before, .FileCalc:before {\n  content: "\\30058";\n}\n\n.zi-SharedToMeLight:before, .SharedToMeLight:before {\n  content: "\\30059";\n}\n\n.zi-DeleteBold:before, .DeleteBold:before {\n  content: "\\30060";\n}\n\n.zi-SpaceBold:before, .SpaceBold:before {\n  content: "\\30061";\n}\n\n.zi-Accept:before, .Accept:before {\n  content: "\\30062";\n}\n\n.zi-ScreensharingOff:before, .ScreensharingOff:before {\n  content: "\\30063";\n}\n\n.zi-ScreensharingOn:before, .ScreensharingOn:before {\n  content: "\\30064";\n}\n\n.zi-Dots:before, .Dots:before {\n  content: "\\30065";\n}\n\n.zi-Key:before, .Key:before {\n  content: "\\30066";\n}\n\n.zi-LockKeyhole:before, .LockKeyhole:before {\n  content: "\\30067";\n}\n\n.zi-MobileBold:before, .MobileBold:before {\n  content: "\\30068";\n}\n\n.zi-MobileLight:before, .MobileLight:before {\n  content: "\\30069";\n}\n\n.zi-MobileRemove:before, .MobileRemove:before {\n  content: "\\30070";\n}\n\n.zi-Pause:before, .Pause:before {\n  content: "\\30071";\n}\n\n.zi-Play:before, .Play:before {\n  content: "\\30072";\n}\n\n.zi-Server:before, .Server:before {\n  content: "\\30073";\n}\n\n.zi-UserBold:before, .UserBold:before {\n  content: "\\30074";\n}\n\n.zi-UserLight:before, .UserLight:before {\n  content: "\\30075";\n}\n\n.zi-Left:before, .Left:before {\n  content: "\\30076";\n}\n\n.zi-Right:before, .Right:before {\n  content: "\\30077";\n}\n\n.zi-SquareBold:before, .SquareBold:before {\n  content: "\\30078";\n}\n\n.zi-SquareCheck:before, .SquareCheck:before {\n  content: "\\30079";\n}\n\n.zi-SquareLight:before, .SquareLight:before {\n  content: "\\30080";\n}\n\n.zi-BookmarkBold:before, .BookmarkBold:before {\n  content: "\\30081";\n}\n\n.zi-BookmarkLight:before, .BookmarkLight:before {\n  content: "\\30082";\n}\n\n.zi-Bottom:before, .Bottom:before {\n  content: "\\30083";\n}\n\n.zi-ReorderDown:before, .ReorderDown:before {\n  content: "\\30084";\n}\n\n.zi-ReorderUp:before, .ReorderUp:before {\n  content: "\\30085";\n}\n\n.zi-FileAudio:before, .FileAudio:before {\n  content: "\\30086";\n}\n\n.zi-FileBlank:before, .FileBlank:before {\n  content: "\\30087";\n}\n\n.zi-FileVideo:before, .FileVideo:before {\n  content: "\\30088";\n}\n\n.zi-FileZip:before, .FileZip:before {\n  content: "\\30089";\n}\n\n.zi-FolderBold:before, .FolderBold:before {\n  content: "\\30090";\n}\n\n.zi-SendBold:before, .SendBold:before {\n  content: "\\30091";\n}\n\n.zi-SendLight:before, .SendLight:before {\n  content: "\\30092";\n}\n\n.zi-SettingsBold:before, .SettingsBold:before {\n  content: "\\30093";\n}\n\n.zi-SettingsLight:before, .SettingsLight:before {\n  content: "\\30094";\n}\n\n.zi-FileApp:before, .FileApp:before {\n  content: "\\30095";\n}\n\n.zi-FileVCard:before, .FileVCard:before {\n  content: "\\30096";\n}\n\n.zi-FileHTML:before, .FileHTML:before {\n  content: "\\30097";\n}\n\n.zi-FileMessage:before, .FileMessage:before {\n  content: "\\30098";\n}\n\n.zi-FileSignature:before, .FileSignature:before {\n  content: "\\30099";\n}\n\n.zi-Restore:before, .Restore:before {\n  content: "\\30100";\n}\n\n.zi-AlertLight:before, .AlertLight:before,\n.zi-Alert:before, .Alert:before {\n  content: "\\30101";\n}\n\n.zi-CircleBold:before, .CircleBold:before {\n  content: "\\30102";\n}\n\n.zi-OpenAlt:before, .OpenAlt:before {\n  content: "\\30103";\n}\n\n.zi-AlertBold:before, .AlertBold:before {\n  content: "\\30104";\n\n}\n\n.zi-Ban:before, .Ban:before {\n  content: "\\30105";\n}\n\n.zi-CalendarBold:before, .CalendarBold:before {\n  content: "\\30106";\n}\n\n.zi-CalendarLight:before, .CalendarLight:before {\n  content: "\\30107";\n}\n\n.zi-CameraOffBold:before, .CameraOffBold:before {\n  content: "\\30108";\n}\n\n.zi-CameraPlusLight:before, .CameraPlusLight:before {\n  content: "\\30109";\n}\n\n.zi-ChannelLight:before, .ChannelLight:before {\n  content: "\\30110";\n}\n\n.zi-ChatBold:before, .ChatBold:before {\n  content: "\\30111";\n}\n\n.zi-ChatLight:before, .ChatLight:before {\n  content: "\\30112";\n}\n\n.zi-CrownBold:before, .CrownBold:before {\n  content: "\\30113";\n}\n\n.zi-CrownLight:before, .CrownLight:before {\n  content: "\\30114";\n}\n\n.zi-Files:before, .Files:before {\n  content: "\\30115";\n}\n\n.zi-Folders:before, .Folders:before {\n  content: "\\30116";\n}\n\n.zi-Items:before, .Items:before {\n  content: "\\30117";\n}\n\n.zi-NewChatBold:before, .NewChatBold:before {\n  content: "\\30118";\n}\n\n.zi-NewChatLight:before, .NewChatLight:before {\n  content: "\\30119";\n}\n\n.zi-NewFolderLight:before, .NewFolderLight:before {\n  content: "\\30120";\n}\n\n.zi-NewSpaceBold:before, .NewSpaceBold:before {\n  content: "\\30121";\n}\n\n.zi-NewSpaceLight:before, .NewSpaceLight:before {\n  content: "\\30122";\n}\n\n.zi-ForwardBold:before, .ForwardBold:before {\n  content: "\\30123";\n}\n\n.zi-ForwardLight:before, .ForwardLight:before {\n  content: "\\30124";\n}\n\n.zi-ArchiveLight:before, .ArchiveLight:before {\n  content: "\\30125";\n}\n\n.zi-ContactBold:before, .ContactBold:before {\n  content: "\\30126";\n}\n\n.zi-ContactLight:before, .ContactLight:before {\n  content: "\\30127";\n}\n\n.zi-ContactListLight:before, .ContactListLight:before {\n  content: "\\30128";\n}\n\n.zi-InboxLight:before, .InboxLight:before {\n  content: "\\30129";\n}\n\n.zi-MailedContactLight:before, .MailedContactLight:before {\n  content: "\\30130";\n}\n\n.zi-MinusAlt:before, .MinusAlt:before {\n  content: "\\30131";\n}\n\n.zi-PhotoLight:before, .PhotoLight:before {\n  content: "\\30132";\n}\n\n.zi-PlusAlt:before, .PlusAlt:before {\n  content: "\\30133";\n}\n\n.zi-Repeat:before, .Repeat:before {\n  content: "\\30134";\n}\n\n.zi-ReplyAllBold:before, .ReplyAllBold:before {\n  content: "\\30135";\n}\n\n.zi-ReplyAllLight:before, .ReplyAllLight:before {\n  content: "\\30136";\n}\n\n.zi-ReplyBold:before, .ReplyBold:before {\n  content: "\\30137";\n}\n\n.zi-ReplyLight:before, .ReplyLight:before {\n  content: "\\30138";\n}\n\n.zi-X:before, .X:before {\n  content: "\\30139";\n}\n\n.zi-ViewOff:before, .ViewOff:before {\n  content: "\\30140";\n}\n\n.zi-HomeBold:before, .HomeBold:before {\n  content: "\\30141";\n}\n\n.zi-RightDouble:before, .RightDouble:before {\n  content: "\\30142";\n}\n\n.zi-LeftDouble:before, .LeftDouble:before {\n  content: "\\30143";\n}\n\n.zi-ZextrasTalk:before, .ZextrasTalk:before {\n  content: "\\30144";\n}\n\n.zi-ZextrasDrive:before, .ZextrasDrive:before {\n  content: "\\30145";\n}\n\n.zi-MailBold:before, .MailBold:before {\n  content: "\\30146";\n}\n\n.zi-CloseLarge:before, .CloseLarge:before {\n  content: "\\30147";\n}\n\n.zi-DotsVertical:before, .DotsVertical:before {\n  content: "\\30148";\n}\n\n.zi-InfoBold:before, .InfoBold:before {\n  content: "\\30149";\n}\n\n.zi-MobileOnlineBold:before, .MobileOnlineBold:before {\n  content: "\\30150";\n}\n\n.zi-MobileOnlineLight:before, .MobileOnlineLight:before {\n  content: "\\30151";\n}\n\n.zi-OfflineBold:before, .OfflineBold:before {\n  content: "\\30152";\n}\n\n.zi-OfflineLight:before, .OfflineLight:before {\n  content: "\\30153";\n}\n\n.zi-OnlineBold:before, .OnlineBold:before {\n  content: "\\30154";\n}\n\n.zi-OnlineLight:before, .OnlineLight:before {\n  content: "\\30155";\n}\n\n.zi-CircleCheckLight:before, .CircleCheckLight:before {\n  content: "\\30156";\n}\n\n.zi-ZimbraConnect:before, .ZimbraConnect:before {\n  content: "\\30157";\n}\n\n.zi-SpaceChannelBold:before, .SpaceChannelBold:before {\n  content: "\\30158";\n}\n\n.zi-SpaceChannelLight:before, .SpaceChannelLight:before {\n  content: "\\30159";\n}\n\n.zi-ZextrasDocs:before, .ZextrasDocs:before {\n  content: "\\30160";\n}\n\n.zi-ZimbraDrive:before, .ZimbraDrive:before {\n  content: "\\30161";\n}\n\n.zi-SmileBold:before, .SmileBold:before {\n  content: "\\30162";\n}\n\n.zi-SadBold:before, .SadBold:before {\n  content: "\\30163";\n}\n\n.zi-SadLight:before, .SadLight:before {\n  content: "\\30164";\n}\n\n.zi-DeadBold:before, .DeadBold:before {\n  content: "\\30165";\n}\n\n.zi-DeadLight:before, .DeadLight:before {\n  content: "\\30166";\n}\n\n.zi-AddContactBold:before, .AddContactBold:before {\n  content: "\\30167";\n}\n\n.zi-AddContactLight:before, .AddContactLight:before {\n  content: "\\30168";\n}\n\n.zi-FileOffLight:before, .FileOffLight:before {\n  content: "\\30169";\n}\n\n.zi-FileDocsOffLight:before, .FileDocsOffLight:before {\n  content: "\\30170";\n}\n\n.zi-FileImageOffLight:before, .FileImageOffLight:before {\n  content: "\\30171";\n}\n\n.zi-FileCalcOffLight:before, .FileCalcOffLight:before {\n  content: "\\30172";\n}\n\n.zi-FileZipOffLight:before, .FileZipOffLight:before {\n  content: "\\30173";\n}\n\n.zi-FileVideoOffLight:before, .FileVideoOffLight:before {\n  content: "\\30174";\n}\n\n.zi-FilePDFOffLight:before, .FilePDFOffLight:before {\n  content: "\\30175";\n}\n\n.zi-FilePresentationOffLight:before, .FilePresentationOffLight:before {\n  content: "\\30176";\n}\n\n.zi-FileHTMLOffLight:before, .FileHTMLOffLight:before {\n  content: "\\30177";\n}\n\n.zi-FileVCardOffLight:before, .FileVCardOffLight:before {\n  content: "\\30178";\n}\n\n.zi-FileMessageOffLight:before, .FileMessageOffLight:before {\n  content: "\\30179";\n}\n\n.zi-FileAppOffLight:before, .FileAppOffLight:before {\n  content: "\\30180";\n}\n\n.zi-Media:before, .Media:before {\n  content: "\\30181";\n}\n\n.zi-UploadBold:before, .UploadBold:before {\n  content: "\\30182";\n}\n\n.zi-UploadLight:before, .UploadLight:before {\n  content: "\\30183";\n}\n\n.zi-UploadSquareBold:before, .UploadSquareBold:before {\n  content: "\\30184";\n}\n\n.zi-UploadSquareLight:before, .UploadSquareLight:before {\n  content: "\\30185";\n}\n\n.zi-MoonBold:before, .MoonBold:before {\n  content: "\\30186";\n}\n\n.zi-MoonLight:before, .MoonLight:before {\n  content: "\\30187";\n}\n\n.zi-SunBold:before, .SunBold:before {\n  content: "\\30188";\n}\n\n.zi-SunLight:before, .SunLight:before {\n  content: "\\30189";\n}\n\n.zi-DownDoubleLight:before, .DownDoubleLight:before {\n  content: "\\30190";\n}\n\n' ]
        } ]);
        exports.locals = {
            zi: "_zextras_team_web_client_release_assets_zi",
            Imgzi: "_zextras_team_web_client_release_assets_Imgzi",
            "zi-Activity": "_zextras_team_web_client_release_assets_zi-Activity",
            Activity: "_zextras_team_web_client_release_assets_Activity",
            "zi-Attachment": "_zextras_team_web_client_release_assets_zi-Attachment",
            Attachment: "_zextras_team_web_client_release_assets_Attachment",
            "zi-Circle": "_zextras_team_web_client_release_assets_zi-Circle",
            Circle: "_zextras_team_web_client_release_assets_Circle",
            "zi-CameraOnBold": "_zextras_team_web_client_release_assets_zi-CameraOnBold",
            CameraOnBold: "_zextras_team_web_client_release_assets_CameraOnBold",
            "zi-CameraOff": "_zextras_team_web_client_release_assets_zi-CameraOff",
            CameraOff: "_zextras_team_web_client_release_assets_CameraOff",
            "zi-CameraOn": "_zextras_team_web_client_release_assets_zi-CameraOn",
            CameraOn: "_zextras_team_web_client_release_assets_CameraOn",
            "zi-SpaceLight": "_zextras_team_web_client_release_assets_zi-SpaceLight",
            SpaceLight: "_zextras_team_web_client_release_assets_SpaceLight",
            "zi-Close": "_zextras_team_web_client_release_assets_zi-Close",
            Close: "_zextras_team_web_client_release_assets_Close",
            "zi-Copy": "_zextras_team_web_client_release_assets_zi-Copy",
            Copy: "_zextras_team_web_client_release_assets_Copy",
            "zi-DeleteMessage": "_zextras_team_web_client_release_assets_zi-DeleteMessage",
            DeleteMessage: "_zextras_team_web_client_release_assets_DeleteMessage",
            "zi-DeleteLight": "_zextras_team_web_client_release_assets_zi-DeleteLight",
            DeleteLight: "_zextras_team_web_client_release_assets_DeleteLight",
            "zi-FileDocs": "_zextras_team_web_client_release_assets_zi-FileDocs",
            FileDocs: "_zextras_team_web_client_release_assets_FileDocs",
            "zi-DoubleTick": "_zextras_team_web_client_release_assets_zi-DoubleTick",
            DoubleTick: "_zextras_team_web_client_release_assets_DoubleTick",
            "zi-Down": "_zextras_team_web_client_release_assets_zi-Down",
            Down: "_zextras_team_web_client_release_assets_Down",
            "zi-Download": "_zextras_team_web_client_release_assets_zi-Download",
            Download: "_zextras_team_web_client_release_assets_Download",
            "zi-FileImage": "_zextras_team_web_client_release_assets_zi-FileImage",
            FileImage: "_zextras_team_web_client_release_assets_FileImage",
            "zi-Drive": "_zextras_team_web_client_release_assets_zi-Drive",
            Drive: "_zextras_team_web_client_release_assets_Drive",
            "zi-Edit": "_zextras_team_web_client_release_assets_zi-Edit",
            Edit: "_zextras_team_web_client_release_assets_Edit",
            "zi-Smile": "_zextras_team_web_client_release_assets_zi-Smile",
            Smile: "_zextras_team_web_client_release_assets_Smile",
            "zi-FolderOpen": "_zextras_team_web_client_release_assets_zi-FolderOpen",
            FolderOpen: "_zextras_team_web_client_release_assets_FolderOpen",
            "zi-FolderLight": "_zextras_team_web_client_release_assets_zi-FolderLight",
            FolderLight: "_zextras_team_web_client_release_assets_FolderLight",
            "zi-Grid": "_zextras_team_web_client_release_assets_zi-Grid",
            Grid: "_zextras_team_web_client_release_assets_Grid",
            "zi-History": "_zextras_team_web_client_release_assets_zi-History",
            History: "_zextras_team_web_client_release_assets_History",
            "zi-Home": "_zextras_team_web_client_release_assets_zi-Home",
            Home: "_zextras_team_web_client_release_assets_Home",
            "zi-Image": "_zextras_team_web_client_release_assets_zi-Image",
            Image: "_zextras_team_web_client_release_assets_Image",
            "zi-Info": "_zextras_team_web_client_release_assets_zi-Info",
            Info: "_zextras_team_web_client_release_assets_Info",
            "zi-Last": "_zextras_team_web_client_release_assets_zi-Last",
            Last: "_zextras_team_web_client_release_assets_Last",
            "zi-Leave": "_zextras_team_web_client_release_assets_zi-Leave",
            Leave: "_zextras_team_web_client_release_assets_Leave",
            "zi-Less": "_zextras_team_web_client_release_assets_zi-Less",
            Less: "_zextras_team_web_client_release_assets_Less",
            "zi-Link": "_zextras_team_web_client_release_assets_zi-Link",
            Link: "_zextras_team_web_client_release_assets_Link",
            "zi-List": "_zextras_team_web_client_release_assets_zi-List",
            List: "_zextras_team_web_client_release_assets_List",
            "zi-Mail": "_zextras_team_web_client_release_assets_zi-Mail",
            Mail: "_zextras_team_web_client_release_assets_Mail",
            "zi-MicrophoneOff": "_zextras_team_web_client_release_assets_zi-MicrophoneOff",
            MicrophoneOff: "_zextras_team_web_client_release_assets_MicrophoneOff",
            "zi-MicrophoneOn": "_zextras_team_web_client_release_assets_zi-MicrophoneOn",
            MicrophoneOn: "_zextras_team_web_client_release_assets_MicrophoneOn",
            "zi-Move": "_zextras_team_web_client_release_assets_zi-Move",
            Move: "_zextras_team_web_client_release_assets_Move",
            "zi-NotificationOff": "_zextras_team_web_client_release_assets_zi-NotificationOff",
            NotificationOff: "_zextras_team_web_client_release_assets_NotificationOff",
            "zi-NotificationOn": "_zextras_team_web_client_release_assets_zi-NotificationOn",
            NotificationOn: "_zextras_team_web_client_release_assets_NotificationOn",
            "zi-Open": "_zextras_team_web_client_release_assets_zi-Open",
            Open: "_zextras_team_web_client_release_assets_Open",
            "zi-FilePDF": "_zextras_team_web_client_release_assets_zi-FilePDF",
            FilePDF: "_zextras_team_web_client_release_assets_FilePDF",
            "zi-PhoneOff": "_zextras_team_web_client_release_assets_zi-PhoneOff",
            PhoneOff: "_zextras_team_web_client_release_assets_PhoneOff",
            "zi-PhoneOn": "_zextras_team_web_client_release_assets_zi-PhoneOn",
            PhoneOn: "_zextras_team_web_client_release_assets_PhoneOn",
            "zi-Plus": "_zextras_team_web_client_release_assets_zi-Plus",
            Plus: "_zextras_team_web_client_release_assets_Plus",
            "zi-FilePresentation": "_zextras_team_web_client_release_assets_zi-FilePresentation",
            FilePresentation: "_zextras_team_web_client_release_assets_FilePresentation",
            "zi-Print": "_zextras_team_web_client_release_assets_zi-Print",
            Print: "_zextras_team_web_client_release_assets_Print",
            "zi-Regenerate": "_zextras_team_web_client_release_assets_zi-Regenerate",
            Regenerate: "_zextras_team_web_client_release_assets_Regenerate",
            "zi-Search": "_zextras_team_web_client_release_assets_zi-Search",
            Search: "_zextras_team_web_client_release_assets_Search",
            "zi-SharedByMeBold": "_zextras_team_web_client_release_assets_zi-SharedByMeBold",
            SharedByMeBold: "_zextras_team_web_client_release_assets_SharedByMeBold",
            "zi-SharedByMeLight": "_zextras_team_web_client_release_assets_zi-SharedByMeLight",
            SharedByMeLight: "_zextras_team_web_client_release_assets_SharedByMeLight",
            "zi-SharedToMeBold": "_zextras_team_web_client_release_assets_zi-SharedToMeBold",
            SharedToMeBold: "_zextras_team_web_client_release_assets_SharedToMeBold",
            "zi-StarBold": "_zextras_team_web_client_release_assets_zi-StarBold",
            StarBold: "_zextras_team_web_client_release_assets_StarBold",
            "zi-StarLight": "_zextras_team_web_client_release_assets_zi-StarLight",
            StarLight: "_zextras_team_web_client_release_assets_StarLight",
            "zi-Tick": "_zextras_team_web_client_release_assets_zi-Tick",
            Tick: "_zextras_team_web_client_release_assets_Tick",
            "zi-Up": "_zextras_team_web_client_release_assets_zi-Up",
            Up: "_zextras_team_web_client_release_assets_Up",
            "zi-Upload": "_zextras_team_web_client_release_assets_zi-Upload",
            Upload: "_zextras_team_web_client_release_assets_Upload",
            "zi-Visualize": "_zextras_team_web_client_release_assets_zi-Visualize",
            Visualize: "_zextras_team_web_client_release_assets_Visualize",
            "zi-VolumeOff": "_zextras_team_web_client_release_assets_zi-VolumeOff",
            VolumeOff: "_zextras_team_web_client_release_assets_VolumeOff",
            "zi-VolumeOn": "_zextras_team_web_client_release_assets_zi-VolumeOn",
            VolumeOn: "_zextras_team_web_client_release_assets_VolumeOn",
            "zi-FileCalc": "_zextras_team_web_client_release_assets_zi-FileCalc",
            FileCalc: "_zextras_team_web_client_release_assets_FileCalc",
            "zi-SharedToMeLight": "_zextras_team_web_client_release_assets_zi-SharedToMeLight",
            SharedToMeLight: "_zextras_team_web_client_release_assets_SharedToMeLight",
            "zi-DeleteBold": "_zextras_team_web_client_release_assets_zi-DeleteBold",
            DeleteBold: "_zextras_team_web_client_release_assets_DeleteBold",
            "zi-SpaceBold": "_zextras_team_web_client_release_assets_zi-SpaceBold",
            SpaceBold: "_zextras_team_web_client_release_assets_SpaceBold",
            "zi-Accept": "_zextras_team_web_client_release_assets_zi-Accept",
            Accept: "_zextras_team_web_client_release_assets_Accept",
            "zi-ScreensharingOff": "_zextras_team_web_client_release_assets_zi-ScreensharingOff",
            ScreensharingOff: "_zextras_team_web_client_release_assets_ScreensharingOff",
            "zi-ScreensharingOn": "_zextras_team_web_client_release_assets_zi-ScreensharingOn",
            ScreensharingOn: "_zextras_team_web_client_release_assets_ScreensharingOn",
            "zi-Dots": "_zextras_team_web_client_release_assets_zi-Dots",
            Dots: "_zextras_team_web_client_release_assets_Dots",
            "zi-Key": "_zextras_team_web_client_release_assets_zi-Key",
            Key: "_zextras_team_web_client_release_assets_Key",
            "zi-LockKeyhole": "_zextras_team_web_client_release_assets_zi-LockKeyhole",
            LockKeyhole: "_zextras_team_web_client_release_assets_LockKeyhole",
            "zi-MobileBold": "_zextras_team_web_client_release_assets_zi-MobileBold",
            MobileBold: "_zextras_team_web_client_release_assets_MobileBold",
            "zi-MobileLight": "_zextras_team_web_client_release_assets_zi-MobileLight",
            MobileLight: "_zextras_team_web_client_release_assets_MobileLight",
            "zi-MobileRemove": "_zextras_team_web_client_release_assets_zi-MobileRemove",
            MobileRemove: "_zextras_team_web_client_release_assets_MobileRemove",
            "zi-Pause": "_zextras_team_web_client_release_assets_zi-Pause",
            Pause: "_zextras_team_web_client_release_assets_Pause",
            "zi-Play": "_zextras_team_web_client_release_assets_zi-Play",
            Play: "_zextras_team_web_client_release_assets_Play",
            "zi-Server": "_zextras_team_web_client_release_assets_zi-Server",
            Server: "_zextras_team_web_client_release_assets_Server",
            "zi-UserBold": "_zextras_team_web_client_release_assets_zi-UserBold",
            UserBold: "_zextras_team_web_client_release_assets_UserBold",
            "zi-UserLight": "_zextras_team_web_client_release_assets_zi-UserLight",
            UserLight: "_zextras_team_web_client_release_assets_UserLight",
            "zi-Left": "_zextras_team_web_client_release_assets_zi-Left",
            Left: "_zextras_team_web_client_release_assets_Left",
            "zi-Right": "_zextras_team_web_client_release_assets_zi-Right",
            Right: "_zextras_team_web_client_release_assets_Right",
            "zi-SquareBold": "_zextras_team_web_client_release_assets_zi-SquareBold",
            SquareBold: "_zextras_team_web_client_release_assets_SquareBold",
            "zi-SquareCheck": "_zextras_team_web_client_release_assets_zi-SquareCheck",
            SquareCheck: "_zextras_team_web_client_release_assets_SquareCheck",
            "zi-SquareLight": "_zextras_team_web_client_release_assets_zi-SquareLight",
            SquareLight: "_zextras_team_web_client_release_assets_SquareLight",
            "zi-BookmarkBold": "_zextras_team_web_client_release_assets_zi-BookmarkBold",
            BookmarkBold: "_zextras_team_web_client_release_assets_BookmarkBold",
            "zi-BookmarkLight": "_zextras_team_web_client_release_assets_zi-BookmarkLight",
            BookmarkLight: "_zextras_team_web_client_release_assets_BookmarkLight",
            "zi-Bottom": "_zextras_team_web_client_release_assets_zi-Bottom",
            Bottom: "_zextras_team_web_client_release_assets_Bottom",
            "zi-ReorderDown": "_zextras_team_web_client_release_assets_zi-ReorderDown",
            ReorderDown: "_zextras_team_web_client_release_assets_ReorderDown",
            "zi-ReorderUp": "_zextras_team_web_client_release_assets_zi-ReorderUp",
            ReorderUp: "_zextras_team_web_client_release_assets_ReorderUp",
            "zi-FileAudio": "_zextras_team_web_client_release_assets_zi-FileAudio",
            FileAudio: "_zextras_team_web_client_release_assets_FileAudio",
            "zi-FileBlank": "_zextras_team_web_client_release_assets_zi-FileBlank",
            FileBlank: "_zextras_team_web_client_release_assets_FileBlank",
            "zi-FileVideo": "_zextras_team_web_client_release_assets_zi-FileVideo",
            FileVideo: "_zextras_team_web_client_release_assets_FileVideo",
            "zi-FileZip": "_zextras_team_web_client_release_assets_zi-FileZip",
            FileZip: "_zextras_team_web_client_release_assets_FileZip",
            "zi-FolderBold": "_zextras_team_web_client_release_assets_zi-FolderBold",
            FolderBold: "_zextras_team_web_client_release_assets_FolderBold",
            "zi-SendBold": "_zextras_team_web_client_release_assets_zi-SendBold",
            SendBold: "_zextras_team_web_client_release_assets_SendBold",
            "zi-SendLight": "_zextras_team_web_client_release_assets_zi-SendLight",
            SendLight: "_zextras_team_web_client_release_assets_SendLight",
            "zi-SettingsBold": "_zextras_team_web_client_release_assets_zi-SettingsBold",
            SettingsBold: "_zextras_team_web_client_release_assets_SettingsBold",
            "zi-SettingsLight": "_zextras_team_web_client_release_assets_zi-SettingsLight",
            SettingsLight: "_zextras_team_web_client_release_assets_SettingsLight",
            "zi-FileApp": "_zextras_team_web_client_release_assets_zi-FileApp",
            FileApp: "_zextras_team_web_client_release_assets_FileApp",
            "zi-FileVCard": "_zextras_team_web_client_release_assets_zi-FileVCard",
            FileVCard: "_zextras_team_web_client_release_assets_FileVCard",
            "zi-FileHTML": "_zextras_team_web_client_release_assets_zi-FileHTML",
            FileHTML: "_zextras_team_web_client_release_assets_FileHTML",
            "zi-FileMessage": "_zextras_team_web_client_release_assets_zi-FileMessage",
            FileMessage: "_zextras_team_web_client_release_assets_FileMessage",
            "zi-FileSignature": "_zextras_team_web_client_release_assets_zi-FileSignature",
            FileSignature: "_zextras_team_web_client_release_assets_FileSignature",
            "zi-Restore": "_zextras_team_web_client_release_assets_zi-Restore",
            Restore: "_zextras_team_web_client_release_assets_Restore",
            "zi-AlertLight": "_zextras_team_web_client_release_assets_zi-AlertLight",
            AlertLight: "_zextras_team_web_client_release_assets_AlertLight",
            "zi-Alert": "_zextras_team_web_client_release_assets_zi-Alert",
            Alert: "_zextras_team_web_client_release_assets_Alert",
            "zi-CircleBold": "_zextras_team_web_client_release_assets_zi-CircleBold",
            CircleBold: "_zextras_team_web_client_release_assets_CircleBold",
            "zi-OpenAlt": "_zextras_team_web_client_release_assets_zi-OpenAlt",
            OpenAlt: "_zextras_team_web_client_release_assets_OpenAlt",
            "zi-AlertBold": "_zextras_team_web_client_release_assets_zi-AlertBold",
            AlertBold: "_zextras_team_web_client_release_assets_AlertBold",
            "zi-Ban": "_zextras_team_web_client_release_assets_zi-Ban",
            Ban: "_zextras_team_web_client_release_assets_Ban",
            "zi-CalendarBold": "_zextras_team_web_client_release_assets_zi-CalendarBold",
            CalendarBold: "_zextras_team_web_client_release_assets_CalendarBold",
            "zi-CalendarLight": "_zextras_team_web_client_release_assets_zi-CalendarLight",
            CalendarLight: "_zextras_team_web_client_release_assets_CalendarLight",
            "zi-CameraOffBold": "_zextras_team_web_client_release_assets_zi-CameraOffBold",
            CameraOffBold: "_zextras_team_web_client_release_assets_CameraOffBold",
            "zi-CameraPlusLight": "_zextras_team_web_client_release_assets_zi-CameraPlusLight",
            CameraPlusLight: "_zextras_team_web_client_release_assets_CameraPlusLight",
            "zi-ChannelLight": "_zextras_team_web_client_release_assets_zi-ChannelLight",
            ChannelLight: "_zextras_team_web_client_release_assets_ChannelLight",
            "zi-ChatBold": "_zextras_team_web_client_release_assets_zi-ChatBold",
            ChatBold: "_zextras_team_web_client_release_assets_ChatBold",
            "zi-ChatLight": "_zextras_team_web_client_release_assets_zi-ChatLight",
            ChatLight: "_zextras_team_web_client_release_assets_ChatLight",
            "zi-CrownBold": "_zextras_team_web_client_release_assets_zi-CrownBold",
            CrownBold: "_zextras_team_web_client_release_assets_CrownBold",
            "zi-CrownLight": "_zextras_team_web_client_release_assets_zi-CrownLight",
            CrownLight: "_zextras_team_web_client_release_assets_CrownLight",
            "zi-Files": "_zextras_team_web_client_release_assets_zi-Files",
            Files: "_zextras_team_web_client_release_assets_Files",
            "zi-Folders": "_zextras_team_web_client_release_assets_zi-Folders",
            Folders: "_zextras_team_web_client_release_assets_Folders",
            "zi-Items": "_zextras_team_web_client_release_assets_zi-Items",
            Items: "_zextras_team_web_client_release_assets_Items",
            "zi-NewChatBold": "_zextras_team_web_client_release_assets_zi-NewChatBold",
            NewChatBold: "_zextras_team_web_client_release_assets_NewChatBold",
            "zi-NewChatLight": "_zextras_team_web_client_release_assets_zi-NewChatLight",
            NewChatLight: "_zextras_team_web_client_release_assets_NewChatLight",
            "zi-NewFolderLight": "_zextras_team_web_client_release_assets_zi-NewFolderLight",
            NewFolderLight: "_zextras_team_web_client_release_assets_NewFolderLight",
            "zi-NewSpaceBold": "_zextras_team_web_client_release_assets_zi-NewSpaceBold",
            NewSpaceBold: "_zextras_team_web_client_release_assets_NewSpaceBold",
            "zi-NewSpaceLight": "_zextras_team_web_client_release_assets_zi-NewSpaceLight",
            NewSpaceLight: "_zextras_team_web_client_release_assets_NewSpaceLight",
            "zi-ForwardBold": "_zextras_team_web_client_release_assets_zi-ForwardBold",
            ForwardBold: "_zextras_team_web_client_release_assets_ForwardBold",
            "zi-ForwardLight": "_zextras_team_web_client_release_assets_zi-ForwardLight",
            ForwardLight: "_zextras_team_web_client_release_assets_ForwardLight",
            "zi-ArchiveLight": "_zextras_team_web_client_release_assets_zi-ArchiveLight",
            ArchiveLight: "_zextras_team_web_client_release_assets_ArchiveLight",
            "zi-ContactBold": "_zextras_team_web_client_release_assets_zi-ContactBold",
            ContactBold: "_zextras_team_web_client_release_assets_ContactBold",
            "zi-ContactLight": "_zextras_team_web_client_release_assets_zi-ContactLight",
            ContactLight: "_zextras_team_web_client_release_assets_ContactLight",
            "zi-ContactListLight": "_zextras_team_web_client_release_assets_zi-ContactListLight",
            ContactListLight: "_zextras_team_web_client_release_assets_ContactListLight",
            "zi-InboxLight": "_zextras_team_web_client_release_assets_zi-InboxLight",
            InboxLight: "_zextras_team_web_client_release_assets_InboxLight",
            "zi-MailedContactLight": "_zextras_team_web_client_release_assets_zi-MailedContactLight",
            MailedContactLight: "_zextras_team_web_client_release_assets_MailedContactLight",
            "zi-MinusAlt": "_zextras_team_web_client_release_assets_zi-MinusAlt",
            MinusAlt: "_zextras_team_web_client_release_assets_MinusAlt",
            "zi-PhotoLight": "_zextras_team_web_client_release_assets_zi-PhotoLight",
            PhotoLight: "_zextras_team_web_client_release_assets_PhotoLight",
            "zi-PlusAlt": "_zextras_team_web_client_release_assets_zi-PlusAlt",
            PlusAlt: "_zextras_team_web_client_release_assets_PlusAlt",
            "zi-Repeat": "_zextras_team_web_client_release_assets_zi-Repeat",
            Repeat: "_zextras_team_web_client_release_assets_Repeat",
            "zi-ReplyAllBold": "_zextras_team_web_client_release_assets_zi-ReplyAllBold",
            ReplyAllBold: "_zextras_team_web_client_release_assets_ReplyAllBold",
            "zi-ReplyAllLight": "_zextras_team_web_client_release_assets_zi-ReplyAllLight",
            ReplyAllLight: "_zextras_team_web_client_release_assets_ReplyAllLight",
            "zi-ReplyBold": "_zextras_team_web_client_release_assets_zi-ReplyBold",
            ReplyBold: "_zextras_team_web_client_release_assets_ReplyBold",
            "zi-ReplyLight": "_zextras_team_web_client_release_assets_zi-ReplyLight",
            ReplyLight: "_zextras_team_web_client_release_assets_ReplyLight",
            "zi-X": "_zextras_team_web_client_release_assets_zi-X",
            X: "_zextras_team_web_client_release_assets_X",
            "zi-ViewOff": "_zextras_team_web_client_release_assets_zi-ViewOff",
            ViewOff: "_zextras_team_web_client_release_assets_ViewOff",
            "zi-HomeBold": "_zextras_team_web_client_release_assets_zi-HomeBold",
            HomeBold: "_zextras_team_web_client_release_assets_HomeBold",
            "zi-RightDouble": "_zextras_team_web_client_release_assets_zi-RightDouble",
            RightDouble: "_zextras_team_web_client_release_assets_RightDouble",
            "zi-LeftDouble": "_zextras_team_web_client_release_assets_zi-LeftDouble",
            LeftDouble: "_zextras_team_web_client_release_assets_LeftDouble",
            "zi-ZextrasTalk": "_zextras_team_web_client_release_assets_zi-ZextrasTalk",
            ZextrasTalk: "_zextras_team_web_client_release_assets_ZextrasTalk",
            "zi-ZextrasDrive": "_zextras_team_web_client_release_assets_zi-ZextrasDrive",
            ZextrasDrive: "_zextras_team_web_client_release_assets_ZextrasDrive",
            "zi-MailBold": "_zextras_team_web_client_release_assets_zi-MailBold",
            MailBold: "_zextras_team_web_client_release_assets_MailBold",
            "zi-CloseLarge": "_zextras_team_web_client_release_assets_zi-CloseLarge",
            CloseLarge: "_zextras_team_web_client_release_assets_CloseLarge",
            "zi-DotsVertical": "_zextras_team_web_client_release_assets_zi-DotsVertical",
            DotsVertical: "_zextras_team_web_client_release_assets_DotsVertical",
            "zi-InfoBold": "_zextras_team_web_client_release_assets_zi-InfoBold",
            InfoBold: "_zextras_team_web_client_release_assets_InfoBold",
            "zi-MobileOnlineBold": "_zextras_team_web_client_release_assets_zi-MobileOnlineBold",
            MobileOnlineBold: "_zextras_team_web_client_release_assets_MobileOnlineBold",
            "zi-MobileOnlineLight": "_zextras_team_web_client_release_assets_zi-MobileOnlineLight",
            MobileOnlineLight: "_zextras_team_web_client_release_assets_MobileOnlineLight",
            "zi-OfflineBold": "_zextras_team_web_client_release_assets_zi-OfflineBold",
            OfflineBold: "_zextras_team_web_client_release_assets_OfflineBold",
            "zi-OfflineLight": "_zextras_team_web_client_release_assets_zi-OfflineLight",
            OfflineLight: "_zextras_team_web_client_release_assets_OfflineLight",
            "zi-OnlineBold": "_zextras_team_web_client_release_assets_zi-OnlineBold",
            OnlineBold: "_zextras_team_web_client_release_assets_OnlineBold",
            "zi-OnlineLight": "_zextras_team_web_client_release_assets_zi-OnlineLight",
            OnlineLight: "_zextras_team_web_client_release_assets_OnlineLight",
            "zi-CircleCheckLight": "_zextras_team_web_client_release_assets_zi-CircleCheckLight",
            CircleCheckLight: "_zextras_team_web_client_release_assets_CircleCheckLight",
            "zi-ZimbraConnect": "_zextras_team_web_client_release_assets_zi-ZimbraConnect",
            ZimbraConnect: "_zextras_team_web_client_release_assets_ZimbraConnect",
            "zi-SpaceChannelBold": "_zextras_team_web_client_release_assets_zi-SpaceChannelBold",
            SpaceChannelBold: "_zextras_team_web_client_release_assets_SpaceChannelBold",
            "zi-SpaceChannelLight": "_zextras_team_web_client_release_assets_zi-SpaceChannelLight",
            SpaceChannelLight: "_zextras_team_web_client_release_assets_SpaceChannelLight",
            "zi-ZextrasDocs": "_zextras_team_web_client_release_assets_zi-ZextrasDocs",
            ZextrasDocs: "_zextras_team_web_client_release_assets_ZextrasDocs",
            "zi-ZimbraDrive": "_zextras_team_web_client_release_assets_zi-ZimbraDrive",
            ZimbraDrive: "_zextras_team_web_client_release_assets_ZimbraDrive",
            "zi-SmileBold": "_zextras_team_web_client_release_assets_zi-SmileBold",
            SmileBold: "_zextras_team_web_client_release_assets_SmileBold",
            "zi-SadBold": "_zextras_team_web_client_release_assets_zi-SadBold",
            SadBold: "_zextras_team_web_client_release_assets_SadBold",
            "zi-SadLight": "_zextras_team_web_client_release_assets_zi-SadLight",
            SadLight: "_zextras_team_web_client_release_assets_SadLight",
            "zi-DeadBold": "_zextras_team_web_client_release_assets_zi-DeadBold",
            DeadBold: "_zextras_team_web_client_release_assets_DeadBold",
            "zi-DeadLight": "_zextras_team_web_client_release_assets_zi-DeadLight",
            DeadLight: "_zextras_team_web_client_release_assets_DeadLight",
            "zi-AddContactBold": "_zextras_team_web_client_release_assets_zi-AddContactBold",
            AddContactBold: "_zextras_team_web_client_release_assets_AddContactBold",
            "zi-AddContactLight": "_zextras_team_web_client_release_assets_zi-AddContactLight",
            AddContactLight: "_zextras_team_web_client_release_assets_AddContactLight",
            "zi-FileOffLight": "_zextras_team_web_client_release_assets_zi-FileOffLight",
            FileOffLight: "_zextras_team_web_client_release_assets_FileOffLight",
            "zi-FileDocsOffLight": "_zextras_team_web_client_release_assets_zi-FileDocsOffLight",
            FileDocsOffLight: "_zextras_team_web_client_release_assets_FileDocsOffLight",
            "zi-FileImageOffLight": "_zextras_team_web_client_release_assets_zi-FileImageOffLight",
            FileImageOffLight: "_zextras_team_web_client_release_assets_FileImageOffLight",
            "zi-FileCalcOffLight": "_zextras_team_web_client_release_assets_zi-FileCalcOffLight",
            FileCalcOffLight: "_zextras_team_web_client_release_assets_FileCalcOffLight",
            "zi-FileZipOffLight": "_zextras_team_web_client_release_assets_zi-FileZipOffLight",
            FileZipOffLight: "_zextras_team_web_client_release_assets_FileZipOffLight",
            "zi-FileVideoOffLight": "_zextras_team_web_client_release_assets_zi-FileVideoOffLight",
            FileVideoOffLight: "_zextras_team_web_client_release_assets_FileVideoOffLight",
            "zi-FilePDFOffLight": "_zextras_team_web_client_release_assets_zi-FilePDFOffLight",
            FilePDFOffLight: "_zextras_team_web_client_release_assets_FilePDFOffLight",
            "zi-FilePresentationOffLight": "_zextras_team_web_client_release_assets_zi-FilePresentationOffLight",
            FilePresentationOffLight: "_zextras_team_web_client_release_assets_FilePresentationOffLight",
            "zi-FileHTMLOffLight": "_zextras_team_web_client_release_assets_zi-FileHTMLOffLight",
            FileHTMLOffLight: "_zextras_team_web_client_release_assets_FileHTMLOffLight",
            "zi-FileVCardOffLight": "_zextras_team_web_client_release_assets_zi-FileVCardOffLight",
            FileVCardOffLight: "_zextras_team_web_client_release_assets_FileVCardOffLight",
            "zi-FileMessageOffLight": "_zextras_team_web_client_release_assets_zi-FileMessageOffLight",
            FileMessageOffLight: "_zextras_team_web_client_release_assets_FileMessageOffLight",
            "zi-FileAppOffLight": "_zextras_team_web_client_release_assets_zi-FileAppOffLight",
            FileAppOffLight: "_zextras_team_web_client_release_assets_FileAppOffLight",
            "zi-Media": "_zextras_team_web_client_release_assets_zi-Media",
            Media: "_zextras_team_web_client_release_assets_Media",
            "zi-UploadBold": "_zextras_team_web_client_release_assets_zi-UploadBold",
            UploadBold: "_zextras_team_web_client_release_assets_UploadBold",
            "zi-UploadLight": "_zextras_team_web_client_release_assets_zi-UploadLight",
            UploadLight: "_zextras_team_web_client_release_assets_UploadLight",
            "zi-UploadSquareBold": "_zextras_team_web_client_release_assets_zi-UploadSquareBold",
            UploadSquareBold: "_zextras_team_web_client_release_assets_UploadSquareBold",
            "zi-UploadSquareLight": "_zextras_team_web_client_release_assets_zi-UploadSquareLight",
            UploadSquareLight: "_zextras_team_web_client_release_assets_UploadSquareLight",
            "zi-MoonBold": "_zextras_team_web_client_release_assets_zi-MoonBold",
            MoonBold: "_zextras_team_web_client_release_assets_MoonBold",
            "zi-MoonLight": "_zextras_team_web_client_release_assets_zi-MoonLight",
            MoonLight: "_zextras_team_web_client_release_assets_MoonLight",
            "zi-SunBold": "_zextras_team_web_client_release_assets_zi-SunBold",
            SunBold: "_zextras_team_web_client_release_assets_SunBold",
            "zi-SunLight": "_zextras_team_web_client_release_assets_zi-SunLight",
            SunLight: "_zextras_team_web_client_release_assets_SunLight",
            "zi-DownDoubleLight": "_zextras_team_web_client_release_assets_zi-DownDoubleLight",
            DownDoubleLight: "_zextras_team_web_client_release_assets_DownDoubleLight"
        };
    },
    "./node_modules/moment/locale sync recursive ^\\.\\/.*$": function(module, exports, __webpack_require__) {
        var map = {
            "./af": "./node_modules/moment/locale/af.js",
            "./af.js": "./node_modules/moment/locale/af.js",
            "./ar": "./node_modules/moment/locale/ar.js",
            "./ar-dz": "./node_modules/moment/locale/ar-dz.js",
            "./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
            "./ar-kw": "./node_modules/moment/locale/ar-kw.js",
            "./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
            "./ar-ly": "./node_modules/moment/locale/ar-ly.js",
            "./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
            "./ar-ma": "./node_modules/moment/locale/ar-ma.js",
            "./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
            "./ar-sa": "./node_modules/moment/locale/ar-sa.js",
            "./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
            "./ar-tn": "./node_modules/moment/locale/ar-tn.js",
            "./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
            "./ar.js": "./node_modules/moment/locale/ar.js",
            "./az": "./node_modules/moment/locale/az.js",
            "./az.js": "./node_modules/moment/locale/az.js",
            "./be": "./node_modules/moment/locale/be.js",
            "./be.js": "./node_modules/moment/locale/be.js",
            "./bg": "./node_modules/moment/locale/bg.js",
            "./bg.js": "./node_modules/moment/locale/bg.js",
            "./bm": "./node_modules/moment/locale/bm.js",
            "./bm.js": "./node_modules/moment/locale/bm.js",
            "./bn": "./node_modules/moment/locale/bn.js",
            "./bn.js": "./node_modules/moment/locale/bn.js",
            "./bo": "./node_modules/moment/locale/bo.js",
            "./bo.js": "./node_modules/moment/locale/bo.js",
            "./br": "./node_modules/moment/locale/br.js",
            "./br.js": "./node_modules/moment/locale/br.js",
            "./bs": "./node_modules/moment/locale/bs.js",
            "./bs.js": "./node_modules/moment/locale/bs.js",
            "./ca": "./node_modules/moment/locale/ca.js",
            "./ca.js": "./node_modules/moment/locale/ca.js",
            "./cs": "./node_modules/moment/locale/cs.js",
            "./cs.js": "./node_modules/moment/locale/cs.js",
            "./cv": "./node_modules/moment/locale/cv.js",
            "./cv.js": "./node_modules/moment/locale/cv.js",
            "./cy": "./node_modules/moment/locale/cy.js",
            "./cy.js": "./node_modules/moment/locale/cy.js",
            "./da": "./node_modules/moment/locale/da.js",
            "./da.js": "./node_modules/moment/locale/da.js",
            "./de": "./node_modules/moment/locale/de.js",
            "./de-at": "./node_modules/moment/locale/de-at.js",
            "./de-at.js": "./node_modules/moment/locale/de-at.js",
            "./de-ch": "./node_modules/moment/locale/de-ch.js",
            "./de-ch.js": "./node_modules/moment/locale/de-ch.js",
            "./de.js": "./node_modules/moment/locale/de.js",
            "./dv": "./node_modules/moment/locale/dv.js",
            "./dv.js": "./node_modules/moment/locale/dv.js",
            "./el": "./node_modules/moment/locale/el.js",
            "./el.js": "./node_modules/moment/locale/el.js",
            "./en-SG": "./node_modules/moment/locale/en-SG.js",
            "./en-SG.js": "./node_modules/moment/locale/en-SG.js",
            "./en-au": "./node_modules/moment/locale/en-au.js",
            "./en-au.js": "./node_modules/moment/locale/en-au.js",
            "./en-ca": "./node_modules/moment/locale/en-ca.js",
            "./en-ca.js": "./node_modules/moment/locale/en-ca.js",
            "./en-gb": "./node_modules/moment/locale/en-gb.js",
            "./en-gb.js": "./node_modules/moment/locale/en-gb.js",
            "./en-ie": "./node_modules/moment/locale/en-ie.js",
            "./en-ie.js": "./node_modules/moment/locale/en-ie.js",
            "./en-il": "./node_modules/moment/locale/en-il.js",
            "./en-il.js": "./node_modules/moment/locale/en-il.js",
            "./en-nz": "./node_modules/moment/locale/en-nz.js",
            "./en-nz.js": "./node_modules/moment/locale/en-nz.js",
            "./eo": "./node_modules/moment/locale/eo.js",
            "./eo.js": "./node_modules/moment/locale/eo.js",
            "./es": "./node_modules/moment/locale/es.js",
            "./es-do": "./node_modules/moment/locale/es-do.js",
            "./es-do.js": "./node_modules/moment/locale/es-do.js",
            "./es-us": "./node_modules/moment/locale/es-us.js",
            "./es-us.js": "./node_modules/moment/locale/es-us.js",
            "./es.js": "./node_modules/moment/locale/es.js",
            "./et": "./node_modules/moment/locale/et.js",
            "./et.js": "./node_modules/moment/locale/et.js",
            "./eu": "./node_modules/moment/locale/eu.js",
            "./eu.js": "./node_modules/moment/locale/eu.js",
            "./fa": "./node_modules/moment/locale/fa.js",
            "./fa.js": "./node_modules/moment/locale/fa.js",
            "./fi": "./node_modules/moment/locale/fi.js",
            "./fi.js": "./node_modules/moment/locale/fi.js",
            "./fo": "./node_modules/moment/locale/fo.js",
            "./fo.js": "./node_modules/moment/locale/fo.js",
            "./fr": "./node_modules/moment/locale/fr.js",
            "./fr-ca": "./node_modules/moment/locale/fr-ca.js",
            "./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
            "./fr-ch": "./node_modules/moment/locale/fr-ch.js",
            "./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
            "./fr.js": "./node_modules/moment/locale/fr.js",
            "./fy": "./node_modules/moment/locale/fy.js",
            "./fy.js": "./node_modules/moment/locale/fy.js",
            "./ga": "./node_modules/moment/locale/ga.js",
            "./ga.js": "./node_modules/moment/locale/ga.js",
            "./gd": "./node_modules/moment/locale/gd.js",
            "./gd.js": "./node_modules/moment/locale/gd.js",
            "./gl": "./node_modules/moment/locale/gl.js",
            "./gl.js": "./node_modules/moment/locale/gl.js",
            "./gom-latn": "./node_modules/moment/locale/gom-latn.js",
            "./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
            "./gu": "./node_modules/moment/locale/gu.js",
            "./gu.js": "./node_modules/moment/locale/gu.js",
            "./he": "./node_modules/moment/locale/he.js",
            "./he.js": "./node_modules/moment/locale/he.js",
            "./hi": "./node_modules/moment/locale/hi.js",
            "./hi.js": "./node_modules/moment/locale/hi.js",
            "./hr": "./node_modules/moment/locale/hr.js",
            "./hr.js": "./node_modules/moment/locale/hr.js",
            "./hu": "./node_modules/moment/locale/hu.js",
            "./hu.js": "./node_modules/moment/locale/hu.js",
            "./hy-am": "./node_modules/moment/locale/hy-am.js",
            "./hy-am.js": "./node_modules/moment/locale/hy-am.js",
            "./id": "./node_modules/moment/locale/id.js",
            "./id.js": "./node_modules/moment/locale/id.js",
            "./is": "./node_modules/moment/locale/is.js",
            "./is.js": "./node_modules/moment/locale/is.js",
            "./it": "./node_modules/moment/locale/it.js",
            "./it-ch": "./node_modules/moment/locale/it-ch.js",
            "./it-ch.js": "./node_modules/moment/locale/it-ch.js",
            "./it.js": "./node_modules/moment/locale/it.js",
            "./ja": "./node_modules/moment/locale/ja.js",
            "./ja.js": "./node_modules/moment/locale/ja.js",
            "./jv": "./node_modules/moment/locale/jv.js",
            "./jv.js": "./node_modules/moment/locale/jv.js",
            "./ka": "./node_modules/moment/locale/ka.js",
            "./ka.js": "./node_modules/moment/locale/ka.js",
            "./kk": "./node_modules/moment/locale/kk.js",
            "./kk.js": "./node_modules/moment/locale/kk.js",
            "./km": "./node_modules/moment/locale/km.js",
            "./km.js": "./node_modules/moment/locale/km.js",
            "./kn": "./node_modules/moment/locale/kn.js",
            "./kn.js": "./node_modules/moment/locale/kn.js",
            "./ko": "./node_modules/moment/locale/ko.js",
            "./ko.js": "./node_modules/moment/locale/ko.js",
            "./ku": "./node_modules/moment/locale/ku.js",
            "./ku.js": "./node_modules/moment/locale/ku.js",
            "./ky": "./node_modules/moment/locale/ky.js",
            "./ky.js": "./node_modules/moment/locale/ky.js",
            "./lb": "./node_modules/moment/locale/lb.js",
            "./lb.js": "./node_modules/moment/locale/lb.js",
            "./lo": "./node_modules/moment/locale/lo.js",
            "./lo.js": "./node_modules/moment/locale/lo.js",
            "./lt": "./node_modules/moment/locale/lt.js",
            "./lt.js": "./node_modules/moment/locale/lt.js",
            "./lv": "./node_modules/moment/locale/lv.js",
            "./lv.js": "./node_modules/moment/locale/lv.js",
            "./me": "./node_modules/moment/locale/me.js",
            "./me.js": "./node_modules/moment/locale/me.js",
            "./mi": "./node_modules/moment/locale/mi.js",
            "./mi.js": "./node_modules/moment/locale/mi.js",
            "./mk": "./node_modules/moment/locale/mk.js",
            "./mk.js": "./node_modules/moment/locale/mk.js",
            "./ml": "./node_modules/moment/locale/ml.js",
            "./ml.js": "./node_modules/moment/locale/ml.js",
            "./mn": "./node_modules/moment/locale/mn.js",
            "./mn.js": "./node_modules/moment/locale/mn.js",
            "./mr": "./node_modules/moment/locale/mr.js",
            "./mr.js": "./node_modules/moment/locale/mr.js",
            "./ms": "./node_modules/moment/locale/ms.js",
            "./ms-my": "./node_modules/moment/locale/ms-my.js",
            "./ms-my.js": "./node_modules/moment/locale/ms-my.js",
            "./ms.js": "./node_modules/moment/locale/ms.js",
            "./mt": "./node_modules/moment/locale/mt.js",
            "./mt.js": "./node_modules/moment/locale/mt.js",
            "./my": "./node_modules/moment/locale/my.js",
            "./my.js": "./node_modules/moment/locale/my.js",
            "./nb": "./node_modules/moment/locale/nb.js",
            "./nb.js": "./node_modules/moment/locale/nb.js",
            "./ne": "./node_modules/moment/locale/ne.js",
            "./ne.js": "./node_modules/moment/locale/ne.js",
            "./nl": "./node_modules/moment/locale/nl.js",
            "./nl-be": "./node_modules/moment/locale/nl-be.js",
            "./nl-be.js": "./node_modules/moment/locale/nl-be.js",
            "./nl.js": "./node_modules/moment/locale/nl.js",
            "./nn": "./node_modules/moment/locale/nn.js",
            "./nn.js": "./node_modules/moment/locale/nn.js",
            "./pa-in": "./node_modules/moment/locale/pa-in.js",
            "./pa-in.js": "./node_modules/moment/locale/pa-in.js",
            "./pl": "./node_modules/moment/locale/pl.js",
            "./pl.js": "./node_modules/moment/locale/pl.js",
            "./pt": "./node_modules/moment/locale/pt.js",
            "./pt-br": "./node_modules/moment/locale/pt-br.js",
            "./pt-br.js": "./node_modules/moment/locale/pt-br.js",
            "./pt.js": "./node_modules/moment/locale/pt.js",
            "./ro": "./node_modules/moment/locale/ro.js",
            "./ro.js": "./node_modules/moment/locale/ro.js",
            "./ru": "./node_modules/moment/locale/ru.js",
            "./ru.js": "./node_modules/moment/locale/ru.js",
            "./sd": "./node_modules/moment/locale/sd.js",
            "./sd.js": "./node_modules/moment/locale/sd.js",
            "./se": "./node_modules/moment/locale/se.js",
            "./se.js": "./node_modules/moment/locale/se.js",
            "./si": "./node_modules/moment/locale/si.js",
            "./si.js": "./node_modules/moment/locale/si.js",
            "./sk": "./node_modules/moment/locale/sk.js",
            "./sk.js": "./node_modules/moment/locale/sk.js",
            "./sl": "./node_modules/moment/locale/sl.js",
            "./sl.js": "./node_modules/moment/locale/sl.js",
            "./sq": "./node_modules/moment/locale/sq.js",
            "./sq.js": "./node_modules/moment/locale/sq.js",
            "./sr": "./node_modules/moment/locale/sr.js",
            "./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
            "./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
            "./sr.js": "./node_modules/moment/locale/sr.js",
            "./ss": "./node_modules/moment/locale/ss.js",
            "./ss.js": "./node_modules/moment/locale/ss.js",
            "./sv": "./node_modules/moment/locale/sv.js",
            "./sv.js": "./node_modules/moment/locale/sv.js",
            "./sw": "./node_modules/moment/locale/sw.js",
            "./sw.js": "./node_modules/moment/locale/sw.js",
            "./ta": "./node_modules/moment/locale/ta.js",
            "./ta.js": "./node_modules/moment/locale/ta.js",
            "./te": "./node_modules/moment/locale/te.js",
            "./te.js": "./node_modules/moment/locale/te.js",
            "./tet": "./node_modules/moment/locale/tet.js",
            "./tet.js": "./node_modules/moment/locale/tet.js",
            "./tg": "./node_modules/moment/locale/tg.js",
            "./tg.js": "./node_modules/moment/locale/tg.js",
            "./th": "./node_modules/moment/locale/th.js",
            "./th.js": "./node_modules/moment/locale/th.js",
            "./tl-ph": "./node_modules/moment/locale/tl-ph.js",
            "./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
            "./tlh": "./node_modules/moment/locale/tlh.js",
            "./tlh.js": "./node_modules/moment/locale/tlh.js",
            "./tr": "./node_modules/moment/locale/tr.js",
            "./tr.js": "./node_modules/moment/locale/tr.js",
            "./tzl": "./node_modules/moment/locale/tzl.js",
            "./tzl.js": "./node_modules/moment/locale/tzl.js",
            "./tzm": "./node_modules/moment/locale/tzm.js",
            "./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
            "./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
            "./tzm.js": "./node_modules/moment/locale/tzm.js",
            "./ug-cn": "./node_modules/moment/locale/ug-cn.js",
            "./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
            "./uk": "./node_modules/moment/locale/uk.js",
            "./uk.js": "./node_modules/moment/locale/uk.js",
            "./ur": "./node_modules/moment/locale/ur.js",
            "./ur.js": "./node_modules/moment/locale/ur.js",
            "./uz": "./node_modules/moment/locale/uz.js",
            "./uz-latn": "./node_modules/moment/locale/uz-latn.js",
            "./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
            "./uz.js": "./node_modules/moment/locale/uz.js",
            "./vi": "./node_modules/moment/locale/vi.js",
            "./vi.js": "./node_modules/moment/locale/vi.js",
            "./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
            "./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
            "./yo": "./node_modules/moment/locale/yo.js",
            "./yo.js": "./node_modules/moment/locale/yo.js",
            "./zh-cn": "./node_modules/moment/locale/zh-cn.js",
            "./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
            "./zh-hk": "./node_modules/moment/locale/zh-hk.js",
            "./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
            "./zh-tw": "./node_modules/moment/locale/zh-tw.js",
            "./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
        };
        function webpackContext(req) {
            var id = webpackContextResolve(req);
            return __webpack_require__(id);
        }
        function webpackContextResolve(req) {
            if (!__webpack_require__.o(map, req)) {
                var e = new Error("Cannot find module '" + req + "'");
                e.code = "MODULE_NOT_FOUND";
                throw e;
            }
            return map[req];
        }
        webpackContext.keys = function webpackContextKeys() {
            return Object.keys(map);
        };
        webpackContext.resolve = webpackContextResolve;
        module.exports = webpackContext;
        webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";
    },
    "./src/components/assets/ZextrasIconFont.svg": function(module, exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "43fe43c6cd4ad4736c1b36c0e293cb28.svg";
    },
    "./src/components/assets/ZextrasIconFont.ttf": function(module, exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "8d61aac8b97f0e9677634952ab269247.ttf";
    },
    "./src/components/assets/ZextrasIconFont.woff": function(module, exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "f86bc9db38f1df5f9ee1e2b30c1c87c0.woff";
    },
    "./src/components/assets/logo-team-noballs.svg": function(module, exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "70e72abccc43318dc1c264c915341dfe.svg";
    },
    "./src/components/loading/LoadingAnimation.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return LoadingAnimation;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/components/loading/LoadingAnimation.less");
        var _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1__);
        function LoadingAnimation() {
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.threeBounce
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: [ _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.child, _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.bounce1 ].join(" ")
            }), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: [ _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.child, _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.bounce2 ].join(" ")
            }), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: [ _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.child, _LoadingAnimation_less__WEBPACK_IMPORTED_MODULE_1___default.a.bounce3 ].join(" ")
            }));
        }
    },
    "./src/components/loading/LoadingAnimation.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/components/loading/LoadingAnimation.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/components/loading/LoadingPage.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return LoadingPage;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _LoadingPage_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/components/loading/LoadingPage.less");
        var _LoadingPage_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_LoadingPage_less__WEBPACK_IMPORTED_MODULE_1__);
        var _LoadingAnimation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/components/loading/LoadingAnimation.js");
        function LoadingPage(_ref) {
            var className = _ref.className;
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: [ className, _LoadingPage_less__WEBPACK_IMPORTED_MODULE_1___default.a.container ].join(" ")
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_LoadingAnimation__WEBPACK_IMPORTED_MODULE_2__["default"], null));
        }
    },
    "./src/components/loading/LoadingPage.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/components/loading/LoadingPage.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/constants.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "REQUEST_TIMEOUT", (function() {
            return REQUEST_TIMEOUT;
        }));
        var REQUEST_TIMEOUT = 5e3;
    },
    "./src/featureDetector.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "browserSupportWebSocket", (function() {
            return browserSupportWebSocket;
        }));
        __webpack_require__.d(__webpack_exports__, "browserSupportPromise", (function() {
            return browserSupportPromise;
        }));
        __webpack_require__.d(__webpack_exports__, "browserSupportIntersectionObserver", (function() {
            return browserSupportIntersectionObserver;
        }));
        __webpack_require__.d(__webpack_exports__, "browserSupportWindowScrollTo", (function() {
            return browserSupportWindowScrollTo;
        }));
        __webpack_require__.d(__webpack_exports__, "browserSupportCaptureStream", (function() {
            return browserSupportCaptureStream;
        }));
        __webpack_require__.d(__webpack_exports__, "browserSupportWebrtc", (function() {
            return browserSupportWebrtc;
        }));
        __webpack_require__.d(__webpack_exports__, "featureMap", (function() {
            return featureMap;
        }));
        __webpack_require__.d(__webpack_exports__, "browserSupportForAllSelectedFeature", (function() {
            return browserSupportForAllSelectedFeature;
        }));
        __webpack_require__.d(__webpack_exports__, "mobileAndTabletCheck", (function() {
            return mobileAndTabletCheck;
        }));
        var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
        var browserSupportWebSocket = function browserSupportWebSocket() {
            return "WebSocket" in window || "MozWebSocket" in window;
        };
        var browserSupportPromise = function browserSupportPromise() {
            return "Promise" in window;
        };
        var browserSupportIntersectionObserver = function browserSupportIntersectionObserver() {
            return "IntersectionObserver" in window;
        };
        var browserSupportWindowScrollTo = function browserSupportWindowScrollTo() {
            return "scrollTo" in window;
        };
        var browserSupportCaptureStream = function browserSupportCaptureStream() {
            var canvas = document.createElement("canvas");
            try {
                var ctx = canvas.getContext("2d");
                canvas.captureStream();
            } catch (e) {
                console.error(e.stack);
                return false;
            }
            return true;
        };
        var browserSupportWebrtc = function browserSupportWebrtc() {
            var isWebRTCSupported = navigator.mediaDevices != null && navigator.mediaDevices.getUserMedia != null && window.RTCPeerConnection != null;
            return isWebRTCSupported;
        };
        var featureMap = {
            WEB_RTC: "webRtc",
            PROMISE: "promise",
            WEB_SOCKET: "webSocket",
            INTERSECTION_OBSERVER: "IntersectionObserver",
            WINDOW_SCROLL_TO: "scrollTo",
            CAPTURE_STREAM: "captureStream"
        };
        var browserSupportForAllSelectedFeature = function browserSupportForAllSelectedFeature() {
            var result = true;
            for (var _len = arguments.length, features = new Array(_len), _key = 0; _key < _len; _key++) {
                features[_key] = arguments[_key];
            }
            if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["includes"])(features, featureMap.PROMISE)) {
                result = browserSupportPromise();
                if (result === false) {
                    return result;
                }
            }
            if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["includes"])(features, featureMap.WEB_RTC)) {
                result = browserSupportWebrtc();
                if (result === false) {
                    return result;
                }
            }
            if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["includes"])(features, featureMap.WEB_SOCKET)) {
                result = browserSupportWebSocket();
                if (result === false) {
                    return result;
                }
            }
            if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["includes"])(features, featureMap.INTERSECTION_OBSERVER)) {
                result = browserSupportIntersectionObserver();
                if (result === false) {
                    return result;
                }
            }
            if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["includes"])(features, featureMap.WINDOW_SCROLL_TO)) {
                result = browserSupportWindowScrollTo();
                if (result === false) {
                    return result;
                }
            }
            if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["includes"])(features, featureMap.CAPTURE_STREAM)) {
                result = browserSupportCaptureStream();
                if (result === false) {
                    return result;
                }
            }
            return result;
        };
        var mobileAndTabletCheck = function mobileAndTabletCheck() {
            var check = false;
            (function(a) {
                if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true;
            })(navigator.userAgent || navigator.vendor || window.opera);
            return check;
        };
    },
    "./src/network/ApiClient.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "ApiClient", (function() {
            return ApiClient;
        }));
        var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/rxjs/_esm5/index.js");
        var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/moment/moment.js");
        var moment__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
        var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/rxjs/_esm5/operators/index.js");
        var _links_ws_WsLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/network/links/ws/WsLink.js");
        var _links_ws_MockedWsLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/network/links/ws/MockedWsLink.js");
        var _links_ws_MockedWsLink__WEBPACK_IMPORTED_MODULE_4___default = __webpack_require__.n(_links_ws_MockedWsLink__WEBPACK_IMPORTED_MODULE_4__);
        var _links_ws_notifications_IMeetingJoinedNotification__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/network/links/ws/notifications/IMeetingJoinedNotification.js");
        var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/constants.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var KEY_SESSION_DATA = "team_session";
        var ApiClient = function() {
            function ApiClient(apiLink, capabilities) {
                _defineProperty(this, "isConnected", void 0);
                _defineProperty(this, "currentSession", void 0);
                _defineProperty(this, "_capabilities", void 0);
                _defineProperty(this, "_apiLink", void 0);
                _defineProperty(this, "_currentApiVersion", void 0);
                _defineProperty(this, "_authToken", void 0);
                _defineProperty(this, "_wsLink", void 0);
                this._capabilities = capabilities;
                this._apiLink = apiLink;
                this._currentApiVersion = ApiClient.MIN_API_VERSION;
                this._authToken = {
                    cookie: "",
                    expire_on: 0
                };
                this.currentSession = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](ApiClient._getStoredSessionInfo());
                this.currentSession.subscribe(ApiClient._storeSessionInfo);
                this._wsLink = new (false ? undefined : _links_ws_WsLink__WEBPACK_IMPORTED_MODULE_3__["WsLink"])(this._currentApiVersion);
                this.isConnected = this._wsLink.isConnected;
            }
            ApiClient._getStoredSessionInfo = function _getStoredSessionInfo() {
                var data = localStorage.getItem(KEY_SESSION_DATA);
                if (!__TEAM_IS_CLASSIC_ZIMLET && !__TEAM_IS_STANDALONE_APP && data != null) {
                    return JSON.parse(data);
                }
            };
            ApiClient._storeSessionInfo = function _storeSessionInfo(loginData) {
                if (!__TEAM_IS_CLASSIC_ZIMLET && !__TEAM_IS_STANDALONE_APP && loginData != null) {
                    localStorage.setItem(KEY_SESSION_DATA, JSON.stringify(loginData));
                } else {
                    localStorage.removeItem(KEY_SESSION_DATA);
                }
            };
            var _proto = ApiClient.prototype;
            _proto.login = function login(username, password) {
                var _this = this;
                return new Promise((function(resolve, reject) {
                    if (_this.currentSession.getValue() != null) {
                        resolve(_this.currentSession.getValue());
                    }
                    var authData = {};
                    if (typeof username === "undefined") {
                        authData.auth_method = "zimbra_token";
                    } else {
                        authData.auth_method = "password";
                        authData.email = username;
                        authData.password = password;
                    }
                    _this._executeLoginRequest(authData).then(resolve)["catch"](_this._interceptRejection(reject));
                }));
            };
            _proto.loginMeeting = function loginMeeting(email, name, password) {
                var _this2 = this;
                return new Promise((function(resolve, reject) {
                    _this2._executeLoginRequest({
                        auth_method: "anonymous_access",
                        name: name,
                        email: email,
                        password: password
                    }).then(resolve)["catch"](_this2._interceptRejection(reject));
                }));
            };
            _proto.logout = function logout() {
                var _this3 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/logout";
                return new Promise((function(resolve, reject) {
                    _this3._wsLink.disconnect();
                    _this3.currentSession.next(void 0);
                    _this3._apiLink(ENDPOINT, {}).then((function(response) {
                        _this3._currentApiVersion = ApiClient.MIN_API_VERSION;
                        _this3._authToken = {
                            cookie: "",
                            expire_on: 0
                        };
                        resolve(void 0);
                    }))["catch"](_this3._interceptRejection(reject));
                }));
            };
            _proto.getHistory = function getHistory(conversation_id, from, to) {
                var _this4 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/getHistory";
                return new Promise((function(resolve, reject) {
                    _this4._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        from: from,
                        to: to
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this4._interceptRejection(reject));
                }));
            };
            _proto.getConversations = function getConversations(newer_than) {
                var _this5 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/getConversations";
                return new Promise((function(resolve, reject) {
                    _this5._apiLink(ENDPOINT, {
                        newer_than: newer_than
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this5._interceptRejection(reject));
                }));
            };
            _proto.uploadUserPicture = function uploadUserPicture(file) {
                var _this6 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/uploadUserPicture";
                return new Promise((function(resolve, reject) {
                    _this6._apiLink(ENDPOINT, {
                        file: file
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this6._interceptRejection(reject));
                }));
            };
            _proto.uploadConversationPicture = function uploadConversationPicture(file, conversation_id) {
                var _this7 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/uploadConversationPicture";
                var QUERY_STRING = "?conversation_id=" + encodeURIComponent(conversation_id);
                return new Promise((function(resolve, reject) {
                    _this7._apiLink(ENDPOINT + QUERY_STRING, {
                        file: file
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this7._interceptRejection(reject));
                }));
            };
            _proto.sendFile = function sendFile(file, conversation_id, temporary_client_message_id, requestCanceller, description) {
                switch (this._currentApiVersion) {
                  case ApiClient.API_VERSION_V2:
                  case ApiClient.API_VERSION_V1:
                    {
                        return this._currentApiVersionNotSupported("sendFile");
                    }

                  default:
                    {
                        return this._sendFileWithCurrentApiVersionSupported(file, conversation_id, temporary_client_message_id, requestCanceller, description);
                    }
                }
            };
            _proto._sendFileWithCurrentApiVersionSupported = function _sendFileWithCurrentApiVersionSupported(file, conversation_id, temporary_client_message_id, requestCanceller, description) {
                var _this8 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/sendFile";
                var QUERY_STRING = "?conversation_id=" + encodeURIComponent(conversation_id) + "&temporary_client_message_id=" + temporary_client_message_id;
                return new Promise((function(resolve, reject) {
                    _this8._apiLink(ENDPOINT + QUERY_STRING, {
                        file: file,
                        description: description
                    }, requestCanceller).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this8._interceptRejection(reject));
                }));
            };
            _proto._currentApiVersionNotSupported = function _currentApiVersionNotSupported(apiName) {
                var _this9 = this;
                return new Promise((function(resolve, reject) {
                    var error = new Error(apiName + " API unsupported in current API version(" + _this9._currentApiVersion + ")");
                    console.error("Intercept API rejection:", error);
                    reject(error);
                }));
            };
            _proto.getDownloadLink = function getDownloadLink(message_id, conversation_id) {
                var ENDPOINT = "v" + this._currentApiVersion + "/downloadFile";
                var QUERY_STRING = "?message_id=" + encodeURIComponent(message_id) + "&conversation_id=" + encodeURIComponent(conversation_id);
                return "/zx/team/" + ENDPOINT + QUERY_STRING;
            };
            _proto.downloadFile = function downloadFile(message_id, conversation_id) {
                var _this10 = this;
                switch (this._currentApiVersion) {
                  case ApiClient.API_VERSION_V1:
                    {
                        return this._currentApiVersionNotSupported("downloadFile");
                    }

                  default:
                    {
                        var ENDPOINT = "v" + this._currentApiVersion + "/downloadFile";
                        var QUERY_STRING = "?message_id=" + encodeURIComponent(message_id) + "&conversation_id=" + encodeURIComponent(conversation_id);
                        return new Promise((function(resolve, reject) {
                            _this10._apiLink(ENDPOINT + QUERY_STRING, {}).then((function(response) {
                                return resolve(response);
                            }))["catch"](_this10._interceptRejection(reject));
                        }));
                    }
                }
            };
            _proto.getConversation = function getConversation(conversation_id) {
                var _this11 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/getConversation";
                return new Promise((function(resolve, reject) {
                    _this11._apiLink(ENDPOINT, {
                        conversation_id: conversation_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this11._interceptRejection(reject));
                }));
            };
            _proto.createConversation = function createConversation(user_id) {
                var _this12 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/createConversation";
                return new Promise((function(resolve, reject) {
                    _this12._apiLink(ENDPOINT, {
                        user_id: user_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this12._interceptRejection(reject));
                }));
            };
            _proto.createGroup = function createGroup(invited_user_ids, topic) {
                var _this13 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/createGroup";
                return new Promise((function(resolve, reject) {
                    _this13._apiLink(ENDPOINT, {
                        invited_user_ids: invited_user_ids,
                        topic: topic
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this13._interceptRejection(reject));
                }));
            };
            _proto.createSpace = function createSpace(name, invited_user_ids, topic) {
                var _this14 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/createSpace";
                return new Promise((function(resolve, reject) {
                    _this14._apiLink(ENDPOINT, {
                        name: name,
                        invited_user_ids: invited_user_ids,
                        topic: topic
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this14._interceptRejection(reject));
                }));
            };
            _proto.createChannel = function createChannel(spaceId, name, topic) {
                var _this15 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/createChannel";
                return new Promise((function(resolve, reject) {
                    _this15._apiLink(ENDPOINT, {
                        space_id: spaceId,
                        name: name,
                        topic: topic
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this15._interceptRejection(reject));
                }));
            };
            _proto.searchContacts = function searchContacts(only_internal, query) {
                var _this16 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/searchContacts";
                return new Promise((function(resolve, reject) {
                    _this16._apiLink(ENDPOINT, {
                        only_internal: only_internal,
                        query: query
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this16._interceptRejection(reject));
                }));
            };
            _proto.getUserDetails = function getUserDetails(emails, user_ids) {
                var _this17 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/getUserDetails";
                return new Promise((function(resolve, reject) {
                    _this17._apiLink(ENDPOINT, {
                        emails: emails,
                        user_ids: user_ids
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this17._interceptRejection(reject));
                }));
            };
            _proto.setConversationTopic = function setConversationTopic(conversation_id, topic) {
                var _this18 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/setConversationTopic";
                return new Promise((function(resolve, reject) {
                    _this18._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        topic: topic
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this18._interceptRejection(reject));
                }));
            };
            _proto.leaveConversation = function leaveConversation(conversation_id) {
                var _this19 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/leaveConversation";
                return new Promise((function(resolve, reject) {
                    _this19._apiLink(ENDPOINT, {
                        conversation_id: conversation_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this19._interceptRejection(reject));
                }));
            };
            _proto.inviteToConversation = function inviteToConversation(conversation_id, invited_user_ids, invited_emails) {
                var _this20 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/inviteToConversation";
                return new Promise((function(resolve, reject) {
                    _this20._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        invited_user_ids: invited_user_ids,
                        invited_emails: invited_emails
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this20._interceptRejection(reject));
                }));
            };
            _proto.joinConversation = function joinConversation(conversation_id) {
                var _this21 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/joinConversation";
                return new Promise((function(resolve, reject) {
                    _this21._apiLink(ENDPOINT, {
                        conversation_id: conversation_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this21._interceptRejection(reject));
                }));
            };
            _proto.kickFromConversation = function kickFromConversation(conversation_id, kicked_user_ids) {
                var _this22 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/kickFromConversation";
                return new Promise((function(resolve, reject) {
                    _this22._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        kicked_user_ids: kicked_user_ids
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this22._interceptRejection(reject));
                }));
            };
            _proto.deleteConversation = function deleteConversation(conversation_id) {
                var _this23 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/deleteConversation";
                return new Promise((function(resolve, reject) {
                    _this23._apiLink(ENDPOINT, {
                        conversation_id: conversation_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this23._interceptRejection(reject));
                }));
            };
            _proto.setConversationName = function setConversationName(conversation_id, name) {
                var _this24 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/setConversationName";
                return new Promise((function(resolve, reject) {
                    _this24._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        name: name
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this24._interceptRejection(reject));
                }));
            };
            _proto.addConversationOwner = function addConversationOwner(conversation_id, user_id) {
                var _this25 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/addConversationOwner";
                return new Promise((function(resolve, reject) {
                    _this25._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        user_id: user_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this25._interceptRejection(reject));
                }));
            };
            _proto.removeConversationOwner = function removeConversationOwner(conversation_id, user_id) {
                var _this26 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/removeConversationOwner";
                return new Promise((function(resolve, reject) {
                    _this26._apiLink(ENDPOINT, {
                        conversation_id: conversation_id,
                        user_id: user_id
                    }).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this26._interceptRejection(reject));
                }));
            };
            _proto.createInstantMeetingWithParamsObj = function createInstantMeetingWithParamsObj(params) {
                var _this27 = this;
                var ENDPOINT = "v" + this._currentApiVersion + "/createInstantMeeting";
                return new Promise((function(resolve, reject) {
                    _this27._apiLink(ENDPOINT, params).then((function(response) {
                        return resolve(response);
                    }))["catch"](_this27._interceptRejection(reject));
                }));
            };
            _proto.joinMeeting = function joinMeeting(conversation_id) {
                var _this28 = this;
                var joinPromise = new Promise((function(resolve, reject) {
                    var temporary_client_meeting_id = conversation_id + moment__WEBPACK_IMPORTED_MODULE_1___default()().valueOf();
                    var joinMeetingParams = {
                        conversation_id: conversation_id,
                        type: "join_meeting",
                        temporary_client_meeting_id: temporary_client_meeting_id
                    };
                    var subscription = _this28._wsLink.onNotification.pipe(_links_ws_notifications_IMeetingJoinedNotification__WEBPACK_IMPORTED_MODULE_5__["meetingJoinedFilter"], Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["filter"])((function(notification) {
                        return notification.temporary_client_meeting_id != null && notification.temporary_client_meeting_id === temporary_client_meeting_id;
                    }))).subscribe((function(meetingJoinedNotification) {
                        subscription.unsubscribe();
                        resolve(meetingJoinedNotification.meeting);
                    }));
                    _this28.send(joinMeetingParams);
                }));
                var timeoutPromise = new Promise((function(resolve, reject) {
                    setTimeout(reject, _constants__WEBPACK_IMPORTED_MODULE_6__["REQUEST_TIMEOUT"], "join_meeting timeout reject");
                }));
                return Promise.race([ joinPromise, timeoutPromise ]);
            };
            _proto._executeLoginRequest = function _executeLoginRequest(data) {
                var _this29 = this;
                var ENDPOINT = "login";
                return new Promise((function(resolve, reject) {
                    _this29._apiLink(ENDPOINT, _extends({}, data, {}, {
                        min_api_version: ApiClient.MIN_API_VERSION,
                        max_api_version: ApiClient.MAX_API_VERSION,
                        capabilities: [].concat(_this29._capabilities)
                    })).then((function(response) {
                        var loginResponse = response;
                        _this29._currentApiVersion = loginResponse.selected_api_version;
                        _this29._authToken = {
                            cookie: loginResponse.auth_token.cookie,
                            expire_on: loginResponse.auth_token.expire_on
                        };
                        var sessionData = {
                            selected_api_version: loginResponse.selected_api_version,
                            public_ws_url: loginResponse.public_ws_url,
                            public_api_url: loginResponse.public_api_url,
                            user_info: _extends({}, loginResponse.user_info),
                            capabilities: _extends({}, loginResponse.capabilities)
                        };
                        _this29.currentSession.next(sessionData);
                        var appUrl = "ws://localhost:9000/zx/ws-chat/" + loginResponse.selected_api_version;
                        var isApp = "com_zimbra_connect_classic" === "app";
                        if (loginResponse.selected_api_version >= 7) {
                            try {
                                if (window.parent.location.hostname != null && loginResponse.public_ws_path != null) {
                                    _this29._wsLink.connect(isApp ? appUrl : "wss://" + window.parent.location.hostname + loginResponse.public_ws_path);
                                }
                            } catch (e) {
                                _this29._wsLink.connect(isApp ? appUrl : loginResponse.public_ws_url);
                            }
                        } else {
                            _this29._wsLink.connect(isApp ? appUrl : loginResponse.public_ws_url);
                        }
                        resolve(sessionData);
                    }))["catch"](_this29._interceptRejection(reject));
                }));
            };
            _proto._interceptRejection = function _interceptRejection(reject) {
                return function _interceptRejection(err) {
                    console.error("Intercept API rejection:", err);
                    reject(err);
                };
            };
            _proto.leaveMeeting = function leaveMeeting(conversation_id) {
                var leaveMeetingParams = {
                    conversation_id: conversation_id,
                    type: "leave_meeting"
                };
                this.send(leaveMeetingParams);
            };
            _proto.send = function send(sendParams) {
                this._wsLink.send(sendParams);
            };
            _proto.getOnNotificationSubject = function getOnNotificationSubject() {
                return this._wsLink.onNotification;
            };
            return ApiClient;
        }();
        _defineProperty(ApiClient, "MIN_API_VERSION", 1);
        _defineProperty(ApiClient, "MAX_API_VERSION", 7);
        _defineProperty(ApiClient, "API_VERSION_V1", 1);
        _defineProperty(ApiClient, "API_VERSION_V2", 2);
        _defineProperty(ApiClient, "API_VERSION_V3", 3);
        _defineProperty(ApiClient, "API_VERSION_V4", 4);
        _defineProperty(ApiClient, "API_VERSION_V5", 5);
        _defineProperty(ApiClient, "API_VERSION_V6", 6);
        _defineProperty(ApiClient, "API_VERSION_V7", 7);
    },
    "./src/network/links/rest/apiLink.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createApiLink;
        }));
        var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
        var query_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/query-string/index.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_1__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function createApiLink(uri) {
            var printDebug = Object(query_string__WEBPACK_IMPORTED_MODULE_1__["parse"])(window.parent.location.search).dev === "1";
            var reqCounter = 0;
            return function(endpoint, postData, requestCanceller) {
                return new Promise((function(resolve, reject) {
                    var downloadFileRegex = /downloadFile/;
                    var uploadUserPictureRegex = /uploadUserPicture/;
                    var uploadConversationPictureRegex = /uploadConversationPicture/;
                    var sendFileRegex = /sendFile/;
                    var currentReqId = reqCounter++;
                    var sendDate = Date.now();
                    if (printDebug) {
                        console.log("" + uri + endpoint + "  [￪ - " + currentReqId + "]", postData);
                    }
                    function returnResponse(resp) {
                        if (printDebug) {
                            console.log("" + uri + endpoint + " [￬ - " + currentReqId + " (" + (Date.now() - sendDate) + "ms)]", resp);
                        }
                        resolve(_extends({}, resp));
                    }
                    function returnError(err) {
                        if (printDebug) {
                            console.error("" + uri + endpoint + " [✗ - " + currentReqId + " (" + (Date.now() - sendDate) + "ms)]", err);
                        }
                        reject(err);
                    }
                    function reqListener() {
                        if (this.status === 200) {
                            var response;
                            try {
                                response = JSON.parse(this.responseText);
                            } catch (e) {
                                returnError({
                                    statusCode: -1,
                                    error: e
                                });
                            }
                            if (response != null) {
                                returnResponse(response);
                            } else {
                                returnError({
                                    statusCode: this.status,
                                    error: new Error("Empty response")
                                });
                            }
                        } else {
                            returnError({
                                statusCode: this.status,
                                error: this.responseText
                            });
                        }
                    }
                    function reqListenerDownloadFile() {
                        if (this.status === 200) {
                            var response;
                            try {
                                response = this.response;
                                console.log(response);
                            } catch (e) {
                                returnError({
                                    statusCode: -1,
                                    error: e
                                });
                            }
                            if (response != null) {
                                returnResponse({
                                    file: response
                                });
                            } else {
                                returnError({
                                    statusCode: this.status,
                                    error: new Error("Empty response")
                                });
                            }
                        } else {
                            returnError({
                                statusCode: this.status
                            });
                        }
                    }
                    function transferFailed() {
                        returnError({
                            statusCode: -1,
                            error: new Error("Transfer failed")
                        });
                    }
                    function transferCanceled() {
                        returnError({
                            statusCode: -1,
                            error: new Error("Transfer Canceled")
                        });
                    }
                    var req = new XMLHttpRequest;
                    if (requestCanceller != null) {
                        requestCanceller.abort = function() {
                            req.abort();
                        };
                    }
                    if (downloadFileRegex.test(endpoint)) {
                        req.addEventListener("load", reqListenerDownloadFile);
                    } else {
                        req.addEventListener("load", reqListener);
                    }
                    req.addEventListener("error", transferFailed);
                    req.addEventListener("abort", transferCanceled);
                    if (downloadFileRegex.test(endpoint)) {
                        req.open("GET", uri + endpoint, true);
                        req.responseType = "blob";
                    } else {
                        req.open("POST", uri + endpoint, true);
                    }
                    if (uploadUserPictureRegex.test(endpoint)) {
                        req.setRequestHeader("Content-Type", postData.file.type);
                        req.send(postData.file);
                    } else if (uploadConversationPictureRegex.test(endpoint)) {
                        req.setRequestHeader("Content-Type", postData.file.type);
                        req.send(postData.file);
                    } else if (sendFileRegex.test(endpoint)) {
                        var contentDispositionHeaderValue = "attachment; filename*=\"UTF-8''" + encodeURIComponent(postData.file.name) + '"';
                        if (postData.description != null) {
                            contentDispositionHeaderValue += "; description*=\"utf-8''" + encodeURIComponent(postData.description) + '"';
                        }
                        req.setRequestHeader("Content-Disposition", contentDispositionHeaderValue);
                        req.setRequestHeader("Content-Type", postData.file.type);
                        req.send(postData.file);
                    } else {
                        postData = Object(lodash__WEBPACK_IMPORTED_MODULE_0__["omitBy"])(postData, lodash__WEBPACK_IMPORTED_MODULE_0__["isUndefined"]);
                        req.send(JSON.stringify(postData));
                    }
                }));
            };
        }
    },
    "./src/network/links/rest/mockedApiLink.js": function(module, exports) {},
    "./src/network/links/ws/MockedWsLink.js": function(module, exports) {},
    "./src/network/links/ws/WsLink.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "WsLink", (function() {
            return WsLink;
        }));
        var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/rxjs/_esm5/index.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/query-string/index.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_1__);
        var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var WsLink = function() {
            function WsLink(currentApiVersion) {
                var _this = this;
                _defineProperty(this, "isConnected", void 0);
                _defineProperty(this, "onNotification", void 0);
                _defineProperty(this, "_currentApiVersion", void 0);
                _defineProperty(this, "_socketReconnectDelay", void 0);
                _defineProperty(this, "_socketClosed", void 0);
                _defineProperty(this, "_webSocket", void 0);
                _defineProperty(this, "_public_ws_url", void 0);
                _defineProperty(this, "_openDate", void 0);
                _defineProperty(this, "_printDebug", void 0);
                _defineProperty(this, "_navigatorOnline", void 0);
                _defineProperty(this, "_debouncedDisconnect", void 0);
                _defineProperty(this, "_onOpenHandler", (function(e) {
                    _this._openDate = Date.now();
                    _this.isConnected.next(true);
                    if (_this._socketClosed === true) {
                        _this._socketClosed = false;
                        _this._socketReconnectDelay = 1e3;
                    }
                }));
                _defineProperty(this, "_onMessageHandler", (function(e) {
                    if (typeof e.data === "string") {
                        var notification = JSON.parse(e.data);
                        if (_this._printDebug) {
                            console.log("WS [￬]", notification);
                        }
                        _this.onNotification.next(notification);
                    }
                }));
                _defineProperty(this, "_onCloseHandler", (function(e) {
                    console.error("[WEBSOCKET close in (" + (Date.now() - _this._openDate) + "ms)]");
                    _this.isConnected.next(false);
                    if (_this._socketClosed === false) {
                        _this._socketClosed = true;
                        _this._createWebSocket();
                    } else {
                        var doubleDelay = _this._socketReconnectDelay * 2;
                        _this._socketReconnectDelay = doubleDelay < 17e3 ? doubleDelay : 16e3;
                        _this._createWebSocket();
                    }
                }));
                _defineProperty(this, "_onErrorHandler", (function(e) {
                    console.log("on error");
                }));
                _defineProperty(this, "connectAndAttach", (function() {
                    if (_this._webSocket != null && _this._webSocket.readyState === 1) {
                        return;
                    }
                    _this._webSocket = new WebSocket(_this._public_ws_url);
                    _this._attachWsEventListeners(_this._webSocket);
                }));
                this._currentApiVersion = currentApiVersion;
                this.isConnected = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](false);
                this.onNotification = new rxjs__WEBPACK_IMPORTED_MODULE_0__["Subject"];
                this._socketClosed = false;
                this._socketReconnectDelay = 1e3;
                this._printDebug = Object(query_string__WEBPACK_IMPORTED_MODULE_1__["parse"])(location.search).dev === "1";
                this._debouncedDisconnect = Object(lodash__WEBPACK_IMPORTED_MODULE_2__["debounce"])((function() {
                    console.log("The network connection has been lost.");
                    _this.disconnect();
                    _this._navigatorOnline = false;
                }), 500);
                window.parent.addEventListener("offline", (function() {
                    _this._debouncedDisconnect();
                }));
                window.parent.addEventListener("online", (function() {
                    console.log("You are now connected to the network.");
                    _this._debouncedDisconnect.cancel();
                    _this._navigatorOnline = true;
                    _this.connect();
                }));
            }
            var _proto = WsLink.prototype;
            _proto.setCurrentApiVersion = function setCurrentApiVersion(version) {
                this.disconnect();
                this._currentApiVersion = version;
                this.connect();
            };
            _proto.connect = function connect(public_ws_url) {
                if (public_ws_url != null) {
                    this._public_ws_url = public_ws_url;
                }
                this._createWebSocket();
            };
            _proto.disconnect = function disconnect() {
                this._destroyWebSocket();
            };
            _proto.send = function send(sendParams) {
                if (this._webSocket != null && this._webSocket.readyState === 1) {
                    if (this._printDebug) {
                        console.log("WS [￪]", sendParams);
                    }
                    this._webSocket.send(JSON.stringify(sendParams));
                }
            };
            _proto._attachWsEventListeners = function _attachWsEventListeners(ws) {
                ws.addEventListener("message", this._onMessageHandler);
                ws.addEventListener("open", this._onOpenHandler);
                ws.addEventListener("close", this._onCloseHandler);
                ws.addEventListener("error", this._onErrorHandler);
            };
            _proto._destroyWebSocket = function _destroyWebSocket() {
                if (this._webSocket != null) this._webSocket.close();
                if (this._webSocket != null) this._webSocket.removeEventListener("message", this._onMessageHandler);
                if (this._webSocket != null) this._webSocket.removeEventListener("open", this._onOpenHandler);
                if (this._webSocket != null) this._webSocket.removeEventListener("close", this._onCloseHandler);
                if (this._webSocket != null) this._webSocket.removeEventListener("error", this._onErrorHandler);
                this._webSocket = void 0;
                this._socketClosed = true;
            };
            _proto._createWebSocket = function _createWebSocket() {
                if (this._socketClosed === true) {
                    setTimeout(this.connectAndAttach, this._socketReconnectDelay);
                } else {
                    this.connectAndAttach();
                }
            };
            return WsLink;
        }();
    },
    "./src/network/links/ws/notifications/IMeetingJoinedNotification.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "meetingJoinedFilter", (function() {
            return meetingJoinedFilter;
        }));
        var _NotificationTypeMap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/network/links/ws/notifications/NotificationTypeMap.js");
        var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/rxjs/_esm5/operators/index.js");
        var meetingJoinedFilter = Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["filter"])((function(notification) {
            return notification.type === _NotificationTypeMap__WEBPACK_IMPORTED_MODULE_0__["TeamNotificationTypeMap"].meeting_joined;
        }));
    },
    "./src/network/links/ws/notifications/NotificationTypeMap.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "OpenNotificationTypeMap", (function() {
            return OpenNotificationTypeMap;
        }));
        __webpack_require__.d(__webpack_exports__, "TeamNotificationTypeMap", (function() {
            return TeamNotificationTypeMap;
        }));
        var OpenNotificationTypeMap = {
            new_message: "new_message",
            writing_status: "writing_status",
            message_ack: "message_ack",
            user_presence: "user_presence",
            user_details: "user_details"
        };
        var TeamNotificationTypeMap = {
            conversation_owner_changed: "conversation_owner_changed",
            new_meeting: "new_meeting",
            meeting_answered: "meeting_answered",
            meeting_closed: "meeting_closed",
            meeting_session_list: "meeting_session_list",
            webrtc_data: "webrtc_data",
            meeting_joined: "meeting_joined",
            preview_ready: "preview_ready"
        };
    }
} ]);
//# sourceMappingURL=10.e193c214.chunk.js.map