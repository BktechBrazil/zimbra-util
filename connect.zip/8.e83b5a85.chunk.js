(window["com_zimbra_connect_classic_jsonp"] = window["com_zimbra_connect_classic_jsonp"] || []).push([ [ 8 ], {
    "./src/i18n/translations/team_web_client_de.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                channelInfo: "Kanalinformationen",
                spaceInfo: "Space- Informationen",
                groupInfo: "Gruppeninformationen",
                contactInfo: "Kontaktdaten",
                invite: "In Gruppe einladen",
                new: {
                    instantMeeting: "Neues Instant Meeting",
                    channel: "Neuer Kanal",
                    space: "Neuer Space",
                    group: "Neue Gruppe",
                    conversation: "Neue Unterhaltung"
                },
                channels: "Kanäle",
                conversations: "Unterhaltungen",
                instantInfo: "Instant Meeting Info",
                filter: {
                    channel: "Gefilterte Kanäle",
                    conversation: "Gefilterte Unterhaltungen"
                }
            },
            contactInfo: "Kontaktdaten",
            commonSpaces: "Gemeinsame Spaces",
            commonGroups: "Gemeinsame Gruppen",
            participants: "Teilnehmer",
            topic: "Thema",
            phone: "Telefon",
            bio: "Biographie",
            name: "Name",
            email: "E-Mail",
            chat: "Chat",
            general: "{{spaceName}} - Allgemein",
            status: {
                last_seen: "Zuletzt gesehen {{lastSeen}}",
                offline: "Offline",
                online: "Online",
                guest: "Gast"
            },
            new: {
                speakToYourFriend: "Mit Ihrem Freund sprechen",
                invite: "Teilnehmer hinzufügen",
                spaceSelect: "Wählen Sie einen Space aus, um einen Kanal zu erstellen",
                spaceSelectRequire: "Erforderlich. Kanäle sind immer an einen Space geknüpft",
                nameRequired: "Erforderlich. Max. 140 Zeichen, bereits genutzte Namen vermeiden",
                "channel-optionalTopic": "Optional. Beschreibt den Inhalt des Kanals",
                "space-optionalTopic": "Optional. Beschreibt den Inhalt",
                "group-optionalTopic": "Optional. Beschreibt den Inhalt der Gruppe",
                optional: "optional",
                selectPic: "Wählen Sie ein Bild aus",
                instantMeeting: "Neues Instant Meeting",
                channel: "Neuer Kanal",
                space: "Neuer Space",
                group: "Neue Gruppe",
                conversation: "Neue Unterhaltung",
                attendee: {
                    feedback: {
                        negative: "Die eingegebene E-Mail Adresse ist nicht gültig, bitte geben Sie eine gültige E-Mail ein",
                        emailReplicated: "Die eingegebene E-Mail wurde bereits hinzugefügt",
                        neutral: "EINGABE - Taste drücken, um die Adresse zur Teilnehmerliste hinzuzufügen",
                        positive: "Teilnehmer zur Liste hinzugefügt"
                    },
                    empty: "Sie haben noch keine Teilnehmer hinzugefügt",
                    title: "Teilnehmerliste",
                    invite: "Teilnehmer hinzufügen"
                },
                participants: {
                    limit: "Sie können bis zu {{max_participants}} Leute einladen",
                    requires: {
                        one: "Erfordert zumindest einen weiteren Teilnehmer",
                        two: "Erfordert zumindest 2 weitere"
                    }
                }
            },
            button: {
                remove: "Entfernen",
                delete: "Löschen",
                leave: "Verlassen",
                join: "Beitreten",
                new: "NEU",
                start: "Start"
            },
            treeMenu: {
                instantMeeting: "Instant Meeting",
                spaces: "Spaces",
                conversations: "Unterhaltungen"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "Ihre Kamera und Ihr Mikrofon sind ausgeschaltet",
                        cameraOff: "Ihre Kamera ist ausgeschaltet"
                    },
                    hideUserVideo: "Video dieses Benutzers verbergen",
                    showUserVideo: "Video dieses Benutzers zeigen",
                    muteUserAudio: "Audio dieses Benutzers stumm schalten",
                    unmuteUserAudio: "Audio dieses Benutzers laut schalten",
                    enableScreenSharing: "ScreenSharing einschalten",
                    disableScreensharing: "ScreenSharing ausschalten",
                    enableVideo: "Video einschalten",
                    disableVideo: "Video ausschalten",
                    enableAudio: "Audio einschalten",
                    disableAudio: "Audio ausschalten",
                    closeCall: "Diesen Anruf beenden",
                    pttHint: "'T' zum Sprechen gedrückt halten"
                },
                startModal: {
                    enter: "Eingabe",
                    noVideoAndNoAudio: "Kamera aus, Mikrofon aus",
                    videoAndNoAudio: "Kamera an, Mikrofon aus",
                    noVideoAndAudio: "Kamera aus, Mikrofon an",
                    videoAndAudio: "Kamera an, Mikrofon an",
                    save: "Diese Einstellungen speichern",
                    cancel: "Abbrechen",
                    description: "Wie möchten Sie dem Meeting beitreten?"
                }
            },
            modal: {
                endCallByOwner: "Der Besitzer dieses Instant Meetings hat entschieden, den Anruf zu beenden. Wir hoffen, dass Ihnen das Instant Meeting Erlebnis gefallen hat.",
                closedInstantMeeting: "Instant Meeting geschlossen"
            },
            undo: "Rückgängig machen",
            edit: "Bearbeiten",
            input: {
                topicMax255Characters: "Max. 255 Zeichen",
                topicNeeds2Letters: "Das Gruppenthema muss aus mindestens zwei Buchstaben bestehen (oder gar keinen)",
                topicOptional: "Optional. Beschreibt den Inhalt",
                "nameRequired-max140Characters-avoidReusingNames": "Erforderlich. Max. 140 Zeichen, bereits genutzte Namen vermeiden",
                nameMax140Characters: "Max. 140 Zeichen",
                nameRequired: "Ein Name ist erforderlich",
                nameNeeds2Letters: "Der Name muss aus mindestens zwei Buchstaben bestehen"
            },
            action: {
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Ein anderes Instant Meeting läuft gerade.\nEs kann nur ein Instant Meeting zur gleichen Zeit geben",
                inviteFeedback: "Einladung versendet",
                copyLink: "oder kopieren Sie den Link und verschicken Sie ihn",
                scrollToNewMessage: "Zur neuen Nachricht scrollen",
                scrollToTheBottom: "Nach unten scrollen",
                returnToCallTab: "Gehe zum Meeting Registerkarte",
                joinChannel: "Treten Sie dem Kanal bei, um Nachrichten zu senden und Benachrichtigungen zu erhalten",
                silenceGeneral: "Allgemein stumm schalten",
                confirm: {
                    deleteChannel: "Sind Sie sicher, dass Sie diesen Kanal löschen möchten?",
                    leaveChannel: "Sind Sie sicher, dass Sie diesen Kanal verlassen möchten?",
                    deleteSpace: "Sind sie sicher, dass Sie den Space löschen möchten?",
                    removeBuddy: "Sind Sie sicher, dass Sie diesen Freund entfernen möchten?",
                    leaveGroup: "Sind Sie sicher, dass Sie die Gruppe verlassen möchten?"
                },
                joinChannelAction: "Diesem Kanal beitreten",
                deleteChannel: "Kanal löschen",
                deleteSpace: "Space löschen",
                leaveSpace: "Space verlassen",
                inviteToSpace: "In den Space einladen",
                leaveChannel: "Diesen Kanal verlassen",
                removeBuddy: "Freund entfernen",
                leaveGroup: "Gruppe verlassen",
                inviteParticipants: "Teilnehmer hinzufügen",
                blockUser: "Benutzer sperren",
                clearHistory: "Verlauf löschen",
                sendConversation: "Unterhaltung per E-Mail schicken",
                silenceConversation: "Unterhaltung stumm schalten"
            },
            instantMeeting: {
                continue: "Mit dem alten Instant Meeting fortfahren",
                create: "Ein neues Instant Meeting erstellen"
            },
            instantMeetingAlreadyRunningText: "Durch das Erstellen einer Neuen wird die Vorherige beendet und die Teilnehmer werden die Verbindung verlieren. Was möchten Sie tun?",
            instantMeetingAlreadyRunningTitle: "Ein Instant Meeting läuft bereits.",
            error: {
                uploadConversationPicturesFailed: "Upload des Unterhaltungsbildes fehlgeschlagen",
                uploadPicturesFailed: "Upload des Profilbildes fehlgeschlagen"
            },
            notification: {
                markAllAsRead: "Alle als gelesen markieren",
                member: {
                    channel: {
                        join: "{{member_name}} ist dem Kanal beigetreten"
                    },
                    join: "{{member_name}} ist der Unterhaltung beigetreten",
                    deleted: {
                        space: "{{member_name}} hat den Space gelöscht",
                        channel: "{{member_name}} hat den Kanal gelöscht",
                        instantMeeting: "{{member_name}} hat das Instant Meeting gelöscht"
                    },
                    created: {
                        space: "{{member_name}} hat den Space erstellt",
                        channel: "{{member_name}} hat den Kanal erstellt",
                        group: "{{member_name}} hat die Gruppe erstellt",
                        single: "{{member_name}} hat die Unterhaltung erstellt"
                    },
                    you: {
                        kicked: {
                            space: "Sie haben {{member_name}} aus dem Space entfernt",
                            channel: "Sie haben {{member_name}} aus dem Kanal entfernt"
                        },
                        invited: "Sie haben {{member_name}} eingeladen"
                    },
                    kicked: {
                        space: "{{member_name}} wurde von {{kicked_by}} aus dem Space entfernt",
                        channel: "{{member_name}} wurde von {{kicked_by}} aus dem Kanal entfernt"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} hat das Space-Bild geändert",
                            channel: "{{member_name}} hat das Kanalbild geändert",
                            group: "{{member_name}} hat das Gruppenbild geändert"
                        },
                        name: {
                            space: "{{member_name}} hat den Space - Namen zu {{topic}} geändert",
                            channel: "{{member_name}} hat den Kanalnamen zu {{topic}} geändert"
                        },
                        topic: {
                            space: "{{member_name}} hat das Kanal- Thema zu {{topic}} geändert",
                            channel: "{{member_name}} hat das Kanalthema zu {{topic}} geändert",
                            group: "{{member_name}} hat das Gruppenthema zu {{topic}} geändert"
                        }
                    },
                    left: {
                        space: "{{member_name}} hat den Space verlassen",
                        channel: "{{member_name}} hat den Kanal verlassen",
                        group: "{{member_name}} hat die Gruppe verlassen"
                    },
                    invited: "{{member_name}} wurde von {{invited_by}} eingeladen"
                },
                drive_size_exceeded: "Die Datei ist zu groß",
                newMessage: "Neue Nachricht",
                unreadMessages: "Ungelesene Nachrichten",
                remindLater: "Erinnere mich später…",
                dismiss: "Abweisen",
                answer: "Annehmen",
                newMeeting: "Eingehender Anruf von:",
                meeting: {
                    ended: "Meeting beendet",
                    started: "Meeting hat begonnen"
                },
                you: {
                    deleted: {
                        space: "Sie haben den Space gelöscht",
                        channel: "Sie haben den Kanal gelöscht",
                        instantMeeting: "Sie haben das Instant Meeting gelöscht"
                    },
                    created: {
                        space: "Sie haben den Space erstellt",
                        channel: "Sie haben den Kanal erstellt",
                        group: "Sie haben die Gruppe erstellt",
                        single: "Sie haben die Unterhaltung erstellt"
                    },
                    kicked: {
                        space: "Sie wurden von{{kicked_by}} aus dem Space entfernt",
                        channel: "Sie wurden von {{kicked_by}} aus dem Kanal entfernt"
                    },
                    changed: {
                        picture: {
                            space: "Sie haben den Space-Namen geändert",
                            channel: "Sie haben das Kanalbild geändert",
                            group: "Sie haben das Gruppenbild geändert"
                        },
                        name: {
                            space: "Sie haben den Space- Namen zu {{topic}} geändert",
                            channel: "Sie haben den Kanalnamen zu {{topic}} geändert"
                        },
                        topic: {
                            space: "Sie haben das Space - Thema zu {{topic}} geändert",
                            channel: "Sie haben das Kanalthema zu {{topic}} geändert",
                            group: "Sie haben das Gruppenthema zu {{topic}} geändert"
                        }
                    },
                    left: {
                        space: "Sie haben den Space verlassen",
                        channel: "Sie haben den Kanal verlassen",
                        group: "Sie haben die Gruppe verlassen"
                    },
                    invited: "Sie wurden von {{invited_by}} eingeladen",
                    join: {
                        instantMeeting: "Sie sind dem Instant Meeting beigetreten",
                        space: "Sie sind dem Space beigetreten",
                        channel: "Sie sind dem Kanal beigetreten",
                        group: "Sie sind der Gruppe beigetreten"
                    }
                },
                conversation: {
                    created: "Unterhaltung erstellt"
                }
            },
            message: {
                browserNotSupported: {
                    Connect: "Wir unterstützen diese Version Ihres Browsers nicht. Wir empfehlen Ihnen dringend, Ihren Browser zu aktualisieren, um alle Connect Funktionen zu nutzen!",
                    Team: "Wir unterstützen diese Version Ihres Browsers nicht. Wir empfehlen Ihnen dringend, Ihren Browser zu aktualisieren, um alle Team Funktionen zu nutzen!"
                },
                popup: {
                    readBy: "Gelesen von"
                }
            },
            contactOwner: "Bitte kontaktieren Sie den Besitzer.",
            fileNotAvailable: "Datei nicht verfügbar.",
            placeholder: {
                limit: {
                    overquota: "Diese Gruppe hat die zugelassene Höchstzahl an Teilnehmern erreicht",
                    reached: "Um andere Leute einzuladen, entfernen sie einen der ausgewählten Kontakte"
                },
                writeMail: "Schreiben Sie eine E-Mail Adresse",
                filter: "Schreiben, um die Liste zu filtern",
                searchResults: "Beginnen Sie, untern zu schreiben, um Suchergebnisse zu sehen",
                pickAddress: "Beginnen Sie zu schreiben, um eine Adresse auszuwählen",
                addTopic: "Thema hinzufügen"
            },
            settings: {
                notification: {
                    title: {
                        hint: "Nachrichtenvorschau in Benachrichtigungen anzeigen",
                        minichat: "Minimierten Chat öffnen, wenn eine neue Nachricht ankommt",
                        notifications: "Benachrichtigungen"
                    },
                    desktop: "Desktop Benachrichtigungen",
                    spawn: {
                        label: "Zeitspanne der Benachrichtigung"
                    },
                    spawn0: "Niemals verschwinden",
                    spawn10: "10 Sekunden",
                    spawn5: "5 Sekunden",
                    spawn3: "3 Sekunden",
                    meeting: "Benachrichtigungen während Meetings",
                    zimbra: "Zimbra Benachrichtigungen",
                    team: "Team Benachrichtigungen",
                    connect: "Connect Benachrichtigungen"
                },
                avatar: {
                    size: "Maximale Größe 256kB",
                    autocenter: "Das Bild wird automatisch zentriert."
                },
                profile: {
                    title: "Profil",
                    maximumDimension: "Maximale Größe: 256kb.",
                    update: "Aktualisierung",
                    restore: "Wiederherstellen"
                },
                connect: {
                    title: "Connect Einstellungen"
                },
                team: {
                    title: "Team Einstellungen"
                },
                meeting: {
                    title: {
                        meetingStart: "Meeting Anfangseinstellungen"
                    },
                    default: {
                        video: "Kamera",
                        audio: "Mikrofon"
                    }
                },
                notifications: {
                    title: "Benachrichtigungen"
                }
            },
            mail: {
                invite: {
                    redirect: "Zum Space gehen",
                    space: "Sie wurden in einen neuen Space eingeladen!",
                    generated_by_team: "Diese email wurde automatisch von Team erstellt",
                    generated_by_connect: "Diese email wurde automatisch von Zimbra Connect erstellt",
                    follow_to_join: "Um dem Meeting beizutreten, nutzen Sie bitte diesen Link:",
                    join_now: "Jetzt beitreten",
                    message: "Sie wurden eingeladen, dem Meeting beizutreten"
                },
                kick: {
                    redirect: "Zu Home gehen",
                    space: "Sie wurden aus diesem Space entfernt"
                }
            },
            selection: {
                participants: {
                    many: "Sie können noch weitere {{limit}} Teilnehmer einladen",
                    one: "Sie können noch einen letzten Teilnehmer einladen",
                    none: "Sie haben die vom Administrator festgelegte Höchstzahl an Teilnehmern erreicht"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}} schreibt…"
                },
                generic: {
                    status: "schreibt…"
                }
            },
            space: {
                administrator: "Space Administrator"
            },
            cancel: "Abbrechen",
            save: "Speichern",
            shared: {
                link: "Geteilter Link",
                media: "Geteilte Medien"
            },
            description: {
                members: {
                    many: "{{membersCount}} Mitglieder",
                    one: "Ein Teilnehmer"
                }
            },
            newMessages: "Neue Nachrichten",
            miniChat: {
                header: {
                    collapse: "Zusammenklappen",
                    meeting: "Meeting starten",
                    openInTeam: "In Team öffnen",
                    close: "Schließen",
                    expand: "Aufklappen"
                }
            },
            password: "Passwort",
            nickname: "Nickname",
            external: {
                login: {
                    accessMeeting: "Dem Meeting beitreten",
                    signIn: "Anmelden"
                }
            },
            conversation: {
                fileUploadDescription: "Dateibeschreibung"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_en_US.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            connectMenuItem: "Bate-papo",
            treeMenu: {
                conversations: "Conversations",
                spaces: "Spaces",
                instantMeeting: "Instant Meeting"
            },
            button: {
                new: "NEW",
                join: "Join",
                leave: "Leave",
                delete: "Delete",
                remove: "Remove",
                start: "Start"
            },
            new: {
                conversation: "New conversation",
                group: "New group",
                space: "New space",
                channel: "New channel",
                instantMeeting: "New instant meeting",
                selectPic: "Select an image",
                optional: "optional",
                "group-optionalTopic": "Optional. It describes the subject matter of the group",
                "space-optionalTopic": "Optional. It describes the subject matter",
                "channel-optionalTopic": "Optional. It describes the subject matter of the channel",
                nameRequired: "Required. Max. 140 characters, avoid reusing names",
                spaceSelectRequire: "Required. Channels are always linked to a space",
                spaceSelect: "Select a space to create a channel",
                invite: "Add participants",
                participants: {
                    requires: {
                        two: "Requires at least 2 others",
                        one: "Requires at least one more participant"
                    },
                    limit: "You can invite up to {{max_participants}} people"
                },
                attendee: {
                    feedback: {
                        positive: "Attendee added to the list",
                        neutral: "Press ENTER to add the address into the attendee list",
                        negative: "The email entered is not a valid one, please insert a valid email",
                        emailReplicated: "The email entered has already been added"
                    },
                    invite: "Add attendee",
                    title: "Attendee List",
                    empty: "You've not added any attendee yet"
                },
                speakToYourFriend: "Speak to your friend"
            },
            header: {
                conversations: "Conversations",
                channels: "Channels",
                new: {
                    conversation: "New conversation",
                    group: "New group",
                    space: "New space",
                    channel: "New channel",
                    instantMeeting: "New instant meeting"
                },
                contactInfo: "Contact Info",
                groupInfo: "Group Info",
                spaceInfo: "Space Info",
                channelInfo: "Channel Info",
                invite: "Invite into group",
                filter: {
                    conversation: "Filtered conversations",
                    channel: "Filtered channels"
                },
                instantInfo: "Instant Meeting Info"
            },
            status: {
                online: "Online",
                offline: "Offline",
                last_seen: "Last seen {{lastSeen}}",
                guest: "Guest"
            },
            general: "{{spaceName}} - General",
            chat: "Chat",
            email: "Email",
            name: "Name",
            bio: "Bio",
            phone: "Phone",
            topic: "Topic",
            participants: "Participants",
            commonGroups: "Common groups",
            commonSpaces: "Common spaces",
            contactInfo: "Contact info",
            placeholder: {
                searchResults: "Start typing above to see search results",
                addTopic: "Add topic",
                pickAddress: "Start typing to pick an address",
                limit: {
                    reached: "To invite other people, remove one of the selected contacts",
                    overquota: "This group has reached the maximum limit of participants"
                },
                filter: "Type to filter the list",
                writeMail: "Type an email address"
            },
            newMessages: "New Messages",
            description: {
                members: {
                    one: "One participant",
                    many: "{{membersCount}} members"
                }
            },
            action: {
                silenceConversation: "Silence conversation",
                sendConversation: "Send conversation by email",
                clearHistory: "Clear history",
                blockUser: "Block User",
                inviteParticipants: "Add participants",
                leaveGroup: "Leave group",
                removeBuddy: "Remove buddy",
                confirm: {
                    leaveGroup: "Are you sure you want to leave the group?",
                    removeBuddy: "Are you sure you want to remove this buddy?",
                    deleteSpace: "Are you sure you want to delete the space?",
                    leaveChannel: "Are you sure you want to leave the channel?",
                    deleteChannel: "Are you sure you want to delete the channel?"
                },
                leaveChannel: "Leave this channel",
                inviteToSpace: "Invite into the space",
                leaveSpace: "Leave space",
                deleteSpace: "Delete space",
                deleteChannel: "Delete channel",
                joinChannelAction: "Join this channel",
                silenceGeneral: "Silence general",
                joinChannel: "Join the channel to send messages and receive notifications",
                returnToCallTab: "Go to meeting tab",
                scrollToTheBottom: "Scroll to the bottom",
                scrollToNewMessage: "Scroll to new message",
                copyLink: "or copy the link and send it",
                inviteFeedback: "Invite sent",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Another instant meeting is running. \n Only one instant meeting can exists at a time"
            },
            shared: {
                media: "Media shared",
                link: "Link shared"
            },
            save: "Save",
            cancel: "Cancel",
            space: {
                administrator: "Space Administrator"
            },
            notification: {
                you: {
                    join: {
                        group: "You have joined the group",
                        channel: "You have joined the channel",
                        space: "You have joined the space",
                        instantMeeting: "You have joined the instant meeting"
                    },
                    invited: "You have been invited by {{invited_by}}",
                    left: {
                        group: "You have left the group",
                        channel: "You have left the channel",
                        space: "You have left the space"
                    },
                    changed: {
                        topic: {
                            group: "You have changed the group's topic in {{topic}}",
                            channel: "You have changed the channel's topic in {{topic}}",
                            space: "You have changed the space's topic in {{topic}}"
                        },
                        name: {
                            channel: "You have changed the channel's name in {{name}}",
                            space: "You have changed the space's name in {{name}}"
                        },
                        picture: {
                            group: "You have changed the group's picture",
                            channel: "You have changed the channel's picture",
                            space: "You have changed the space's name"
                        }
                    },
                    kicked: {
                        channel: "You have been removed from the channel by {{kicked_by}}",
                        space: "You have been removed from the space by {{kicked_by}}"
                    },
                    created: {
                        single: "You have created the conversation",
                        group: "You have created the group",
                        channel: "You have created the channel",
                        space: "You have created the space"
                    },
                    deleted: {
                        channel: "You have deleted the channel",
                        space: "You have deleted the space",
                        instantMeeting: "You have deleted the Instant Meeting"
                    }
                },
                member: {
                    invited: "{{member_name}} has been invited by {{invited_by}}",
                    you: {
                        invited: "You have invited {{member_name}}",
                        kicked: {
                            channel: "You have removed from the channel {{member_name}}",
                            space: "You have removed from the space {{member_name}}"
                        }
                    },
                    left: {
                        group: "{{member_name}} has left the group",
                        channel: "{{member_name}} has left the channel",
                        space: "{{member_name}} has left the space"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} has changed the group's topic in {{topic}}",
                            channel: "{{member_name}} has changed the channel's topic in {{topic}}",
                            space: "{{member_name}} has changed the space's topic in {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} has changed the channel's name in {{name}}",
                            space: "{{member_name}} has changed the space's name in {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} has changed the group's picture",
                            channel: "{{member_name}} has changed the channel's picture",
                            space: "{{member_name}} has changed the space's picture"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} has been removed from the channel by {{kicked_by}}",
                        space: "{{member_name}} has been removed from the space by {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} has created the conversation",
                        group: "{{member_name}} has created the group",
                        channel: "{{member_name}} has created the channel",
                        space: "{{member_name}} has created the space"
                    },
                    deleted: {
                        instantMeeting: "{{member_name}} has deleted the Instant Meeting",
                        channel: "{{member_name}} has deleted the channel",
                        space: "{{member_name}} has deleted the space"
                    },
                    join: "{{member_name}} has joined the conversation",
                    channel: {
                        join: "{{member_name}} has joined the channel"
                    }
                },
                conversation: {
                    created: "Conversation created"
                },
                meeting: {
                    started: "Meeting started",
                    ended: "Meeting ended"
                },
                newMeeting: "Incoming call from:",
                answer: "Answer",
                dismiss: "Dismiss",
                remindLater: "Remind me later…",
                unreadMessages: "Unread Messages",
                newMessage: "New message",
                drive_size_exceeded: "The file is too large",
                markAllAsRead: "Mark all as read"
            },
            writing: {
                generic: {
                    status: "is writing…"
                },
                specific: {
                    status: "{{writer}} is writing…"
                }
            },
            selection: {
                participants: {
                    none: "You have reached the limit of participants set by the administrator",
                    one: "You can invite a last participant",
                    many: "You can invite other {{limit}} participants"
                }
            },
            mail: {
                invite: {
                    message: "You are invited to join the meeting",
                    join_now: "Join now",
                    follow_to_join: "To join the meeting please follow this link:",
                    generated_by_connect: "This email was automatically generated by Zimbra Connect",
                    generated_by_team: "This email was automatically generated by Team",
                    space: "You have been invited into a new space!",
                    redirect: "Go to space"
                },
                kick: {
                    space: "You have been removed from this space",
                    redirect: "Go home"
                }
            },
            settings: {
                team: {
                    title: "Team Settings"
                },
                connect: {
                    title: "Connect Settings"
                },
                notification: {
                    connect: "Connect notifications",
                    team: "Team notifications",
                    zimbra: "Zimbra notifications",
                    meeting: "Notifications during meetings",
                    spawn3: "3 seconds",
                    spawn5: "5 seconds",
                    spawn10: "10 seconds",
                    spawn0: "Never disappear",
                    spawn: {
                        label: "Notification time span"
                    },
                    desktop: "Desktop notifications",
                    title: {
                        notifications: "Notifications",
                        minichat: "Open the minified chat as a new message arrives",
                        hint: "Show message preview in notifications"
                    }
                },
                profile: {
                    title: "Profile"
                },
                avatar: {
                    autocenter: "The image will be centered automatically.",
                    size: "Maximum dimension 256 kB"
                },
                meeting: {
                    title: {
                        meetingStart: "Meeting initial settings"
                    },
                    default: {
                        video: "Camera",
                        audio: "Microphone"
                    }
                }
            },
            fileNotAvailable: "File not available.",
            contactOwner: "Please contact the owner.",
            message: {
                browserNotSupported: {
                    Team: "The version of your browser is not supported. It's highly recommended to update the browser to benefit from all the Team features!",
                    Connect: "The version of your browser is not supported. It's highly recommended to update the browser to benefit from all the Connect features!"
                },
                popup: {
                    readBy: "Read by"
                }
            },
            error: {
                uploadPicturesFailed: "Failed to upload profile picture",
                uploadConversationPicturesFailed: "Failed to upload conversation picture"
            },
            instantMeetingAlreadyRunningTitle: "An instant meeting is already running.",
            instantMeetingAlreadyRunningText: "Creating a new one will overwrite the older one and your attendee will lost the connection, what would you do?",
            instantMeeting: {
                create: "Create a new instant meeting",
                continue: "Continue with the old instant meeting"
            },
            input: {
                "nameRequired-max140Characters-avoidReusingNames": "Required. Max. 140 characters, avoid reusing names",
                nameNeeds2Letters: "Name needs at least two letters",
                nameRequired: "A name is required",
                nameError3: "Max. 140 characters",
                topicOptional: "Optional. It describes the subject matter",
                topicNeeds2Letters: "A group's topic needs at least two letters (or none)",
                topicMax255Characters: "Max. 255 characters",
                nameMax140Characters: "Max. 140 characters"
            },
            edit: "Edit",
            undo: "Undo",
            modal: {
                closedInstantMeeting: "Instant meeting closed",
                endCallByOwner: "The owner of the instant meeting has decided to end the call, we hope you enjoined the instant meeting experience."
            },
            miniChat: {
                header: {
                    collapse: "Collapse",
                    expand: "Expand",
                    meeting: "Start Meeting",
                    openInTeam: "Open in Team",
                    close: "Close"
                }
            },
            meeting: {
                interactions: {
                    pttHint: "Hold 'T' to talk",
                    status: {
                        cameraMicOff: "Your camera and microphone are off",
                        cameraOff: "Your camera is off"
                    },
                    hideUserVideo: "Hide this user's video",
                    showUserVideo: "Show this user's video",
                    muteUserAudio: "Mute this user's audio",
                    unmuteUserAudio: "Unmute this user's audio",
                    enableScreenSharing: "Enable ScreenSharing",
                    disableScreensharing: "Disable ScreenSharing",
                    enableVideo: "Enable Video",
                    disableVideo: "Disable Video",
                    enableAudio: "Enable Audio",
                    enableAudioWithHint: "Enable Audio (press and hold 'T' to talk)",
                    disableAudio: "Disable Audio",
                    closeCall: "Close this call"
                },
                startModal: {
                    save: "Save these settings",
                    cancel: "Cancel",
                    description: "How do you want to enter the meeting?",
                    enter: "Enter",
                    noVideoAndNoAudio: "Camera off, Microphone off",
                    videoAndNoAudio: "Camera on, Microphone off",
                    noVideoAndAudio: "Camera off, Microphone on",
                    videoAndAudio: "Camera on, Microphone on"
                }
            },
            password: "Password",
            nickname: "Nickname",
            external: {
                login: {
                    accessMeeting: "To access the meeting",
                    signIn: "Sign in"
                }
            },
            conversation: {
                fileUploadDescription: "File Description"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_es.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            connectMenuItem: "Connect",
            treeMenu: {
                conversations: "Conversaciones",
                spaces: "Espacios",
                instantMeeting: "Reunión Instantánea"
            },
            button: {
                new: "NUEVO",
                join: "Unirse",
                leave: "Abandonar",
                delete: "Eliminar",
                remove: "Remover",
                start: "Inicio"
            },
            new: {
                group: "Nuevo grupo",
                space: "Nuevo Espacio",
                channel: "Nuevo Canal",
                instantMeeting: "Nueva Reunión Instantánea",
                selectPic: "Seleccionar imagen",
                optional: "opcional",
                "group-optionalTopic": "Opcional. Describe el tema del grupo",
                "space-optionalTopic": "Opcional. Describe el tema",
                "channel-optionalTopic": "Opcional. Describe el tema del Canal",
                nameRequired: "Requerido. Máx. 140 caracteres. Evitar nombres repetidos",
                spaceSelectRequire: "Requerido. Los Canales están siempre vinculados a un Espacio",
                spaceSelect: "Seleccione un Espacio para crear un Canal",
                invite: "Añadir participantes",
                participants: {
                    requires: {
                        two: "Requiere de por lo menos 2 más",
                        one: "Requiere de por lo menos 2 participantes más"
                    },
                    limit: "Puedes invitar hasta {{max_participants}} personas"
                },
                conversation: "Nueva conversación",
                attendee: {
                    feedback: {
                        emailReplicated: "El email ingresado ya ha sido agregado",
                        negative: "El e-mail ingresado no es válido. Por favor ingresa una dirección de email válida",
                        neutral: "Presiona ENTER para agregar la dirección a la lista de participantes",
                        positive: "Participante agregado a la lista"
                    },
                    empty: "No has agregado ningún participante aún",
                    title: "Lista de participantes",
                    invite: "Agregar participante"
                },
                speakToYourFriend: "Habla con tu colega"
            },
            header: {
                conversations: "Conversaciones",
                channels: "Canales",
                new: {
                    conversation: "Nueva conversación",
                    group: "Nuevo grupo",
                    space: "Nuevo Espacio",
                    channel: "Nuevo Canal",
                    instantMeeting: "Nueva Reunión Instantánea"
                },
                contactInfo: "Información de contacto",
                groupInfo: "Información de grupo",
                spaceInfo: "Información del Espacio",
                channelInfo: "Información del Canal",
                invite: "Invitar al grupo",
                instantInfo: "Información sobre la Reunión Instantánea",
                filter: {
                    channel: "Canales filtrados",
                    conversation: "Conversaciones filtradas"
                }
            },
            status: {
                online: "Online",
                last_seen: "Visto por última vez {{lastSeen}}",
                offline: "Offline",
                guest: "Invitado"
            },
            general: "{{spaceName}} - General",
            chat: "Chat",
            email: "Email",
            name: "Nombre",
            bio: "Bio",
            phone: "Teléfono",
            topic: "Tema",
            participants: "Participantes",
            commonGroups: "Grupos comunes",
            commonSpaces: "Espacios comunes",
            contactInfo: "Información de contacto",
            placeholder: {
                searchResults: "Comienza a escribir encima para ver los resultados de la búsqueda",
                addTopic: "Agregar tema",
                pickAddress: "Comience a escribir para ver las direcciones",
                limit: {
                    reached: "Para invitar a otras personas, remueva una de los contactos seleccionados",
                    overquota: "Este grupo ha alcanzado el límite máximo de participantes"
                },
                writeMail: "Escriba una dirección de e-mail",
                filter: "Escriba para filtrar de la lista"
            },
            newMessages: "Mensajes nuevos",
            description: {
                members: {
                    one: "Un participante",
                    many: "{{membersCount}} miembros"
                }
            },
            action: {
                silenceConversation: "Silenciar conversación",
                sendConversation: "Enviar conversación por e-mail",
                clearHistory: "Limpiar historial",
                blockUser: "Bloquear usuario",
                inviteParticipants: "Agregar participantes",
                leaveGroup: "Abandonar grupo",
                removeBuddy: "Remover contacto",
                confirm: {
                    leaveGroup: "¿Está seguro que desea abandonar el grupo?",
                    removeBuddy: "¿Está seguro que desea remover este contacto?",
                    deleteSpace: "¿Está seguro que desea eliminar este Espacio?",
                    leaveChannel: "¿Está seguro que desea abandonar el Canal?",
                    deleteChannel: "¿Está seguro que desea eliminar el Canal?"
                },
                leaveChannel: "Abandonar este Canal",
                inviteToSpace: "Invitar al Espacio",
                leaveSpace: "Abandonar Espacio",
                deleteSpace: "Eliminar Espacio",
                deleteChannel: "Eliminar Canal",
                joinChannelAction: "Unirse a este Canal",
                silenceGeneral: "Silencio general",
                joinChannel: "Únase al Canal para enviar mensajes y recibir notificaciones",
                returnToCallTab: "Ir a la pestaña de reunión",
                inviteFeedback: "Invitación enviada",
                copyLink: "o copie el enlace y compártalo",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Hay otra Reunión Instantánea en curso\nSolo se permite una Reunión Instantánea a la vez",
                scrollToNewMessage: "Desplazar hasta nuevo mensaje",
                scrollToTheBottom: "Desplazar hasta el final"
            },
            shared: {
                media: "Media compartida",
                link: "Enlace compartido"
            },
            save: "Guardar",
            cancel: "Cancelar",
            space: {
                administrator: "Administrador del Espacio"
            },
            notification: {
                you: {
                    join: {
                        group: "Acabas de unirte al grupo",
                        channel: "Acabas de unirte al Canal",
                        space: "Acabas de unirte al Espacio",
                        instantMeeting: "Acabas de unirte a una Reunión Instantánea"
                    },
                    invited: "Ha sido invitado por {{invited_by}}",
                    left: {
                        group: "Has dejado el grupo",
                        channel: "Has abandonado el Canal",
                        space: "Has abandonado el Espacio"
                    },
                    changed: {
                        topic: {
                            group: "Acabas de cambiar el tema del grupo por {{topic}}",
                            channel: "Acabas de cambiar el tema del Canal por {{topic}}",
                            space: "Acabas de cambiar el tema del Espacio por {{topic}}"
                        },
                        name: {
                            channel: "Acabas de cambiar el nombre del Canal por {{name}}",
                            space: "Acabas de cambiar el nombre del Espacio por {{name}}"
                        },
                        picture: {
                            group: "Has cambiado la imagen del grupo",
                            channel: "Has cambiado la imagen del Canal",
                            space: "Has cambiado la imagen del Espacio"
                        }
                    },
                    kicked: {
                        channel: "Has sido removido del Canal por {{kicked_by}}",
                        space: "Has sido removido del Espacio por {{kicked_by}}"
                    },
                    created: {
                        single: "Has creado la conversación",
                        group: "Has creado el grupo",
                        channel: "Has creado el Canal",
                        space: "Has creado el Espacio"
                    },
                    deleted: {
                        channel: "Has eliminado el Canal",
                        space: "Has eliminado el Espacio",
                        instantMeeting: "Has eliminado la Reunión Instantánea"
                    }
                },
                member: {
                    invited: "{{member_name}} ha sido invitado por {{invited_by}}",
                    left: {
                        group: "{{member_name}} dejó el grupo",
                        channel: "{{member_name}} abandonó el Canal",
                        space: "{{member_name}} abandonó el Espacio"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} ha cambiado el tema del grupo por {{topic}}",
                            channel: "{{member_name}} ha cambiado el tema del Canal por {{topic}}",
                            space: "{{member_name}} ha cambiado el tema del Espacio por {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} ha cambiado el nombre del Canal por {{name}}",
                            space: "{{member_name}} ha cambiado el nombre del Espacio por {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} ha cambiado la imagen del grupo",
                            channel: "{{member_name}} ha cambiado la imagen del Canal",
                            space: "{{member_name}} ha cambiado la imagen del Espacio"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} ha sido removido del Canal por {{kicked_by}}",
                        space: "{{member_name}} ha sido removido del Espacio por {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} ha creado la conversación",
                        group: "{{member_name}} ha creado el grupo",
                        channel: "{{member_name}} ha creado el Canal",
                        space: "{{member_name}} ha creado el Espacio"
                    },
                    deleted: {
                        channel: "{{member_name}} ha eliminado el Canal",
                        space: "{{member_name}} ha eliminado el Espacio",
                        instantMeeting: "{{member_name}} ha eliminado la Reunión Instantánea"
                    },
                    join: "{{member_name}} se ha unido a la conversación",
                    channel: {
                        join: "{{member_name}} se ha unido al Canal"
                    },
                    you: {
                        kicked: {
                            space: "Has sido removido del Espacio {{member_name}}",
                            channel: "Has sido removido del Canal {{member_name}}"
                        },
                        invited: "Has invitado a {{member_name}}"
                    }
                },
                conversation: {
                    created: "Conversación creada"
                },
                meeting: {
                    started: "Reunión iniciada",
                    ended: "Reunión finalizada"
                },
                newMeeting: "Llamada entrante de:",
                answer: "Contestar",
                dismiss: "Desestimar",
                newMessage: "Nuevo mensaje",
                remindLater: "Recordarme más tarde…",
                markAllAsRead: "Marcar como leído",
                drive_size_exceeded: "El archivo es demasiado grande",
                unreadMessages: "Mensajes no leídos"
            },
            writing: {
                generic: {
                    status: "está escribiendo…"
                },
                specific: {
                    status: "{{writer}} está escribiendo…"
                }
            },
            selection: {
                participants: {
                    none: "Has alcanzado el límite de participantes establecido por el administrador",
                    one: "Puedes invitar un participante más",
                    many: "Puedes invitar aún {{limit}} participantes"
                }
            },
            mail: {
                invite: {
                    message: "Has sido invitado a unirte a la reunión",
                    join_now: "Unirse ahora",
                    follow_to_join: "Para unirse a la reunión por favor siga este enlace:",
                    generated_by_connect: "Este correo ha sido generado automáticamente por Zimbra Connect",
                    generated_by_team: "Este correo ha sido generado automáticamente por Team",
                    redirect: "Ir al Espacio",
                    space: "¡Has sido invitado a participar de un nuevo Espacio!"
                },
                kick: {
                    space: "Has sido removido de este Espacio",
                    redirect: "Ir al Home"
                }
            },
            message: {
                browserNotSupported: {
                    Connect: "La versión del navegador no es soportada. ¡Recomendamos que actualice su navegador para poder beneficiarse de todas las funcionalidades de Connect!",
                    Team: "La versión de su navegador no es soportada. ¡Recomendamos que actualice su navegador para poder beneficiarse de todas las funcionalidades de Team!"
                },
                popup: {
                    readBy: "Leido por"
                }
            },
            contactOwner: "Por favor contacte con el propietario.",
            fileNotAvailable: "Archivo no disponible.",
            settings: {
                notification: {
                    title: {
                        hint: "Mostrar vista previa de los mensajes en las Notificaciones",
                        minichat: "Abra el chat minimizado cuando lleguen los mensajes",
                        notifications: "Notificaciones"
                    },
                    desktop: "Notificaciones de escritorio",
                    spawn: {
                        label: "Frecuencia de notificación"
                    },
                    spawn0: "Nunca desaparece",
                    spawn10: "10 segundos",
                    spawn5: "5 segundos",
                    spawn3: "3 segundos",
                    meeting: "Notificaciones durante la reunión",
                    zimbra: "Notificaciones de Zimbra",
                    team: "Notificaciones de Team",
                    connect: "Notificaciones de Connect"
                },
                avatar: {
                    size: "Tamaño máximo 256 Kb",
                    autocenter: "La imagen se centrará automáticamente."
                },
                profile: {
                    title: "Perfil",
                    errorSnackbar: "Parece que hay un error con la edición",
                    maximumDimension: "Dimensión máxima: 256 Kb.",
                    chooseAProfilePic: "Elije una foto de perfil que otros usuarios verán, la imagen se centrará automáticamente.",
                    statusOptionalDescription: "Opcional. Hazle saber a los demás lo que estás pensando",
                    userStatus: "Estado",
                    errorMessage: "Oops, algo salió mal",
                    update: "Actualizar",
                    restore: "Restaurar",
                    reset: "Restablecer"
                },
                connect: {
                    title: "Configuraciones de Connect"
                },
                team: {
                    title: "Configuraciones de Team"
                },
                meeting: {
                    title: {
                        meetingStart: "Configuraciones iniciales de la reunión"
                    },
                    default: {
                        video: "Cámara",
                        audio: "Micrófono"
                    },
                    enableCamera: "Activar cámara",
                    enableMicrophone: "Activar micrófono",
                    description: "Establecer las preferencias de audio y vídeo para entrar en las reuniones. Siempre es posible personalizar las preferencias antes de unirse a cada reunión.",
                    meetings: "Reuniones"
                },
                modal: {
                    description: "Aquí se pueden modificar las preferencias de Team para disfrutar de una completa experiencia de chat!"
                },
                notifications: {
                    description: "Establecer las preferencias para cada tipo de notificación en Teams.",
                    title: "Notificaciones"
                }
            },
            modal: {
                endCallByOwner: "El organizador de la Reunión Instantánea ha decidido finalizar la llamada, esperamos que haya disfrutado de la experiencia.",
                closedInstantMeeting: "Reunión Instantánea terminada"
            },
            undo: "Deshacer",
            edit: "Editar",
            input: {
                topicMax255Characters: "Máximo 255 caracteres",
                topicNeeds2Letters: "El tema de un grupo necesita de por lo menos dos letras (o ninguna)",
                topicOptional: "Opcional. Describe el tema",
                nameMax140Characters: "Máximo 140 caracteres",
                nameRequired: "Se requiere un nombre",
                nameNeeds2Letters: "El nombre necesita al menos dos letras",
                "nameRequired-max140Characters-avoidReusingNames": "Necesario. Máximo 140 caracteres. Evite reutilizar nombres"
            },
            instantMeeting: {
                continue: "Continuar con la Reunión Instantánea anterior",
                create: "Crear nueva Reunión Instantánea"
            },
            instantMeetingAlreadyRunningText: "Si crea una nueva, anulará la anterior y los participantes perderá la conexión ¿Qué desea hacer?",
            instantMeetingAlreadyRunningTitle: "Ya hay una Reunión Instantánea en curso.",
            error: {
                uploadPicturesFailed: "Falló al cargar la imagen del perfil",
                uploadConversationPicturesFailed: "Falló al cargar la imagen de la conversación"
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "Su cámara y micrófono están desactivados",
                        cameraOff: "Su cámara está apagada"
                    },
                    hideUserVideo: "Ocultar video de este usuario",
                    showUserVideo: "Mostrar video de este usuario",
                    muteUserAudio: "Silenciar el audio para este usuario",
                    unmuteUserAudio: "Restablecer el audio para este usuario",
                    enableScreenSharing: "Activar compartición de pantalla",
                    disableScreensharing: "Desactivar compartición de pantalla",
                    enableVideo: "Activar video",
                    disableVideo: "Desactivar video",
                    enableAudio: "Activar audio",
                    disableAudio: "Desactivar audio",
                    closeCall: "Terminar esta llamada"
                },
                startModal: {
                    save: "Guardar las configuraciones",
                    cancel: "Cancelar",
                    description: "¿Cómo quieres entrar en la reunión?",
                    enter: "Entrar",
                    noVideoAndNoAudio: "Cámara encendida, micrófono apagado",
                    videoAndNoAudio: "Cámara encendida, micrófono apagado",
                    noVideoAndAudio: "Cámara apagada, micrófono encendido",
                    videoAndAudio: "Cámara encendida, micrófono encendido"
                }
            },
            miniChat: {
                header: {
                    expand: "Expandir",
                    collapse: "Contraer",
                    meeting: "Iniciar Reunión",
                    openInTeam: "Abrir en Team",
                    close: "Cerrar"
                }
            },
            password: "Contraseña",
            nickname: "Apodo",
            external: {
                login: {
                    accessMeeting: "Para accesar a la reunión",
                    signIn: "Iniciar sesión"
                }
            },
            conversation: {
                fileUploadDescription: "Descripción del archivo"
            },
            loadingScreen: {
                poweredBy: "powered by"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_fr.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            modal: {
                endCallByOwner: "Le propriétaire de l’instant meeting à décidé de terminer cet appel, nous espérons que vous avez apprécié l’expérience.",
                closedInstantMeeting: "Instant meeting fermé"
            },
            undo: "Annuler",
            edit: "Éditer",
            input: {
                topicMax255Characters: "Max. 255 caractères",
                topicNeeds2Letters: "Le sujet d’un groupe doit avoir au moins deux lettres (ou aucune)",
                topicOptional: "Optionnel. il décrit le sujet",
                nameMax140Characters: "Max. 140 caractères",
                nameRequired: "Un nom est requis",
                nameNeeds2Letters: "Le nom doit avoir au moins deux lettres",
                "nameRequired-max140Characters-avoidReusingNames": "Obligatoire. Max. 140 caractères, éviter de réutiliser les noms"
            },
            action: {
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Un autre instant meeting est en cours.\nIl ne peut y avoir qu’un seul instant meeting à la fois",
                inviteFeedback: "Invitation envoyée",
                copyLink: "ou copier le lien et l’envoyer",
                scrollToNewMessage: "Scroller jusqu’au nouveau message",
                scrollToTheBottom: "Scroller jusqu’en bas",
                returnToCallTab: "Aller à l'onglet meeting",
                joinChannel: "Rejoindre le canal pour envoyer des messages et recevoir des notifications",
                silenceGeneral: "général silencieux",
                confirm: {
                    deleteChannel: "Êtes-vous sûr de vouloir supprimer ce canal ?",
                    leaveChannel: "Êtes-vous sûr de vouloir quitter ce canal ?",
                    deleteSpace: "Êtes-vous sûr de vouloir supprimer cet espace ?",
                    removeBuddy: "Êtes-vous sûr de vouloir supprimer ce camarade ?",
                    leaveGroup: "Êtes-vous sûr de vouloir quitter le groupe ?"
                },
                joinChannelAction: "Rejoindre ce canal",
                deleteChannel: "Supprimer le canal",
                deleteSpace: "Supprimer l'espace",
                leaveSpace: "Quitter l'espace",
                inviteToSpace: "Inviter dans l'espace",
                leaveChannel: "Quitter ce canal",
                removeBuddy: "Supprimer un camarade",
                leaveGroup: "Quitter le groupe",
                inviteParticipants: "Ajouter des participants",
                blockUser: "Bloquer un utilisateur",
                clearHistory: "Effacer l’historique",
                sendConversation: "Envoyer la conversation par email",
                silenceConversation: "Conversation silencieuse"
            },
            instantMeeting: {
                continue: "Continuer avec l’ancien instant meeting",
                create: "Créer un nouvel instant meeting"
            },
            instantMeetingAlreadyRunningText: "La création d’un nouveau terminera le précédent et les participants perdront la connexion, que souhaitez-vous faire ?",
            instantMeetingAlreadyRunningTitle: "Un instant meeting est déjà en cours.",
            error: {
                uploadPicturesFailed: "Impossible de télécharger la photo de profil",
                uploadConversationPicturesFailed: "Échec de téléversement de l'image de la conversation"
            },
            new: {
                attendee: {
                    feedback: {
                        emailReplicated: "L’adresse mail entrée a déjà été ajoutée",
                        negative: "L’e-mail entré n’est pas valide, veuillez en insérer un correct",
                        neutral: "Appuyez sue ENTRÉE pour ajouter l’adresse à la liste des participants",
                        positive: "Participant ajouté à la liste"
                    },
                    empty: "Vous n'avez par encore ajouté de participants",
                    title: "Liste des participants",
                    invite: "Ajouter des participants"
                },
                participants: {
                    limit: "Vous pouvez inviter jusqu’à {{max_participants}} personnes",
                    requires: {
                        one: "Nécessite au moins un participant de plus",
                        two: "Nécessite au moins 2 autres"
                    }
                },
                speakToYourFriend: "Parlez à vos amis",
                invite: "Ajouter des participants",
                spaceSelect: "Sélectionner un espace pour créer un canal",
                spaceSelectRequire: "Obligatoire. Les Canaux sont toujours liés à un Espace",
                nameRequired: "Obligatoire. Max. 140 caractères, éviter de réutiliser les noms",
                "channel-optionalTopic": "Optionnel, il décrit le sujet du canal",
                "space-optionalTopic": "Optionnel. Il décrit le sujet",
                "group-optionalTopic": "Optionnel. Il décrit le sujet du groupe",
                optional: "optionnel",
                selectPic: "Sélectionnez une image",
                instantMeeting: "Nouvel instant meeting",
                channel: "Nouveau canal",
                space: "Nouvel Espace",
                group: "Nouveau groupe",
                conversation: "Nouvelle conversation"
            },
            notification: {
                markAllAsRead: "Tout marquer comme lu",
                member: {
                    channel: {
                        join: "{{member_name}} a rejoint le canal"
                    },
                    join: "{{member_name}} a rejoint la conversation",
                    deleted: {
                        space: "{{member_name}} a supprimé l’espace",
                        channel: "{{member_name}} a supprimé le canal",
                        instantMeeting: "{{member_name}} a supprimé l’instant meeting"
                    },
                    created: {
                        space: "{{member_name}} a créé l’espace",
                        channel: "{{member_name}} a créé le canal",
                        group: "{{member_name}} a créé le groupe",
                        single: "{{member_name}} a créé la conversation"
                    },
                    you: {
                        kicked: {
                            space: "Vous avez supprimé de l’espace {{member_name}}",
                            channel: "Vous avez supprimé du canal {{member_name}}"
                        },
                        invited: "Vous avez invité {{member_name}}"
                    },
                    kicked: {
                        space: "{{member_name}} a été supprimé de l’espace par {{kicked_by}}",
                        channel: "{{member_name}} a été supprimé du canal par {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} a changé l’image de l’espace",
                            channel: "{{member_name}} a changé l’image du canal",
                            group: "{{member_name}} a changé l’image du groupe"
                        },
                        name: {
                            space: "{{member_name}} a changé le nom de l’espace en {{name}}",
                            channel: "{{member_name}} à changé le nom du canal en {{name}}"
                        },
                        topic: {
                            space: "{{member_name}} a changé le sujet de l’espace en {{topic}}",
                            channel: "{{member_name}} a changé le sujet du canal en {{topic}}",
                            group: "{{member_name}} a changé le sujet du groupe en {{topic}}"
                        }
                    },
                    left: {
                        space: "{{member_name}} a quitté l’espace",
                        channel: "{{member_name}} a quitté le canal",
                        group: "{{member_name}} a quitté le groupe"
                    },
                    invited: "{{member_name}} a été invité par {{invited_by}}"
                },
                drive_size_exceeded: "Le fichier est trop grand",
                newMessage: "Nouveau message",
                unreadMessages: "Messages non lus",
                remindLater: "Me le rappeler plus tard…",
                dismiss: "Rejeter",
                answer: "réponse",
                newMeeting: "Appel entrant de :",
                meeting: {
                    ended: "Réunion terminée",
                    started: "Réunion commencée"
                },
                you: {
                    deleted: {
                        space: "Vous avez supprimé l’espace",
                        channel: "Vous avez supprimé le canal",
                        instantMeeting: "Vous avez supprimé l’instant meeting"
                    },
                    created: {
                        space: "Vous avez créé l’espace",
                        channel: "Vous avez créé le canal",
                        group: "Vous avez créé le groupe",
                        single: "Vous avez créé la conversation"
                    },
                    kicked: {
                        space: "Vous avez été supprimé de l’espace par {{kicked_by}}",
                        channel: "Vous avez été supprimé du canal par {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "Vous avez changé l’image de l’espace",
                            channel: "Vous avez changé l'image du canal",
                            group: "Vous avez changé l'image du groupe"
                        },
                        name: {
                            space: "Vous avez changé le nom de l’espace en {{name}}",
                            channel: "Vous avez changé le nom du canal en {{name}}"
                        },
                        topic: {
                            space: "Vous avez changé le sujet de l’espace en {{topic}}",
                            channel: "Vous avez changé le sujet du canal en {{topic}}",
                            group: "Vous avez changé le sujet du groupe en {{topic}}"
                        }
                    },
                    left: {
                        space: "Vous avez quitté l’espace",
                        channel: "Vous avez quitté le canal",
                        group: "Vous avez quitté le groupe"
                    },
                    invited: "Vous avez été invité par {{invited_by}}",
                    join: {
                        instantMeeting: "Vous avez rejoint l’instant meeting",
                        space: "Vous avez rejoint l'espace",
                        channel: "Vous avez rejoint le canal",
                        group: "Vous avez rejoint le groupe"
                    }
                },
                conversation: {
                    created: "Conversation créée"
                }
            },
            button: {
                start: "Commencer",
                remove: "Supprimer",
                delete: "Supprimer",
                leave: "Quitter",
                join: "Rejoindre",
                new: "Nouvelle"
            },
            message: {
                browserNotSupported: {
                    Connect: "Cette version de votre navigateur n'est plus supportée. Il est fortement recommandé de mettre à jour le navigateur pour bénéficier de toutes les fonctionnalités de Connect !",
                    Team: "Cette version de votre navigateur n'est plus supportée. Il est fortement recommandé de mettre à jour le navigateur pour bénéficier de toutes les fonctionnalités de Team !"
                },
                popup: {
                    readBy: "Lu par"
                }
            },
            contactOwner: "Veuillez contacter le propriétaire.",
            fileNotAvailable: "Le fichier n’est pas disponible.",
            placeholder: {
                limit: {
                    overquota: "Ce groupe a atteint le nombre maximum de participants",
                    reached: "Pour inviter d’autre personne, supprimé un des contacts sélectionné"
                },
                writeMail: "Tapez une adresse e-mail",
                filter: "Tapez pour filtrer la liste",
                pickAddress: "Commencez à taper pour choisir une adresse",
                addTopic: "Ajouter un sujet",
                searchResults: "Commencez à taper ci-dessus pour voir les résultats de la recherche"
            },
            settings: {
                notification: {
                    title: {
                        hint: "Afficher l'aperçu des messages dans les notifications",
                        minichat: "Ouvrez le chat minifié lorsqu'un nouveau message arrive",
                        notifications: "Notifications"
                    },
                    desktop: "Notifications desktop",
                    spawn: {
                        label: "Apparition de l'heure de notification"
                    },
                    spawn0: "Ne disparais jamais",
                    spawn10: "10 secondes",
                    spawn5: "5 secondes",
                    spawn3: "3 secondes",
                    meeting: "Notifications durant les réunions",
                    zimbra: "Notifications Zimbra",
                    team: "Notifications Team",
                    connect: "Notifications Connect"
                },
                avatar: {
                    size: "Dimension maximale 256 kB",
                    autocenter: "L’image sera centrée automatiquement."
                },
                profile: {
                    title: "Profil",
                    errorSnackbar: "Il semble y avoir une erreur dans votre édition",
                    maximumDimension: "Taille maximale : 256kb.",
                    chooseAProfilePic: "Choisissez une photo de profil que les autres utilisateurs verront, l'image sera centrée automatiquement.",
                    statusOptionalDescription: "Facultatif. Faites savoir aux autres ce que vous pensez",
                    userStatus: "Statut",
                    errorMessage: "Oups, il y a un problème",
                    update: "Mettre à jour",
                    restore: "Restaurer",
                    reset: "Réinitialiser"
                },
                connect: {
                    title: "Paramètres Connect"
                },
                team: {
                    title: "Paramètres Team"
                },
                meeting: {
                    title: {
                        meetingStart: "Paramètres initiaux de la conférence"
                    },
                    default: {
                        video: "Caméra",
                        audio: "Microphone"
                    },
                    enableCamera: "Activer la caméra",
                    enableMicrophone: "Activer le microphone",
                    description: "Définissez vos préférences audio et vidéo pour entrer dans les réunions. Vous pouvez toujours personnaliser vos préférences avant de vous joindre à chaque réunion.",
                    meetings: "Réunions"
                },
                modal: {
                    description: "Vous pouvez définir ici toutes les préférences de l'équipe afin de profiter d'une expérience de tchat complète et personnalisée !"
                },
                notifications: {
                    description: "Définissez vos préférences pour chaque type de notification dans Team.",
                    title: "Notifications"
                }
            },
            header: {
                instantInfo: "Info de l’Instant Meeting",
                filter: {
                    channel: "Canaux filtrés",
                    conversation: "Conversations filtrées"
                },
                invite: "Inviter dans un groupe",
                channelInfo: "Info du canal",
                spaceInfo: "Info de l'espace",
                groupInfo: "Info du groupe",
                contactInfo: "Contact info",
                new: {
                    instantMeeting: "Nouvel instant meeting",
                    channel: "Nouveau canal",
                    space: "Nouvel espace",
                    group: "Nouveau groupe",
                    conversation: "Nouvelle conversation"
                },
                channels: "Canaux",
                conversations: "Conversations"
            },
            mail: {
                invite: {
                    redirect: "Aller à l’espace",
                    space: "Vous avez été invité dans un nouvel espace !",
                    generated_by_team: "Ce mail a été automatiquement généré par Team",
                    generated_by_connect: "Ce mail a été automatiquement généré par Zimbra Connect",
                    follow_to_join: "Pour rejoindre la réunion, veuillez suivre ce lien :",
                    join_now: "Rejoignez maintenant",
                    message: "Vous êtes invité à rejoindre la réunion"
                },
                kick: {
                    redirect: "Aller à l’accueil",
                    space: "Vous avez été supprimé de cet espace"
                }
            },
            selection: {
                participants: {
                    many: "Vous pouvez encore inviter {{limit}} participants",
                    one: "Vous pouvez inviter un dernier participant",
                    none: "Vous avez atteint la limite de participants imposée par l’administrateur"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}} est en train d’écrire…"
                },
                generic: {
                    status: "est en train d’écrire…"
                }
            },
            space: {
                administrator: "Administrateur d’Espace"
            },
            cancel: "Annuler",
            save: "Sauvegarder",
            shared: {
                link: "Lien partagé",
                media: "Media partagé"
            },
            description: {
                members: {
                    many: "{{membersCount}} membres",
                    one: "un participant"
                }
            },
            newMessages: "Nouveau Messages",
            contactInfo: "Contact info",
            commonSpaces: "Espaces communs",
            commonGroups: "Groupes communs",
            participants: "Participants",
            topic: "Sujet",
            phone: "Téléphone",
            bio: "Bio",
            name: "Nom",
            email: "Email",
            chat: "Chat",
            general: "{{spaceName}} - General",
            status: {
                last_seen: "Vu pour la dernière fois {{lastSeen}}",
                offline: "Hors ligne",
                online: "En ligne",
                guest: "Invité"
            },
            treeMenu: {
                instantMeeting: "Instant Meeting",
                spaces: "Espaces",
                conversations: "Conversations"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            miniChat: {
                header: {
                    expand: "Développer",
                    close: "Fermer",
                    openInTeam: "Ouvrir dans Team",
                    meeting: "Démarrer la réunion",
                    collapse: "Déployer"
                }
            },
            meeting: {
                interactions: {
                    unmuteUserAudio: "Réactiver le micro de ce participant",
                    showUserVideo: "Afficher la vidéo de ce participant",
                    hideUserVideo: "Masquer la vidéo de ce participant",
                    status: {
                        cameraOff: "Votre caméra est désactivée",
                        cameraMicOff: "Votre caméra et votre microphone sont désactivés"
                    },
                    enableScreenSharing: "Activer le partage d'écran",
                    muteUserAudio: "Désactiver le micro de ce participant",
                    pttHint: "Maintenez la touche 'T' pour parler",
                    closeCall: "Raccrocher cet appel",
                    disableAudio: "Désactiver l'audio",
                    enableAudioWithHint: "Activer l'audio (maintenez 'T' pour parler)",
                    enableAudio: "Activer l'audio",
                    disableVideo: "Désactiver la vidéo",
                    enableVideo: "Activer la vidéo",
                    disableScreensharing: "Désactiver le partage d'écran"
                },
                startModal: {
                    videoAndAudio: "Caméra active, microphone actif",
                    noVideoAndAudio: "Caméra désactivée, microphone actif",
                    videoAndNoAudio: "Caméra active, microphone désactivé",
                    noVideoAndNoAudio: "Caméra désactivée, microphone désactivé",
                    enter: "Entrer",
                    description: "Comment souhaitez-vous entrer dans cette réunion ?",
                    cancel: "Annuler",
                    save: "Sauvegarder cette configuration"
                }
            },
            external: {
                login: {
                    signIn: "S'enregistrer",
                    accessMeeting: "Accéder à la réunion"
                }
            },
            nickname: "Surnom",
            password: "Mot de passe",
            conversation: {
                fileUploadDescription: "Description du fichier"
            },
            loadingScreen: {
                poweredBy: "motorisé par"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_hi.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "आपका कैमरा और माइक बंद हैं",
                        cameraOff: "आपका कैमरा बंद है"
                    },
                    hideUserVideo: "इस यूज़र का विडियो छिपाएँ",
                    showUserVideo: "इस यूज़र का विडियो दिखाएँ",
                    muteUserAudio: "इस यूज़र की ऑडियो बंद करें",
                    unmuteUserAudio: "इस यूज़र की ऑडियो चालू करें",
                    enableScreenSharing: "स्क्रीनशेयरिंग चालू करें",
                    disableScreensharing: "स्क्रीनशेयरिंग बंद करें",
                    enableVideo: "विडियो चालू करें",
                    disableVideo: "विडियो बंद करें",
                    enableAudio: "ऑडियो चालू करें",
                    enableAudioWithHint: "ऑडियो चालू करें (बात करने के लिए 'T' बटन दबा कर रखें)",
                    disableAudio: "ऑडियो बंद करें",
                    closeCall: "इस कॉल को बंद करें",
                    pttHint: "बात करने के लिए 'T' दबा कर रखें"
                },
                startModal: {
                    save: "इन सेटिंग्स को सेव करें",
                    cancel: "कैंसल करें",
                    description: "आप मीटिंग में कैसे एंटर करना चाहते हैं?",
                    enter: "एंटर करें",
                    noVideoAndAudio: "कैमरा बंद, माइक्रोफोन चालू",
                    noVideoAndNoAudio: "कैमरा बंद, माइक्रोफोन बंद",
                    videoAndNoAudio: "कैमरा चालू, माइक्रोफोन बंद",
                    videoAndAudio: "कैमरा चालू, माइक्रोफोन चालू"
                }
            },
            modal: {
                endCallByOwner: "इंस्टेंट मीटिंग के ओनर ने कॉल खत्म कर दिया है, उम्मीद है आपको इंस्टेंट मीटिंग एक्सपीरियंस पसंद आया होगा।",
                closedInstantMeeting: "इंस्टेंट मीटिंग बंद हो गई"
            },
            undo: "अनडू करें",
            edit: "बदलाव करें",
            input: {
                topicMax255Characters: "अधिकतम 255 कैरक्टर",
                topicNeeds2Letters: "किसी ग्रुप के विषय में कम से कम दो अक्षर (या कोई नहीं) होने चाहिए",
                topicOptional: "वैकल्पिक। यह विषय बताता है",
                nameMax140Characters: "अधिकतम 140 कैरक्टर",
                nameRequired: "एक नाम जरूरी है",
                nameNeeds2Letters: "नाम में कम से कम दो अक्षर होने चाहिए",
                "nameRequired-max140Characters-avoidReusingNames": "जरूरी है। अधिकतम 140 कैरक्टर, नाम दोबारा उपयोग करने से बचें"
            },
            action: {
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "एक और इंस्टेंट मीटिंग चल रही है\nएक बार में केवल एक ही इंस्टेंट मीटिंग चल सकती है",
                inviteFeedback: "इन्वाइट भेजा गया",
                copyLink: "या लिंक को कॉपी करें और भेज दें",
                scrollToNewMessage: "नए मैसेज में स्क्रॉल करें",
                scrollToTheBottom: "स्क्रॉल करके नीचे जाएँ",
                returnToCallTab: "मीटिंग टैब में जाएँ",
                joinChannel: "मैसेज भेजने और अधिसूचनाएं पाने के लिए चैनल जॉइन करें",
                silenceGeneral: "सामान्य को साइलेंस करें",
                confirm: {
                    deleteChannel: "क्या आप वाकई में इस चैनल को डिलीट करना चाहते हैं?",
                    leaveChannel: "क्या आप वाकई में इस चैनल को छोड़ना चाहते हैं?",
                    deleteSpace: "क्या आप वाकई में स्पेस डिलीट करना चाहते हैं?",
                    removeBuddy: "क्या आप वाकई में इस दोस्त को हटाना चाहते हैं?",
                    leaveGroup: "क्या आप वाकई में ग्रुप छोड़ना चाहते हैं?"
                },
                joinChannelAction: "इस चैनल को जॉइन करें",
                deleteChannel: "चैनल डिलीट करें",
                inviteToSpace: "स्पेस में बुलाएँ",
                deleteSpace: "स्पेस डिलीट करें",
                leaveSpace: "स्पेस छोड़ें",
                leaveChannel: "यह चैनल छोड़ें",
                removeBuddy: "दोस्त हटाएँ",
                leaveGroup: "ग्रुप छोड़ें",
                inviteParticipants: "पर्टिसिपेंट्स जोड़ें",
                blockUser: "यूज़र को ब्लॉक करें",
                clearHistory: "हिस्ट्री क्लियर करें",
                sendConversation: "बात-चीत ईमेल से भेजें",
                silenceConversation: "बात-चीत साइलेंस करें"
            },
            instantMeeting: {
                continue: "पुरानी इंस्टेंट मीटिंग से जारी रखें",
                create: "एक नई इंस्टेंट मीटिंग बनाएँ"
            },
            instantMeetingAlreadyRunningText: "एक नई बनाने से पुरानी खत्म हो जाएगी और हाजिर व्यक्ति का कनेक्शन टूट जाएगा। आप क्या करना चाहते हैं?",
            instantMeetingAlreadyRunningTitle: "एक इंस्टेंट मीटिंग पहले ही चल रही है।",
            error: {
                uploadConversationPicturesFailed: "बात-चीत की फोटो अपलोड नहीं कर पाया",
                uploadPicturesFailed: "प्रोफ़ाइल फोटो अपलोड नहीं कर पाया"
            },
            new: {
                attendee: {
                    feedback: {
                        emailReplicated: "एंटर की गई ईमेल पहले ही जोड़ दी गई है",
                        negative: "एंटर की गई एमेल मान्य नहीं है, कोई मान्य ईमेल डालें",
                        neutral: "हाजिर व्यक्ति लिस्ट में एड्रेस जोड़ने के लिए ENTER दबाएँ",
                        positive: "हाजिर व्यक्ति को लिस्ट में जोड़ा गया"
                    },
                    empty: "आपने अभी तक किसी हाजिर व्यक्ति को नहीं जोड़ा है",
                    title: "हाजिर व्यक्तियों की लिस्ट",
                    invite: "हाजिर व्यक्ति जोड़ें"
                },
                participants: {
                    limit: "आप ज़्यादा से ज़्यादा {{max_participants}} लोगों को इन्वाइट कर सकते हैं",
                    requires: {
                        one: "कम से कम एक और पार्टिसिपेंट जरूरी है",
                        two: "कम से कम 2 और की जरूरत होती है"
                    }
                },
                speakToYourFriend: "अपने दोस्त से बात करें",
                invite: "पर्टिसिपेंट्स जोड़ें",
                spaceSelect: "कोई चैनल बनाने के लिए एक स्पेस सिलेक्ट करें",
                spaceSelectRequire: "जरूरी। चैनल हमेशा किसी स्पेस से लिंक होते हैं",
                nameRequired: "जरूरी है। अधिकतम 140 कैरक्टर, नाम दोबारा उपयोग करने से बचें",
                "channel-optionalTopic": "वैकल्पिक। यह चैनल का विषय बताता है",
                "space-optionalTopic": "वैकल्पिक। यह विषय बताता है",
                "group-optionalTopic": "वैकल्पिक। यह ग्रुप का विषय बताता है",
                optional: "वैकल्पिक",
                selectPic: "कोई फोटो सिलेक्ट करें",
                instantMeeting: "नया इंस्टेंट मैसेजिंग",
                channel: "नया चैनल",
                space: "नया स्पेस",
                group: "नया ग्रुप",
                conversation: "नई बात-चीत"
            },
            notification: {
                markAllAsRead: "सभी को पढ़ा गया मार्क करें",
                member: {
                    channel: {
                        join: "{{member_name}} ने चैनल जॉइन कर लिया है"
                    },
                    join: "{{member_name}} ने बात-चीत जॉइन कर ली है",
                    deleted: {
                        space: "{{member_name}} ने स्पेस डिलीट कर दिया है",
                        channel: "{{member_name}} ने चैनल डिलीट कर दिया है",
                        instantMeeting: "{{member_name}} ने इंस्टेंट मीटिंग डिलीट कर दी है"
                    },
                    created: {
                        space: "{{member_name}} ने स्पेस बना दिया है",
                        channel: "{{member_name}} ने चैनल बना दिया है",
                        group: "{{member_name}} ने ग्रुप बना दिया है",
                        single: "{{member_name}} ने बात-चीत बना दी है"
                    },
                    you: {
                        kicked: {
                            space: "आपको {{member_name}} स्पेस से बाहर कर दिया गया है",
                            channel: "आपको {{member_name}} चैनल से बाहर कर दिया गया है"
                        },
                        invited: "आपने {{member_name}} को इन्वाइट किया है"
                    },
                    kicked: {
                        space: "{{member_name}} को {{kicked_by}} ने स्पेस से बाहर निकाल दिया है",
                        channel: "{{member_name}} को {{kicked_by}} ने चैनल से बाहर निकाल दिया है"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} ने स्पेस की फोटो बदल दी है",
                            channel: "{{member_name}} ने चैनल की फोटो बदल दी है",
                            group: "{{member_name}} ने ग्रुप की फोटो बदल दी है"
                        },
                        name: {
                            space: "{{member_name}} ने स्पेस का नाम {{name}} में बदल दिया है",
                            channel: "{{member_name}} ने चैनल का नाम {{name}} में बदल दिया है"
                        },
                        topic: {
                            space: "{{member_name}} ने स्पेस का विषय {{topic}} में बदल दिया है",
                            channel: "{{member_name}} ने चैनल का विषय {{topic}} में बदल दिया है",
                            group: "{{member_name}} ने ग्रुप का विषय {{topic}} में बदल दिया है"
                        }
                    },
                    left: {
                        space: "{{member_name}} ने स्पेस छोड़ दिया है",
                        channel: "{{member_name}} ने चैनल छोड़ दिया है",
                        group: "{{member_name}} ने ग्रुप छोड़ दिया है"
                    },
                    invited: "{{member_name}} को {{invited_by}} ने इन्वाइट किया है"
                },
                drive_size_exceeded: "यह फाइल बहुत बड़ी है",
                newMessage: "नया मैसेज",
                unreadMessages: "नहीं पढ़े मैसेज",
                remindLater: "मुझे बाद में याद दिलाएँ…",
                dismiss: "छोड़ें",
                answer: "जबाब दें",
                newMeeting: "इनकमिंग कॉल आ रहा है इनका:",
                meeting: {
                    ended: "मीटिंग खत्म हो गई",
                    started: "मीटिंग शुरू हो गई"
                },
                you: {
                    deleted: {
                        space: "आपने स्पेस डिलीट कर दिया है",
                        channel: "आपने चैनल डिलीट कर दिया है",
                        instantMeeting: "आपने इंस्टेंट मीटिंग डिलीट कर दी है"
                    },
                    created: {
                        space: "आपने स्पेस बना दिया है",
                        channel: "आपने चैनल बना दिया है",
                        group: "आपने ग्रुप बना दिया है",
                        single: "आपने बात-चीत बना दी है"
                    },
                    kicked: {
                        space: "आपको {{kicked_by}} ने स्पेस से बाहर निकल दिया है",
                        channel: "आपको {{kicked_by}} ने चैनल से बाहर निकल दिया है"
                    },
                    changed: {
                        picture: {
                            space: "आपने स्पेस का नाम बदल दिया है",
                            channel: "आपने चैनल की फोटो बदल दी है",
                            group: "आपने ग्रुप की फोटो बदल दी है"
                        },
                        name: {
                            space: "आपने स्पेस के नाम को {{name}} में बदल दिया है",
                            channel: "आपने चैनल के नाम को {{name}} में बदल दिया है"
                        },
                        topic: {
                            space: "आपने स्पेस के विषय को {{topic}} में बदल दिया है",
                            channel: "आपने चैनल के विषय को {{topic}} में बदल दिया है",
                            group: "आपने ग्रुप के विषय को {{topic}} में बदल दिया है"
                        }
                    },
                    left: {
                        space: "आपने स्पेस छोड़ दिया है",
                        channel: "आपने चैनल छोड़ दिया है",
                        group: "आपने ग्रुप छोड़ दिया है"
                    },
                    invited: "आपको {{invited_by}} ने इन्वाइट किया है",
                    join: {
                        instantMeeting: "आपने इंस्टेंट मैसेजिंग जॉइन कर ली है",
                        space: "आपने स्पेस जॉइन कर लिया है",
                        channel: "आपने चैनल जॉइन कर लिया है",
                        group: "आपने ग्रुप जॉइन कर लिया है"
                    }
                },
                conversation: {
                    created: "बात-चीत बनाई गई"
                }
            },
            button: {
                start: "शुरू करें",
                remove: "हटाएँ",
                delete: "डिलीट करें",
                leave: "छोड़ें",
                join: "जॉइन करें",
                new: "नया"
            },
            message: {
                browserNotSupported: {
                    Connect: "हम आपके ब्राउज़र के इस वर्शन को सपोर्ट नहीं करते. आप अपने ब्राउज़र को अपडेट कर लें जिससे Connect के सभी फीचर्स का पूरा लाभ उठा सकें!",
                    Team: "हम आपके ब्राउज़र के इस वर्शन को सपोर्ट नहीं करते. आप अपने ब्राउज़र को अपडेट कर लें जिससे Team के सभी फीचर्स का पूरा लाभ उठा सकें!"
                },
                popup: {
                    readBy: "इन्होंने पढ़ लिया"
                }
            },
            contactOwner: "ऑनर से संपर्क करें।",
            fileNotAvailable: "फाइल उपलब्ध नहीं है।",
            placeholder: {
                limit: {
                    overquota: "यह ग्रुप पार्टिसिपेंट्स की अधिकतम सीमा तक पहुँच गया है",
                    reached: "दूसरों को इन्वाइट करने के लिए सिलेक्ट किए गए किसी एक कांटैक्ट को हटाएँ"
                },
                writeMail: "कोई ईमेल एड्रेस टाइप करें",
                filter: "लिस्ट फ़िल्टर करने के लिए टाइप करें",
                pickAddress: "कोई एड्रेस चुनने के लिए टाइप करना शुरू करें",
                addTopic: "विषय जोड़ें",
                searchResults: "सर्च रिजल्ट्स देखने के लिए ऊपर टाइप करना शुरू करें"
            },
            settings: {
                notification: {
                    title: {
                        hint: "अधिसूचनाओं में मैसेज प्रीव्यू दिखाएँ",
                        minichat: "नया मैसेज आने पर छोटी की गई चैट खोलें",
                        notifications: "अधिसूचनाएं"
                    },
                    desktop: "डेस्कटॉप अधिसूचनाएं",
                    spawn0: "कभी सामने से न हटे",
                    spawn10: "10 सेकंड",
                    spawn5: "5 सेकंड",
                    spawn3: "3 सेकंड",
                    meeting: "मीटिंग के दौरान अधिसूचनाएं",
                    zimbra: "Zimbra अधिसूचनाएं",
                    team: "Team अधिसूचनाएं",
                    connect: "Connect अधिसूचनाएं",
                    spawn: {
                        label: "अधिसूचना समय आवृत्ति"
                    }
                },
                avatar: {
                    size: "अधिकतम डाइमैन्शन 256 kB",
                    autocenter: "इमेज अपने आप सेंटर में आ जाएगी।"
                },
                profile: {
                    title: "प्रोफ़ाइल",
                    update: "अपडेट करें"
                },
                connect: {
                    title: "Connect सेटिंग्स"
                },
                team: {
                    title: "Team सेटिंग्स"
                },
                meeting: {
                    title: {
                        meetingStart: "मीटिंग की शुरुआती सेटिंग्स"
                    },
                    default: {
                        video: "कैमरा",
                        audio: "माइक्रोफोन"
                    }
                },
                notifications: {
                    title: "अधिसूचनाएं"
                }
            },
            header: {
                instantInfo: "इंस्टेंट मीटिंग जानकारी",
                filter: {
                    channel: "फ़िल्टर किए गए चैनल",
                    conversation: "फ़िल्टर की हुई बात-चीतें"
                },
                invite: "ग्रुप में बुलाएँ",
                channelInfo: "चैनल जानकारी",
                spaceInfo: "Space जानकारी",
                groupInfo: "ग्रुप जानकारी",
                contactInfo: "संपर्क जानकारी",
                new: {
                    instantMeeting: "नया इंस्टेंट मैसेजिंग",
                    channel: "नया चैनल",
                    space: "नया स्पेस",
                    group: "नया ग्रुप",
                    conversation: "नई बात-चीत"
                },
                channels: "चैनल",
                conversations: "बात-चीतें"
            },
            mail: {
                invite: {
                    redirect: "स्पेस में जाएँ",
                    space: "आपको एक नए स्पेस में इन्वाइट किया गया है!",
                    generated_by_team: "यह मेल Team ने अपने-आप बनाई है",
                    generated_by_connect: "यह मेल Zimbra Connect ने अपने-आप बनाई है",
                    follow_to_join: "मीटिंग जॉइन करने के लिए इस लिंक को फॉलो करें:",
                    join_now: "अभी जॉइन करें",
                    message: "आपको मीटिंग जॉइन करने के लिए इन्वाइट किया गया है"
                },
                kick: {
                    redirect: "होम पर जाएँ",
                    space: "आपको इस स्पेस से हटा दिया गया है"
                }
            },
            selection: {
                participants: {
                    many: "आप दूसरे {{limit}} पार्टिसिपेंट बुला सकते हैं",
                    one: "आप एक आखिरी पार्टिसिपेंट को बुला सकते हैं",
                    none: "आप एडमिनिस्ट्रेटर द्वारा सेट पार्टिसिपेंट की सीमा तक पहुँच गए हैं"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}} लिख रहे/रही हैं…"
                },
                generic: {
                    status: "लिख रहे/रहीं हैं…"
                }
            },
            space: {
                administrator: "Space एडमिनिस्ट्रेटर"
            },
            cancel: "कैंसल करें",
            save: "सेव करें",
            shared: {
                link: "लिंक शेयर की गई",
                media: "मीडिया शेयर किया गया"
            },
            description: {
                members: {
                    many: "{{membersCount}} मेम्बर",
                    one: "एक पार्टिसिपेंट"
                }
            },
            newMessages: "नए मैसेज",
            contactInfo: "संपर्क जानकारी",
            commonSpaces: "कॉमन स्पेसेस",
            commonGroups: "कॉमन ग्रुप",
            participants: "पार्टिसिपेंट्स",
            topic: "विषय",
            phone: "फोन",
            bio: "बायो",
            name: "नाम",
            email: "ईमेल",
            chat: "चैट करें",
            general: "{{spaceName}} - सामान्य",
            status: {
                last_seen: "पिछली बार देखा गया / गई {{lastSeen}}",
                offline: "ऑफलाइन",
                online: "ऑनलाइन",
                guest: "गेस्ट"
            },
            treeMenu: {
                instantMeeting: "इंस्टेंट मैसेजिंग",
                spaces: "Spaces",
                conversations: "बात-चीतें"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            miniChat: {
                header: {
                    collapse: "नीचे करें",
                    meeting: "मीटिंग शुरू करें",
                    openInTeam: "Team में खोलें",
                    close: "बंद करें",
                    expand: "बड़ा करें"
                }
            },
            password: "पासवर्ड",
            nickname: "उर्फनाम",
            external: {
                login: {
                    accessMeeting: "मीटिंग एक्सेस करने के लिए",
                    signIn: "साइन-इन करें"
                }
            },
            conversation: {
                fileUploadDescription: "फाइल विवरण"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_hr.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Tim",
            connectMenuItem: "Komunikator",
            treeMenu: {
                conversations: "Razgovori",
                spaces: "Prostor",
                instantMeeting: "Instantni razgovor"
            },
            button: {
                new: "NOVO",
                join: "Pridruži se",
                leave: "Napusti",
                delete: "Izbriši",
                remove: "Ukloni",
                start: "Početak"
            },
            new: {
                conversation: "Novi razgovor",
                group: "Nova grupa",
                space: "Novi prostor",
                channel: "Novi kanal",
                instantMeeting: "Novi instantni razgovor",
                selectPic: "Odaberi sliku",
                optional: "opcionalno",
                "group-optionalTopic": "Opcionalno. Opisuje predmet grupe",
                "space-optionalTopic": "Opcionalno. Opisuje predmet",
                "channel-optionalTopic": "Opcionalno. Opisuje predmet kanala",
                nameRequired: "Obavezno. Maksimalno 140 znakova, izbjegavajte ponovnu upotrebu imena",
                spaceSelectRequire: "Obavezno. Kanali su uvijek povezani s prostorom",
                spaceSelect: "Odaberite prostor kako biste stvorili kanal",
                invite: "Dodaj sudionike",
                speakToYourFriend: "Pronađi prijatelja",
                participants: {
                    requires: {
                        two: "Minimalno 2 člana",
                        one: "Potreban je još jedan sudionik"
                    },
                    limit: "Možeš pozvati do {{max_participants}} sudionika"
                },
                attendee: {
                    feedback: {
                        positive: "Sudionik dodan na listu",
                        neutral: "Pristini ENTER kako bi dodao adresu u listu sudionika",
                        negative: "Unesena adresa email pošte nije ispravna, ponovo unesite email adresu",
                        emailReplicated: "Uneseni email je već dodan"
                    },
                    invite: "Dodaj sudionika",
                    title: "Lista sudionika",
                    empty: "Nisi još dodao sudionika"
                }
            },
            header: {
                conversations: "Razgovori",
                channels: "Kanali",
                new: {
                    conversation: "Novi razgovor",
                    group: "Nova grupa",
                    space: "Novi prostor",
                    channel: "Novi kanal",
                    instantMeeting: "Novi instantni razgovor"
                },
                contactInfo: "Informacije o kontaktu",
                groupInfo: "Informacije o grupi",
                spaceInfo: "Informacije o prostoru",
                channelInfo: "Informacije o kanalu",
                invite: "Pozovi u grupu",
                filter: {
                    conversation: "Filtrirani razgovori",
                    channel: "Filtrirani kanali"
                },
                instantInfo: "Trenutni sastanak - Informacije"
            },
            status: {
                online: "Na mreži",
                offline: "Izvan mreže",
                last_seen: "Zadnja aktivnost {{lastSeen}}",
                guest: "Gost"
            },
            general: "{{spaceName}} - Osnovno",
            chat: "Razgovor",
            email: "E-pošta",
            name: "Ime",
            bio: "Biografija",
            phone: "Telefon",
            topic: "Tema",
            participants: "Sudionici",
            commonGroups: "Zajedničke grupe",
            commonSpaces: "Zajednički prostori",
            contactInfo: "Kontakt",
            placeholder: {
                searchResults: "Krenite pisati kako biste vidjeli rezultate",
                addTopic: "Dodajte temu",
                pickAddress: "Unesite ime",
                limit: {
                    reached: "Kako biste pozvali druge ljude, maknite jednog od odabranih sudionika",
                    overquota: "Ova grupa je dosegla maksimalni broj sudionika"
                },
                filter: "Unesite nešto kako biste filtrirali listu",
                writeMail: "Unesi email adresu"
            },
            newMessages: "Nove poruke",
            description: {
                members: {
                    one: "Jedan sudionik",
                    many: "{{membersCount}} sudionici"
                }
            },
            action: {
                silenceConversation: "Tihi razgovor",
                sendConversation: "Pošalji razgovor kao e-pošta",
                clearHistory: "Očisti povijest",
                blockUser: "Blokiraj korisnika",
                inviteParticipants: "Dodaj sudionika",
                leaveGroup: "Napusti grupu",
                removeBuddy: "Ukloni prijatelja",
                confirm: {
                    leaveGroup: "Jeste li sigurni da želite napustiti grupu?",
                    removeBuddy: "Jeste li sigurni da želite ukloniti prijatelja?",
                    deleteSpace: "Da li zaista želiš izbrisati prostor?",
                    leaveChannel: "Jesi li siguran da želite napustiti kanal?",
                    deleteChannel: "Jesi li siguran da želiš izbrisati kanal?"
                },
                leaveChannel: "Napusti ovaj kanal",
                inviteToSpace: "Pozovi u prostor",
                leaveSpace: "Napusti prostor",
                deleteSpace: "Izbriši prostor",
                deleteChannel: "Izbriši kanal",
                joinChannelAction: "Priključi se kanalu",
                silenceGeneral: "Opća tišina",
                joinChannel: "Priključi se kanalu za primanje i slanje obavijesti",
                returnToCallTab: "Odi na razgovor",
                scrollToTheBottom: "Odi na dno",
                scrollToNewMessage: "Odi na novu poruku",
                copyLink: "Kopiraj poveznicu i pošalji ju",
                inviteFeedback: "Pozivnica poslana",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Drugi trenutni sastanak je u tijeku.\nSamo jedan trenutni sastanak može biti u nekom trenutku"
            },
            shared: {
                media: "Dijeljenje datoteke",
                link: "Dijeljeni linkovi"
            },
            save: "Spremi",
            cancel: "Odustani",
            space: {
                administrator: "Administrator prostora"
            },
            notification: {
                you: {
                    join: {
                        group: "Priključio si se grupi",
                        channel: "Priključio si se kanalu",
                        space: "Priključio si se prostoru",
                        instantMeeting: "Priključio si se instantnom razgovoru"
                    },
                    invited: "Pozvao te {{invited_by}}",
                    left: {
                        group: "Napustio si grupu",
                        channel: "Napustio si kanal",
                        space: "Napustio si prostor"
                    },
                    changed: {
                        topic: {
                            group: "Promijenio si temu grupe u {{topic}}",
                            channel: "Promijenio si temu kanala u {{topic}}",
                            space: "Promijenio si temu prostora u {{topic}}"
                        },
                        name: {
                            channel: "Promijenio si naziv kanala u {{name}}",
                            space: "Promijenio si naziv prostora u {{name}}"
                        },
                        picture: {
                            group: "Promijenio si sliku grupe",
                            channel: "Promijenio si sliku kanala",
                            space: "Promijenio si naziv prostora"
                        }
                    },
                    kicked: {
                        channel: "Maknut si iz kanala od strane {{kicked_by}}",
                        space: "Maknut si iz prostora od strane {{kicked_by}}"
                    },
                    created: {
                        single: "Kreirao si razgovor",
                        group: "Kreirao si grupu",
                        channel: "Kreirao si kanal",
                        space: "Kreirao si prostor"
                    },
                    deleted: {
                        instantMeeting: "Izbrisao si instantni razgovor",
                        channel: "Izbrisao si kanal",
                        space: "Izbrisao si prostor"
                    }
                },
                member: {
                    invited: "{{member_name}} je pozvan od {{invited_by}}",
                    you: {
                        invited: "Pozvao si {{member_name}}",
                        kicked: {
                            channel: "Maknuo si iz kanala {{member_name}}",
                            space: "Maknuo si iz prostora {{member_name}}"
                        }
                    },
                    left: {
                        group: "{{member_name}} je napustio grupu",
                        channel: "{{member_name}} je napustio kanal",
                        space: "{{member_name}} je napustio prostor"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} je promijenio temu grupe u {{topic}}",
                            channel: "{{member_name}} je promijenio temu kanala u {{topic}}",
                            space: "{{member_name}} je promijenio temu prostora u {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} je promijenio naziv kanala u {{name}}",
                            space: "{{member_name}} je promijenilo naziv prostora u {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} je promijenio sliku grupe",
                            channel: "{{member_name}} je promijenio sliku kanala",
                            space: "{{member_name}} je promijenio sliku prostora"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} je maknut iz kanala od strane {{kicked_by}}",
                        space: "{{member_name}} je maknut iz prosotra od strane {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} je kreirao razgovor",
                        group: "{{member_name}} je kreirao grupu",
                        channel: "{{member_name}} je kreirao kanal",
                        space: "{{member_name}} je kreirao prostor"
                    },
                    deleted: {
                        instantMeeting: "{{member_name}} je obrisao trenutni razgovor",
                        channel: "{{member_name}} je obrisao kanal",
                        space: "{{member_name}} je obrisao prostor"
                    },
                    join: "{{member_name}} se priključio razgovoru",
                    channel: {
                        join: "{{member_name}} se priključio kanalu"
                    }
                },
                conversation: {
                    created: "Razgovor je kreiran"
                },
                meeting: {
                    started: "Sastanak je počeo",
                    ended: "Sastanak je završio"
                },
                newMeeting: "Dolazni poziv od:",
                answer: "Odgovori",
                dismiss: "Odbaci",
                remindLater: "Podsjetnik za kasnije…",
                unreadMessages: "Nepročitane poruke",
                newMessage: "Nova poruka",
                markAllAsRead: "Sve označi kao pročitano",
                drive_size_exceeded: "Datoteka je prevelika"
            },
            writing: {
                generic: {
                    status: "piše…"
                },
                specific: {
                    status: "{{writer}} piše…"
                }
            },
            selection: {
                participants: {
                    none: "Došli ste do limita sudionika postavljenog od strane administratora",
                    one: "Možete pozvat jednog sudionika",
                    many: "Možete pozvati još {{limit}} sudionika"
                }
            },
            mail: {
                invite: {
                    message: "Poziv na sastanak",
                    join_now: "Pridruži se sada",
                    follow_to_join: "Za pridruživanje na sastanak otvorite sljedeću poveznicu:",
                    generated_by_connect: "Automatski generirani email od strane Zimbra Connect",
                    generated_by_team: "Automatski generirani email od strane Team",
                    space: "Pozvani ste u novi prostor!",
                    redirect: "Idi na prostor"
                },
                kick: {
                    space: "Maknuti ste iz ovog prostora",
                    redirect: "Početak"
                }
            },
            settings: {
                team: {
                    title: "Postavke tima"
                },
                connect: {
                    title: "Postavke komunikatora"
                },
                notification: {
                    connect: "Obavijesti komunikatora",
                    team: "Obavijesti tima",
                    zimbra: "Obavijesti Zimbrae",
                    meeting: "Obavijesti tijekom sastanka",
                    spawn3: "3 sekunde",
                    spawn5: "5 sekundi",
                    spawn10: "10 sekundi",
                    spawn0: "Nikad ne nestaje",
                    spawn: {
                        label: "Obavijesti"
                    },
                    desktop: "Obavijesti na radnoj površini",
                    title: {
                        notifications: "Obavijesti",
                        minichat: "Otvori razgovor kada stigne nova poruka",
                        hint: "Prikaži poruke u obavijestima"
                    }
                },
                profile: {
                    title: "Profil"
                },
                avatar: {
                    autocenter: "Slika će biti automatski centrirana.",
                    size: "Maksimalna veličina 256 kB"
                },
                meeting: {
                    title: {
                        meetingStart: "Početne postavke razgovora"
                    },
                    default: {
                        video: "Kamera",
                        audio: "Mikrofon"
                    }
                }
            },
            fileNotAvailable: "Datoteka nije dostupna.",
            contactOwner: "Kontaktirajte vlasnika.",
            message: {
                browserNotSupported: {
                    Team: "Korištena verzija preglednika nije podržana. Probajte s drugim preglednikom!",
                    Connect: "Korištena verzija preglednika nije podržana. Probajte s drugim preglednikom!"
                },
                popup: {
                    readBy: "Pročitao"
                }
            },
            error: {
                uploadPicturesFailed: "Neuspješno učitavanje slike",
                uploadConversationPicturesFailed: "Prijenos slike nije uspio"
            },
            instantMeetingAlreadyRunningTitle: "Trenutni sastanak već traje.",
            instantMeetingAlreadyRunningText: "Kreiranje novog će se ukloniti stari i svi sudionici će izgubiti vezu. Što želite napraviti?",
            instantMeeting: {
                create: "Kreiraj novi trenutni sastanak",
                continue: "Nastavi sa starim trenutnim sastankom"
            },
            input: {
                "nameRequired-max140Characters-avoidReusingNames": "Obavezno. Maksimalno 140 znakova, nemojte koristiti već korištena imena",
                nameNeeds2Letters: "Naziv treba barem dva slova",
                nameRequired: "Naziv je obavezan",
                nameMax140Characters: "Maksimalno 140 znakova",
                topicOptional: "Opcionalno. Opisuje temu",
                topicNeeds2Letters: "Ime grupne teme zahtjeva barem dva slova (ili nijedno)",
                topicMax255Characters: "Maksimalno 255 znakova"
            },
            edit: "Uredi",
            undo: "Vrati",
            modal: {
                closedInstantMeeting: "Trenutni razgovor zatvoren",
                endCallByOwner: "Vlasnik trenutnog razgovora je odlučio završiti poziv."
            },
            miniChat: {
                header: {
                    expand: "Proširi",
                    close: "Zatvori",
                    openInTeam: "Otvori",
                    meeting: "Započni sastanak",
                    collapse: "Sažmi"
                }
            },
            meeting: {
                startModal: {
                    save: "Spremi postavke",
                    videoAndAudio: "Kamera je uključena, mikrofon je uključen",
                    noVideoAndAudio: "Kamera je isključena, mikrofon je isključen",
                    videoAndNoAudio: "Kamera je uključena, mikrofon je isključen",
                    noVideoAndNoAudio: "Kamera je isključena, mikrofon je isključen",
                    enter: "Enter",
                    description: "Kako želite ući na sastanak?",
                    cancel: "Odustani"
                },
                interactions: {
                    pttHint: "Drži 'T' za razgovor",
                    closeCall: "Zatvori ovaj poziv",
                    disableAudio: "Onemogući audio",
                    enableAudioWithHint: "Omogući Audio (pritisni i drži 'T' za razgovor)",
                    enableAudio: "Omogući Audio",
                    disableVideo: "Onemogući video",
                    enableVideo: "Omogući video",
                    disableScreensharing: "Onemogući dijeljenje zaslona",
                    enableScreenSharing: "Omogući dijeljenje zaslona",
                    unmuteUserAudio: "Uključite zvuk ovog korisnika",
                    muteUserAudio: "Isključite zvuk ovog korisnika",
                    showUserVideo: "Prikaži video ovog korisnika",
                    hideUserVideo: "Sakrij video ovog korisnika",
                    status: {
                        cameraOff: "Vaša kamera je isključena",
                        cameraMicOff: "Vaša kamera i mikrofon su isključeni"
                    }
                }
            },
            external: {
                login: {
                    signIn: "Prijava",
                    accessMeeting: "Pristup sastanku"
                }
            },
            nickname: "Nadimak",
            password: "Lozinka",
            conversation: {
                fileUploadDescription: "Opis datoteke"
            },
            loadingScreen: {
                poweredBy: "powered by"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_id.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            edit: "Edit",
            bio: "Bio",
            message: {
                browserNotSupported: {
                    Team: "Kami tidak mendukung versi browser Anda. Sebaiknya perbarui browser Anda untuk mendapatkan manfaat dari semua fitur Team!",
                    Connect: "Kami tidak mendukung versi browser Anda. Sebaiknya perbarui browser Anda untuk mendapatkan manfaat dari semua fitur Connect!"
                },
                popup: {
                    readBy: "Dibaca oleh"
                }
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "Kamera dan mikrofon Anda nonaktif",
                        cameraOff: "Kamera Anda nonaktif"
                    },
                    hideUserVideo: "Sembunyikan video milik pengguna ini",
                    showUserVideo: "Tampilkan video milik pengguna ini",
                    muteUserAudio: "Bisukan audio milik pengguna ini",
                    unmuteUserAudio: "Nyalakan audio milik pengguna ini",
                    enableScreenSharing: "Aktifkan Berbagi Layar",
                    disableScreensharing: "Nonaktifkan Berbagi Layar",
                    enableVideo: "Aktifkan Video",
                    disableVideo: "Nonaktifkan Video",
                    enableAudio: "Aktifkan Audio",
                    enableAudioWithHint: "Aktifkan Audio (tekan dan tahan 'T' untuk berbicara)",
                    disableAudio: "Nonaktifkan Audio",
                    closeCall: "Tutup panggilan ini",
                    pttHint: "Tekan 'T' untuk berbicara"
                },
                startModal: {
                    save: "Simpan setelan ini",
                    cancel: "Batal",
                    description: "Bagaimana cara yang Anda inginkan untuk masuk ke rapat?",
                    enter: "Masuk",
                    noVideoAndNoAudio: "Kamera nonaktif, Mikrofon nonaktif",
                    videoAndNoAudio: "Kamera aktif, Mikrofon nonaktif",
                    noVideoAndAudio: "Kamera nonaktif, Mikrofon nonaktif",
                    videoAndAudio: "Kamera aktif, Mikrofon aktif"
                }
            },
            modal: {
                endCallByOwner: "Pemilik rapat instan telah memutuskan untuk mengakhiri panggilan, kami harap Anda menikmati pengalaman rapat instan.",
                closedInstantMeeting: "Rapat instan ditutup"
            },
            undo: "Batalkan",
            input: {
                topicMax255Characters: "Maksimal 255 karakter",
                topicNeeds2Letters: "Topik grup butuh setidaknya dua huruf (atau tidak sama sekali)",
                topicOptional: "Opsional. Ini mendeskripsikan pokok bahasan",
                nameMax140Characters: "Maksimal 140 karakter",
                nameRequired: "Nama wajib diisi",
                nameNeeds2Letters: "Nama membutuhkan setidaknya dua huruf",
                "nameRequired-max140Characters-avoidReusingNames": "Wajib diisi. Maksimal 140 karakter, hindari menggunakan nama kembali"
            },
            action: {
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Rapat instan yang lain sedang berjalan. \n Hanya satu rapat instan yang bisa berjalan dalam satu waktu",
                inviteFeedback: "Undangan terkirim",
                copyLink: "atau salin dan kirim tautan",
                scrollToNewMessage: "Gulir ke pesan baru",
                scrollToTheBottom: "Gulir ke bawah",
                returnToCallTab: "Buka tab rapat",
                joinChannel: "Gabung ke saluran untuk mengirim pesan dan menerima notifikasi",
                silenceGeneral: "Senyapkan umum",
                confirm: {
                    deleteChannel: "Apakah Anda yakin ingin menghapus saluran?",
                    leaveChannel: "Apakah Anda yakin ingin keluar saluran?",
                    deleteSpace: "Apakah Anda yakin ingin menghapus ruang?",
                    removeBuddy: "Apakah Anda yakin ingin menghapus teman ini?",
                    leaveGroup: "Apakah Anda yakin ingin keluar grup?"
                },
                joinChannelAction: "Gabung dengan saluran ini",
                deleteChannel: "Hapus saluran",
                deleteSpace: "Hapus ruang",
                leaveSpace: "Keluar ruang",
                inviteToSpace: "Undang ke dalam ruang",
                leaveChannel: "Keluar saluran ini",
                removeBuddy: "Hapus teman",
                leaveGroup: "Keluar grup",
                inviteParticipants: "Tambahkan peserta",
                blockUser: "Blokir Pengguna",
                clearHistory: "Bersihkan riwayat",
                sendConversation: "Kirim percakapan melalui email",
                silenceConversation: "Senyapkan percakapan"
            },
            instantMeeting: {
                continue: "Lanjutkan dengan rapat instan lama",
                create: "Buat rapat instan baru"
            },
            instantMeetingAlreadyRunningText: "Membuat yang baru akan menghentikan yang lama dan peserta akan kehilangan koneksi. Apa yang akan Anda lakukan?",
            instantMeetingAlreadyRunningTitle: "Rapat instan sudah berjalan.",
            error: {
                uploadPicturesFailed: "Gagal mengunggah foto profil",
                uploadConversationPicturesFailed: "Gagal mengunggah gambar percakapan"
            },
            new: {
                attendee: {
                    feedback: {
                        emailReplicated: "Email yang dimasukkan telah ditambahkan",
                        negative: "Email yang dimasukkan tidak valid, harap masukkan email yang valid",
                        neutral: "Tekan ENTER untuk menambahkan alamat ke daftar peserta",
                        positive: "Peserta ditambahkan ke daftar"
                    },
                    empty: "Anda belum menambahkan peserta",
                    title: "Daftar Peserta",
                    invite: "Tambah peserta"
                },
                participants: {
                    limit: "Anda bisa mengundang sampai {{max_participants}} orang",
                    requires: {
                        one: "Butuh setidaknya satu peserta lagi",
                        two: "Butuh setidaknya 2 lainnya"
                    }
                },
                speakToYourFriend: "Bicara dengan teman Anda",
                invite: "Tambahkan peserta",
                spaceSelect: "Pilih ruang untuk membuat saluran",
                spaceSelectRequire: "Wajib diisi. Saluran selalu terhubung dengan ruang",
                nameRequired: "Wajib diisi. Maksimal 140 karakter, hindari menggunakan nama kembali",
                "channel-optionalTopic": "Opsional. Ini mendeskripsikan pokok bahasan saluran",
                "space-optionalTopic": "Opsional. Ini mendeskripsikan pokok bahasan",
                "group-optionalTopic": "Opsional. Ini mendeskripsikan pokok bahasan grup",
                optional: "opsional",
                selectPic: "Pilih gambar",
                instantMeeting: "Rapat instan baru",
                channel: "Saluran baru",
                space: "Ruang baru",
                group: "Grup baru",
                conversation: "Percakapan baru"
            },
            notification: {
                markAllAsRead: "Tandai semua telah dibaca",
                member: {
                    channel: {
                        join: "{{member_name}} telah bergabung dengan saluran"
                    },
                    join: "{{member_name}} telah bergabung dalam percakapan",
                    deleted: {
                        space: "{{member_name}} telah menghapus ruang",
                        channel: "{{member_name}} telah menghapus saluran",
                        instantMeeting: "{{member_name}} telah menghapus rapat instan"
                    },
                    created: {
                        space: "{{member_name}} telah membuat ruang",
                        channel: "{{member_name}} telah membuat saluran",
                        group: "{{member_name}} telah membuat grup",
                        single: "{{member_name}} telah membuat percakapan"
                    },
                    you: {
                        kicked: {
                            space: "Anda telah mengeluarkan dari ruang {{member_name}}",
                            channel: "Anda telah mengeluarkan dari saluran {{member_name}}"
                        },
                        invited: "Anda telah mengundang {{member_name}}"
                    },
                    kicked: {
                        space: "{{member_name}} telah dikeluarkan dari ruang oleh {{kicked_by}}",
                        channel: "{{member_name}} telah dikeluarkan dari saluran oleh {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} telah mengganti gambar ruang",
                            channel: "{{member_name}} telah mengganti gambar saluran",
                            group: "{{member_name}} telah mengganti gambar grup"
                        },
                        name: {
                            space: "{{member_name}} telah mengganti nama ruang dalam {{name}}",
                            channel: "{{member_name}} telah mengganti nama saluran dalam {{name}}"
                        },
                        topic: {
                            space: "{{member_name}} telah mengganti topik ruang dalam {{topic}}",
                            channel: "{{member_name}} telah mengganti topik saluran dalam {{topic}}",
                            group: "{{member_name}} telah mengganti topik grup dalam {{topic}}"
                        }
                    },
                    left: {
                        space: "{{member_name}} telah keluar ruang",
                        channel: "{{member_name}} telah keluar saluran",
                        group: "{{member_name}} telah keluar grup"
                    },
                    invited: "{{member_name}} telah diundang oleh {{invited_by}}"
                },
                drive_size_exceeded: "File terlalu besar",
                newMessage: "Pesan baru",
                unreadMessages: "Pesan Belum Dibaca",
                remindLater: "Ingatkan saya nanti…",
                dismiss: "Tolak",
                answer: "Terima",
                newMeeting: "Panggilan masuk dari:",
                meeting: {
                    ended: "Rapat berakhir",
                    started: "Rapat dimulai"
                },
                you: {
                    deleted: {
                        space: "Anda telah menghapus ruang",
                        channel: "Anda telah menghapus saluran",
                        instantMeeting: "Anda telah menghapus rapat instan"
                    },
                    created: {
                        space: "Anda telah membuat ruang",
                        channel: "Anda telah membuat saluran",
                        group: "Anda telah membuat grup",
                        single: "Anda telah membuat percakapan"
                    },
                    kicked: {
                        space: "Anda telah dikeluarkan dari ruang oleh {{kicked_by}}",
                        channel: "Anda telah dikeluarkan dari saluran oleh {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "Anda telah mengganti nama ruang",
                            channel: "Anda telah mengganti gambar saluran",
                            group: "Anda telah mengganti gambar grup"
                        },
                        name: {
                            space: "Anda telah mengganti nama ruang dalam {{name}}",
                            channel: "Anda telah mengganti nama grup dalam {{name}}"
                        },
                        topic: {
                            space: "Anda telah mengganti topik ruang dalam {{topic}}",
                            channel: "Anda telah mengganti topik saluran dalam {{topic}}",
                            group: "Anda telah mengganti topik grup dalam {{topic}}"
                        }
                    },
                    left: {
                        space: "Anda telah keluar dari ruang",
                        channel: "Anda telah keluar dari saluran",
                        group: "Anda telah keluar dari grup"
                    },
                    invited: "Anda telah diundang oleh {{invited_by}}",
                    join: {
                        instantMeeting: "Anda telah bergabung dengan rapat instan",
                        space: "Anda telah bergabung dengan saluran",
                        channel: "Anda telah bergabung dengan saluran",
                        group: "Anda telah bergabung dengan grup"
                    }
                },
                conversation: {
                    created: "Percakapan dibuat"
                }
            },
            button: {
                start: "Mulai",
                remove: "Hapus",
                delete: "Hapus",
                leave: "Keluar",
                join: "Bergabung",
                new: "BARU"
            },
            contactOwner: "Hubungi pemilik.",
            fileNotAvailable: "File tidak tersedia.",
            placeholder: {
                limit: {
                    overquota: "Grup ini telah mencapai batas maksimum peserta",
                    reached: "Untuk mengundang orang lain, hapus salah satu kontak yang dipilih"
                },
                writeMail: "Ketik alamat email",
                filter: "Ketik untuk memfilter daftar",
                pickAddress: "Mulai mengetik untuk memilih alamat",
                addTopic: "Tambahkan topik",
                searchResults: "Mulai mengetik untuk melihat hasil pencarian"
            },
            settings: {
                notification: {
                    title: {
                        hint: "Tampilkan pratinjau pesan dalam notifikasi",
                        minichat: "Buka obrolan mini saat pesan baru muncul",
                        notifications: "Notifikasi"
                    },
                    desktop: "Notifikasi Desktop",
                    spawn: {
                        label: "Waktu notifikasi muncul"
                    },
                    spawn0: "Tidak pernah hilang",
                    spawn10: "10 detik",
                    spawn5: "5 detik",
                    spawn3: "3 detik",
                    meeting: "Notifikasi selama rapat",
                    zimbra: "Notifikasi Zimbra",
                    team: "Notifikasi Team",
                    connect: "Notifikasi Connect"
                },
                avatar: {
                    size: "Dimensi maksimum 256 kB",
                    autocenter: "Gambar akan ditempatkan di tengah secara otomatis."
                },
                profile: {
                    title: "Profil",
                    maximumDimension: "Dimensi maksimum: 256kb.",
                    restore: "Pulihkan"
                },
                connect: {
                    title: "Setelan Connect"
                },
                team: {
                    title: "Setelan Team"
                },
                meeting: {
                    title: {
                        meetingStart: "Setelan awal rapat"
                    },
                    default: {
                        video: "Kamera",
                        audio: "Mikrofon"
                    }
                },
                notifications: {
                    title: "Notifikasi"
                }
            },
            header: {
                instantInfo: "Info Rapat Instan",
                filter: {
                    channel: "Saluran yang difilter",
                    conversation: "Percakapan yang difilter"
                },
                invite: "Undang ke dalam grup",
                channelInfo: "Info Saluran",
                spaceInfo: "Info Ruang",
                groupInfo: "Info Grup",
                contactInfo: "Info Kontak",
                new: {
                    instantMeeting: "Rapat instan baru",
                    channel: "Saluran baru",
                    space: "Ruang baru",
                    group: "Grup baru",
                    conversation: "Percakapan baru"
                },
                channels: "Saluran",
                conversations: "Percakapan"
            },
            mail: {
                invite: {
                    redirect: "Buka ruang",
                    space: "Anda telah diundang ke ruang baru!",
                    generated_by_team: "Email ini telah dibuat secara otomatis oleh Team",
                    generated_by_connect: "Email ini telah dibuat secara otomatis oleh Zimbra Connect",
                    follow_to_join: "Untuk bergabung dalam rapat, ikuti tautan ini:",
                    join_now: "Gabung sekarang",
                    message: "Anda diundang untuk bergabung dalam rapat"
                },
                kick: {
                    redirect: "Buka beranda",
                    space: "Anda telah dikeluarkan dari ruang ini"
                }
            },
            selection: {
                participants: {
                    many: "Anda dapat mengundang {{limit}} peserta lain",
                    one: "Anda dapat mengundang peserta terakhir",
                    none: "Anda telah mencapai batas peserta yang ditetapkan oleh administrator"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}} sedang menulis…"
                },
                generic: {
                    status: "sedang menulis…"
                }
            },
            space: {
                administrator: "Administrator Ruang"
            },
            cancel: "Batal",
            save: "Simpan",
            shared: {
                link: "Tautan dibagikan",
                media: "Media dibagikan"
            },
            description: {
                members: {
                    many: "{{membersCount}} anggota",
                    one: "Satu peserta"
                }
            },
            newMessages: "Pesan Baru",
            contactInfo: "Info kontak",
            commonSpaces: "Ruang umum",
            commonGroups: "Grup umum",
            participants: "Peserta",
            topic: "Topik",
            phone: "Telepon",
            name: "Nama",
            email: "Email",
            chat: "Obrolan",
            general: "{{spaceName}} - Umum",
            status: {
                last_seen: "Terakhir dilihat {{lastSeen}}",
                offline: "Offline",
                online: "Online",
                guest: "Tamu"
            },
            treeMenu: {
                instantMeeting: "Rapat Instan",
                spaces: "Ruang",
                conversations: "Percakapan"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            miniChat: {
                header: {
                    collapse: "Ciutkan",
                    meeting: "Mulai Rapat",
                    openInTeam: "Buka di Team",
                    close: "Tutup",
                    expand: "Perluas"
                }
            },
            password: "Kata sandi",
            nickname: "Nama panggilan",
            external: {
                login: {
                    accessMeeting: "Untuk mengakses rapat",
                    signIn: "Masuk"
                }
            },
            conversation: {
                fileUploadDescription: "Deskripsi File"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_it.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            connectMenuItem: "Connect",
            treeMenu: {
                conversations: "Conversazioni",
                spaces: "Spazi",
                instantMeeting: "Instant Meeting"
            },
            button: {
                new: "NUOVO",
                join: "Partecipa",
                leave: "Abbandona",
                delete: "Elimina",
                remove: "Rimuovi",
                start: "Avvia"
            },
            new: {
                conversation: "Nuova chat singola",
                group: "Nuovo gruppo",
                space: "Nuovo spazio",
                channel: "Nuovo canale",
                instantMeeting: "Nuovo instant meeting",
                selectPic: "Seleziona un'immagine",
                optional: "opzionale",
                "group-optionalTopic": "Opzionale. Descrive l'argomento trattato nel gruppo",
                "space-optionalTopic": "Opzionale. Descrive l'argomento trattato",
                "channel-optionalTopic": "Opzionale. Descrive l'argomento trattato nel canale",
                nameRequired: "Obbligatorio. Evita nomi già utilizzati, massimo 140 caratteri",
                spaceSelectRequire: "Obbligatorio. I canali sono sempre collegati a uno spazio",
                spaceSelect: "Seleziona uno spazio per creare un canale",
                invite: "Aggiungi partecipanti",
                speakToYourFriend: "Chatta con un contatto",
                participants: {
                    requires: {
                        two: "Sono richiesti almeno altri due partecipanti",
                        one: "È richiesto almeno un altro partecipante"
                    },
                    limit: "Puoi invitare fino a {{max_participants}} persone"
                },
                attendee: {
                    feedback: {
                        positive: "Partecipante aggiunto alla lista",
                        neutral: "Premi INVIO per aggiungere l'indirizzo alla lista dei partecipanti",
                        negative: "L'indirizzo mail inserito non è valido, per favore inserisci una mail valida",
                        emailReplicated: "Questa mail è già stata aggiunta"
                    },
                    invite: "Aggiungi partecipante",
                    title: "Lista dei partecipanti",
                    empty: "Non hai ancora aggiunto nessun partecipante"
                }
            },
            header: {
                conversations: "Conversazioni",
                channels: "Canali",
                new: {
                    conversation: "Nuova chat singola",
                    group: "Nuovo gruppo",
                    space: "Nuovo spazio",
                    channel: "Nuovo canale",
                    instantMeeting: "Nuovo instant meeting"
                },
                contactInfo: "Info Contatto",
                groupInfo: "Info gruppo",
                spaceInfo: "Info spazio",
                channelInfo: "Info canale",
                invite: "Invita nel gruppo",
                filter: {
                    conversation: "Chats filtrate",
                    channel: "Canali filtrati"
                },
                instantInfo: "Informazioni Instant Meeting"
            },
            status: {
                online: "Online",
                offline: "Offline",
                last_seen: "Ultima visualizzazione {{lastSeen}}",
                guest: "Ospite"
            },
            general: "{{spaceName}} - Generale",
            chat: "Chat",
            email: "Email",
            name: "Nome",
            bio: "Bio",
            phone: "Telefono",
            topic: "Argomento",
            participants: "Partecipanti",
            commonGroups: "Gruppi in comune",
            commonSpaces: "Spazi in comune",
            contactInfo: "Info contatto",
            placeholder: {
                searchResults: "Cerca",
                addTopic: "Aggiungi argomento",
                pickAddress: "Scrivi per scegliere un indirizzo",
                limit: {
                    reached: "Per aggiungere altre persone, rimuovi uno dei contatti selezionati",
                    overquota: "Questo gruppo ha raggiunto il limite massimo di partecipanti"
                },
                filter: "Digita per filtrare la lista",
                writeMail: "Digita un indirizzo mail"
            },
            newMessages: "Nuovi messaggi",
            description: {
                members: {
                    one: "Unico partecipante",
                    many: "{{membersCount}} membri"
                }
            },
            action: {
                silenceConversation: "Silenzia conversazione",
                sendConversation: "Invia conversazione tramite email",
                clearHistory: "Cancella cronologia",
                blockUser: "Blocca utente",
                inviteParticipants: "Aggiungi partecipanti",
                leaveGroup: "Abbandona il gruppo",
                removeBuddy: "Rimuovi partecipante",
                confirm: {
                    leaveGroup: "Sei sicuro di voler abbandonare il gruppo?",
                    removeBuddy: "Sei sicuro di voler rimuovere questo partecipante?",
                    deleteSpace: "Sei sicuro di volere eliminare questo spazio?",
                    leaveChannel: "Sei sicuro di voler abbandonare il canale?",
                    deleteChannel: "Sei sicuro di voler eliminare questo canale?"
                },
                leaveChannel: "Abbandona il canale",
                inviteToSpace: "Invita all'interno dello spazio",
                leaveSpace: "Abbandona spazio",
                deleteSpace: "Elimina spazio",
                deleteChannel: "Elimina canale",
                joinChannelAction: "Partecipa al canale",
                silenceGeneral: "Silenzia tutto",
                joinChannel: "Partecipa al canale per inviare messaggi e ricevere notifiche",
                returnToCallTab: "Vai alla meeting tab",
                scrollToTheBottom: "Scorri in fondo",
                scrollToNewMessage: "Scorri al nuovo messaggio",
                copyLink: "oppure copia il link e condividilo",
                inviteFeedback: "Invito inviato",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Un altro Instant Meeting è in corso.\nPuò esistere solo un Instant Meeting alla volta"
            },
            shared: {
                media: "Media condivisi",
                link: "Link condivisi"
            },
            save: "Salva",
            cancel: "Annulla",
            space: {
                administrator: "Amministratore dello Spazio"
            },
            notification: {
                you: {
                    join: {
                        group: "Ora fai parte del gruppo",
                        channel: "Ora fai parte del canale",
                        space: "Ora fai parte dello spazio",
                        instantMeeting: "Stai partecipando all'instant meeting"
                    },
                    invited: "Sei stato invitato da {{invited_by}}",
                    left: {
                        group: "Hai abbandonato il gruppo",
                        channel: "Hai abbandonato il canale",
                        space: "Hai abbandonato lo spazio"
                    },
                    changed: {
                        topic: {
                            group: "Hai modificato l'argomento del gruppo in {{topic}}",
                            channel: "Hai modificato l'argomento del canale in {{topic}}",
                            space: "Hai modificato l'argomento dello spazio in {{topic}}"
                        },
                        name: {
                            channel: "Hai modificato il nome del canale in {{name}}",
                            space: "Hai modificato il nome dello spazio in {{name}}"
                        },
                        picture: {
                            group: "Hai modificato l'immagine del gruppo",
                            channel: "Hai modificato l'immagine del canale",
                            space: "Hai modificato l'immagine dello spazio"
                        }
                    },
                    kicked: {
                        channel: "Sei stato rimosso dal canale da {{kicked_by}}",
                        space: "Sei stato rimosso dallo spazio da {{kicked_by}}"
                    },
                    created: {
                        single: "Hai creato la chat singola",
                        group: "Hai creato il gruppo",
                        channel: "Hai creato il canale",
                        space: "Hai creato lo spazio"
                    },
                    deleted: {
                        instantMeeting: "Hai cancellato l'instant meeting",
                        channel: "Hai eliminato il canale",
                        space: "Hai eliminato lo spazio"
                    }
                },
                member: {
                    invited: "{{member_name}} è stato invitato da {{invited_by}}",
                    you: {
                        invited: "Hai invitato {{member_name}}",
                        kicked: {
                            channel: "Hai rimosso {{member_name}} dal canale",
                            space: "Hai rimosso {{member_name}} dallo spazio"
                        }
                    },
                    left: {
                        group: "{{member_name}} ha abbandonato il gruppo",
                        channel: "{{member_name}} ha abbandonato il canale",
                        space: "{{member_name}} ha abbandonato lo spazio"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} ha modificato l'argomento del gruppo in {{topic}}",
                            channel: "{{member_name}} ha modificato l'argomento del canale in {{topic}}",
                            space: "{{member_name}} ha modificato l'argomento dello spazio in {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} ha modificato il nome del canale in {{name}}",
                            space: "{{member_name}} ha modificato il nome dello spazio in {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} ha modificato l'immagine del gruppo",
                            channel: "{{member_name}} ha modificato l'immagine del canale",
                            space: "{{member_name}} ha modificato l'immagine dello spazio"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} è stato rimosso dal canale da {{kicked_by}}",
                        space: "{{member_name}} è stato rimosso dallo spazio da {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} ha creato la chat singola",
                        group: "{{member_name}} ha creato il gruppo",
                        channel: "{{member_name}} ha creato il canale",
                        space: "{{member_name}}ha creato lo spazio"
                    },
                    deleted: {
                        instantMeeting: "{{member_name}} ha cancellato l'instant meeting",
                        channel: "{{member_name}} ha eliminato il canale",
                        space: "{{member_name}} ha eliminato lo spazio"
                    },
                    join: "{{member_name}} si è unito alla conversazione",
                    channel: {
                        join: "{{member_name}} partecipa al canale"
                    }
                },
                conversation: {
                    created: "Conversazione creata"
                },
                meeting: {
                    started: "Meeting iniziato",
                    ended: "Meeting terminato"
                },
                newMeeting: "Chiamata in arrivo da:",
                answer: "Rispondi",
                dismiss: "Rifiuta",
                remindLater: "Ricordamelo dopo…",
                unreadMessages: "Messaggi non letti",
                newMessage: "Nuovo messaggio",
                markAllAsRead: "Segna tutto come letto",
                drive_size_exceeded: "Il file è troppo grande"
            },
            writing: {
                generic: {
                    status: "sta scrivendo…"
                },
                specific: {
                    status: "{{writer}} sta scrivendo…"
                }
            },
            selection: {
                participants: {
                    none: "Hai raggiunto il numero massimo di partecipanti deciso dall'amministratore",
                    one: "Puoi invitare un ultimo partecipante",
                    many: "Puoi invitare altri {{limit}} partecipanti"
                }
            },
            mail: {
                invite: {
                    message: "Sei invitato a partecipare al meeting",
                    join_now: "Partecipa",
                    follow_to_join: "Per partecipare al meeting segui questo link:",
                    generated_by_connect: "Questa mail è stata generata automaticamente da Zimbra Connect",
                    generated_by_team: "Questa mail è stata generata automaticamente da Team",
                    space: "Sei stato invitato in un nuovo spazio!",
                    redirect: "Vai allo spazio"
                },
                kick: {
                    space: "Sei stato rimosso da questo spazio",
                    redirect: "Torna alla home"
                }
            },
            settings: {
                team: {
                    title: "Impostazioni"
                },
                connect: {
                    title: "Impostazioni"
                },
                notification: {
                    connect: "Notifiche di Connect",
                    team: "Notifiche di Team",
                    zimbra: "Notifiche di Zimbra",
                    meeting: "Notifiche durante i meeting",
                    spawn3: "3 secondi",
                    spawn5: "5 secondi",
                    spawn10: "10 secondi",
                    spawn0: "Non scompaiono mai",
                    spawn: {
                        label: "Tempo di permanenza delle notifiche"
                    },
                    desktop: "Notifiche desktop",
                    title: {
                        notifications: "Notifiche",
                        minichat: "Apri la mini chat quando arrivano nuovi messaggi",
                        hint: "Mostra l'anteprima del messaggio nella notifica"
                    }
                },
                profile: {
                    title: "Profilo",
                    maximumDimension: "Dimensione massima: 256kb.",
                    statusOptionalDescription: "Opzionale. Fai sapere agli altri a cosa stai pensando. Lunghezza massima: 256 caratteri",
                    userStatus: "Stato",
                    update: "Aggiorna",
                    restore: "Annulla modifiche",
                    reset: "Ripristina",
                    errorSnackbar: "Sembra esserci un errore con la tua modifica",
                    chooseAProfilePic: "Scegli una foto del profilo da mostrare agli altri utenti, l'immagine verrà centrata automaticamente.",
                    errorMessage: "Spiacente, qualcosa non va",
                    errorGenericResponse: "Qualcosa è andato storto. Per favore riprova",
                    errorUpdatingAvatarStatus: "Errore durante l'impostazione dello stato. Riprova",
                    errorRemovingAvatarPicture: "Errore durante la rimozione dell'immagine del profilo. Riprova",
                    errorUploadingAvatarPicture: "Errore durante il caricamento della nuova immagine profilo. Riprova"
                },
                avatar: {
                    autocenter: "L'immagine verrà centrata automaticamente.",
                    size: "La dimensione massima è di 256 kB"
                },
                meeting: {
                    title: {
                        meetingStart: "Impostazioni di inizio meeting"
                    },
                    default: {
                        video: "Fotocamera",
                        audio: "Microfono"
                    },
                    meetings: "Riunioni",
                    enableCamera: "Abilita fotocamera",
                    enableMicrophone: "Abilita microfono",
                    description: "Imposta le tue preferenze audio e video per partecipare alle riunioni. Potrai sempre personalizzarle prima di ogni riunione."
                },
                notifications: {
                    description: "Imposta le tue preferenze per ogni tipo di notifica in Team.",
                    title: "Notifiche"
                },
                modal: {
                    description: "Qui puoi impostare tutte le preferenze dedicate di Team per vivere un'esperienza di chat completamente personalizzata!"
                }
            },
            fileNotAvailable: "File non disponibile.",
            contactOwner: "Per favore contatta il proprietario.",
            message: {
                browserNotSupported: {
                    Team: "La versione del tuo browser non è supportata. Si consiglia di aggiornarlo per poter usare tutte le features di Team!",
                    Connect: "La versione del tuo browser non è supportata. Si consiglia di aggiornarlo per poter usare tutte le features di Connect!"
                },
                popup: {
                    readBy: "Letto da"
                }
            },
            error: {
                uploadPicturesFailed: "Fallimento nell'upload dell'immagine profilo",
                uploadConversationPicturesFailed: "Impossibile caricare l'immagine della conversazione"
            },
            instantMeetingAlreadyRunningTitle: "Un instant meeting è già in corso.",
            instantMeetingAlreadyRunningText: "Crearne uno nuovo sovrascriverà il precedente e i partecipanti perderanno la connessione, cosa vuoi fare?",
            instantMeeting: {
                create: "Crea un nuovo Instant Meeting",
                continue: "Continua col precedente Instant Meeting"
            },
            input: {
                "nameRequired-max140Characters-avoidReusingNames": "Obbligatorio. Evita nomi già utilizzati, può contenere al massimo 140 caratteri",
                nameNeeds2Letters: "Il nome deve contenere almeno due lettere",
                nameRequired: "Il nome è obbligatorio",
                nameMax140Characters: "Può contenere al massimo 140 caratteri",
                topicOptional: "Opzionale. Descrive l'argomento trattato",
                topicNeeds2Letters: "Se l'argomento del gruppo esiste, deve contenere almeno due lettere",
                topicMax255Characters: "Può contenere al massimo 255 caratteri"
            },
            edit: "Modifica",
            undo: "Annulla",
            modal: {
                closedInstantMeeting: "Instant Meeting terminato",
                endCallByOwner: "Il proprietario dell'Instant Meeting ha deciso di terminare la call, speriamo tu abbia gradito l'esperienza dell'Instant Meeting."
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "La tua webcam e il microfono sono spenti",
                        cameraOff: "La tua webcam è spenta"
                    },
                    hideUserVideo: "Nascondi video di questo utente",
                    showUserVideo: "Mostra video di questo utente",
                    muteUserAudio: "Silenzia audio di questo utente",
                    unmuteUserAudio: "Attiva audio di questo utente",
                    enableScreenSharing: "Abilita Condivisione Schermo",
                    disableScreensharing: "Disabilita Condivisione Schermo",
                    enableVideo: "Abilita Video",
                    disableVideo: "Disabilita Video",
                    enableAudio: "Abilita Audio",
                    enableAudioWithHint: "Abilita Audio (mantieni premuto 'T' per parlare)",
                    disableAudio: "Disabilita Audio",
                    closeCall: "Chiudi questa chiamata",
                    pttHint: "Tieni premuto 'T' per parlare"
                },
                startModal: {
                    save: "Salva impostazioni",
                    cancel: "Annulla",
                    description: "Come vuoi accedere al meeting?",
                    enter: "Accedi",
                    noVideoAndNoAudio: "Webcam spenta, Microfono spento",
                    videoAndNoAudio: "Webcam attiva, Microfono spento",
                    noVideoAndAudio: "Webcam spenta, Microfono attivo",
                    videoAndAudio: "Webcam attiva, Microfono attivo"
                }
            },
            miniChat: {
                header: {
                    collapse: "Riduci",
                    meeting: "Avvia Meeting",
                    openInTeam: "Apri in Team",
                    close: "Chiudi",
                    expand: "Espandi"
                }
            },
            password: "Password",
            nickname: "Nickname",
            external: {
                login: {
                    accessMeeting: "Per accedere al meeting",
                    signIn: "Accedi"
                }
            },
            conversation: {
                fileUploadDescription: "Descrizione file"
            },
            loadingScreen: {
                poweredBy: "offerto da"
            },
            connection: {
                retryConnection: "Riprova a connetterti",
                online: "Di nuovo online!",
                offline: "Sembra esserci un errore di connessione al server"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_ja.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            modal: {
                endCallByOwner: "インスタント会議の所有者が通話を終了することにしました。インスタント会議をお楽しみいただけたことを願います。",
                closedInstantMeeting: "インスタント会議が終了しました"
            },
            undo: "元に戻す",
            edit: "編集する",
            input: {
                topicMax255Characters: "最大255文字",
                topicNeeds2Letters: "グループのトピックは2文字以上（または空欄）でなければなりません",
                topicOptional: "オプション。 題目を記述します",
                nameMax140Characters: "最大140文字",
                nameRequired: "名前は必須です",
                nameNeeds2Letters: "名前には2文字以上必要です",
                "nameRequired-max140Characters-avoidReusingNames": "必須。 最大140文字で、同じ名前は使わないでください"
            },
            action: {
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "別のインスタント会議が行われています。\n  一度に一つだけインスタント会議を行えます",
                inviteFeedback: "招待状が送信されました",
                copyLink: "またはリンクをコピーして送信してください",
                scrollToNewMessage: "新しいメッセージまでスクロールする",
                scrollToTheBottom: "一番下までスクロールする",
                returnToCallTab: "ミーティングタブに進む",
                joinChannel: "チャンネルに参加してメッセージを送信し、通知を受信してください",
                silenceGeneral: "サイレンスの一般設定",
                confirm: {
                    deleteChannel: "本当にこのチャンネルを削除しますか？",
                    leaveChannel: "本当にこのチャンネルから退会しますか？",
                    deleteSpace: "本当にこのスペースを削除しますか？",
                    removeBuddy: "本当にこの仲間を削除しますか？",
                    leaveGroup: "本当にこのグループから退会しますか？"
                },
                joinChannelAction: "このチャンネルに参加する",
                deleteChannel: "チャンネルを削除する",
                deleteSpace: "スペースを削除する",
                leaveSpace: "スペースから退会する",
                inviteToSpace: "スペースに招待する",
                leaveChannel: "このチャンネルから退会する",
                removeBuddy: "仲間を削除する",
                leaveGroup: "グループから退会する",
                inviteParticipants: "参加者を追加する",
                blockUser: "ユーザーをブロックする",
                clearHistory: "履歴をクリアする",
                sendConversation: "メールで会話を送信する",
                silenceConversation: "サイレンス会話"
            },
            instantMeeting: {
                continue: "古いインスタント会議で続行する",
                create: "新しいインスタント会議を作成する"
            },
            instantMeetingAlreadyRunningText: "新しい内容を作成すると古い内容が上書きされて、参加者はConnectを失います。どうしますか？",
            instantMeetingAlreadyRunningTitle: "既にインスタント会議が行われています。",
            error: {
                uploadPicturesFailed: "プロファイル写真のアップロードに失敗しました",
                uploadConversationPicturesFailed: "会話画像をアップロードできませんでした"
            },
            new: {
                attendee: {
                    feedback: {
                        emailReplicated: "入力したメールアドレスは既に追加されています",
                        negative: "入力したメールアドレスは無効です。有効なメールアドレスを入力してください",
                        neutral: "Enterキーを押して、アドレスを参加者リストに追加してください",
                        positive: "参加者がリストに追加されました"
                    },
                    empty: "まだ参加者を追加していません",
                    title: "参加者リスト",
                    invite: "参加者を追加する"
                },
                participants: {
                    limit: "最大{{max参加者}}名まで招待できます",
                    requires: {
                        one: "さらに1名以上の参加者が必要です",
                        two: "他に2つ以上必要です"
                    }
                },
                speakToYourFriend: "友達と話す",
                invite: "参加者を追加する",
                spaceSelect: "チャンネルを作成するスペースを選択してください",
                spaceSelectRequire: "必須。チャンネルは常にスペースにリンクされています",
                nameRequired: "必須。 最大140文字で、同じ名前は利用しないでください",
                "channel-optionalTopic": "オプション。チャンネルの題目を記述します",
                "space-optionalTopic": "オプション。題目を記述します",
                "group-optionalTopic": "オプション。グループの題目を記述します",
                optional: "オプション",
                selectPic: "画像を選択してください",
                instantMeeting: "新しいインスタント会議",
                channel: "新しいチャンネル",
                space: "新しいスペース",
                group: "新しいグループ",
                conversation: "新しい会話"
            },
            notification: {
                markAllAsRead: "すべて未読にする",
                member: {
                    channel: {
                        join: "{{member_name}}がチャンネルに参加しました"
                    },
                    join: "{{member_name}} が会話に参加しました",
                    deleted: {
                        space: "{{member_name}}がスペースを削除しました",
                        channel: "{{member_name}}がチャンネルを削除しました",
                        instantMeeting: "{{member_name}}がインスタント会議を削除しました"
                    },
                    created: {
                        space: "{{member_name}}がスペースを作成しました",
                        channel: "{{member_name}}がチャンネルを作成しました",
                        group: "{{member_name}}がグループを作成しました",
                        single: "{{member_name}}が会話を作成しました"
                    },
                    you: {
                        kicked: {
                            space: "スペース{{member_name}}から削除されました",
                            channel: "チャンネル{{member_name}}から削除されました"
                        },
                        invited: "{{member_name}}を招待しました"
                    },
                    kicked: {
                        space: "{{member_name}}が{{kicked_by}}によってスペースから削除されました",
                        channel: "{{member_name}}が{{kicked_by}}によってチャンネルから削除されました"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} がスペースの写真を変更しました",
                            channel: "{{member_name}} がチャンネルの写真を変更しました",
                            group: "{{member_name}} がグループの写真を変更しました"
                        },
                        name: {
                            space: "{{member_name}}がスペース名を{{name}}に変更しました",
                            channel: "{{member_name}}がチャンネル名を{{name}}に変更しました"
                        },
                        topic: {
                            space: "{{member_name}}がスペースのトピックを{{topic}}に変更しました",
                            channel: "{{member_name}}がチャンネルのトピックを{{topic}}に変更しました",
                            group: "{{member_name}}がグループのトピックを{{topic}}に変更しました"
                        }
                    },
                    left: {
                        space: "{{member_name}}がスペースから退会しました",
                        channel: "{{member_name}}がチャンネルから退会しました",
                        group: "{{member_name}}がグループから退会しました"
                    },
                    invited: "{{member_name}} が{{invited_by}}によって招待されました"
                },
                drive_size_exceeded: "ファイルが大きすぎます",
                newMessage: "新しいメッセージ",
                unreadMessages: "未読のメッセージ",
                remindLater: "後で通知する…",
                dismiss: "拒否する",
                answer: "応答する",
                newMeeting: "以下からの着信：",
                meeting: {
                    ended: "会議が終了しました",
                    started: "会議が開始しました"
                },
                you: {
                    deleted: {
                        space: "スペースを削除しました",
                        channel: "チャンネルを削除しました",
                        instantMeeting: "インスタント会議を削除しました"
                    },
                    created: {
                        space: "スペースを作成しました",
                        channel: "チャンネルを作成しました",
                        group: "グループを作成しました",
                        single: "会話を作成しました"
                    },
                    kicked: {
                        space: "{{kicked_by}}によってスペースから削除されました",
                        channel: "{{kicked_by}}によってチャンネルから削除されました"
                    },
                    changed: {
                        picture: {
                            space: "スペース名を変更しました",
                            channel: "チャンネルの写真を変更しました",
                            group: "グループの写真を変更しました"
                        },
                        name: {
                            space: "スペース名を{{name}}に変更しました",
                            channel: "チャンネル名を{{name}}に変更しました"
                        },
                        topic: {
                            space: "スペースのトピックを{{topic}}に変更しました",
                            channel: "チャンネルのトピックを{{topic}}に変更しました",
                            group: "グループのトピックを{{topic}}に変更しました"
                        }
                    },
                    left: {
                        space: "スペースから退会しました",
                        channel: "チャンネルから退会しました",
                        group: "グループから退会しました"
                    },
                    invited: "{{invited_by}}によって招待されました",
                    join: {
                        instantMeeting: "このインスタント会議に参加しました",
                        space: "このスペースに参加しました",
                        channel: "このチャンネルに参加しました",
                        group: "このグループに参加しました"
                    }
                },
                conversation: {
                    created: "会話が作成されました"
                }
            },
            button: {
                start: "開始する",
                remove: "削除する",
                delete: "削除する",
                leave: "退会する",
                join: "参加する",
                new: "新しい"
            },
            message: {
                browserNotSupported: {
                    Connect: "このバージョンのブラウザには対応していません. Connectのあらゆる機能を利用するには、ブラウザーを更新することを強くお勧めします！",
                    Team: "このバージョンのブラウザには対応していません. Teamのあらゆる機能を利用するには、ブラウザーを更新することを強くお勧めします！"
                },
                popup: {
                    readBy: "閲覧者"
                }
            },
            contactOwner: "所有者にお問い合わせください。",
            fileNotAvailable: "ファイルは利用できません。",
            placeholder: {
                limit: {
                    overquota: "このグループは参加者数の上限に達しました",
                    reached: "他の人を招待するには、選択した連絡先の1つを削除してください"
                },
                writeMail: "メールアドレスを入力してください",
                filter: "リストを入力してフィルタリングしてください",
                pickAddress: "アドレスを入力し始め、選択してください",
                addTopic: "トピックを追加する",
                searchResults: "上の欄に入力して検索結果を確認してください"
            },
            settings: {
                notification: {
                    title: {
                        hint: "通知にメッセージのプレビューを表示する",
                        minichat: "新しいメッセージが届いた際に縮小されたチャットを開く",
                        notifications: "通知"
                    },
                    desktop: "デスクトップ通知",
                    spawn: {
                        label: "通知時間の生成"
                    },
                    spawn0: "退席しない",
                    spawn10: "10秒間",
                    spawn5: "5秒間",
                    spawn3: "3秒間",
                    meeting: "ミーティング中の通知",
                    zimbra: "Zimbra通知",
                    team: "Teamの通知",
                    connect: "Connectの通知"
                },
                avatar: {
                    size: "最大サイズ256 kB",
                    autocenter: "画像が自動生成されます。"
                },
                profile: {
                    title: "プロファイル"
                },
                connect: {
                    title: "Connectの設定"
                },
                team: {
                    title: "Teamの設定"
                },
                meeting: {
                    title: {
                        meetingStart: "会議の初期設定"
                    },
                    default: {
                        video: "カメラ",
                        audio: "マイク"
                    }
                },
                notifications: {
                    title: "通知"
                }
            },
            header: {
                instantInfo: "インスタント会議の情報",
                filter: {
                    channel: "フィルタリングされたチャンネル",
                    conversation: "フィルタリングされた会話"
                },
                invite: "グループに招待する",
                channelInfo: "チャンネル情報",
                spaceInfo: "スペース情報",
                groupInfo: "グループ情報",
                contactInfo: "連絡先情報",
                new: {
                    instantMeeting: "新しいインスタントミーティング",
                    channel: "新しいチャンネル",
                    space: "新しいスペース",
                    group: "新しいグループ",
                    conversation: "新しい会話"
                },
                channels: "チャンネル",
                conversations: "会話"
            },
            mail: {
                invite: {
                    redirect: "スペースに進む",
                    space: "新しいスペースに招待されました！",
                    generated_by_team: "このメールはTeamによって自動的に生成されました",
                    generated_by_connect: "このメールはZimbra Connectによって自動的に生成されました",
                    follow_to_join: "会議に参加するには、このリンクをクリックしてください:",
                    join_now: "今すぐ参加する",
                    message: "会議に招待されました"
                },
                kick: {
                    redirect: "ホームに戻る",
                    space: "このスペースから削除されました"
                }
            },
            selection: {
                participants: {
                    many: "さらに{{limit}}名の参加者を招待できます",
                    one: "最後の参加者を招待できます",
                    none: "管理者が設定した参加者の上限に達しました"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}}が入力しています…"
                },
                generic: {
                    status: "が入力しています…"
                }
            },
            space: {
                administrator: "スペース管理者"
            },
            cancel: "キャンセル",
            save: "保存する",
            shared: {
                link: "リンクがシェアされました",
                media: "メディアが共有されました"
            },
            description: {
                members: {
                    many: "{{membersCount}}名のメンバー",
                    one: "参加者1名"
                }
            },
            newMessages: "新しいメッセージ",
            contactInfo: "連絡先情報",
            commonSpaces: "共通スペース",
            commonGroups: "共通グループ",
            participants: "参加者",
            topic: "トピック",
            phone: "電話番号",
            bio: "自己紹介",
            name: "名前",
            email: "メールアドレス",
            chat: "チャット",
            general: "{{spaceName}} - 一般設定",
            status: {
                last_seen: "最終閲覧 {{lastSeen}}",
                offline: "オフライン",
                online: "オンライン",
                guest: "ゲスト"
            },
            treeMenu: {
                instantMeeting: "インスタントミーティング",
                spaces: "スペース",
                conversations: "会話"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "カメラとマイクがオフです",
                        cameraOff: "カメラがオフです"
                    },
                    hideUserVideo: "このユーザーの動画を非表示にする",
                    showUserVideo: "このユーザーの動画を表示する",
                    muteUserAudio: "このユーザーのオーディオをミュートにする",
                    unmuteUserAudio: "このユーザーのオーディオのミュートを解除する",
                    enableScreenSharing: "画面共有を有効にする",
                    disableScreensharing: "画面共有を無効にする",
                    enableVideo: "動画を有効にする",
                    disableVideo: "動画を無効にする",
                    enableAudio: "オーディオを有効にする",
                    enableAudioWithHint: "オーディオを有効にする（Tを押したまま話す）",
                    disableAudio: "オーディオを無効にする",
                    closeCall: "この通話を閉じる",
                    pttHint: "Tを押したまま話す"
                },
                startModal: {
                    description: "どのように会議に参加しますか？",
                    save: "この設定を保存する",
                    cancel: "キャンセル",
                    enter: "参加する",
                    noVideoAndNoAudio: "カメラオフ、マイクオフ",
                    videoAndNoAudio: "カメラオン、マイクオフ",
                    noVideoAndAudio: "カメラオフ、マイクオン",
                    videoAndAudio: "カメラオン、マイクオン"
                }
            },
            miniChat: {
                header: {
                    collapse: "崩壊する",
                    meeting: "会議を開始する",
                    openInTeam: "Teamで開く",
                    close: "閉じる",
                    expand: "拡張する"
                }
            },
            external: {
                login: {
                    accessMeeting: "会議にアクセスするには",
                    signIn: "サインイン"
                }
            },
            password: "パスワード",
            nickname: "ニックネーム",
            conversation: {
                fileUploadDescription: "ファイルの説明"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_nl.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            button: {
                new: "NIEUW",
                join: "Meedoen",
                delete: "Wissen",
                remove: "Verwijderen",
                leave: "Verlaten",
                start: "Starten"
            },
            header: {
                contactInfo: "Contactinfo",
                new: {
                    instantMeeting: "Nieuwe instant meeting",
                    conversation: "Nieuw gesprek",
                    group: "Nieuwe groep",
                    space: "Nieuwe space",
                    channel: "Nieuw kanaal"
                },
                channelInfo: "Kanaalinfo",
                conversations: "Gesprekken",
                channels: "Kanalen",
                groupInfo: "Groepsinfo",
                spaceInfo: "Space-info",
                invite: "In de groep uitnodigen",
                instantInfo: "Instant Meeting Info",
                filter: {
                    channel: "Gefilterde kanalen",
                    conversation: "Gefilterde gesprekken"
                }
            },
            general: "{{spaceName}} - Algemeen",
            email: "E-mail",
            name: "Naam",
            contactInfo: "Contactinfo",
            status: {
                online: "Online",
                offline: "Offline",
                last_seen: "Laatst bekeken {{lastSeen}}",
                guest: "Gast"
            },
            chat: "Chat",
            newMessages: "Nieuwe berichten",
            action: {
                blockUser: "Gebruiker blokkeren",
                sendConversation: "Gesprek per e-mail versturen",
                inviteParticipants: "Deelnemers toevoegen",
                confirm: {
                    removeBuddy: "Weet u zeker dat u deze buddy wilt verwijderen?",
                    leaveGroup: "Weet u zeker dat u de groep wilt verlaten?",
                    deleteSpace: "Weet u zeker dat u de ruimte wilt verwijderen?",
                    leaveChannel: "Weet u zeker dat u het kanaal wilt verlaten?",
                    deleteChannel: "Weet u zeker dat u het kanaal wilt verwijderen?"
                },
                silenceConversation: "Stil gesprek",
                clearHistory: "Historiek wissen",
                leaveGroup: "Groep verlaten",
                removeBuddy: "Buddy verwijderen",
                leaveChannel: "Dit kanaal verlaten",
                inviteToSpace: "In de ruimte uitnodigen",
                leaveSpace: "Ruimte verlaten",
                deleteSpace: "Ruimte wissen",
                deleteChannel: "Kanaal verwijderen",
                joinChannelAction: "Dit kanaal vervoegen",
                silenceGeneral: "Algemene stilte",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Er is een andere instant meeting aan de gang. \n Er kan maar één instant meeting tegelijk bestaan",
                inviteFeedback: "Uitnodiging verzonden",
                copyLink: "of de link kopiëren en versturen",
                scrollToNewMessage: "Scroll naar nieuw bericht",
                scrollToTheBottom: "Scroll naar beneden",
                returnToCallTab: "Ga naar de meeting-tab",
                joinChannel: "Sluit u aan bij het kanaal om berichten te versturen en meldingen te ontvangen"
            },
            new: {
                channel: "Nieuw kanaal",
                spaceSelectRequire: "Verplicht.Kanalen zijn altijd gekoppeld aan een space",
                selectPic: "Een afbeelding selecteren",
                group: "Nieuwe groep",
                invite: "Deelnemers toevoegen",
                optional: "optioneel",
                space: "Nieuwe space",
                nameRequired: "Verplicht. Max. 140 tekens, vermijd hergebruik van namen",
                conversation: "Nieuw gesprek",
                "group-optionalTopic": "Optioneel. Het beschrijft het onderwerp van de groep",
                "channel-optionalTopic": "Optioneel. Het beschrijft het onderwerp van het kanaal",
                instantMeeting: "Nieuwe instant meeting",
                "space-optionalTopic": "Optioneel. Het beschrijft het onderwerp",
                spaceSelect: "Selecteer een space om een kanaal te creëren",
                speakToYourFriend: "Met uw vriend spreken",
                attendee: {
                    feedback: {
                        emailReplicated: "De ingevulde e-mail is reeds toegevoegd",
                        negative: "De ingevulde e-mail is niet geldig, vul een geldige e-mail in",
                        neutral: "Druk op ENTER om het adres toe te voegen aan de lijst met aanwezigen",
                        positive: "Aanwezige aan de lijst toegevoegd"
                    },
                    empty: "U heeft geen enkele aanwezige toegevoegd",
                    title: "Lijst met aanwezigen",
                    invite: "Aanwezige toevoegen"
                },
                participants: {
                    limit: "U kunt maximum {{max_participants}} personen uitnodigen",
                    requires: {
                        one: "Vereist minstens één extra deelnemer",
                        two: "Vereist minstens 2 andere"
                    }
                }
            },
            phone: "Telefoon",
            placeholder: {
                addTopic: "Onderwerp toevoegen",
                searchResults: "Begin hierboven te typen om de zoekresultaten te zien",
                limit: {
                    overquota: "Deze groep heeft het maximum aantal deelnemers bereikt",
                    reached: "Om andere mensen uit te nodigen, verwijder een van de geselecteerde contacten"
                },
                writeMail: "Een e-mail adres typen",
                filter: "Type om de lijst te filteren",
                pickAddress: "Begin met typen om een adres te kiezen"
            },
            connectMenuItem: "Connect",
            commonSpaces: "Gemeenschappelijke spaces",
            bio: "Bio",
            topic: "Onderwerp",
            participants: "Deelnemers",
            commonGroups: "Gemeenschappelijke groepen",
            description: {
                members: {
                    one: "Een deelnemer",
                    many: "{{membersCount}} leden"
                }
            },
            treeMenu: {
                conversations: "Gesprekken",
                spaces: "Spaces",
                instantMeeting: "Instant Meeting"
            },
            modal: {
                endCallByOwner: "De eigenaar van de instant meeting heeft besloten om het gesprek te beëindigen, we hopen dat u van de instant meeting-ervaring heeft genoten.",
                closedInstantMeeting: "Instant meeting gesloten"
            },
            undo: "Ongedaan maken",
            edit: "Bewerken",
            input: {
                topicMax255Characters: "Max. 255 characters",
                topicNeeds2Letters: "Een groepsonderwerp heeft ten minste twee letters nodig (of geen)",
                topicOptional: "Optioneel. Het beschrijft het onderwerp",
                nameMax140Characters: "Max. 140 tekens",
                nameRequired: "Een naam is verplicht",
                nameNeeds2Letters: "Naam heeft ten minste twee letters nodig",
                "nameRequired-max140Characters-avoidReusingNames": "Verplicht. Max. 140 tekens, vermijd hergebruik van namen"
            },
            instantMeeting: {
                continue: "Verdergaan met de oude instant meeting",
                create: "Een nieuwe instant meeting creëren"
            },
            instantMeetingAlreadyRunningText: "Het creëren van een nieuwe zal de oudere beëindigen en uw aanwezige zal de verbinding verliezen. Wat wilt u doen?",
            instantMeetingAlreadyRunningTitle: "Er is al een instant meeting aan de gang.",
            error: {
                uploadPicturesFailed: "Uploaden profielfoto mislukt",
                uploadConversationPicturesFailed: "Uploaden gesprekafbeelding mislukt"
            },
            notification: {
                markAllAsRead: "Alles als gelezen markeren",
                member: {
                    channel: {
                        join: "{{member_name}} heeft zich aangesloten bij het kanaal"
                    },
                    join: "{{member_name}} heeft zich aangesloten bij het gesprek",
                    deleted: {
                        space: "{{member_name}} heeft de space gewist",
                        channel: "{{member_name}} heeft het kanaal gewist",
                        instantMeeting: "{{member_name}} heeft de instant meeting gewist"
                    },
                    created: {
                        space: "{{member_name}} heeft de space gecreëerd",
                        channel: "heeft het kanaal gecreëerd",
                        group: "{{member_name}} heeft de groep gecreëerd",
                        single: "{{member_name}} heeft het gesprek gecreëerd"
                    },
                    you: {
                        kicked: {
                            space: "U heeft {{member_name}} uit de space verwijderd",
                            channel: "U heeft {{member_name}} uit het kanaal verwijderd"
                        },
                        invited: "U heeft {{member_name}} uitgenodigd"
                    },
                    kicked: {
                        space: "{{member_name}} is uit de space verwijderd door {{kicked_by}}",
                        channel: "{{member_name}} is uit het kanaal verwijderd door {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} heeft de afbeelding van de space veranderd",
                            channel: "{{member_name}} heeft de afbeelding van het kanaal veranderd",
                            group: "{{member_name}} heeft de afbeelding van de groep veranderd"
                        },
                        name: {
                            space: "{{member_name}} heeft de naam van de space veranderd in {{name}}",
                            channel: "{{member_name}} heeft de naam van het kanaal veranderd in {{name}}"
                        },
                        topic: {
                            space: "{{member_name}} heeft het onderwerp van de space veranderd in {{topic}}",
                            channel: "{{member_name}} heeft het onderwerp van het kanaal veranderd in {{topic}}",
                            group: "{{member_name}} heeft het onderwerp van de groep veranderd in {{topic}}"
                        }
                    },
                    left: {
                        space: "{{member_name}} heeft de space verlaten",
                        channel: "{{member_name}} heeft het kanaal verlaten",
                        group: "{{member_name}} heeft de groep verlaten"
                    },
                    invited: "{{member_name}} is uitgenodigd door {{invited_by}}"
                },
                drive_size_exceeded: "Het bestand is te groot",
                newMessage: "Nieuw bericht",
                unreadMessages: "Ongelezen berichten",
                remindLater: "Herinner me er later aan…",
                dismiss: "Weigeren",
                answer: "Antwoorden",
                newMeeting: "Inkomend gesprek van:",
                meeting: {
                    ended: "Meeting beëindigd",
                    started: "Meeting gestart"
                },
                you: {
                    deleted: {
                        space: "U hebt de space gewist",
                        channel: "U hebt het kanaal gewist",
                        instantMeeting: "U hebt de instant meeting gewist"
                    },
                    created: {
                        space: "U heeft de space gecreëerd",
                        channel: "U heeft het kanaal gecreëerd",
                        group: "U heeft de groep gecreëerd",
                        single: "U heeft het gesprek gecreëerd"
                    },
                    kicked: {
                        space: "U bent van de space verwijderd door {{kicked_by}}",
                        channel: "U bent van het kanaal verwijderd door {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "U hebt de afbeelding van de space veranderd",
                            channel: "U hebt de afbeelding van het kanaal veranderd",
                            group: "U hebt de afbeelding van de groep veranderd"
                        },
                        name: {
                            space: "U heeft de naam van de space veranderd in {{name}}",
                            channel: "U heeft de naam van het kanaal veranderd in {{name}}"
                        },
                        topic: {
                            space: "U heeft het onderwerp van de space veranderd in {{topic}}",
                            channel: "U heeft het onderwerp van het kanaal veranderd in {{topic}}",
                            group: "U hebt het onderwerp van de groep veranderd in {{topic}}"
                        }
                    },
                    left: {
                        space: "U heeft de space verlaten",
                        channel: "U heeft het kanaal verlaten",
                        group: "U heeft de groep verlaten"
                    },
                    invited: "U bent uitgenodigd door {{invited_by}}",
                    join: {
                        instantMeeting: "U hebt zich aangesloten bij de instant meeting",
                        space: "U hebt zich aangesloten bij de space",
                        channel: "U hebt zich aangesloten bij het kanaal",
                        group: "U hebt zich aangesloten bij de groep"
                    }
                },
                conversation: {
                    created: "Gesprek gecreëerd"
                }
            },
            message: {
                browserNotSupported: {
                    Connect: "We ondersteunen deze versie van uw browser niet. We raden u aan om uw browser te updaten om te kunnen profiteren van alle functies van Connect!",
                    Team: "We ondersteunen deze versie van uw browser niet. We raden u aan om uw browser te updaten om te kunnen profiteren van alle functies van Team!"
                },
                popup: {
                    readBy: "Gelezen door"
                }
            },
            contactOwner: "Contacteer de eigenaar.",
            fileNotAvailable: "Bestand niet beschikbaar.",
            settings: {
                notification: {
                    title: {
                        hint: "Berichtvoorbeeld tonen in meldingen",
                        minichat: "Open de geminimaliseerde chat als er een nieuw bericht binnenkomt",
                        notifications: "Meldingen"
                    },
                    desktop: "Desktopmeldingen",
                    spawn: {
                        label: "Melding tijdspanne"
                    },
                    spawn0: "Nooit verdwijnen",
                    spawn10: "10 seconden",
                    spawn5: "5 seconden",
                    spawn3: "3 seconden",
                    meeting: "Meldingen gedurende meetings",
                    zimbra: "Zimbra-meldingen",
                    team: "Team-meldingen",
                    connect: "Connect-meldingen"
                },
                avatar: {
                    size: "Maximale grootte 256 kB",
                    autocenter: "De afbeelding wordt automatisch gecentreerd."
                },
                profile: {
                    title: "Profiel",
                    maximumDimension: "Maximale grootte: 256kb.",
                    userStatus: "Status",
                    update: "Update",
                    restore: "Herstellen"
                },
                connect: {
                    title: "Connect-instellingen"
                },
                team: {
                    title: "Team-instellingen"
                },
                meeting: {
                    default: {
                        video: "Camera",
                        audio: "Microfoon"
                    },
                    title: {
                        meetingStart: "Meeting initiële instellingen"
                    }
                }
            },
            mail: {
                invite: {
                    redirect: "Ga naar space",
                    space: "U bent uitgenodigd in een nieuwe space!",
                    generated_by_team: "Deze mail is automatisch gegenereerd door Team",
                    generated_by_connect: "Deze mail is automatisch gegenereerd door Zimbra Connect",
                    follow_to_join: "Volg deze link om deel te nemen aan de meeting:",
                    join_now: "Doe nu mee",
                    message: "U bent uitgenodigd om deel te nemen aan de meeting"
                },
                kick: {
                    redirect: "Ga maar de startpagina",
                    space: "U bent uit deze space verwijderd"
                }
            },
            selection: {
                participants: {
                    many: "U kunt {{limit}} andere deelnemers uitnodigen",
                    one: "U kunt een laatste deelnemer uitnodigen",
                    none: "U hebt de limiet van de deelnemers bereikt die door de administrator is ingesteld"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}} is aan het schrijven…"
                },
                generic: {
                    status: "is aan het schrijven…"
                }
            },
            space: {
                administrator: "Space Administrator"
            },
            cancel: "Annuleren",
            save: "Opslaan",
            shared: {
                link: "Gedeelde link",
                media: "Gedeelde media"
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "Uw camera en microfoon staan uit",
                        cameraOff: "Uw camera staat uit"
                    },
                    hideUserVideo: "De video van deze gebruiker verbergen",
                    showUserVideo: "De video van deze gebruiker weergeven",
                    muteUserAudio: "De audio van deze gebruiker dempen",
                    unmuteUserAudio: "Dempen van de audio van deze gebruiker uitschakelen",
                    enableScreenSharing: "Schermdelen inschakelen",
                    disableScreensharing: "Schermdelen uitschakelen",
                    enableVideo: "Video inschakelen",
                    disableVideo: "Video uitschakelen",
                    enableAudio: "Audio inschakelen",
                    enableAudioWithHint: "Audio inschakelen (druk en houd 'T' ingedrukt om te praten)",
                    disableAudio: "Audio uitschakelen",
                    closeCall: "Dit gesprek afsluiten"
                },
                startModal: {
                    save: "Deze instellingen bewaren",
                    cancel: "Annuleren",
                    description: "Hoe wilt u de vergadering bevestigen?",
                    enter: "Bevestigen",
                    noVideoAndNoAudio: "Camera uit, Microfoon uit",
                    videoAndNoAudio: "Camera aan, Microfoon uit",
                    noVideoAndAudio: "Camera uit, Microfoon aan",
                    videoAndAudio: "Camera aan, Microfoon aan"
                }
            },
            password: "Wachtwoord",
            nickname: "Bijnaam",
            external: {
                login: {
                    accessMeeting: "Toegang krijgen tot de vergadering",
                    signIn: "Aanmelden"
                }
            },
            miniChat: {
                header: {
                    collapse: "Uitklappen",
                    meeting: "Meeting starten",
                    openInTeam: "In Team openen",
                    close: "Sluiten",
                    expand: "Uitklappen"
                }
            },
            conversation: {
                fileUploadDescription: "Bestandsomschrijving"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_pt.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            connectMenuItem: "Bate-papo",
            treeMenu: {
                conversations: "Conversas",
                spaces: "Espaços",
                instantMeeting: "Reunião instantânea"
            },
            button: {
                new: "NOVO",
                join: "Junte-se",
                leave: "Sair",
                delete: "Apagar",
                remove: "Remover",
                start: "Inicio"
            },
            new: {
                group: "Novo grupo",
                space: "Novo espaço",
                channel: "Novo canal",
                instantMeeting: "Nova reunião instantánea",
                selectPic: "Selecionar imagem",
                optional: "Opcional",
                "group-optionalTopic": "Opcional. Descreve o assunto do grupo",
                "space-optionalTopic": "Opcional. Descreve o assunto",
                "channel-optionalTopic": "Opcional. Descreve o assunto do canal",
                nameRequired: "Requerido. Máx. 140 caracteres. Evite repetir nomes",
                spaceSelectRequire: "Requerido. Canais estão sempre ligados a um espaço",
                spaceSelect: "Selecione um espaço para criar um canal",
                invite: "Adicionar participantes",
                participants: {
                    requires: {
                        two: "Requer pelo menos 2 mais",
                        one: "Requer pelo menos mais um participante"
                    },
                    limit: "Você pode convidar até {{max_participants}} pessoas"
                },
                conversation: "Nova conversa",
                attendee: {
                    feedback: {
                        emailReplicated: "O e-mail introduzido já foi adicionado",
                        negative: "O e-mail introduzido não é válido, por favor insira um e-mail válido",
                        neutral: "Pressione ENTER para adicionar o endereço à lista de participantes",
                        positive: "Participante adicionado à lista"
                    },
                    empty: "Ainda não adicionou nenhum participante",
                    title: "Lista de Participantes",
                    invite: "Adicionar participante"
                },
                speakToYourFriend: "Fale com seu colega"
            },
            header: {
                conversations: "Conversações",
                channels: "Canais",
                new: {
                    conversation: "Nova conversa",
                    group: "Novo grupo",
                    space: "Novo espaço",
                    channel: "Novo canal",
                    instantMeeting: "Nova reunião instantânea"
                },
                contactInfo: "Informação de contato",
                groupInfo: "Informação do grupo",
                spaceInfo: "Informação do espaço",
                channelInfo: "Informação do canal",
                invite: "Convidar para o grupo",
                instantInfo: "Informações sobre reuniões instantâneas",
                filter: {
                    channel: "Canais filtrados",
                    conversation: "Conversas filtradas"
                }
            },
            status: {
                online: "Online",
                last_seen: "Visto por última vez {{lastSeen}}",
                offline: "Desconectado",
                guest: "Convidado"
            },
            general: "{{spaceName}} - Geral",
            chat: "Chat",
            email: "Email",
            name: "Nome",
            bio: "Biografia",
            phone: "Telefone",
            topic: "Assunto",
            participants: "Participantes",
            commonGroups: "Grupos comuns",
            commonSpaces: "Espaços comuns",
            contactInfo: "Informação de contacto",
            placeholder: {
                searchResults: "Comece a digitar em cima para ver os resultados da pesquisa",
                addTopic: "Adicionar assunto",
                pickAddress: "Comece a digitar para escolher um endereço",
                limit: {
                    reached: "Para convidar outras pessoas remova uma nos contatos selecionados",
                    overquota: "Este grupo atingiu o número máximo de participantes"
                },
                writeMail: "Digite um endereço de e-mail",
                filter: "Digite para filtrar a lista"
            },
            newMessages: "Novas mensagens",
            description: {
                members: {
                    one: "Um participante",
                    many: "{{membersCount}} membros"
                }
            },
            action: {
                silenceConversation: "Silenciar conversa",
                sendConversation: "Enviar conversa por e-mail",
                clearHistory: "Apagar histórico",
                blockUser: "Bloquear contacto",
                inviteParticipants: "Adicionar participantes",
                leaveGroup: "Deixar grupo",
                removeBuddy: "Remover contacto",
                confirm: {
                    leaveGroup: "Tem certeza que quer deixar o grupo?",
                    removeBuddy: "Tem certeza que quer excluir esse contacto?",
                    deleteSpace: "Tem a certeza que quer eliminar o espaço?",
                    leaveChannel: "Tem certeza que quer deixar o canal?",
                    deleteChannel: "Tem certeza que quer eliminar o canal?"
                },
                leaveChannel: "Deixar este canal",
                inviteToSpace: "Convidar para o espaço",
                leaveSpace: "Deixar espaço",
                deleteSpace: "Eliminar espaço",
                deleteChannel: "Eliminar canal",
                joinChannelAction: "Junte-se ao canal",
                silenceGeneral: "Silêncio geral",
                joinChannel: "Junte-se ao canal para enviar mensagens e recever notificações",
                returnToCallTab: "Mudar para a aba de reunião",
                inviteFeedback: "Convite enviado",
                copyLink: "ou copie o link e envie-o",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Outra reunião instantânea está a decorrer. \n Só pode haver uma reunião instantânea de cada vez",
                scrollToNewMessage: "Rolar até nova mensagem",
                scrollToTheBottom: "Rolar até ao fundo"
            },
            shared: {
                media: "Media partilhada",
                link: "Link partilhado"
            },
            save: "Salvar",
            cancel: "Cancelar",
            space: {
                administrator: "Administrador do espaço"
            },
            notification: {
                you: {
                    join: {
                        group: "Você juntou-se ao grupo",
                        channel: "Você juntou-se ao canal",
                        space: "Você juntou-se ao espaço",
                        instantMeeting: "Você juntou-se à reunião instantânea"
                    },
                    invited: "Você foi convidado por {{invited_by}}",
                    left: {
                        group: "Você saiu do grupo",
                        channel: "Você deixou o canal",
                        space: "Você deixou o espaço"
                    },
                    changed: {
                        topic: {
                            group: "Você mudou o assunto do grupo para {{topic}}",
                            channel: "Você mudou o assunto do canal para {{topic}}",
                            space: "Você mudou o assunto do espaço para {{topic}}"
                        },
                        name: {
                            channel: "Você mudou o nome do canal para {{name}}",
                            space: "Você mudou o nome do espaço para {{name}}"
                        },
                        picture: {
                            group: "Você mudou a imagem do grupo",
                            channel: "Você mudou a imagem do canal",
                            space: "Você mudou a imagem do espaço"
                        }
                    },
                    kicked: {
                        channel: "Você foi removido do canal por {{kicked_by}}",
                        space: "Você foi removido do espaço por {{kicked_by}}"
                    },
                    created: {
                        single: "Você criou a conversa",
                        group: "Você criou o grupo",
                        channel: "Você criou o canal",
                        space: "Você criou o espaço"
                    },
                    deleted: {
                        channel: "O canal foi eliminado",
                        space: "O espaço foi eliminado",
                        instantMeeting: "Você eliminou a reunião instantânea"
                    }
                },
                member: {
                    invited: "{{member_name}} foi convidado por {{invited_by}}",
                    left: {
                        group: "{{member_name}} saiu do grupo",
                        channel: "{{member_name}} deixou o canal",
                        space: "{{member_name}} deixou o espaço"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} mudou o nome do grupo para {{topic}}",
                            channel: "{{member_name}} mudou o assunto do canal para {{topic}}",
                            space: "{{member_name}} mudou o assunto do espaço para {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} mudou o nome do canal para {{name}}",
                            space: "{{member_name}} mudou o nome do espaço para {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} mudou a imagem do grupo",
                            channel: "{{member_name}} mudou a imagem do canal",
                            space: "{{member_name}} mudou a imagem do espaço"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} foi removido do canal por {{kicked_by}}",
                        space: "{{member_name}} foi removido do espaço por {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} criou a conversa",
                        group: "{{member_name}} criou o grupo",
                        channel: "{{member_name}} criou o canal",
                        space: "{{member_name}} criou o espaço"
                    },
                    deleted: {
                        channel: "{{member_name}} eliminou o canal",
                        space: "{{member_name}} eliminou o espaço",
                        instantMeeting: "{{member_name}} eliminou a reunião instantânea"
                    },
                    join: "{{member_name}} juntou-se à conversa",
                    channel: {
                        join: "{{member_name}} juntou-se ao canal"
                    },
                    you: {
                        kicked: {
                            channel: "Você removeu {{member_name}} do canal",
                            space: "Você removeu {{member_name}} do espaço"
                        },
                        invited: "Você convidou {{member_name}}"
                    }
                },
                conversation: {
                    created: "Conversa criada"
                },
                meeting: {
                    started: "Reunião iniciada",
                    ended: "Reunião finalizada"
                },
                newMeeting: "Chamada entrante de:",
                answer: "Responder",
                dismiss: "Dispensar",
                newMessage: "Nova mensagem",
                remindLater: "Lembre-me mais tarde…",
                markAllAsRead: "Marcar tudo como lido",
                drive_size_exceeded: "O ficheiro é demasiado grande",
                unreadMessages: "Mensagens não lidas"
            },
            writing: {
                generic: {
                    status: "está a escrever…"
                },
                specific: {
                    status: "{{writer}} está a escrever…"
                }
            },
            selection: {
                participants: {
                    none: "Você atingiu o limite de participantes definido pelo administrador",
                    one: "Pode convidar um último participante",
                    many: "Você pode convidar mais {{limit}} participante(s)"
                }
            },
            mail: {
                invite: {
                    message: "Você foi convidado para participar da reunião",
                    join_now: "Juntar-se agora",
                    follow_to_join: "Para participar da reunião siga este link:",
                    generated_by_connect: "Este email foi gerado automáticamente por Zimbra Connect",
                    generated_by_team: "Este email foi gerado automáticamente por Team",
                    redirect: "Ir para o espaço",
                    space: "Você foi convidado para participar de um novo espaço!"
                },
                kick: {
                    space: "Você foi removido deste espaço",
                    redirect: "Ir para o Home"
                }
            },
            message: {
                browserNotSupported: {
                    Connect: "A versão do seu navegador não é suportada. É muito recomendo actualizar o navegador para aproveitar todas as funcionalidades do Connect!",
                    Team: "A versão do seu navegador não é suportada. É muito recomendo actualizar o navegador para aproveitar todas as funcionalidades do Team!"
                },
                popup: {
                    readBy: "Lída por"
                }
            },
            contactOwner: "Entre em contato com o proprietário.",
            fileNotAvailable: "Arquivo não disponível.",
            settings: {
                notification: {
                    title: {
                        hint: "Mostrar pré-visualização da mensagem nas notificações",
                        minichat: "Abra o chat minificado quando uma nova mensagem chegar",
                        notifications: "Notificações"
                    },
                    desktop: "Notificações de Desktop",
                    spawn: {
                        label: "Período de tempo de notificação"
                    },
                    spawn0: "Nunca desaparece",
                    spawn10: "10 segundos",
                    spawn5: "5 segundos",
                    spawn3: "3 segundos",
                    meeting: "Notificações durante reuniões",
                    zimbra: "Notificações Zimbra",
                    team: "Notificações do Team",
                    connect: "Notificações do Connect"
                },
                avatar: {
                    size: "Dimensão máxima 256 kB",
                    autocenter: "A imagem será centralizada automaticamente."
                },
                profile: {
                    title: "Perfil",
                    errorSnackbar: "Parece haver um erro com a sua edição",
                    maximumDimension: "Dimensão máxima: 256 Kb.",
                    chooseAProfilePic: "Escolha uma imagem de perfil que os outros utilizadores verão. A imagem será centrada automaticamente.",
                    statusOptionalDescription: "Opcional. Informe os outros sobre o que está a pensar",
                    userStatus: "Estado",
                    errorMessage: "Ups, algo está errado",
                    update: "Actualizar",
                    restore: "Restaurar",
                    reset: "Redefinir"
                },
                connect: {
                    title: "Configurações do Connect"
                },
                team: {
                    title: "Configurações do Team"
                },
                meeting: {
                    title: {
                        meetingStart: "Ajustes iniciais da reunião"
                    },
                    default: {
                        video: "Câmara",
                        audio: "Microfone"
                    },
                    enableCamera: "Activar câmara",
                    enableMicrophone: "Habilitar microfone",
                    description: "Defina as suas preferências de áudio e vídeo para entrar nas reuniões. Pode sempre personalizar as suas preferências antes de entrar em cada reunião.",
                    meetings: "Reuniões"
                },
                modal: {
                    description: "Aqui pode definir todas as preferências do Team a fim de desfrutar de uma experiência de chat personalizada completa!"
                },
                notifications: {
                    description: "Defina as suas preferências para cada tipo de notificação no Team.",
                    title: "Notificações"
                }
            },
            meeting: {
                interactions: {
                    enableAudio: "Activar o Áudio",
                    status: {
                        cameraMicOff: "A sua câmara e microfone estão desligados",
                        cameraOff: "A sua câmara está desligada"
                    },
                    hideUserVideo: "Ocultar o vídeo deste contacto",
                    showUserVideo: "Mostrar o vídeo deste contacto",
                    muteUserAudio: "Desactivar áudio para este contacto",
                    unmuteUserAudio: "Ativar áudio para este contacto",
                    enableScreenSharing: "Activar o ScreenSharing",
                    disableScreensharing: "Desactivar o ScreenSharing",
                    enableVideo: "Activar Vídeo",
                    disableVideo: "Desactivar Vídeo",
                    disableAudio: "Desactivar o áudio",
                    closeCall: "Encerrar esta chamada",
                    pttHint: "Segure 'T' para falar"
                },
                startModal: {
                    save: "Salvar as configurações",
                    cancel: "Cancelar",
                    description: "Como quer entrar na reunião?",
                    enter: "Entrar",
                    noVideoAndNoAudio: "Câmara desligada, Microfone desligado",
                    videoAndNoAudio: "Câmara ligada, Microfone desligado",
                    noVideoAndAudio: "Câmara desligada, Microfone ligado",
                    videoAndAudio: "Câmara ligada, Microfone ligado"
                }
            },
            modal: {
                endCallByOwner: "O proprietário da reunião instantânea decidiu terminar a chamada, esperamos que você tenha gostado da experiência.",
                closedInstantMeeting: "Reunião instantânea encerrada"
            },
            undo: "Desfazer",
            edit: "Editar",
            input: {
                topicMax255Characters: "Máx. 255 caracteres",
                topicNeeds2Letters: "O assunto de um grupo necessita de pelo menos duas letras (ou nenhuma)",
                topicOptional: "Opcional. Descreve o assunto",
                nameMax140Characters: "Máx. 140 caracteres",
                nameRequired: "É necessário um nome",
                nameNeeds2Letters: "O nome precisa de pelo menos duas letras",
                "nameRequired-max140Characters-avoidReusingNames": "Obrigatório. Máx. 140 caracteres, evite reutilizar nomes"
            },
            instantMeeting: {
                continue: "Continuar com a reunião instantânea anterior",
                create: "Criar uma nova reunião instantânea"
            },
            instantMeetingAlreadyRunningText: "A criação de uma nova terminará a anterior e os participantes perderão a sua ligação. O que é que quer fazer?",
            instantMeetingAlreadyRunningTitle: "Já está em andamento uma reunião instantânea.",
            error: {
                uploadConversationPicturesFailed: "Falha no carregamento da imagem da conversa",
                uploadPicturesFailed: "Falha no carregamento da imagem de perfil"
            },
            conversation: {
                fileUploadDescription: "Descrição do ficheiro"
            },
            miniChat: {
                header: {
                    expand: "Expandir",
                    collapse: "Contrair",
                    meeting: "Iniciar reunião",
                    openInTeam: "Abrir em Team",
                    close: "Fechar"
                }
            },
            password: "Palavra-passe",
            nickname: "Nick",
            external: {
                login: {
                    accessMeeting: "Para aceder à reunião",
                    signIn: "Iniciar sessão"
                }
            },
            loadingScreen: {
                poweredBy: "powered by"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_pt_BR.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            connectMenuItem: "Bate-papo",
            treeMenu: {
                conversations: "Conversações",
                spaces: "Espaços",
                instantMeeting: "Reunião instantânea"
            },
            button: {
                new: "NOVO",
                join: "Unir-se",
                leave: "Sair",
                delete: "Excluir",
                remove: "Remover",
                start: "Inicio"
            },
            new: {
                group: "Novo grupo",
                space: "Novo espaço",
                channel: "Novo canal",
                instantMeeting: "Nova reunião instantânea",
                selectPic: "Selecionar imagem",
                optional: "Opcional",
                "group-optionalTopic": "Opcional. Descreve o assunto do grupo",
                "space-optionalTopic": "Opcional. Descreve o assunto",
                "channel-optionalTopic": "Opcional. Descreve o assunto do canal",
                nameRequired: "Obrigatório. Máx. 140 caracteres. Evite repetir nomes",
                spaceSelectRequire: "Obrigatório. Os canais estão sempre ligados a um espaço",
                spaceSelect: "Selecione um espaço para criar um canal",
                invite: "Adicionar participantes",
                participants: {
                    requires: {
                        two: "Requer pelo menos mais dois participantes",
                        one: "Requer pelo menos mais um participante"
                    },
                    limit: "Você pode convidar até {{max_participants}} participantes"
                },
                conversation: "Nova conversa",
                attendee: {
                    feedback: {
                        emailReplicated: "O e-mail digitado já foi adicionado",
                        negative: "O e-mail digitado não é válido, insira um e-mail válido",
                        neutral: "Pressione ENTER para adicionar o endereço à lista de participantes",
                        positive: "Participante adicionado à lista"
                    },
                    empty: "Você ainda não adicionou nenhum participante",
                    title: "Lista de participantes",
                    invite: "Adicionar participante"
                },
                speakToYourFriend: "Fale para o contato"
            },
            header: {
                conversations: "Conversas",
                channels: "Canais",
                new: {
                    conversation: "Nova conversa",
                    group: "Novo grupo",
                    space: "Novo espaço",
                    channel: "Novo canal",
                    instantMeeting: "Nova reunião instantânea"
                },
                contactInfo: "Informação do contato",
                groupInfo: "Informação do grupo",
                spaceInfo: "Informação do espaço",
                channelInfo: "Informação do canal",
                invite: "Convidar ao grupo",
                instantInfo: "Informações sobre Reuniões Instantâneas",
                filter: {
                    channel: "Canais filtrados",
                    conversation: "Conversas filtradas"
                }
            },
            status: {
                online: "Online",
                last_seen: "Visto pela última vez {{lastSeen}}",
                offline: "Offline",
                guest: "Convidado"
            },
            general: "{{spaceName}} - Geral",
            chat: "Bate-papo",
            email: "Email",
            name: "Nome",
            bio: "Biografia",
            phone: "Telefone",
            topic: "Assunto",
            participants: "Participantes",
            commonGroups: "Grupos comuns",
            commonSpaces: "Espaços comuns",
            contactInfo: "Informação de contato",
            placeholder: {
                searchResults: "Digite acima para ver os resultados da busca",
                addTopic: "Adicionar assunto",
                pickAddress: "Comece a digitar para escolher um endereço",
                limit: {
                    reached: "Para convidar outras pessoas, remova um dos contatos selecionados",
                    overquota: "Este grupo atingiu o número máximo de participantes"
                },
                writeMail: "Digite um endereço de e-mail",
                filter: "Digite para filtrar a lista"
            },
            newMessages: "Novas mensagens",
            description: {
                members: {
                    one: "Um participante",
                    many: "{{membersCount}} membros"
                }
            },
            action: {
                silenceConversation: "Silenciar conversa",
                sendConversation: "Enviar conversa por e-mail",
                clearHistory: "Apagar histórico",
                blockUser: "Bloquear usuário",
                inviteParticipants: "Adicionar participantes",
                leaveGroup: "Sair do grupo",
                removeBuddy: "Excluir contato",
                confirm: {
                    leaveGroup: "Tem certeza que quer sair do grupo?",
                    removeBuddy: "Tem certeza que quer excluir esse contato?",
                    deleteSpace: "Tem certeza que quer excluir o espaço?",
                    leaveChannel: "Tem certeza que quer sair do canal?",
                    deleteChannel: "Tem certeza que quer excluir o canal?"
                },
                leaveChannel: "Sair do canal",
                inviteToSpace: "Convidar para o espaço",
                leaveSpace: "Sair do espaço",
                deleteSpace: "Excluir espaço",
                deleteChannel: "Excluir canal",
                joinChannelAction: "Unir-se ao canal",
                silenceGeneral: "Silêncio geral",
                joinChannel: "Unir-se ao canal para enviar mensagens e receber notificações",
                returnToCallTab: "Mudar para a aba de reunião",
                inviteFeedback: "Convite enviado",
                copyLink: "ou copie o link e envie-o",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Outra reunião instantânea está em andamento.\nSomente uma reunião instantânea pode existir por vez",
                scrollToNewMessage: "Rolar para nova mensagem",
                scrollToTheBottom: "Rolar para baixo"
            },
            shared: {
                media: "Mídia compartilhada",
                link: "Link compartilhado"
            },
            save: "Salvar",
            cancel: "Cancelar",
            space: {
                administrator: "Administrador do espaço"
            },
            notification: {
                you: {
                    join: {
                        group: "Você se uniu ao grupo",
                        channel: "Você se uniu ao canal",
                        space: "Você se uniu a um espaço",
                        instantMeeting: "Você se uniu a uma reunião instantânea"
                    },
                    invited: "Você foi convidado por {{invited_by}}",
                    left: {
                        group: "Você saiu do grupo",
                        channel: "Você saiu do canal",
                        space: "Você saiu do espaço"
                    },
                    changed: {
                        topic: {
                            group: "Você mudou o assunto do grupo para {{topic}}",
                            channel: "Você mudou o assunto do canal para {{topic}}",
                            space: "Você mudou o assunto do espaço para {{topic}}"
                        },
                        name: {
                            channel: "Você mudou o nome do canal para {{name}}",
                            space: "Você mudou o nome do espaço para {{name}}"
                        },
                        picture: {
                            group: "Você mudou a imagem do grupo",
                            channel: "Você mudou a imagem do canal",
                            space: "Você mudou a imagem do espaço"
                        }
                    },
                    kicked: {
                        channel: "Você foi removido do canal por {{kicked_by}}",
                        space: "Você foi removido do espaço por {{kicked_by}}"
                    },
                    created: {
                        single: "Você criou a conversa",
                        group: "Você criou o grupo",
                        channel: "Você criou o canal",
                        space: "Você criou o espaço"
                    },
                    deleted: {
                        channel: "Você excluiu o canal",
                        space: "Você excluiu o espaço",
                        instantMeeting: "Você excluiu a reunião instantânea"
                    }
                },
                member: {
                    invited: "{{member_name}} foi convidado por {{invited_by}}",
                    left: {
                        group: "{{member_name}} saiu do grupo",
                        channel: "{{member_name}} saiu do canal",
                        space: "{{member_name}} saiu do espaço"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} mudou o assunto do grupo para {{topic}}",
                            channel: "{{member_name}} mudou o assunto do canal para {{topic}}",
                            space: "{{member_name}} mudou o assunto do espaço para {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} mudou o nome do canal para {{name}}",
                            space: "{{member_name}} mudou o nome do espaço para {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} mudou a imagem do grupo",
                            channel: "{{member_name}} mudou a imagem do canal",
                            space: "{{member_name}} mudou a imagem do espaço"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} foi removido do canal por {{kicked_by}}",
                        space: "{{member_name}} foi removido do espaço por {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} criou a conversa",
                        group: "{{member_name}} criou o grupo",
                        channel: "{{member_name}} criou o canal",
                        space: "{{member_name}} criou o espaço"
                    },
                    deleted: {
                        channel: "{{member_name}} excluiu o canal",
                        space: "{{member_name}} excluiu o espaço",
                        instantMeeting: "{{member_name}} excluiu a reunião instantânea"
                    },
                    join: "{{member_name}} se uniu à conversa",
                    channel: {
                        join: "{{member_name}} se uniu ao canal"
                    },
                    you: {
                        kicked: {
                            space: "Você removeu {{member_name}} do espaço",
                            channel: "Você foi removido do canal {{member_name}}"
                        },
                        invited: "Você convidou {{member_name}}"
                    }
                },
                conversation: {
                    created: "Conversa criada"
                },
                meeting: {
                    started: "Reunião iniciada",
                    ended: "Reunião finalizada"
                },
                newMeeting: "Recebendo chamada de:",
                answer: "Responder",
                dismiss: "Dispensar",
                newMessage: "Nova Mensagem",
                remindLater: "Lembre-me mais tarde…",
                markAllAsRead: "marcar tudo como lido",
                drive_size_exceeded: "O arquivo é muito grande",
                unreadMessages: "Mensagens não lidas"
            },
            writing: {
                generic: {
                    status: "está escrevendo…"
                },
                specific: {
                    status: "{{writer}} está escrevendo…"
                }
            },
            selection: {
                participants: {
                    none: "Você atingiu o limite de participantes estabelecido pelo administrador",
                    one: "Você pode convidar só mais um participante",
                    many: "Você pode convidar mais {{limit}} participante(s)"
                }
            },
            mail: {
                invite: {
                    message: "Você foi convidado para participar da reunião",
                    join_now: "Unir-se agora",
                    follow_to_join: "Para participar da reunião siga este link:",
                    generated_by_connect: "Este email foi gerado automáticamente pelo Zimbra Connect",
                    generated_by_team: "Este email foi gerado automáticamente pelo Team",
                    redirect: "Ir para o espaço",
                    space: "Você foi convidado para participar de um novo espaço!"
                },
                kick: {
                    space: "Você foi removido deste espaço",
                    redirect: "Ir para o home"
                }
            },
            message: {
                browserNotSupported: {
                    Connect: "Esta versão do navegador não é suportada. Recomendamos que você atualize seu navegador para se beneficiar de todos os recursos do Connect!",
                    Team: "A versão do seu navegador não é suportada. Recomendamos que você atualize seu navegador para se beneficiar de todos os recursos do Team!"
                },
                popup: {
                    readBy: "Lida por"
                }
            },
            contactOwner: "Entre em contato com o proprietário.",
            fileNotAvailable: "Arquivo não disponível.",
            settings: {
                notification: {
                    title: {
                        hint: "Mostrar pré-visualização da mensagem nas notificações",
                        minichat: "Abrir o chat minimizado quando uma nova mensagem chegar",
                        notifications: "Notificações"
                    },
                    desktop: "Notificações do Desktop",
                    spawn: {
                        label: "Tempo de notificação"
                    },
                    spawn0: "Nunca desaparecer",
                    spawn10: "10 segundos",
                    spawn5: "5 segundos",
                    spawn3: "3 segundos",
                    meeting: "Notificações durante reuniões",
                    zimbra: "Notificações Zimbra",
                    team: "Notificações do Team",
                    connect: "Notificações do Connect"
                },
                avatar: {
                    size: "Dimensão máxima 256 kB",
                    autocenter: "A imagem será centralizada automaticamente."
                },
                profile: {
                    title: "Perfil",
                    maximumDimension: "Tamanho máximo: 256 Kb.",
                    errorSnackbar: "Tamanho máximo: 256 Kb.",
                    chooseAProfilePic: "Escolha uma imagem de perfil que outros usuários verão. A imagem será centralizada automaticamente.",
                    statusOptionalDescription: "Opcional. Deixe os demais saberem o que você está pensando",
                    userStatus: "Estado",
                    errorMessage: "Whoops, algo está errado",
                    update: "Atualizar",
                    restore: "Restaurar",
                    reset: "Restabelecer"
                },
                connect: {
                    title: "Configurações do Connect"
                },
                team: {
                    title: "Configurações do Team"
                },
                meeting: {
                    title: {
                        meetingStart: "Ajustes iniciais da reunião"
                    },
                    default: {
                        video: "Câmera",
                        audio: "Microfone"
                    },
                    enableCamera: "Habilitar câmera",
                    enableMicrophone: "Habilitar microfone",
                    description: "Defina suas preferências de áudio e vídeo para entrar nas reuniões. Você pode sempre personalizar suas preferências antes de participar de cada reunião.",
                    meetings: "Reuniões"
                },
                modal: {
                    description: "Aqui você pode definir todas as preferências do Team a fim de desfrutar de uma experiência de chat totalmente personalizada!"
                },
                notifications: {
                    description: "Defina suas preferências para cada tipo de notificação do Team",
                    title: "Notificações"
                }
            },
            modal: {
                endCallByOwner: "O proprietário da reunião instantânea decidiu encerrar a chamada. Esperamos que você tenha gostado dessa experiência.",
                closedInstantMeeting: "Reunião instantânea encerrada"
            },
            undo: "Desfazer",
            edit: "Editar",
            input: {
                topicMax255Characters: "Máx. 255 caracteres",
                topicNeeds2Letters: "O assunto de um grupo precisa de pelo menos duas letras (ou nenhuma)",
                topicOptional: "Opcional. Descreve o assunto",
                nameMax140Characters: "Máx. 140 caracteres",
                nameRequired: "É necessário um nome",
                nameNeeds2Letters: "O nome precisa de pelo menos duas letras",
                "nameRequired-max140Characters-avoidReusingNames": "Requeridos. Máx. 140 caracteres. Evite reutilizar nomes"
            },
            instantMeeting: {
                continue: "Continuar com a antiga reunião instantânea",
                create: "Criar uma nova reunião instantânea"
            },
            instantMeetingAlreadyRunningText: "Ao criar uma nova finalizará a antiga, e os participantes perderão a conexão. O que você deseja fazer?",
            instantMeetingAlreadyRunningTitle: "Uma reunião instantânea já está em andamento.",
            error: {
                uploadPicturesFailed: "Falha ao carregar a foto do perfil",
                uploadConversationPicturesFailed: "Falha no upload da foto da conversa"
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "Sua câmera e microfone estão desligados",
                        cameraOff: "Sua câmera está desligada"
                    },
                    hideUserVideo: "Ocultar o vídeo deste usuário",
                    showUserVideo: "Mostrar o vídeo deste usuário",
                    muteUserAudio: "Desativar áudio para este usuário",
                    unmuteUserAudio: "Ativar áudio para este usuário",
                    enableScreenSharing: "Habilitar compartilhamento de tela",
                    disableScreensharing: "Desabilitar compartilhamento de tela",
                    enableVideo: "Habilitar Video",
                    disableVideo: "Desabilitar video",
                    enableAudio: "Habilitar Áudio",
                    enableAudioWithHint: "Habilitar Áudio (pressione e segure 'T' para falar)",
                    disableAudio: "Desabilitar Áudio",
                    closeCall: "Encerrar esta chamada"
                },
                startModal: {
                    save: "Salvar estas configurações",
                    cancel: "Cancelar",
                    description: "Como você quer entrar na reunião?",
                    enter: "Entrar",
                    noVideoAndNoAudio: "Câmera desligada, Microfone desligado",
                    videoAndNoAudio: "Câmera ligada, Microfone desligado",
                    noVideoAndAudio: "Câmera desligada, Microfone ligado",
                    videoAndAudio: "Câmera ligada, Microfone ligado"
                }
            },
            miniChat: {
                header: {
                    expand: "Expandir",
                    collapse: "Recolher",
                    meeting: "Iniciar reunião",
                    openInTeam: "Abrir no Team",
                    close: "Fechar"
                }
            },
            password: "Senha",
            nickname: "Apelido",
            external: {
                login: {
                    accessMeeting: "Para acessar a reunião",
                    signIn: "Fazer login"
                }
            },
            conversation: {
                fileUploadDescription: "Descrição do arquivo"
            },
            loadingScreen: {
                poweredBy: "powered by"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_ro.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            treeMenu: {
                spaces: "Spații"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_ru.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            menuItem: "Team",
            connectMenuItem: "Соединить",
            treeMenu: {
                conversations: "Диалоги",
                spaces: "Переговорные",
                instantMeeting: "Мгновенное совещание"
            },
            button: {
                new: "Новый",
                join: "Присоединиться",
                leave: "Покинуть",
                delete: "Удалить",
                remove: "Удалить",
                start: "Начать"
            },
            new: {
                conversation: "Новый чат",
                group: "Новая группа",
                space: "Новая переговорная",
                channel: "Новый канал",
                instantMeeting: "Новое мгновенное совещание",
                selectPic: "Выберите изображение",
                optional: "Необязательный",
                "group-optionalTopic": "Необязательный.\nОписывает тематику группы",
                "space-optionalTopic": "Опция. Описывает предмет",
                "channel-optionalTopic": "Необязательный. Это описывает предмет канала",
                nameRequired: "Необходимые. Максимум. 140 символов, избегайте повторного использования имен",
                spaceSelectRequire: "Требование. Каналы всегда связаны с переговорной",
                spaceSelect: "Выберите переговорную для создания канала",
                invite: "Добавить участников",
                participants: {
                    requires: {
                        two: "Требуется еще 2",
                        one: "Требуется еще один участник"
                    },
                    limit: "Вы можете пригласить до{{max_participants}} участников"
                },
                attendee: {
                    feedback: {
                        positive: "Участник добавлен в список",
                        neutral: "Нажмите клавишу ВВОД, чтобы добавить адрес в список участников",
                        negative: "Введенный адрес электронной почты не действительный , пожалуйста введите правильный адрес электронной почты",
                        emailReplicated: "Введенный адрес электронной почты уже был добавлен"
                    },
                    invite: "Добавить участника",
                    title: "Список участников",
                    empty: "Вы еще не добавили ни одного участника"
                },
                speakToYourFriend: "Поговори со своим другом"
            },
            header: {
                conversations: "Диалоги",
                channels: "Каналы",
                new: {
                    conversation: "Новый диалог",
                    group: "Новая группа",
                    space: "Новая переговорная",
                    channel: "Новый канал",
                    instantMeeting: "Новое мгновенное совещание"
                },
                contactInfo: "Контактная информация",
                groupInfo: "Информация о группе",
                spaceInfo: "Информация о переговорной",
                channelInfo: "Информация о канале",
                invite: "Пригласить в группу",
                filter: {
                    conversation: "Отфильтрованные беседы",
                    channel: "Отфильтрованные каналы"
                },
                instantInfo: "Информация о мгновенном совещании"
            },
            status: {
                online: "В сети",
                offline: "Offline",
                last_seen: "Последнее посещение {{lastSeen}}",
                guest: "Гость"
            },
            general: "{{spaceName}} - Основное",
            chat: "Чат",
            email: "Емайл",
            name: "Имя",
            bio: "Био",
            phone: "Телефон",
            topic: "Тема",
            participants: "Участники",
            commonGroups: "Общие группы",
            commonSpaces: "Общие переговорные",
            contactInfo: "Контактная информация",
            placeholder: {
                searchResults: "Начните печатать , чтобы увидеть результаты поиска",
                addTopic: "Добавить тему",
                pickAddress: "Начинайте печатать для выбора адреса",
                limit: {
                    reached: "Чтобы пригласить других участников , удалите один из выбранных контактов",
                    overquota: "Эта группа достигла максимального лимита участников"
                },
                filter: "Фильтр списка",
                writeMail: "Напишите электронную почту"
            },
            newMessages: "Новое сообщение",
            description: {
                members: {
                    one: "Один участник",
                    many: "{{membersCount}} Участники"
                }
            },
            action: {
                silenceConversation: "Текстовый чат",
                sendConversation: "Отправить диалог по электронной почте",
                clearHistory: "Удалить историю",
                blockUser: "Заблокировать пользователя",
                inviteParticipants: "Добавить участника",
                leaveGroup: "Выйти из группы",
                removeBuddy: "Удалить друга",
                confirm: {
                    leaveGroup: "Вы уверены, что хотите покинуть группу?",
                    removeBuddy: "Вы уверены, что хотите удалить этого друга ?",
                    deleteSpace: "Вы уверены, что хотите удалить переговорную?",
                    leaveChannel: "Вы уверены, что хотите покинуть канал?",
                    deleteChannel: "Вы уверены, что хотите удалить канал?"
                },
                leaveChannel: "Выйти из канала",
                inviteToSpace: "Пригласить в переговорную",
                leaveSpace: "Покинуть переговорную",
                deleteSpace: "Удалить переговорную",
                deleteChannel: "Удалить канал",
                joinChannelAction: "Присоединиться к этому каналу",
                silenceGeneral: "Общий текстовый чат",
                joinChannel: "Присоединяйтесь к каналу, чтобы отправлять сообщения и получать уведомления",
                returnToCallTab: "Перейти на вкладку встречи",
                copyLink: "или скопируйте ссылку и отправьте",
                inviteFeedback: "Приглашение отправлено",
                scrollToNewMessage: "Прокрутите до нового сообщения",
                scrollToTheBottom: "Прокрутите вниз",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "Еще одно мгновенное совещание.\n  Только одно совещание может существовать одновременно"
            },
            shared: {
                media: "Поделился медиа файлами",
                link: "Поделилась ссылкой"
            },
            save: "Сохранить",
            cancel: "Удалить",
            space: {
                administrator: "Администратор пространства"
            },
            notification: {
                you: {
                    join: {
                        group: "Вы присоединились к группе",
                        channel: "Вы присоединились к каналу",
                        space: "Вы присоединились к переговорной",
                        instantMeeting: "Вы присоединились к мгновенному совещанию"
                    },
                    invited: "Вы были приглашены by {{invited_by}}",
                    left: {
                        group: "Вы покинули группу",
                        channel: "Вы покинули канал",
                        space: "Вы покинули переговорную"
                    },
                    changed: {
                        topic: {
                            group: "Вы изменили тему группы",
                            channel: "Вы изменили тему канала",
                            space: "Вы изменили тему переговорной"
                        },
                        name: {
                            channel: "Вы изменили название канала на {{name}}",
                            space: "Вы изменили название переговорной на"
                        },
                        picture: {
                            group: "Вы изменили картинку группы",
                            channel: "Вы изменили изображение канала",
                            space: "Вы изменили название переговорной"
                        }
                    },
                    kicked: {
                        channel: "Вы были удалены из канала {{kicked_by}}",
                        space: "Вы были удалены из переговорной {{kicked_by}}"
                    },
                    created: {
                        single: "Вы создали диалог",
                        group: "Вы создали группу",
                        channel: "Вы создали канал",
                        space: "Вы создали переговорную"
                    },
                    deleted: {
                        channel: "Вы удалили канал",
                        space: "Вы удалили переговорную",
                        instantMeeting: "Вы удалили мгновенное совещание"
                    }
                },
                member: {
                    invited: "{{member_name}} был приглашен {{Invite_by}}",
                    left: {
                        group: "{{member_name}} который покинул группу",
                        channel: "{{member_name}} который покинул канал",
                        space: "{{member_name}} который покинул переговорную"
                    },
                    changed: {
                        topic: {
                            group: "{{member_name}} Изменил' {{topic}} группы",
                            channel: "{{member_name}} изменили тему канала",
                            space: "{{member_name}} изменил тему канала {{topic}}"
                        },
                        name: {
                            channel: "{{member_name}} Было изменено название канала на {{name}}",
                            space: "{{member_name}} изменил имя переговорной' {{name}}"
                        },
                        picture: {
                            group: "{{member_name}} изменил картину' группы",
                            channel: "{{member_name}} изменил картинку канала",
                            space: "{{member_name}} изменил картинку переговорной"
                        }
                    },
                    kicked: {
                        channel: "{{member_name}} был удален из канала {{kicked_by}}",
                        space: "{{member_name}} был удален из переговорной {{kicked_by}}"
                    },
                    created: {
                        single: "{{member_name}} создал диалог",
                        group: "{{member_name}} создал группу",
                        channel: "{{member_name}} создал канал",
                        space: "{{member_name}} создал переговорную"
                    },
                    deleted: {
                        channel: "{{member_name}} удалил канал",
                        space: "{{member_name}} удалила переговорну",
                        instantMeeting: "{{member_name}} удалил мгновенное совещание"
                    },
                    join: "{{member_name}} присоединился к беседе",
                    you: {
                        invited: "Вы пригласили {{member_name}}",
                        kicked: {
                            space: "Вы вышли из переговорной {{member_name}}",
                            channel: "Вы вышли из канала {{member_name}}"
                        }
                    },
                    channel: {
                        join: "{{member_name}} присоединился к каналу"
                    }
                },
                conversation: {
                    created: "Диалог создан"
                },
                meeting: {
                    started: "Собрание началось",
                    ended: "Совещание закончилась"
                },
                newMeeting: "Входящий звонок от:",
                answer: "Ответ",
                dismiss: "Отклонять",
                remindLater: "Напомнить мне позже…",
                newMessage: "Новое сообщение",
                markAllAsRead: "Отметить все как прочитанное",
                drive_size_exceeded: "Файл слишком большой",
                unreadMessages: "Непрочитанные сообщения"
            },
            writing: {
                generic: {
                    status: "пишет…"
                },
                specific: {
                    status: "{{writer}}пишет…"
                }
            },
            selection: {
                participants: {
                    none: "Вы достигли лимита участников установленного администратором",
                    one: "Вы можете пригласить последнего участника",
                    many: "Вы можете пригласить других {{limit}} участников"
                }
            },
            mail: {
                invite: {
                    message: "Вы приглашены на митинг",
                    join_now: "Присоединиться сейчас",
                    follow_to_join: "Чтобы присоединиться к встрече перейдите по ссылке:",
                    generated_by_connect: "Это письмо было сгенерировано автоматически через Zimbra Connect",
                    generated_by_team: "Это письмо было сгенерировано автоматически через Team",
                    space: "Вы были приглашены в новую переговорную!",
                    redirect: "Зайти в переговорную"
                },
                kick: {
                    space: "Вы были удалены из этой переговорной",
                    redirect: "Выйти"
                }
            },
            settings: {
                team: {
                    title: "Настройки Team"
                },
                connect: {
                    title: "Настройки Connect"
                },
                notification: {
                    connect: "Уведомления Connect",
                    team: "Уведомления Team",
                    zimbra: "Уведомления Zimbra",
                    meeting: "Уведомления во время митингов",
                    spawn3: "3 секунды",
                    spawn5: "5 секунд",
                    spawn10: "10 секунд",
                    spawn0: "Быть всегда онлайн",
                    spawn: {
                        label: "Время появления уведомления"
                    },
                    desktop: "Уведомления desktop",
                    title: {
                        notifications: "Уведомления",
                        minichat: "Откройте свернутый чат при получении нового сообщения",
                        hint: "Показать предварительный просмотр сообщения в уведомлениях"
                    }
                },
                profile: {
                    title: "Профиль",
                    errorSnackbar: "При редактировании произошла ошибка",
                    maximumDimension: "Максимальный размер: 256 КБ.",
                    chooseAProfilePic: "Выберите аватарку, которую будут видеть другие пользователи, изображение будет центрировано автоматически.",
                    statusOptionalDescription: "Опционально. Расскажите другим, о чем вы думаете. максимальное количество 256 знаков",
                    userStatus: "Статус",
                    errorMessage: "Упс, что-то пошло не так",
                    update: "Обновить",
                    restore: "Восстановить",
                    reset: "Сбросить",
                    errorGenericResponse: "Что-то пошло не так. Пожалуйста, попробуйте еще раз",
                    errorUpdatingAvatarStatus: "Что-то пошло не так во время настройки статуса. Пожалуйста, попробуйте еще раз",
                    errorRemovingAvatarPicture: "Что-то пошло не так при удалении аватара. Пожалуйста, попробуйте еще раз",
                    errorUploadingAvatarPicture: "Что-то пошло не так при загрузке нового аватара. Пожалуйста, попробуйте еще раз"
                },
                avatar: {
                    autocenter: "Изображение будет центрировано автоматически.",
                    size: "Максимальный размер 256 КБ"
                },
                meeting: {
                    title: {
                        meetingStart: "Начальные настройки митинга"
                    },
                    default: {
                        video: "Камера",
                        audio: "Микрофон"
                    },
                    enableCamera: "Включить камеру",
                    enableMicrophone: "Включить микрофон",
                    description: "Установите свои аудио и видео предпочтения для участия в собраниях. Вы всегда можете настроить свои предпочтения перед тем, как присоединиться к каждой встрече.",
                    meetings: "Совещания"
                },
                modal: {
                    description: "Здесь вы можете установить специальные настройки , чтобы получить полностью индивидуальный чат!"
                },
                notifications: {
                    description: "Установите свои предпочтения для каждого типа уведомлений в Team.",
                    title: "Уведомления"
                }
            },
            fileNotAvailable: "Файл не доступен.",
            contactOwner: "Пожалуйста свяжитесь с администратором.",
            message: {
                browserNotSupported: {
                    Team: "Мы не поддерживаем данную версию вашего браузера! Настоятельно рекомендуем обновить ваш браузер, чтобы использовать все возможности Team !",
                    Connect: "Мы не поддерживаем данную версию вашего браузера! Настоятельно рекомендуем вам обновить ваш браузер, чтобы использовать все возможности Connect!"
                },
                popup: {
                    readBy: "Прочитано"
                }
            },
            modal: {
                endCallByOwner: "Владелец совещания решил завершить разговор, мы надеемся, что вам понравилось.",
                closedInstantMeeting: "Мгновенное совещание закрыто"
            },
            undo: "Отменить",
            edit: "Редактировать",
            input: {
                topicMax255Characters: "Максимум. 255 символов",
                topicNeeds2Letters: "Тема группы должна содержать как минимум две буквы (или ни одной)",
                topicOptional: "Опция. Это описывает предмет",
                nameMax140Characters: "Максимум 140 символов",
                nameRequired: "Требуется имя",
                nameNeeds2Letters: "Имя должно содержать как минимум две буквы",
                "nameRequired-max140Characters-avoidReusingNames": "Требования. Максимум 140 символов, избегайте повторного использования имен"
            },
            instantMeeting: {
                continue: "Продолжить мгновенное совещание",
                create: "Создать новое мгновенное совещание"
            },
            instantMeetingAlreadyRunningText: "Создание нового перезапишет старое, и ваш участник потеряет связь, что вы хотите сделать?",
            instantMeetingAlreadyRunningTitle: "Мгновенное совещание уже запущено.",
            error: {
                uploadPicturesFailed: "Не удалось загрузить фотографию профиля",
                uploadConversationPicturesFailed: "Не удалось загрузить фотографию беседы"
            },
            miniChat: {
                header: {
                    expand: "Расширять",
                    collapse: "Коллапс",
                    meeting: "Начать встречу",
                    openInTeam: "Открыть в Team",
                    close: "Закрыть"
                }
            },
            meeting: {
                interactions: {
                    pttHint: "Удерживайте T, чтобы поговорить",
                    status: {
                        cameraMicOff: "Ваша камера и микрофон выключены",
                        cameraOff: "Ваша камера выключена"
                    },
                    hideUserVideo: "Скрыть видео этого пользователя",
                    showUserVideo: "Показать видео этого пользователя",
                    muteUserAudio: "Отключить звук этого пользователя",
                    unmuteUserAudio: "Включить звук этого пользователя",
                    enableScreenSharing: "Включить общий доступ к экрану",
                    disableScreensharing: "Отключить общий доступ к экрану",
                    enableVideo: "Включить видео",
                    disableVideo: "Отключить видео",
                    enableAudio: "Включить аудио",
                    enableAudioWithHint: "Включить аудио (нажмите и удерживайте «T», чтобы поговорить)",
                    disableAudio: "Отключить звук",
                    closeCall: "Завершить этот звонок"
                },
                startModal: {
                    save: "Сохраните эти настройки",
                    cancel: "отменить",
                    description: "Как вы хотите войти на встречу?",
                    enter: "Вход",
                    noVideoAndNoAudio: "Камера выключена, микрофон выключен",
                    videoAndNoAudio: "Камера включена, Микрофон выключен",
                    noVideoAndAudio: "Камера выключена, микрофон включен",
                    videoAndAudio: "Камера включена, Микрофон включен"
                }
            },
            password: "Пароль",
            nickname: "Ник",
            external: {
                login: {
                    accessMeeting: "Чтобы получить доступ к встрече",
                    signIn: "Войти в систему"
                }
            },
            conversation: {
                fileUploadDescription: "Описание файла"
            },
            loadingScreen: {
                poweredBy: "разработано"
            },
            connection: {
                retryConnection: "Повторить подключение",
                online: "Снова в сети!",
                offline: "Кажется проблема с подключением к серверу"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_th.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            mail: {
                invite: {
                    redirect: "ไปยังห้องประชุม",
                    space: "คุณได้รับเชิญเข้าสู่ห้องประชุมใหม่!",
                    generated_by_team: "เมลนี้ได้ถูกสร้างขึ้นอัตโนมัติโดย Team",
                    generated_by_connect: "เมลนี้ได้ถูกสร้างขึ้นอัตโนมัติโดย Zimbra Connect",
                    follow_to_join: "หากต้องการเข้าร่วมการประชุมโปรดไปที่ลิงก์นี้:",
                    join_now: "เข้าร่วมตอนนี้",
                    message: "คุณได้รับเชิญให้เข้าร่วมการประชุม"
                },
                kick: {
                    space: "คุณถูกลบออกจากห้องประชุมนี้แล้ว",
                    redirect: "ไปยังหน้าแรก"
                }
            },
            notification: {
                member: {
                    deleted: {
                        space: "{{member_name}} ได้ลบห้องประชุมแล้ว",
                        channel: "{{member_name}} ได้ลบช่องแล้ว",
                        instantMeeting: "{{member_name}} ได้ลบการประชุมแบบทันทีแล้ว"
                    },
                    created: {
                        space: "{{member_name}} ได้สร้างห้องประชุมแล้ว",
                        channel: "{{member_name}} ได้สร้างช่องแล้ว",
                        group: "{{member_name}} ได้สร้างกลุ่มแล้ว",
                        single: "{{member_name}} ได้สร้างบทสนทนาแล้ว"
                    },
                    you: {
                        kicked: {
                            space: "คุณได้ลบออกจากห้องประชุม {{member_name}}",
                            channel: "คุณได้ลบออกจากช่อง {{member_name}}"
                        },
                        invited: "คุณได้เชิญ {{member_name}}"
                    },
                    kicked: {
                        space: "{{member_name}} ได้ถูกลบออกจากห้องประชุมโดย {{kicked_by}}",
                        channel: "{{member_name}} ได้ถูกลบออกจากช่องโดย {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}} ได้เปลี่ยนรูปภาพของห้องประชุมแล้ว",
                            channel: "{{member_name}} ได้เปลี่ยนรูปภาพของช่องแล้ว",
                            group: "{{member_name}} ได้เปลี่ยนรูปภาพของกลุ่มแล้ว"
                        },
                        name: {
                            space: "{{member_name}} ได้เปลี่ยนชื่อของห้องประชุมใน {{name}}",
                            channel: "{{member_name}} ได้เปลี่ยนชื่อของช่องใน {{name}}"
                        },
                        topic: {
                            space: "{{member_name}} ได้เปลี่ยนหัวข้อของห้องประชุมใน {{topic}}",
                            channel: "{{member_name}} ได้เปลี่ยนหัวข้อของช่องใน {{topic}}",
                            group: "{{member_name}} ได้เปลี่ยนหัวข้อของกลุ่มใน {{topic}}"
                        }
                    },
                    left: {
                        space: "{{member_name}} ได้ออกจากห้องประชุมแล้ว",
                        channel: "{{member_name}} ได้ออกจากช่องแล้ว",
                        group: "{{member_name}} ได้ออกจากกลุ่มแล้ว"
                    },
                    channel: {
                        join: "{{member_name}} ได้เข้าร่วมช่องแล้ว"
                    },
                    join: "{{member_name}} ได้เข้าร่วมบทสนทนาแล้ว",
                    invited: "{{member_name}} ได้รับเชิญจาก {{Invite_by}}"
                },
                you: {
                    deleted: {
                        space: "คุณได้ลบห้องประชุมแล้ว",
                        channel: "คุณได้ลบช่องแล้ว",
                        instantMeeting: "คุณได้ลบการประชุมแบบทันทีแล้ว"
                    },
                    created: {
                        space: "คุณได้สร้างห้องประชุมแล้ว",
                        channel: "คุณได้สร้างช่องแล้ว",
                        group: "คุณได้สร้างกลุ่มแล้ว",
                        single: "คุณได้สร้างการสนทนาแล้ว"
                    },
                    kicked: {
                        space: "คุณได้ถูกลบออกจากห้องประชุมโดย {{kicked_by}}",
                        channel: "คุณได้ถูกลบออกจากช่องโดย {{kicked_by}}"
                    },
                    changed: {
                        picture: {
                            space: "คุณได้เปลี่ยนชื่อของห้องประชุมแล้ว",
                            channel: "คุณได้เปลี่ยนรูปภาพของช่องแล้ว",
                            group: "คุณได้เปลี่ยนรูปภาพของกลุ่มแล้ว"
                        },
                        name: {
                            space: "คุณเปลี่ยนชื่อของห้องประชุมใน {{name}}",
                            channel: "คุณเปลี่ยนชื่อของช่องใน {{name}}"
                        },
                        topic: {
                            space: "คุณเปลี่ยนหัวข้อของห้องประชุมใน {{topic}}",
                            channel: "คุณเปลี่ยนหัวข้อของช่องใน {{topic}}",
                            group: "คุณเปลี่ยนหัวข้อของกลุ่มใน {{topic}}"
                        }
                    },
                    left: {
                        space: "คุณได้ออกจากห้องประชุมแล้ว",
                        channel: "คุณได้ออกจากช่องแล้ว",
                        group: "คุณได้ออกจากกลุ่มแล้ว"
                    },
                    join: {
                        space: "คุณได้เข้าร่วมห้องประชุมแล้ว",
                        channel: "คุณได้เข้าร่วมช่องแล้ว",
                        group: "คุณได้เข้าร่วมกลุ่มแล้ว",
                        instantMeeting: "คุณได้เข้าร่วมการประชุมแบบทันทีแล้ว"
                    },
                    invited: "คุณได้รับเชิญจาก {{Invite_by}}"
                },
                markAllAsRead: "ทำเครื่องหมายทั้งหมดว่าอ่านแล้ว",
                drive_size_exceeded: "ไฟล์ใหญ่เกินไป",
                newMessage: "ข้อความใหม่",
                unreadMessages: "ข้อความที่ยังไม่ได้อ่าน",
                remindLater: "เตือนฉันในภายหลัง…",
                dismiss: "ยกเลิก",
                answer: "รับสาย",
                newMeeting: "สายเรียกเข้าจาก:",
                meeting: {
                    ended: "สิ้นสุดการประชุมแล้ว",
                    started: "เริ่มการประชุมแล้ว"
                },
                conversation: {
                    created: "สร้างบทสนทนาแล้ว"
                }
            },
            space: {
                administrator: "ผู้ดูแลห้องประชุม"
            },
            commonSpaces: "ห้องประชุมทั่วไป",
            header: {
                spaceInfo: "ข้อมูลห้องประชุม",
                new: {
                    space: "ห้องประชุมใหม่",
                    instantMeeting: "การประชุมใหม่แบบทันที",
                    channel: "ช่องใหม่",
                    group: "กลุ่มใหม่",
                    conversation: "บทสนทนาใหม่"
                },
                instantInfo: "ข้อมูลการประชุมแบบทันที",
                filter: {
                    channel: "ช่องที่กรองแล้ว",
                    conversation: "บทสนทนาที่กรองแล้ว"
                },
                invite: "เชิญเข้ากลุ่ม",
                channelInfo: "ข้อมูลช่อง",
                groupInfo: "ข้อมูลกลุ่ม",
                contactInfo: "ข้อมูลติดต่อ",
                channels: "ช่อง",
                conversations: "การสนทนา"
            },
            new: {
                spaceSelect: "เลือกห้องประชุมเพื่อสร้างช่อง",
                spaceSelectRequire: "จำเป็น ช่องจะถูกเชื่อมโยงกับห้องประชุมเสมอ",
                space: "ห้องประชุมใหม่",
                attendee: {
                    feedback: {
                        emailReplicated: "เพิ่มอีเมลที่ป้อนแล้ว",
                        negative: "อีเมลที่ป้อนไม่ถูกต้อง โปรดใส่อีเมลที่ถูกต้อง",
                        neutral: "กด ENTER เพื่อเพิ่มที่อยู่ลงในรายการผู้เข้าร่วม",
                        positive: "เพิ่มผู้เข้าร่วมในรายการแล้ว"
                    },
                    empty: "คุณยังไม่ได้เพิ่มผู้เข้าร่วม",
                    title: "รายชื่อผู้เข้าร่วม",
                    invite: "เพิ่มผู้เข้าร่วม"
                },
                participants: {
                    limit: "คุณสามารถเชิญได้สูงสุด {{max_participants}} คน",
                    requires: {
                        two: "ต้องการอย่างน้อยอีก 2 คน",
                        one: "ต้องการผู้เข้าร่วมอย่างน้อยหนึ่งคน"
                    }
                },
                speakToYourFriend: "พูดคุยกับเพื่อนของคุณ",
                invite: "เพิ่มผู้เข้าร่วม",
                nameRequired: "จำเป็น ต้องมีตัวอักษรไม่เกิน 140 ตัว หลีกเลี่ยงการใช้ชื่อซ้ำ",
                "group-optionalTopic": "ไม่จำเป็น มันอธิบายถึงสาระสำคัญของกลุ่ม",
                "space-optionalTopic": "ไม่จำเป็น มันอธิบายถึงสาระสำคัญ",
                "channel-optionalTopic": "ไม่จำเป็น มันอธิบายถึงสาระสำคัญของช่อง",
                optional: "ไม่จำเป็น",
                selectPic: "เลือกภาพ",
                instantMeeting: "การประชุมใหม่แบบทันที",
                channel: "ช่องใหม่",
                group: "กลุ่มใหม่",
                conversation: "บทสนทนาใหม่"
            },
            treeMenu: {
                spaces: "ห้องประชุม",
                instantMeeting: "การประชุมแบบทันที",
                conversations: "การสนทนา"
            },
            action: {
                confirm: {
                    deleteSpace: "คุณแน่ใจหรือไม่ว่าต้องการลบห้องประชุมนี้?",
                    deleteChannel: "คุณแน่ใจหรือไม่ว่าต้องการลบช่องนี้?",
                    leaveChannel: "คุณแน่ใจหรือไม่ว่าต้องการออกจากช่องนี้?",
                    removeBuddy: "คุณแน่ใจหรือไม่ว่าต้องการลบเพื่อนคนนี้ออก?",
                    leaveGroup: "คุณแน่ใจหรือไม่ว่าต้องการออกจากกลุ่ม?"
                },
                deleteSpace: "ลบห้องประชุม",
                leaveSpace: "ออกจากห้องประชุม",
                inviteToSpace: "เชิญเข้าในห้องประชุม",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "การประชุมแบบทันทีอันอื่นกำลังทำงานอยู่\nการประชุมแบบทันทีสามารถทำได้ครั้งละหนึ่งอันเท่านั้น",
                inviteFeedback: "ส่งคำเชิญแล้ว",
                copyLink: "หรือคัดลอกลิงก์และส่ง",
                scrollToNewMessage: "เลื่อนไปที่ข้อความใหม่",
                scrollToTheBottom: "เลื่อนไปที่ด้านล่าง",
                returnToCallTab: "ไปที่แถบการประชุม",
                joinChannel: "เข้าร่วมช่องเพื่อส่งข้อความและรับการแจ้งเตือน",
                joinChannelAction: "เข้าร่วมช่องนี้",
                deleteChannel: "ลบช่อง",
                leaveChannel: "ออกจากช่องนี้",
                removeBuddy: "ลบเพื่อน",
                leaveGroup: "ออกจากกลุ่ม",
                inviteParticipants: "เพิ่มผู้เข้าร่วม",
                blockUser: "บล็อกผู้ใช้",
                clearHistory: "ล้างประวัติ",
                sendConversation: "ส่งการสนทนาทางอีเมล",
                silenceConversation: "ปิดเสียงการสนทนา",
                silenceGeneral: "เงียบปกติ"
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "กล้องและไมโครโฟนของคุณปิดอยู่",
                        cameraOff: "กล้องของคุณปิดอยู่"
                    },
                    hideUserVideo: "ซ่อนวิดีโอของผู้ใช้รายนี้",
                    showUserVideo: "แสดงวิดีโอของผู้ใช้รายนี้",
                    muteUserAudio: "ปิดเสียงของผู้ใช้นี้",
                    unmuteUserAudio: "เปิดเสียงของผู้ใช้นี้",
                    disableScreensharing: "ปิด ScreenSharing",
                    enableScreenSharing: "เปิด ScreenSharing",
                    enableVideo: "เปิดการใช้งานวิดีโอ",
                    disableVideo: "ปิดการใช้งานวิดีโอ",
                    enableAudio: "เปิดการใช้งานเสียง",
                    enableAudioWithHint: "เปิดการใช้งานเสียง (กด 'T' ค้างเพื่อพูด)",
                    disableAudio: "ปิดการใช้งานเสียง",
                    closeCall: "ปิดการโทรนี้",
                    pttHint: "กด 'T' ค้าง เพื่อพูด"
                },
                startModal: {
                    videoAndAudio: "เปิดกล้อง, เปิดไมโครโฟน",
                    noVideoAndAudio: "ปิดกล้อง, เปิดไมโครโฟน",
                    videoAndNoAudio: "เปิดกล้อง, ปิดไมโครโฟน",
                    noVideoAndNoAudio: "ปิดกล้อง, ปิดไมโครโฟน",
                    cancel: "ยกเลิก",
                    save: "บันทึกการตั้งค่าเหล่านี้",
                    enter: "เข้าสู่การประชุม",
                    description: "คุณต้องการเข้าร่วมการประชุมอย่างไร?"
                }
            },
            modal: {
                endCallByOwner: "เจ้าของการประชุมแบบทันทีได้ตัดสินใจที่จะยุติการโทร เราหวังว่าคุณได้รับประสบการณ์ที่ดีจากการประชุมแบบทันที",
                closedInstantMeeting: "ปิดการประชุมแบบทันทีแล้ว"
            },
            undo: "ย้อนกลับ",
            edit: "แก้ไข",
            input: {
                topicMax255Characters: "ไม่เกิน 255 ตัวอักษร",
                topicNeeds2Letters: "หัวข้อของกลุ่มต้องมีตัวอักษรอย่างน้อยสองตัว (หรือไม่มี)",
                topicOptional: "ไม่จำเป็น มันอธิบายถึงสาระสำคัญ",
                nameMax140Characters: "ไม่เกิน 140 ตัวอักษร",
                nameRequired: "ต้องระบุชื่อ",
                nameNeeds2Letters: "ชื่อต้องมีตัวอักษรอย่างน้อยสองตัว",
                "nameRequired-max140Characters-avoidReusingNames": "จำเป็น ต้องมีตัวอักษรไม่เกิน 140 ตัว หลีกเลี่ยงการใช้ชื่อซ้ำ"
            },
            instantMeeting: {
                continue: "ดำเนินการต่อด้วยการประชุมแบบทันทีอันเดิม",
                create: "สร้างการประชุมแบบทันทีใหม่"
            },
            instantMeetingAlreadyRunningText: "การสร้างใหม่จะยุติอันก่อนหน้าและผู้เข้าร่วมจะสูญเสียการเชื่อมต่อ คุณต้องการหรือไม่?",
            instantMeetingAlreadyRunningTitle: "การประชุมแบบทันทีกำลังทำงานอยู่",
            error: {
                uploadPicturesFailed: "การอัปโหลดรูปโปรไฟล์ล้มเหลว",
                uploadConversationPicturesFailed: "ไม่สามารถอัปโหลดรูปภาพการสนทนาได้"
            },
            commonGroups: "กลุ่มทั่วไป",
            button: {
                start: "เริ่ม",
                remove: "ลบออก",
                delete: "ลบ",
                leave: "ออก",
                join: "เข้าร่วม",
                new: "ใหม่"
            },
            message: {
                browserNotSupported: {
                    Connect: "เราไม่รองรับเบราว์เซอร์เวอร์ชั่นนี้ของคุณ. เราขอแนะนำให้คุณอัปเดตเบราว์เซอร์ของคุณ เพื่อใช้ประโยชน์จากคุณสมบัติทั้งหมดของ Connect ได้อย่างเต็มรูปแบบ!",
                    Team: "เราไม่รองรับเบราว์เซอร์เวอร์ชั่นนี้ของคุณ. เราขอแนะนำให้คุณอัปเดตเบราว์เซอร์ของคุณ เพื่อใช้ประโยชน์จากคุณสมบัติทั้งหมดของ Team ได้อย่างเต็มรูปแบบ!"
                },
                popup: {
                    readBy: "อ่านโดย"
                }
            },
            contactOwner: "กรุณาติดต่อเจ้าของ",
            fileNotAvailable: "ไฟล์ไม่พร้อมใช้งาน",
            placeholder: {
                limit: {
                    overquota: "กลุ่มนี้มีผู้เข้าร่วมเต็มจำนวนสูงสุดแล้ว",
                    reached: "หากต้องการเชิญบุคคลอื่นให้คุณลบรายชื่อผู้ติดต่อที่เลือกไว้ออกหนึ่งรายการ"
                },
                writeMail: "พิมพ์ที่อยู่อีเมล",
                filter: "พิมพ์เพื่อกรองรายการ",
                pickAddress: "เริ่มการพิมพ์เพื่อเลือกที่อยู่",
                addTopic: "เพิ่มหัวข้อ",
                searchResults: "พิมพ์ที่ด้านบนเพื่อดูผลการค้นหา"
            },
            settings: {
                notification: {
                    title: {
                        hint: "แสดงตัวอย่างข้อความในการแจ้งเตือน",
                        minichat: "เปิดการแชทแบบย่อเมื่อได้รับข้อความใหม่",
                        notifications: "การแจ้งเตือน"
                    },
                    desktop: "การแจ้งเตือนของเดสก์ท็อป",
                    spawn10: "10 วินาที",
                    spawn5: "5 วินาที",
                    spawn3: "3 วินาที",
                    meeting: "การแจ้งเตือนระหว่างการประชุม",
                    zimbra: "การแจ้งเตือน Zimbra",
                    team: "การแจ้งเตือน Team",
                    connect: "การแจ้งเตือน Connect",
                    spawn: {
                        label: "เวลาเริ่มการแจ้งเตือน"
                    },
                    spawn0: "ไม่เคยหาย"
                },
                avatar: {
                    size: "ขนาดสูงสุด 256kb",
                    autocenter: "ภาพจะถูกจัดกึ่งกลางโดยอัตโนมัติ"
                },
                profile: {
                    title: "โปรไฟล์"
                },
                connect: {
                    title: "การตั้งค่า Connect"
                },
                team: {
                    title: "การตั้งค่า Team"
                },
                meeting: {
                    title: {
                        meetingStart: "การตั้งค่าเริ่มต้นของการประชุม"
                    },
                    default: {
                        video: "กล้อง",
                        audio: "ไมโครโฟน"
                    }
                }
            },
            selection: {
                participants: {
                    many: "คุณสามารถเชิญผู้เข้าร่วมคนอื่น {{limit}} คน",
                    one: "คุณสามารถเชิญผู้เข้าร่วมคนสุดท้าย",
                    none: "คุณมีผู้เข้าร่วมเต็มจำนวนสูงสุดที่กำหนดเอาไว้โดยผู้ดูแลระบบแล้ว"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}} กำลังเขียน…"
                },
                generic: {
                    status: "กำลังเขียน…"
                }
            },
            cancel: "ยกเลิก",
            save: "บันทึก",
            shared: {
                link: "ลิงก์ที่แชร์",
                media: "มีเดียที่แชร์"
            },
            description: {
                members: {
                    many: "สมาชิก {{membersCount}}",
                    one: "ผู้เข้าร่วมหนึ่งคน"
                }
            },
            newMessages: "ข้อความใหม่",
            contactInfo: "ข้อมูลติดต่อ",
            participants: "ผู้เข้าร่วม",
            topic: "หัวข้อ",
            phone: "โทรศัพท์",
            bio: "ข้อมูลส่วนตัว",
            name: "ชื่อ",
            email: "อีเมล",
            chat: "แชท",
            general: "{{spaceName}} - ทั่วไป",
            status: {
                last_seen: "ดูครั้งล่าสุด {{lastSeen}}",
                offline: "ออฟไลน์",
                online: "ออนไลน์",
                guest: "แขก"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            miniChat: {
                header: {
                    expand: "ขยาย",
                    close: "ปิด",
                    openInTeam: "เปิดใน Team",
                    collapse: "ย่อ",
                    meeting: "เริ่มการประชุม"
                }
            },
            external: {
                login: {
                    signIn: "เข้าสู่ระบบ",
                    accessMeeting: "เพื่อเข้าร่วมการประชุม"
                }
            },
            nickname: "ชื่อเล่น",
            password: "รหัสผ่าน",
            conversation: {
                fileUploadDescription: "คำอธิบายไฟล์"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translations/team_web_client_zh-CN.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            action: {
                silenceGeneral: "静音通用频道",
                instantMeetingAlreadyRunningTitle_lowerAPIVersion: "另一个即时会议正在进行。\n一次只能存在一个即时会议",
                scrollToNewMessage: "滑至新消息",
                scrollToTheBottom: "滑至底部",
                inviteFeedback: "已发送邀请",
                copyLink: "或复制链接并发送",
                returnToCallTab: "转到会议选项卡",
                joinChannel: "加入频道以发送消息并接收通知",
                confirm: {
                    deleteChannel: "确定要删除频道吗？",
                    leaveChannel: "确定要离开频道吗？",
                    deleteSpace: "确定要删除空间吗？",
                    removeBuddy: "确定要移除该好友吗？",
                    leaveGroup: "确定要离开群组吗？"
                },
                joinChannelAction: "加入该频道",
                deleteChannel: "删除频道",
                deleteSpace: "删除空间",
                leaveSpace: "离开空间",
                inviteToSpace: "邀请进入空间",
                leaveChannel: "离开该频道",
                removeBuddy: "移除好友",
                leaveGroup: "离开群组",
                inviteParticipants: "添加参与者",
                blockUser: "屏蔽用户",
                clearHistory: "清除历史记录",
                sendConversation: "通过邮件发送会话",
                silenceConversation: "静音会话"
            },
            meeting: {
                interactions: {
                    status: {
                        cameraMicOff: "您的相机和麦克风已关闭",
                        cameraOff: "您的相机已关闭"
                    },
                    hideUserVideo: "隐藏该用户的视频",
                    showUserVideo: "显示该用户的视频",
                    muteUserAudio: "静音该用户的音频",
                    unmuteUserAudio: "取消静音该用户的音频",
                    enableScreenSharing: "启用屏幕共享",
                    disableScreensharing: "禁用屏幕共享",
                    enableVideo: "启用视频",
                    disableVideo: "禁用视频",
                    enableAudio: "启用音频",
                    enableAudioWithHint: "启用音频（按住‘T’键进行通话）",
                    disableAudio: "禁用音频",
                    closeCall: "关闭此呼叫",
                    pttHint: "按住‘T’说话"
                },
                startModal: {
                    save: "保存这些设置",
                    cancel: "取消",
                    description: "您想如何进入该会议？",
                    enter: "进入",
                    noVideoAndNoAudio: "摄像头已关闭，麦克风已关闭",
                    noVideoAndAudio: "摄像头已关闭，麦克风已打开",
                    videoAndNoAudio: "摄像头已打开，麦克风已关闭",
                    videoAndAudio: "摄像头已打开，麦克风已打开"
                }
            },
            modal: {
                endCallByOwner: "即时会议的所有者已决定结束通话，希望您的即时会议体验令人愉快。",
                closedInstantMeeting: "即时会议已关闭"
            },
            undo: "撤消",
            edit: "编辑",
            input: {
                topicMax255Characters: "最多255个字符",
                topicNeeds2Letters: "群组主题至少需要有两个字母（或为空）",
                topicOptional: "可选。描述主题",
                nameMax140Characters: "最多140个字符",
                nameRequired: "需要名称",
                nameNeeds2Letters: "名称至少需要两个字母",
                "nameRequired-max140Characters-avoidReusingNames": "必要。最多140个字符，请避免重复使用名称"
            },
            instantMeeting: {
                continue: "继续旧的即时会议",
                create: "创建新的即时会议"
            },
            instantMeetingAlreadyRunningText: "创建新的将结束旧的，您的与会者将失去连接。确定吗？",
            instantMeetingAlreadyRunningTitle: "即时会议已在进行。",
            error: {
                uploadPicturesFailed: "上传档案图片失败",
                uploadConversationPicturesFailed: "上传会话图片失败"
            },
            new: {
                attendee: {
                    feedback: {
                        emailReplicated: "输入的邮箱已添加",
                        negative: "输入的邮箱无效，请输入有效邮箱",
                        neutral: "按下回车键以将该地址加入与会者列表中",
                        positive: "已在列表中添加与会者"
                    },
                    empty: "您尚未添加任何与会者",
                    title: "与会者列表",
                    invite: "添加与会者"
                },
                speakToYourFriend: "和朋友们聊聊",
                participants: {
                    limit: "您最多可以邀请{{max_participants}}人",
                    requires: {
                        one: "需要至少另外1名参与者",
                        two: "至少需要另外2个"
                    }
                },
                invite: "添加参与者",
                spaceSelect: "选择空间以创建一个频道",
                spaceSelectRequire: "必要。频道将始终链接至空间",
                nameRequired: "必要。最多140个字符，请避免重复使用名称",
                "channel-optionalTopic": "可选。描述频道的主题",
                "space-optionalTopic": "可选。描述主题",
                "group-optionalTopic": "可选。描述群组的主题",
                optional: "可选",
                selectPic: "选择一张图片",
                instantMeeting: "新即时会议",
                channel: "新频道",
                space: "新空间",
                group: "新群组",
                conversation: "新会话"
            },
            notification: {
                markAllAsRead: "全部标记为已读",
                member: {
                    channel: {
                        join: "{{member_name}}已加入频道"
                    },
                    deleted: {
                        instantMeeting: "{{member_name}}已删除即时会议",
                        space: "{{member_name}}已删除空间",
                        channel: "{{member_name}}已删除频道"
                    },
                    you: {
                        kicked: {
                            space: "您已将{{member_name}}从空间中移除",
                            channel: "您已将{{member_name}}从频道中移除"
                        },
                        invited: "您已邀请{{member_name}}"
                    },
                    join: "{{member_name}}已加入会话",
                    created: {
                        space: "{{member_name}}已创建空间",
                        channel: "{{member_name}}已创建频道",
                        group: "{{member_name}}已创建群组",
                        single: "{{member_name}}已创建会话"
                    },
                    kicked: {
                        space: "{{member_name}}已被{{kicked_by}}从空间中移除",
                        channel: "{{member_name}}已被{{kicked_by}}从频道中移除"
                    },
                    changed: {
                        picture: {
                            space: "{{member_name}}已更改空间图片",
                            channel: "{{member_name}}已更改频道图片",
                            group: "{{member_name}}已更改群组图片"
                        },
                        name: {
                            space: "{{member_name}}已更改空间名称：{{name}}",
                            channel: "{{member_name}}已更改频道名称：{{name}}"
                        },
                        topic: {
                            space: "{{member_name}}已更改空间主题：{{topic}}",
                            channel: "{{member_name}}已更改频道主题：{{topic}}",
                            group: "{{member_name}}已更改群组主题：{{topic}}"
                        }
                    },
                    left: {
                        space: "{{member_name}}已离开空间",
                        channel: "{{member_name}}已离开频道",
                        group: "{{member_name}}已离开群组"
                    },
                    invited: "{{invited_by}}邀请了{{member_name}}"
                },
                drive_size_exceeded: "文件太大",
                unreadMessages: "未读消息",
                you: {
                    deleted: {
                        instantMeeting: "您已删除即时会议",
                        space: "您已删除空间",
                        channel: "您已删除频道"
                    },
                    join: {
                        instantMeeting: "您已加入即时会议",
                        space: "您已加入空间",
                        channel: "您已加入频道",
                        group: "您已加入群组"
                    },
                    created: {
                        space: "您已创建空间",
                        channel: "您已创建频道",
                        group: "您已创建群组",
                        single: "您已创建会话"
                    },
                    kicked: {
                        space: "您已被{{kicked_by}}从空间中移除",
                        channel: "您已被{{kicked_by}}从频道中移除"
                    },
                    changed: {
                        picture: {
                            space: "您已更改空间图片",
                            channel: "您已更改频道图片",
                            group: "您已更改群组图片"
                        },
                        name: {
                            space: "您已更改空间名称：{{name}}",
                            channel: "您已更改频道名称：{{name}}"
                        },
                        topic: {
                            space: "您已更改空间主题：{{topic}}",
                            channel: "您已更改频道主题：{{topic}}",
                            group: "您已更改群组主题：{{topic}}"
                        }
                    },
                    left: {
                        space: "您已离开空间",
                        channel: "您已离开频道",
                        group: "您已离开群组"
                    },
                    invited: "{{invited_by}}邀请了您"
                },
                newMessage: "新消息",
                remindLater: "稍后提醒…",
                dismiss: "收起",
                answer: "答复",
                newMeeting: "呼入电话，来自：",
                meeting: {
                    ended: "会议已结束",
                    started: "会议已开始"
                },
                conversation: {
                    created: "会话已创建"
                }
            },
            button: {
                start: "开始",
                remove: "移除",
                delete: "删除",
                leave: "离开",
                join: "加入",
                new: "新建"
            },
            mail: {
                kick: {
                    redirect: "前往主页",
                    space: "您已被移出该空间"
                },
                invite: {
                    redirect: "前往空间",
                    space: "您已受邀加入新空间！",
                    generated_by_team: "该邮件由团队自动生成",
                    generated_by_connect: "该邮件由连接自动生成",
                    follow_to_join: "如需加入会议，请使用以下链接：",
                    join_now: "立即加入",
                    message: "您已受邀加入会议"
                }
            },
            message: {
                browserNotSupported: {
                    Connect: "不支持该版本的浏览器. 我们强烈建议您更新浏览器以充分享受连接的全部功能！",
                    Team: "不支持该版本的浏览器. 我们强烈建议您更新浏览器以充分享受团队的全部功能！"
                },
                popup: {
                    readBy: "已读："
                }
            },
            contactOwner: "请联系所有者。",
            fileNotAvailable: "文件不可用。",
            placeholder: {
                limit: {
                    overquota: "该群组已达到参与者数量上限",
                    reached: "如需邀请其他人，请移除一个选定的联系人"
                },
                writeMail: "键入邮箱地址",
                filter: "输入以筛选列表",
                pickAddress: "开始输入以选择地址",
                addTopic: "添加主题",
                searchResults: "在上方输入以查看搜索结果"
            },
            settings: {
                notification: {
                    title: {
                        hint: "在通知中显示消息预览",
                        minichat: "当有新消息时打开最小化的聊天窗口",
                        notifications: "通知"
                    },
                    desktop: "桌面通知",
                    spawn: {
                        label: "通知时限"
                    },
                    spawn0: "永不消失",
                    spawn10: "10秒",
                    spawn5: "5秒",
                    spawn3: "3秒",
                    meeting: "会议期间的通知",
                    zimbra: "Zimbra通知",
                    team: "团队通知",
                    connect: "连接通知"
                },
                avatar: {
                    size: "最大尺寸为256 kB",
                    autocenter: "图片将自动居中。"
                },
                profile: {
                    title: "档案"
                },
                connect: {
                    title: "连接设置"
                },
                team: {
                    title: "团队设置"
                },
                meeting: {
                    title: {
                        meetingStart: "会议初始设置"
                    },
                    default: {
                        video: "摄像头",
                        audio: "麦克风"
                    }
                }
            },
            header: {
                instantInfo: "即时会议信息",
                filter: {
                    channel: "筛选后频道",
                    conversation: "筛选后会话"
                },
                invite: "邀请加入群组",
                channelInfo: "频道信息",
                spaceInfo: "空间信息",
                groupInfo: "群组信息",
                contactInfo: "联系信息",
                new: {
                    instantMeeting: "新即时会议",
                    channel: "新频道",
                    space: "新空间",
                    group: "新群组",
                    conversation: "新会话"
                },
                channels: "频道",
                conversations: "会话"
            },
            selection: {
                participants: {
                    many: "您还可以邀请{{limit}}名参与者",
                    one: "您可以邀请最后一位参与者",
                    none: "您已达到管理员设置的参与者限制"
                }
            },
            writing: {
                specific: {
                    status: "{{writer}}正在输入…"
                },
                generic: {
                    status: "正在输入…"
                }
            },
            space: {
                administrator: "空间管理员"
            },
            cancel: "取消",
            save: "保存",
            shared: {
                link: "已分享链接",
                media: "已分享媒体"
            },
            description: {
                members: {
                    many: "{{membersCount}}名成员",
                    one: "1名参与者"
                }
            },
            newMessages: "新消息",
            contactInfo: "联系信息",
            commonSpaces: "共同空间",
            commonGroups: "共同群组",
            participants: "参与者",
            topic: "主题",
            phone: "电话",
            bio: "简介",
            name: "名称",
            email: "邮箱",
            chat: "聊天",
            general: "{{spaceName}}-通用",
            status: {
                last_seen: "上次出现{{lastSeen}}",
                offline: "离线",
                online: "在线",
                guest: "访客"
            },
            treeMenu: {
                instantMeeting: "即时会议",
                spaces: "空间",
                conversations: "会话"
            },
            connectMenuItem: "Connect",
            menuItem: "Team",
            miniChat: {
                header: {
                    expand: "展开",
                    collapse: "收起",
                    meeting: "开始会议",
                    openInTeam: "在团队中打开",
                    close: "关闭"
                }
            },
            password: "密码",
            nickname: "昵称",
            external: {
                login: {
                    accessMeeting: "如需访问会议",
                    signIn: "登录"
                }
            },
            conversation: {
                fileUploadDescription: "文件描述"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_de.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Abbrechen",
                save: "Speichern",
                ok: "Ok",
                start: "Start"
            },
            header: {
                LOGOUT: "Ausloggen"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_en_US.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Cancel",
                save: "Save",
                ok: "Ok",
                start: "Start"
            },
            header: {
                LOGOUT: "Logout"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_es.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Cancelar",
                save: "Guardar",
                start: "Inicio",
                ok: "Ok"
            },
            header: {
                LOGOUT: "Cerrar sesión"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_fr.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Annuler",
                save: "Sauvegarder",
                ok: "Ok",
                start: "Commencer"
            },
            header: {
                LOGOUT: "Déconnexion"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_hi.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                LOGOUT: "लॉगआउट करें"
            },
            buttons: {
                start: "शुरू करें",
                ok: "ठीक है",
                save: "सेव करें",
                cancel: "कैंसल करें"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_hr.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Odustani",
                save: "Spremi",
                ok: "U redu",
                start: "Početak"
            },
            header: {
                LOGOUT: "Odjava"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_id.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                LOGOUT: "Keluar"
            },
            buttons: {
                start: "Mulai",
                ok: "Ok",
                save: "Simpan",
                cancel: "Batal"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_it.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Cancella",
                save: "Salva",
                start: "Avvia",
                ok: "Ok"
            },
            header: {
                LOGOUT: "Disconnetti"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_ja.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                LOGOUT: "ログアウト"
            },
            buttons: {
                start: "開始する",
                ok: "Ok",
                save: "保存する",
                cancel: "キャンセル"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_nl.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                LOGOUT: "Uitloggen"
            },
            buttons: {
                start: "Starten",
                ok: "OK",
                save: "Opslaan",
                cancel: "Annuleren"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_pt.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Cancelar",
                save: "Salvar",
                start: "Inicio",
                ok: "Ok"
            },
            header: {
                LOGOUT: "Logout"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_pt_BR.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Cancelar",
                save: "Salvar",
                start: "Início",
                ok: "Ok"
            },
            header: {
                LOGOUT: "Logout"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_ro.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                start: "Start",
                ok: "O.k",
                save: "Salvați",
                cancel: "Anulare"
            },
            header: {
                LOGOUT: "Deconectare"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_ru.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            buttons: {
                cancel: "Отменить",
                save: "Сохранить",
                start: "Начать",
                ok: "Ок"
            },
            header: {
                LOGOUT: "Выйти"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_th.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                LOGOUT: "ออกจากระบบ"
            },
            buttons: {
                start: "เริ่ม",
                ok: "ตกลง",
                save: "บันทึก",
                cancel: "ยกเลิก"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/i18n/translationsInterop/interop_zh-CN.properties": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        const properties = {
            header: {
                LOGOUT: "注销"
            },
            buttons: {
                start: "开始",
                ok: "OK",
                save: "保存",
                cancel: "取消"
            }
        };
        __webpack_exports__["default"] = properties;
    },
    "./src/interop/i18n.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "setLocale", (function() {
            return setLocale;
        }));
        __webpack_require__.d(__webpack_exports__, "getTranslationByPath", (function() {
            return getTranslationByPath;
        }));
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return getTranslations;
        }));
        var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
        var _i18n_translations_team_web_client_de_properties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/i18n/translations/team_web_client_de.properties");
        var _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/i18n/translations/team_web_client_en_US.properties");
        var _i18n_translations_team_web_client_es_properties__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/i18n/translations/team_web_client_es.properties");
        var _i18n_translations_team_web_client_fr_properties__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/i18n/translations/team_web_client_fr.properties");
        var _i18n_translations_team_web_client_hi_properties__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/i18n/translations/team_web_client_hi.properties");
        var _i18n_translations_team_web_client_hr_properties__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/i18n/translations/team_web_client_hr.properties");
        var _i18n_translations_team_web_client_id_properties__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./src/i18n/translations/team_web_client_id.properties");
        var _i18n_translations_team_web_client_it_properties__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./src/i18n/translations/team_web_client_it.properties");
        var _i18n_translations_team_web_client_ja_properties__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("./src/i18n/translations/team_web_client_ja.properties");
        var _i18n_translations_team_web_client_nl_properties__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("./src/i18n/translations/team_web_client_nl.properties");
        var _i18n_translations_team_web_client_pt_properties__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("./src/i18n/translations/team_web_client_pt.properties");
        var _i18n_translations_team_web_client_pt_BR_properties__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("./src/i18n/translations/team_web_client_pt_BR.properties");
        var _i18n_translations_team_web_client_ro_properties__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("./src/i18n/translations/team_web_client_ro.properties");
        var _i18n_translations_team_web_client_ru_properties__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("./src/i18n/translations/team_web_client_ru.properties");
        var _i18n_translations_team_web_client_th_properties__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("./src/i18n/translations/team_web_client_th.properties");
        var _i18n_translations_team_web_client_zh_CN_properties__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("./src/i18n/translations/team_web_client_zh-CN.properties");
        var _i18n_translationsInterop_interop_de_properties__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("./src/i18n/translationsInterop/interop_de.properties");
        var _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("./src/i18n/translationsInterop/interop_en_US.properties");
        var _i18n_translationsInterop_interop_es_properties__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__("./src/i18n/translationsInterop/interop_es.properties");
        var _i18n_translationsInterop_interop_fr_properties__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__("./src/i18n/translationsInterop/interop_fr.properties");
        var _i18n_translationsInterop_interop_hi_properties__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__("./src/i18n/translationsInterop/interop_hi.properties");
        var _i18n_translationsInterop_interop_hr_properties__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__("./src/i18n/translationsInterop/interop_hr.properties");
        var _i18n_translationsInterop_interop_id_properties__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__("./src/i18n/translationsInterop/interop_id.properties");
        var _i18n_translationsInterop_interop_it_properties__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__("./src/i18n/translationsInterop/interop_it.properties");
        var _i18n_translationsInterop_interop_ja_properties__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__("./src/i18n/translationsInterop/interop_ja.properties");
        var _i18n_translationsInterop_interop_nl_properties__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__("./src/i18n/translationsInterop/interop_nl.properties");
        var _i18n_translationsInterop_interop_pt_properties__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__("./src/i18n/translationsInterop/interop_pt.properties");
        var _i18n_translationsInterop_interop_pt_BR_properties__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__("./src/i18n/translationsInterop/interop_pt_BR.properties");
        var _i18n_translationsInterop_interop_ro_properties__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__("./src/i18n/translationsInterop/interop_ro.properties");
        var _i18n_translationsInterop_interop_ru_properties__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__("./src/i18n/translationsInterop/interop_ru.properties");
        var _i18n_translationsInterop_interop_th_properties__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__("./src/i18n/translationsInterop/interop_th.properties");
        var _i18n_translationsInterop_interop_zh_CN_properties__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__("./src/i18n/translationsInterop/interop_zh-CN.properties");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        var allTranslations = {
            en_US: _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"],
            de: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_de_properties__WEBPACK_IMPORTED_MODULE_1__["default"]),
            hi: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_hi_properties__WEBPACK_IMPORTED_MODULE_5__["default"]),
            id: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_id_properties__WEBPACK_IMPORTED_MODULE_7__["default"]),
            it: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_it_properties__WEBPACK_IMPORTED_MODULE_8__["default"]),
            ru: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_ru_properties__WEBPACK_IMPORTED_MODULE_14__["default"]),
            es: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_es_properties__WEBPACK_IMPORTED_MODULE_3__["default"]),
            pt_PT: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_pt_properties__WEBPACK_IMPORTED_MODULE_11__["default"]),
            pt_BR: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_pt_BR_properties__WEBPACK_IMPORTED_MODULE_12__["default"]),
            hr: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_hr_properties__WEBPACK_IMPORTED_MODULE_6__["default"]),
            fr: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_fr_properties__WEBPACK_IMPORTED_MODULE_4__["default"]),
            fr_FR: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_fr_properties__WEBPACK_IMPORTED_MODULE_4__["default"]),
            fr_CA: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_fr_properties__WEBPACK_IMPORTED_MODULE_4__["default"]),
            ja: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_ja_properties__WEBPACK_IMPORTED_MODULE_9__["default"]),
            nl: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_nl_properties__WEBPACK_IMPORTED_MODULE_10__["default"]),
            th: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_th_properties__WEBPACK_IMPORTED_MODULE_15__["default"]),
            zh_CN: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_zh_CN_properties__WEBPACK_IMPORTED_MODULE_16__["default"]),
            ro: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translations_team_web_client_en_US_properties__WEBPACK_IMPORTED_MODULE_2__["default"], _i18n_translations_team_web_client_ro_properties__WEBPACK_IMPORTED_MODULE_13__["default"])
        };
        var interopTranslations = {
            en_US: _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"],
            de: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_de_properties__WEBPACK_IMPORTED_MODULE_17__["default"]),
            hi: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_hi_properties__WEBPACK_IMPORTED_MODULE_21__["default"]),
            id: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_id_properties__WEBPACK_IMPORTED_MODULE_23__["default"]),
            it: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_it_properties__WEBPACK_IMPORTED_MODULE_24__["default"]),
            ru: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_ru_properties__WEBPACK_IMPORTED_MODULE_30__["default"]),
            es: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_es_properties__WEBPACK_IMPORTED_MODULE_19__["default"]),
            pt_PT: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_pt_properties__WEBPACK_IMPORTED_MODULE_27__["default"]),
            pt_BR: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_pt_BR_properties__WEBPACK_IMPORTED_MODULE_28__["default"]),
            hr: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_hr_properties__WEBPACK_IMPORTED_MODULE_22__["default"]),
            fr: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_fr_properties__WEBPACK_IMPORTED_MODULE_20__["default"]),
            fr_FR: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_fr_properties__WEBPACK_IMPORTED_MODULE_20__["default"]),
            fr_CA: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_fr_properties__WEBPACK_IMPORTED_MODULE_20__["default"]),
            ja: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_ja_properties__WEBPACK_IMPORTED_MODULE_25__["default"]),
            nl: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_nl_properties__WEBPACK_IMPORTED_MODULE_26__["default"]),
            th: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_th_properties__WEBPACK_IMPORTED_MODULE_31__["default"]),
            zh_CN: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_zh_CN_properties__WEBPACK_IMPORTED_MODULE_32__["default"]),
            ro: Object(lodash__WEBPACK_IMPORTED_MODULE_0__["merge"])({}, _i18n_translationsInterop_interop_en_US_properties__WEBPACK_IMPORTED_MODULE_18__["default"], _i18n_translationsInterop_interop_ro_properties__WEBPACK_IMPORTED_MODULE_29__["default"])
        };
        var currentLocale;
        var currentTranslation;
        function setLocale(locale) {
            if (locale === void 0) {
                locale = "en_US";
            }
            if (locale === currentLocale) {
                return;
            }
            currentLocale = locale;
            var translation = allTranslations.en_US;
            if (allTranslations.hasOwnProperty(locale)) {
                translation = allTranslations[locale];
            }
            var interopTranslation = interopTranslations.en_US;
            if (interopTranslations.hasOwnProperty(locale)) {
                interopTranslation = interopTranslations[locale];
            }
            if (__TEAM_IS_STANDALONE_APP || __TEAM_IS_CLASSIC_ZIMLET) {
                currentTranslation = _extends({
                    "zextras-team-zimlet": translation
                }, interopTranslation);
            } else {
                currentTranslation = {
                    "zextras-team-zimlet": translation
                };
            }
        }
        function getTranslationByPath(path) {
            var pos = getTranslations();
            var steps = path.split(".");
            while (steps.length > 1) {
                var step = steps.shift();
                if (!pos.hasOwnProperty(step)) pos[step] = {};
                pos = pos[step];
            }
            return pos[steps[0]];
        }
        function getTranslations(locale) {
            if (locale) setLocale(locale);
            return currentTranslation;
        }
    },
    "./src/routing/paths.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "SLUG", (function() {
            return SLUG;
        }));
        __webpack_require__.d(__webpack_exports__, "changeSlug", (function() {
            return changeSlug;
        }));
        __webpack_require__.d(__webpack_exports__, "getPaths", (function() {
            return getPaths;
        }));
        var SLUG = true ? "connect" : undefined;
        function changeSlug(slug) {
            if (slug !== "" && slug !== null) {
                SLUG = slug + "/" + (true ? "connect" : undefined);
            }
            return SLUG;
        }
        function getPaths(slug) {
            var mSlug = slug || SLUG;
            return {
                MAIN: "/" + mSlug + "/conversations",
                CONVERSATION: "/" + mSlug + "/conversation/:conversationId",
                CHANNEL: "/" + mSlug + "/channel/:spaceId/:channelId",
                NEW: {
                    CONVERSATION: "/" + mSlug + "/new/conversation",
                    GROUP: "/" + mSlug + "/new/group",
                    SPACE: "/" + mSlug + "/new/space",
                    CHANNEL: "/" + mSlug + "/new/channel",
                    INSTANTMEETING: "/" + mSlug + "/new/instantMeeting"
                },
                INVITE: {
                    GROUP: "/" + mSlug + "/conversation/:conversationId/invite",
                    SPACE: "/" + mSlug + "/channel/:spaceId/:channelId/invite"
                },
                LOGIN: "/" + mSlug + "/login",
                LOADING: "/" + mSlug + "/loading",
                MEETING: "/" + mSlug + "/meeting/:meetingId"
            };
        }
    }
} ]);
//# sourceMappingURL=8.e83b5a85.chunk.js.map
