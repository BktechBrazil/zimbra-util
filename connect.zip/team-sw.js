var serviceWorkerOption = {"assets":["/zx/zimlet/com_zimbra_connect_classic/48c35af5f4d77d4eb015ad6da7591d1b.css","/zx/zimlet/com_zimbra_connect_classic/e9dbbe8a693dd275c16d32feb101f1c1.woff","/zx/zimlet/com_zimbra_connect_classic/987b84570ea69ee660455b8d5e91f5f1.woff2","/zx/zimlet/com_zimbra_connect_classic/d704bb3d579b7d5e40880c75705c8a71.woff","/zx/zimlet/com_zimbra_connect_classic/6232f43d15b0e7a0bf0fe82e295bdd06.woff2","/zx/zimlet/com_zimbra_connect_classic/a1471d1d6431c893582a5f6a250db3f9.woff","/zx/zimlet/com_zimbra_connect_classic/55536c8e9e9a532651e3cf374f290ea3.woff2","/zx/zimlet/com_zimbra_connect_classic/210a7c781f5a354a0e4985656ab456d9.woff","/zx/zimlet/com_zimbra_connect_classic/d69924b98acd849cdeba9fbff3f88ea6.woff2","/zx/zimlet/com_zimbra_connect_classic/de8b7431b74642e830af4d4f4b513ec9.woff","/zx/zimlet/com_zimbra_connect_classic/285467176f7fe6bb6a9c6873b3dad2cc.woff2","/zx/zimlet/com_zimbra_connect_classic/ffcc050b2d92d4b14a4fcb527ee0bcc8.woff","/zx/zimlet/com_zimbra_connect_classic/510dec37fa69fba39593e01a469ee018.woff2","/zx/zimlet/com_zimbra_connect_classic/cf6613d1adf490972c557a8e318e0868.woff","/zx/zimlet/com_zimbra_connect_classic/037d830416495def72b7881024c14b7b.woff2","/zx/zimlet/com_zimbra_connect_classic/846d1890aee87fde5d8ced8eba360c3a.woff","/zx/zimlet/com_zimbra_connect_classic/010c1aeee3c6d1cbb1d5761d80353823.woff2","/zx/zimlet/com_zimbra_connect_classic/9680d5a0c32d2fd084e07bbc4c8b2923.woff","/zx/zimlet/com_zimbra_connect_classic/d8bcbe724fd6f4ba44d0ee6a2675890f.woff2","/zx/zimlet/com_zimbra_connect_classic/bafb105baeb22d965c70fe52ba6b49d9.woff","/zx/zimlet/com_zimbra_connect_classic/5d4aeb4e5f5ef754e307d7ffaef688bd.woff2","/zx/zimlet/com_zimbra_connect_classic/f9102ba39626ef7e27969b12ade5569c.eot","/zx/zimlet/com_zimbra_connect_classic/5daa009f943fe711e4b8a525df535925.svg","/zx/zimlet/com_zimbra_connect_classic/eba2d3e5d5c79840fdd7c16a6ce2e513.ttf","/zx/zimlet/com_zimbra_connect_classic/e248709f076358529e828489ce375e6c.woff","/zx/zimlet/com_zimbra_connect_classic/33b02754833e36eec2d9e5acb2576c0a.mp3","/zx/zimlet/com_zimbra_connect_classic/cace6a2e68890a66567a12b6d0e07647.mp3","/zx/zimlet/com_zimbra_connect_classic/a070f1a954eda4a57aab73fca6e36eeb.mp3","/zx/zimlet/com_zimbra_connect_classic/8b85122e034a41e419b918529573d50d.mp3","/zx/zimlet/com_zimbra_connect_classic/43fe43c6cd4ad4736c1b36c0e293cb28.svg","/zx/zimlet/com_zimbra_connect_classic/8d61aac8b97f0e9677634952ab269247.ttf","/zx/zimlet/com_zimbra_connect_classic/f86bc9db38f1df5f9ee1e2b30c1c87c0.woff","/zx/zimlet/com_zimbra_connect_classic/579747c7eba0a188620b57f426c643dd.mp3","/zx/zimlet/com_zimbra_connect_classic/78f9d4efd0f85a959a6d3f5ea456f048.ogg","/zx/zimlet/com_zimbra_connect_classic/5315fb7c34709f3ffc6d44619a456c58.svg","/zx/zimlet/com_zimbra_connect_classic/70e72abccc43318dc1c264c915341dfe.svg","/zx/zimlet/com_zimbra_connect_classic/135461607f32a7151ddab8f15f4528ee.svg","/zx/zimlet/com_zimbra_connect_classic/1f852c8ba250ec39b540da52f0d364d2.svg","/zx/zimlet/com_zimbra_connect_classic/ff97453adb5e6d6c48c06e015a4b6053.png","/zx/zimlet/com_zimbra_connect_classic/4315ce7e6c621d3ad086feb84e912dac.svg","/zx/zimlet/com_zimbra_connect_classic/91c1e6d1d002e34a8dbdaf9c2f50b403.svg","/zx/zimlet/com_zimbra_connect_classic/0.f9b7ccdf.chunk.js","/zx/zimlet/com_zimbra_connect_classic/1.3ec4b1db.chunk.js","/zx/zimlet/com_zimbra_connect_classic/2.e35f7715.chunk.js","/zx/zimlet/com_zimbra_connect_classic/3.b35b9c21.chunk.js","/zx/zimlet/com_zimbra_connect_classic/4.02734945.chunk.js","/zx/zimlet/com_zimbra_connect_classic/5.12120e59.chunk.js","/zx/zimlet/com_zimbra_connect_classic/6.0edce394.chunk.js","/zx/zimlet/com_zimbra_connect_classic/7.f9243f8d.chunk.js","/zx/zimlet/com_zimbra_connect_classic/8.e83b5a85.chunk.js","/zx/zimlet/com_zimbra_connect_classic/9.1cbd1730.chunk.js","/zx/zimlet/com_zimbra_connect_classic/10.e193c214.chunk.js","/zx/zimlet/com_zimbra_connect_classic/11.5efb4a92.chunk.js","/zx/zimlet/com_zimbra_connect_classic/12.bac8b54d.chunk.js","/zx/zimlet/com_zimbra_connect_classic/com_zimbra_connect_classic.js","/zx/zimlet/com_zimbra_connect_classic/external_app.js","/zx/zimlet/com_zimbra_connect_classic/index.html","/zx/zimlet/com_zimbra_connect_classic/invite_ext_meeting.template.html","/zx/zimlet/com_zimbra_connect_classic/invite_ext_meeting.template.txt","/zx/zimlet/com_zimbra_connect_classic/invite_to_space.template.html","/zx/zimlet/com_zimbra_connect_classic/invite_to_space.template.txt","/zx/zimlet/com_zimbra_connect_classic/kick_from_space.template.html","/zx/zimlet/com_zimbra_connect_classic/kick_from_space.template.txt"]};
        
        (function(modules) {
    var installedModules = {};
    function __webpack_require__(moduleId) {
        if (installedModules[moduleId]) {
            return installedModules[moduleId].exports;
        }
        var module = installedModules[moduleId] = {
            i: moduleId,
            l: false,
            exports: {}
        };
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        module.l = true;
        return module.exports;
    }
    __webpack_require__.m = modules;
    __webpack_require__.c = installedModules;
    __webpack_require__.d = function(exports, name, getter) {
        if (!__webpack_require__.o(exports, name)) {
            Object.defineProperty(exports, name, {
                enumerable: true,
                get: getter
            });
        }
    };
    __webpack_require__.r = function(exports) {
        if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
            Object.defineProperty(exports, Symbol.toStringTag, {
                value: "Module"
            });
        }
        Object.defineProperty(exports, "__esModule", {
            value: true
        });
    };
    __webpack_require__.t = function(value, mode) {
        if (mode & 1) value = __webpack_require__(value);
        if (mode & 8) return value;
        if (mode & 4 && typeof value === "object" && value && value.__esModule) return value;
        var ns = Object.create(null);
        __webpack_require__.r(ns);
        Object.defineProperty(ns, "default", {
            enumerable: true,
            value: value
        });
        if (mode & 2 && typeof value != "string") for (var key in value) __webpack_require__.d(ns, key, function(key) {
            return value[key];
        }.bind(null, key));
        return ns;
    };
    __webpack_require__.n = function(module) {
        var getter = module && module.__esModule ? function getDefault() {
            return module["default"];
        } : function getModuleExports() {
            return module;
        };
        __webpack_require__.d(getter, "a", getter);
        return getter;
    };
    __webpack_require__.o = function(object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    __webpack_require__.p = "/zx/zimlet/com_zimbra_connect_classic/";
    return __webpack_require__(__webpack_require__.s = "./src/sw/service-worker.js");
})({
    "./src/routing/paths.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "SLUG", (function() {
            return SLUG;
        }));
        __webpack_require__.d(__webpack_exports__, "changeSlug", (function() {
            return changeSlug;
        }));
        __webpack_require__.d(__webpack_exports__, "getPaths", (function() {
            return getPaths;
        }));
        var SLUG = true ? "connect" : undefined;
        function changeSlug(slug) {
            if (slug !== "" && slug !== null) {
                SLUG = slug + "/" + (true ? "connect" : undefined);
            }
            return SLUG;
        }
        function getPaths(slug) {
            var mSlug = slug || SLUG;
            return {
                MAIN: "/" + mSlug + "/conversations",
                CONVERSATION: "/" + mSlug + "/conversation/:conversationId",
                CHANNEL: "/" + mSlug + "/channel/:spaceId/:channelId",
                NEW: {
                    CONVERSATION: "/" + mSlug + "/new/conversation",
                    GROUP: "/" + mSlug + "/new/group",
                    SPACE: "/" + mSlug + "/new/space",
                    CHANNEL: "/" + mSlug + "/new/channel",
                    INSTANTMEETING: "/" + mSlug + "/new/instantMeeting"
                },
                INVITE: {
                    GROUP: "/" + mSlug + "/conversation/:conversationId/invite",
                    SPACE: "/" + mSlug + "/channel/:spaceId/:channelId/invite"
                },
                LOGIN: "/" + mSlug + "/login",
                LOADING: "/" + mSlug + "/loading",
                MEETING: "/" + mSlug + "/meeting/:meetingId"
            };
        }
    },
    "./src/sw/service-worker.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        var _routing_paths__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/routing/paths.js");
        var OPEN_CONVERSATION_REGEX = /^open::conversation::(.*)/;
        self.addEventListener("install", (function(event) {}));
        self.addEventListener("notificationclick", (function(event) {
            if (event.action === "" || OPEN_CONVERSATION_REGEX.test(event.action)) {
                var conversationId = event.action === "" ? event.notification.data.conversation_id : OPEN_CONVERSATION_REGEX.exec(event.action)[1];
                var path = (__TEAM_USE_HASH_HISTORY ? "/#/" + _routing_paths__WEBPACK_IMPORTED_MODULE_0__["SLUG"] : _routing_paths__WEBPACK_IMPORTED_MODULE_0__["SLUG"]) + "/conversation/" + conversationId;
                var promiseChain = clients.matchAll({
                    includeUncontrolled: true,
                    type: "window"
                }).then((function(allClients) {
                    if (allClients.length < 1) {
                        return clients.openWindow(path);
                    }
                    return allClients[0].focus();
                }));
                event.waitUntil(promiseChain);
            }
        }));
    }
});
//# sourceMappingURL=team-sw.js.map