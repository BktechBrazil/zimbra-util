(function(modules) {
    function webpackJsonpCallback(data) {
        var chunkIds = data[0];
        var moreModules = data[1];
        var moduleId, chunkId, i = 0, resolves = [];
        for (;i < chunkIds.length; i++) {
            chunkId = chunkIds[i];
            if (Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
                resolves.push(installedChunks[chunkId][0]);
            }
            installedChunks[chunkId] = 0;
        }
        for (moduleId in moreModules) {
            if (Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
                modules[moduleId] = moreModules[moduleId];
            }
        }
        if (parentJsonpFunction) parentJsonpFunction(data);
        while (resolves.length) {
            resolves.shift()();
        }
    }
    var installedModules = {};
    var installedChunks = {
        com_zimbra_connect_classic: 0
    };
    function jsonpScriptSrc(chunkId) {
        return __webpack_require__.p + "" + ({}[chunkId] || chunkId) + "." + {
            0: "f9b7ccdf",
            1: "3ec4b1db",
            2: "e35f7715",
            3: "b35b9c21",
            4: "02734945",
            5: "12120e59",
            6: "0edce394",
            7: "f9243f8d",
            8: "e83b5a85",
            9: "1cbd1730",
            10: "e193c214",
            11: "5efb4a92"
        }[chunkId] + ".chunk.js";
    }
    function __webpack_require__(moduleId) {
        if (installedModules[moduleId]) {
            return installedModules[moduleId].exports;
        }
        var module = installedModules[moduleId] = {
            i: moduleId,
            l: false,
            exports: {}
        };
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        module.l = true;
        return module.exports;
    }
    __webpack_require__.e = function requireEnsure(chunkId) {
        var promises = [];
        var installedChunkData = installedChunks[chunkId];
        if (installedChunkData !== 0) {
            if (installedChunkData) {
                promises.push(installedChunkData[2]);
            } else {
                var promise = new Promise((function(resolve, reject) {
                    installedChunkData = installedChunks[chunkId] = [ resolve, reject ];
                }));
                promises.push(installedChunkData[2] = promise);
                var script = document.createElement("script");
                var onScriptComplete;
                script.charset = "utf-8";
                script.timeout = 120;
                if (__webpack_require__.nc) {
                    script.setAttribute("nonce", __webpack_require__.nc);
                }
                script.src = jsonpScriptSrc(chunkId);
                var error = new Error;
                onScriptComplete = function(event) {
                    script.onerror = script.onload = null;
                    clearTimeout(timeout);
                    var chunk = installedChunks[chunkId];
                    if (chunk !== 0) {
                        if (chunk) {
                            var errorType = event && (event.type === "load" ? "missing" : event.type);
                            var realSrc = event && event.target && event.target.src;
                            error.message = "Loading chunk " + chunkId + " failed.\n(" + errorType + ": " + realSrc + ")";
                            error.name = "ChunkLoadError";
                            error.type = errorType;
                            error.request = realSrc;
                            chunk[1](error);
                        }
                        installedChunks[chunkId] = undefined;
                    }
                };
                var timeout = setTimeout((function() {
                    onScriptComplete({
                        type: "timeout",
                        target: script
                    });
                }), 12e4);
                script.onerror = script.onload = onScriptComplete;
                document.head.appendChild(script);
            }
        }
        return Promise.all(promises);
    };
    __webpack_require__.m = modules;
    __webpack_require__.c = installedModules;
    __webpack_require__.d = function(exports, name, getter) {
        if (!__webpack_require__.o(exports, name)) {
            Object.defineProperty(exports, name, {
                enumerable: true,
                get: getter
            });
        }
    };
    __webpack_require__.r = function(exports) {
        if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
            Object.defineProperty(exports, Symbol.toStringTag, {
                value: "Module"
            });
        }
        Object.defineProperty(exports, "__esModule", {
            value: true
        });
    };
    __webpack_require__.t = function(value, mode) {
        if (mode & 1) value = __webpack_require__(value);
        if (mode & 8) return value;
        if (mode & 4 && typeof value === "object" && value && value.__esModule) return value;
        var ns = Object.create(null);
        __webpack_require__.r(ns);
        Object.defineProperty(ns, "default", {
            enumerable: true,
            value: value
        });
        if (mode & 2 && typeof value != "string") for (var key in value) __webpack_require__.d(ns, key, function(key) {
            return value[key];
        }.bind(null, key));
        return ns;
    };
    __webpack_require__.n = function(module) {
        var getter = module && module.__esModule ? function getDefault() {
            return module["default"];
        } : function getModuleExports() {
            return module;
        };
        __webpack_require__.d(getter, "a", getter);
        return getter;
    };
    __webpack_require__.o = function(object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
    };
    __webpack_require__.p = "/zx/zimlet/com_zimbra_connect_classic/";
    __webpack_require__.oe = function(err) {
        console.error(err);
        throw err;
    };
    var jsonpArray = window["com_zimbra_connect_classic_jsonp"] = window["com_zimbra_connect_classic_jsonp"] || [];
    var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
    jsonpArray.push = webpackJsonpCallback;
    jsonpArray = jsonpArray.slice();
    for (var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
    var parentJsonpFunction = oldJsonpFunction;
    return __webpack_require__(__webpack_require__.s = "./src/classic/index.js");
})({
    "./src/classic/index.js": function(module, exports, __webpack_require__) {
        window.__TEAM_IS_CLASSIC_ZIMLET = true;
        window.__TEAM_USE_HASH_HISTORY = false;
        window.__TEAM_IS_STANDALONE_APP = false;
        window.__TEAM_IS_EXTERNAL_APP = false;
        function ZimletClassic() {}
        ZimletClassic.prototype = new ZmZimletBase;
        ZimletClassic.prototype.constructor = ZimletClassic;
        ZimletClassic.prototype._showHideSidebar = void 0;
        ZimletClassic.prototype.init = function() {
            var _this = this;
            if (typeof Promise === "undefined") {
                return;
            }
            Promise.all([ __webpack_require__.e(1).then(__webpack_require__.bind(null, "./node_modules/rxjs/_esm5/index.js")), Promise.all([ __webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(7), __webpack_require__.e(6), __webpack_require__.e(8), __webpack_require__.e(11) ]).then(__webpack_require__.bind(null, "./src/interop/zimbraClassic/index.js")), Promise.all([ __webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(7), __webpack_require__.e(9), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(8), __webpack_require__.e(10) ]).then(__webpack_require__.bind(null, "./src/index.js")) ]).then((function(_ref) {
                var rxjsModule = _ref[0], ZimletClassicInteropModule = _ref[1], ZimletModule = _ref[2];
                var BehaviorSubject = rxjsModule["BehaviorSubject"];
                var createStore = ZimletClassicInteropModule["createStore"];
                var createMenuHandler = ZimletClassicInteropModule["createMenuHandler"];
                var createAppRouter = ZimletClassicInteropModule["createAppRouter"];
                _this._showHideSidebar = ZimletClassicInteropModule["showHideSidebar"];
                var createContext = ZimletClassicInteropModule["default"];
                ZimletClassicInteropModule["applyZimbraHacks"]();
                var Zimlet = ZimletModule["default"];
                _this._isTabShown = new BehaviorSubject(false);
                try {
                    var store = createStore();
                    var _createMenuHandler = createMenuHandler(store, _this), registerMenuSlot = _createMenuHandler.registerMenuSlot, addTab = _createMenuHandler.addTab, removeTab = _createMenuHandler.removeTab;
                    var _createAppRouter = createAppRouter(store, addTab, removeTab), addRoutesToApp = _createAppRouter.addRoutesToApp, DwtTeamRouter = _createAppRouter.DwtTeamRouter;
                    _this._DwtTeamRouter = DwtTeamRouter;
                    var context = createContext(store, registerMenuSlot, addRoutesToApp);
                    var zimlet = new Zimlet(context);
                    zimlet.init();
                    _this.tryToShowHideSidebar(true);
                } catch (err) {
                    console.error(err);
                }
            }));
        };
        ZimletClassic.prototype.appLaunch = function(appName) {
            appCtxt.getCurrentApp().getController().getView().setView(new this._DwtTeamRouter({
                parent: appCtxt.getShell(),
                tabShown: this._isTabShown
            }));
        };
        ZimletClassic.prototype.tryToShowHideSidebar = function(show) {
            if (this._showHideSidebar) {
                this._showHideSidebar(show);
            }
        };
        ZimletClassic.prototype.appActive = function(appName, active) {
            if (active) {
                Dwt.setTitle(ZmMsg.zimbraTitle + ": " + (true ? "Connect" : undefined));
            }
            this.tryToShowHideSidebar(!active);
        };
        ZimletClassic.prototype.onShowView = function(view) {
            var isMainView = view.startsWith("com_zimbra_connect_classic");
            if (this._isTabShown) {
                this._isTabShown.next(isMainView);
            }
            if (isMainView) {
                appCtxt.getAppViewMgr().displayComponent(ZmAppViewMgr.C_TREE, false, true);
                appCtxt.getAppViewMgr().displayComponent(ZmAppViewMgr.C_TREE_FOOTER, false, true);
                appCtxt.getAppViewMgr().displayComponent(ZmAppViewMgr.C_TOOLBAR_TOP, false, true);
                appCtxt.getAppViewMgr().displayComponent(ZmAppViewMgr.C_NEW_BUTTON, false, true);
                var controller = appCtxt.getAppController();
                var appChooser = controller.getAppChooser();
                var appButton = appChooser.getButton(view);
                appButton.delClassName("ZAlert");
            }
        };
        window["com_zimbra_connect_classic" + "_hdlr"] = ZimletClassic;
    }
});
//# sourceMappingURL=com_zimbra_connect_classic.js.map