(window["com_zimbra_connect_classic_jsonp"] = window["com_zimbra_connect_classic_jsonp"] || []).push([ [ 12 ], {
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/standalone/style.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        var getUrl = __webpack_require__("./node_modules/css-loader/dist/runtime/getUrl.js");
        var ___CSS_LOADER_URL___0___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.eot"));
        var ___CSS_LOADER_URL___1___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.ttf"));
        var ___CSS_LOADER_URL___2___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.woff"));
        var ___CSS_LOADER_URL___3___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.svg"));
        var ___CSS_LOADER_URL___4___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100.woff2"));
        var ___CSS_LOADER_URL___5___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100.woff"));
        var ___CSS_LOADER_URL___6___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100italic.woff2"));
        var ___CSS_LOADER_URL___7___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100italic.woff"));
        var ___CSS_LOADER_URL___8___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300.woff2"));
        var ___CSS_LOADER_URL___9___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300.woff"));
        var ___CSS_LOADER_URL___10___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300italic.woff2"));
        var ___CSS_LOADER_URL___11___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300italic.woff"));
        var ___CSS_LOADER_URL___12___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-regular.woff2"));
        var ___CSS_LOADER_URL___13___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-regular.woff"));
        var ___CSS_LOADER_URL___14___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-italic.woff2"));
        var ___CSS_LOADER_URL___15___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-italic.woff"));
        var ___CSS_LOADER_URL___16___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500.woff2"));
        var ___CSS_LOADER_URL___17___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500.woff"));
        var ___CSS_LOADER_URL___18___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500italic.woff2"));
        var ___CSS_LOADER_URL___19___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500italic.woff"));
        var ___CSS_LOADER_URL___20___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700.woff2"));
        var ___CSS_LOADER_URL___21___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700.woff"));
        var ___CSS_LOADER_URL___22___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700italic.woff2"));
        var ___CSS_LOADER_URL___23___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700italic.woff"));
        exports.push([ module.i, "@font-face{\n  font-family:'zimbra-icons';\n  src:url(" + ___CSS_LOADER_URL___0___ + ");\n  src:url(" + ___CSS_LOADER_URL___0___ + ") format('embedded-opentype'), url(" + ___CSS_LOADER_URL___1___ + ") format('truetype'), url(" + ___CSS_LOADER_URL___2___ + ") format('woff'), url(" + ___CSS_LOADER_URL___3___ + ') format(\'svg\');\n  font-weight:normal;\n  font-style:normal;\n}\n.zimbra-icon{\n  font-family:\'zimbra-icons\' !important;\n  speak:none;\n  font-style:normal;\n  font-weight:normal;\n  -webkit-font-feature-settings:normal;\n          font-feature-settings:normal;\n  font-variant:normal;\n  text-transform:none;\n  line-height:1;\n  vertical-align:middle;\n  -webkit-font-smoothing:antialiased;\n  -moz-osx-font-smoothing:grayscale;\n}\n.zimbra-icon:before{\n  content:\'      �\';\n}\n.zimbra-icon-add-event:before{\n  content:"\\e900";\n}\n.zimbra-icon-folder-add:before{\n  content:"\\e901";\n}\n.zimbra-icon-add-note:before{\n  content:"\\e902";\n}\n.zimbra-icon-plus:before{\n  content:"\\e903";\n}\n.zimbra-icon-archive:before{\n  content:"\\e904";\n}\n.zimbra-icon-caret-down:before{\n  content:"\\e905";\n}\n.zimbra-icon-user-o:before{\n  content:"\\e906";\n}\n.zimbra-icon-user:before{\n  content:"\\e907";\n}\n.zimbra-icon-bold:before{\n  content:"\\e908";\n}\n.zimbra-icon-list-ul:before{\n  content:"\\e909";\n}\n.zimbra-icon-calendar-alt-o:before{\n  content:"\\e90a";\n}\n.zimbra-icon-calendar-o:before{\n  content:"\\e90b";\n}\n.zimbra-icon-align-center:before{\n  content:"\\e90c";\n}\n.zimbra-icon-chat:before{\n  content:"\\e90d";\n}\n.zimbra-icon-check-square:before{\n  content:"\\e90e";\n}\n.zimbra-icon-square-o:before{\n  content:"\\e90f";\n}\n.zimbra-icon-check:before{\n  content:"\\e910";\n}\n.zimbra-icon-close-circle:before{\n  content:"\\e911";\n}\n.zimbra-icon-close:before{\n  content:"\\e912";\n}\n.zimbra-icon-collapse-items:before{\n  content:"\\e913";\n}\n.zimbra-icon-angle-double-left:before{\n  content:"\\e914";\n}\n.zimbra-icon-pencil:before{\n  content:"\\e915";\n}\n.zimbra-icon-address-book:before{\n  content:"\\e916";\n}\n.zimbra-icon-arrows-alt-inverse:before{\n  content:"\\e917";\n}\n.zimbra-icon-file-word-o:before{\n  content:"\\e918";\n}\n.zimbra-icon-chevron-right:before{\n  content:"\\e919";\n}\n.zimbra-icon-download:before{\n  content:"\\e91a";\n}\n.zimbra-icon-angle-right:before{\n  content:"\\e91b";\n}\n.zimbra-icon-smile-o:before{\n  content:"\\e91c";\n}\n.zimbra-icon-expand-items:before{\n  content:"\\e91d";\n}\n.zimbra-icon-angle-double-right:before{\n  content:"\\e91e";\n}\n.zimbra-icon-facebook-official:before{\n  content:"\\e91f";\n}\n.zimbra-icon-mail-forward:before{\n  content:"\\e920";\n}\n.zimbra-icon-expand:before{\n  content:"\\e921";\n}\n.zimbra-icon-GIF:before{\n  content:"\\e922";\n}\n.zimbra-icon-grid:before{\n  content:"\\e923";\n}\n.zimbra-icon-question-circle:before{\n  content:"\\e924";\n}\n.zimbra-icon-home:before{\n  content:"\\e925";\n}\n.zimbra-icon-image:before{\n  content:"\\e926";\n}\n.zimbra-icon-arrows-alt:before{\n  content:"\\e927";\n}\n.zimbra-icon-indent:before{\n  content:"\\e928";\n}\n.zimbra-icon-italic:before{\n  content:"\\e929";\n}\n.zimbra-icon-align-left:before{\n  content:"\\e92a";\n}\n.zimbra-icon-link:before{\n  content:"\\e92b";\n}\n.zimbra-icon-mobile-phone:before{\n  content:"\\e92c";\n}\n.zimbra-icon-ellipsis-h:before{\n  content:"\\e92d";\n}\n.zimbra-icon-folder-move:before{\n  content:"\\e92e";\n}\n.zimbra-icon-angle-left:before{\n  content:"\\e92f";\n}\n.zimbra-icon-angle-down:before{\n  content:"\\e930";\n}\n.zimbra-icon-book:before{\n  content:"\\e931";\n}\n.zimbra-icon-list-ol:before{\n  content:"\\e932";\n}\n.zimbra-icon-external-link:before{\n  content:"\\e933";\n}\n.zimbra-icon-outdent:before{\n  content:"\\e934";\n}\n.zimbra-icon-file-pdf-o:before{\n  content:"\\e935";\n}\n.zimbra-icon-multimedia-active:before{\n  content:"\\e936";\n}\n.zimbra-icon-multimedia:before{\n  content:"\\e937";\n}\n.zimbra-icon-file-powerpoint-o:before{\n  content:"\\e938";\n}\n.zimbra-icon-print:before{\n  content:"\\e939";\n}\n.zimbra-icon-radio:before{\n  content:"\\e93a";\n}\n.zimbra-icon-radio-active:before{\n  content:"\\e93b";\n}\n.zimbra-icon-mail-reply-all:before{\n  content:"\\e93c";\n}\n.zimbra-icon-mail-reply:before{\n  content:"\\e93d";\n}\n.zimbra-icon-align-right:before{\n  content:"\\e93e";\n}\n.zimbra-icon-search:before{\n  content:"\\e93f";\n}\n.zimbra-icon-cog:before{\n  content:"\\e940";\n}\n.zimbra-icon-music:before{\n  content:"\\e941";\n}\n.zimbra-icon-shield:before{\n  content:"\\e942";\n}\n.zimbra-icon-star:before{\n  content:"\\e943";\n}\n.zimbra-icon-alarm:before{\n  content:"\\e944";\n}\n.zimbra-icon-arrow-left:before{\n  content:"\\e945";\n}\n.zimbra-icon-address-book-sync:before{\n  content:"\\e946";\n}\n.zimbra-icon-adn:before{\n  content:"\\e947";\n}\n.zimbra-icon-font:before{\n  content:"\\e948";\n}\n.zimbra-icon-trash:before{\n  content:"\\e949";\n}\n.zimbra-icon-twitter:before{\n  content:"\\e94a";\n}\n.zimbra-icon-underline:before{\n  content:"\\e94b";\n}\n.zimbra-icon-arrow-down:before{\n  content:"\\e94c";\n}\n.zimbra-icon-users:before{\n  content:"\\e94d";\n}\n.zimbra-icon-play-circle-o:before{\n  content:"\\e94e";\n}\n.zimbra-icon-file-excel-o:before{\n  content:"\\e94f";\n}\n.zimbra-icon-file-archive-o:before{\n  content:"\\e950";\n}\n.zimbra-icon-clock:before{\n  content:"\\e951";\n}\n.zimbra-icon-check-circle:before{\n  content:"\\e952";\n}\n.zimbra-icon-minus:before{\n  content:"\\e953";\n}\n.zimbra-icon-camera:before{\n  content:"\\e954";\n}\n.zimbra-icon-minus-square:before{\n  content:"\\e955";\n}\n.zimbra-icon-paperclip:before{\n  content:"\\e956";\n}\n.zimbra-icon-arrow-up:before{\n  content:"\\e957";\n}\n.zimbra-icon-bell:before{\n  content:"\\e958";\n}\n.zimbra-icon-calendar-range:before{\n  content:"\\e959";\n}\n.zimbra-icon-trash-forever:before{\n  content:"\\e95a";\n}\n.zimbra-icon-user-circle-o:before{\n  content:"\\e95b";\n}\n.zimbra-icon-add-contact:before{\n  content:"\\e95c";\n}\n.zimbra-icon-envelope:before{\n  content:"\\e95d";\n}\n.zimbra-icon-add-circle:before{\n  content:"\\e95e";\n}\n.zimbra-icon-text-options:before{\n  content:"\\e95f";\n}\n.zimbra-icon-assign-list:before{\n  content:"\\e960";\n}\n.zimbra-icon-bars:before{\n  content:"\\e961";\n}\n.zimbra-icon-restore:before{\n  content:"\\e962";\n}\n.zimbra-icon-remove-list:before{\n  content:"\\e963";\n}\n.zimbra-icon-lock:before{\n  content:"\\e964";\n}\n.zimbra-icon-repeat:before{\n  content:"\\e965";\n}\n.zimbra-icon-refresh:before{\n  content:"\\e966";\n}\n.zimbra-icon-chevron-left:before{\n  content:"\\e967";\n}\n.zimbra-icon-bell-slash:before{\n  content:"\\e968";\n}\n.zimbra-icon-warning:before{\n  content:"\\e969";\n}\n.zimbra-icon-encrypted:before{\n  content:"\\e96a";\n}\n.zimbra-icon-search-plus:before{\n  content:"\\e96b";\n}\n.zimbra-icon-search-minus:before{\n  content:"\\e96c";\n}\n.zimbra-icon-rotate_right:before{\n  content:"\\e96d";\n}\n.zimbra-icon-rotate_left:before{\n  content:"\\e96e";\n}\n.zimbra-icon-not-signed:before{\n  content:"\\e96f";\n}\n.zimbra-icon-signed:before{\n  content:"\\e970";\n}\n.zimbra-icon-cloud:before{\n  content:"\\e971";\n}\n.zimbra-icon-videocam:before{\n  content:"\\e972";\n}\n.zimbra-icon-location:before{\n  content:"\\e973";\n}\n.zimbra-icon-verified:before{\n  content:"\\e974";\n}\n.zimbra-icon-not-verified:before{\n  content:"\\e975";\n}\n.zimbra-icon-outline-user-circle-o:before{\n  content:"\\e976";\n}\n.zimbra-icon-web:before{\n  content:"\\e977";\n}\n.zimbra-icon-code:before{\n  content:"\\e978";\n}\n.zimbra-icon-check-square-o:before{\n  content:"\\e979";\n}\n@font-face{\n  font-family:\'Roboto\';\n  font-style:normal;\n  font-weight:100;\n  src:local(\'Roboto Thin\'), local(\'Roboto-Thin\'), url(' + ___CSS_LOADER_URL___4___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___5___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:italic;\n  font-weight:100;\n  src:local('Roboto Thin Italic'), local('Roboto-ThinItalic'), url(" + ___CSS_LOADER_URL___6___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___7___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:normal;\n  font-weight:300;\n  src:local('Roboto Light'), local('Roboto-Light'), url(" + ___CSS_LOADER_URL___8___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___9___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:italic;\n  font-weight:300;\n  src:local('Roboto Light Italic'), local('Roboto-LightItalic'), url(" + ___CSS_LOADER_URL___10___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___11___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:normal;\n  font-weight:400;\n  src:local('Roboto'), local('Roboto-Regular'), url(" + ___CSS_LOADER_URL___12___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___13___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:italic;\n  font-weight:400;\n  src:local('Roboto Italic'), local('Roboto-Italic'), url(" + ___CSS_LOADER_URL___14___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___15___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:normal;\n  font-weight:500;\n  src:local('Roboto Medium'), local('Roboto-Medium'), url(" + ___CSS_LOADER_URL___16___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___17___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:italic;\n  font-weight:500;\n  src:local('Roboto Medium Italic'), local('Roboto-MediumItalic'), url(" + ___CSS_LOADER_URL___18___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___19___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:normal;\n  font-weight:700;\n  src:local('Roboto Bold'), local('Roboto-Bold'), url(" + ___CSS_LOADER_URL___20___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___21___ + ") format('woff');\n}\n@font-face{\n  font-family:'Roboto';\n  font-style:italic;\n  font-weight:700;\n  src:local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(" + ___CSS_LOADER_URL___22___ + ") format('woff2'), url(" + ___CSS_LOADER_URL___23___ + ') format(\'woff\');\n}\n@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n:root{\n  --toolbar-height:49px;\n  --checkbox-size:42px;\n  --mobile-toolbar-height:57px;\n  --external-header-height:24px;\n  --search-header-height:72px;\n  --sidebar-width:192px;\n  --rightbar-width:192px;\n  --login-background-color:#0088c1;\n  --login-inner-background-color:#fff;\n  --gray-base:#000;\n  --gray-darkest:#262626;\n  --gray-darker:#4d4d4d;\n  --gray-dark:#666666;\n  --gray:#777777;\n  --gray-light:#999999;\n  --gray-lighter:#d9d9d9;\n  --gray-lightest:#f2f2f2;\n  --gray-placeholder:#999999;\n  --warm-gray:#999999;\n  --off-white:#fafafa;\n  --gold:#ffb81c;\n  --gold-lighter:#ffc84f;\n  --translucent-white:rgba(255, 255, 255, .7);\n  --brand-primary:#0088c1;\n  --brand-secondary:#f15b24;\n  --brand-tertiary:#0568ae;\n  --brand-quarternary:#74d6ff;\n  --brand-success:#007a3e;\n  --brand-info:#5bc0de;\n  --brand-warning:#ffb81c;\n  --brand-danger:#cf2a2a;\n  --branding-font-family:"Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-regular:"Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-medium:"Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-bold:"Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-medium-italic:"Roboto", Helvetica, Arial, sans-serif;\n  --color-light-positive:#00bd02;\n  --color-light-negative:#ff1f1f;\n  --body-bg:#fff;\n  --text-color:#4d4d4d;\n  --dialog-title-fg:black;\n  --background-gray:#f2f2f2;\n  --link-color:#0568ae;\n  --link-hover-color:#033c64;\n  --link-hover-decoration:underline;\n  --item-hover-bg:#ffffff;\n  --item-selected-bg:rgba(193, 237, 255, .5);\n  --border-color-primary:#d9d9d9;\n  --hr-border:#f2f2f2;\n  --placeholder-color:#999999;\n  --app-menu-active-color:#f2f2f2;\n  --list-active-bg:rgba(0, 136, 193, .15);\n  --list-hover-bg:rgba(0, 136, 193, .08);\n  --sidebar-bg-color:#f2f2f2;\n  --sidebar-header-bg-color:#f2f2f2;\n  --sidebar-primary-button-color:#0088c1;\n  --sidebar-shaded-color:#d9d9d9;\n  --rightbar-bg-color:#f2f2f2;\n  --read-pane-toolbar-color:#f2f2f2;\n  --read-pane-bg-color:#f2f2f2;\n  --border-color:#d9d9d9;\n  --favorite-indicator-active:#ffb81c;\n  --favorite-indicator-inactive:#777777;\n  --favorite-indicator-hover:#ffc84f;\n  --favorite-indicator-disabled:#d9d9d9;\n  --trash-indicator:#777777;\n  --trash-indicator-hover:#0568ae;\n  --file-type-doc:#0f73ff;\n  --file-type-ppt:#ff9937;\n  --file-type-pdf:#ff4c4e;\n  --file-type-xls:#0e9d58;\n  --file-type-zip:#ada293;\n  --file-type-default:#949cae;\n  --file-type-media:#BC0E67;\n  --file-type-code:#00B4CA;\n  --toast-success-color:#00d171;\n  --toast-failure-color:#cf2a2a;\n  --font-family-sans-serif:"Roboto", Helvetica, Arial, sans-serif;\n  --font-family-serif:Georgia, "Times New Roman", Times, serif;\n  --font-family-monospace:Menlo, Monaco, Consolas, "Courier New", monospace;\n  --font-family-base:"Roboto", Helvetica, Arial, sans-serif;\n  --font-brand-primary:inherit;\n  --font-family-primary:inherit;\n  --font-family-secondary:inherit;\n  --font-size-base:14px;\n  --font-size-med:16px;\n  --font-size-large:18px;\n  --font-size-small:12px;\n  --font-size-h1:36px;\n  --font-size-h2:30px;\n  --font-size-h3:24px;\n  --font-size-h4:18px;\n  --font-size-h5:14px;\n  --font-size-h6:12px;\n  --line-height-base:1.42857143;\n  --line-height-computed:20px;\n  --headings-font-family:inherit;\n  --headings-font-weight:300;\n  --headings-line-height:1.1;\n  --headings-color:inherit;\n  --headings-small-color:#999999;\n  --icon-size-xs:12px;\n  --icon-size-sm:16px;\n  --icon-size-md:24px;\n  --icon-size-lg:32px;\n  --logo-height:32px;\n  --logo-max-width:200px;\n  --spacing-xs:4px;\n  --spacing-sm:8px;\n  --spacing-md:16px;\n  --spacing-lg:24px;\n  --spacing-xl:32px;\n  --screen-xs:480px;\n  --screen-phone:480px;\n  --screen-sm:769px;\n  --screen-tablet:769px;\n  --screen-md:1025px;\n  --screen-desktop:1025px;\n  --screen-lg:1300px;\n  --screen-lg-desktop:1300px;\n  --screen-xs-max:768px;\n  --screen-sm-max:1024px;\n  --screen-md-max:1299px;\n}\nbody{\n  -webkit-print-color-adjust:exact;\n  height:auto;\n  overflow:visible;\n  position:static;\n  position:initial;\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n}\nhtml,\nbody{\n  position:absolute;\n  left:0;\n  top:0;\n  width:100%;\n  height:100%;\n  background-color:#fff;\n  font:14px/1.42857143 "Roboto", Helvetica, Arial, sans-serif;\n  color:#4d4d4d;\n  overflow:hidden;\n  -webkit-tap-highlight-color:rgba(0, 0, 0, 0);\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app{\n  position:absolute;\n  left:0;\n  top:0;\n  width:100%;\n  height:100%;\n  font-size:13px;\n  contain:strict;\n  overflow:hidden;\n}\n*,\n*:before,\n*:after{\n  -webkit-box-sizing:border-box;\n  box-sizing:border-box;\n}\ninput[type="text"]:invalid,\ninput[type="email"]:invalid{\n  -webkit-box-shadow:none;\n  box-shadow:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-icon{\n  font-family:\'zimbra-icons\' !important;\n  speak:none;\n  font-style:normal;\n  font-weight:normal;\n  -webkit-font-feature-settings:normal;\n  font-feature-settings:normal;\n  font-variant:normal;\n  text-transform:none;\n  line-height:1;\n  vertical-align:middle;\n  -webkit-font-smoothing:antialiased;\n  -moz-osx-font-smoothing:grayscale;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header.\\[1\\]_\\[2\\]_zimbra-client_header_headerSearch{\n  -webkit-box-pack:initial;\n  -webkit-justify-content:initial;\n  -ms-flex-pack:initial;\n  justify-content:initial;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header{\n  display:none;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n  -ms-flex-align:center;\n  align-items:center;\n  width:100%;\n  min-width:1024px;\n  height:72px;\n  background-color:#f2f2f2;\n  color:#4d4d4d;\n  white-space:nowrap;\n  position:relative;\n  padding:0 16px;\n  z-index:1;\n  -webkit-box-shadow:0 2px 4px rgba(0, 0, 0, .2);\n  box-shadow:0 2px 4px rgba(0, 0, 0, .2);\n  -webkit-box-pack:justify;\n  -webkit-justify-content:space-between;\n  -ms-flex-pack:justify;\n  justify-content:space-between;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header_primaryLogo{\n  text-align:left;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header_primaryLogoInner{\n  width:200px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_client-logo_logo{\n  display:inline-block;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_search_headerSearch{\n  height:auto;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_search_searchContainer{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-flex:1;\n  -webkit-flex:1;\n  -ms-flex:1;\n  flex:1;\n  -webkit-box-pack:end;\n  -webkit-justify-content:flex-end;\n  -ms-flex-pack:end;\n  justify-content:flex-end;\n  height:100%;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n  -ms-flex-align:center;\n  align-items:center;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActions{\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  white-space:nowrap;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n  -ms-flex-align:center;\n  align-items:center;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_appMenu{\n  width:100%;\n  background-color:white;\n  overflow:visible;\n  border-bottom:solid 1px #d9d9d9;\n  position:relative;\n}\n.\\[1\\]_\\[2\\]_blocks_popover_popover-container{\n  display:inline-block;\n  max-width:100%;\n}\n.\\[1\\]_\\[2\\]_blocks_popover_popover-container .\\[1\\]_\\[2\\]_blocks_popover_button{\n  background:transparent;\n  border:none;\n  color:#000;\n  cursor:pointer;\n  display:inline-block;\n  padding:0;\n  max-width:100%;\n}\n.\\[1\\]_\\[2\\]_blocks_popover_popover-container .\\[1\\]_\\[2\\]_blocks_popover_button:focus,\n.\\[1\\]_\\[2\\]_blocks_popover_popover-container .\\[1\\]_\\[2\\]_blocks_popover_button:hover{\n  outline:none;\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_blocks_popover_popover-container .\\[1\\]_\\[2\\]_blocks_popover_button .\\[1\\]_\\[2\\]_blocks_popover_title{\n  display:inline-block;\n  font-weight:bold;\n  text-transform:capitalize;\n  vertical-align:middle;\n  text-align:center;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_action-button_button{\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  font-weight:regular;\n  display:inline-block;\n  position:relative;\n  -webkit-box-sizing:border-box;\n  box-sizing:border-box;\n  padding:0 14px;\n  height:48px;\n  background:rgba(0, 0, 0, 0);\n  border:0;\n  text-decoration:none;\n  font-size:100%;\n  color:#4d4d4d;\n  white-space:nowrap;\n  -webkit-transition:all 200ms ease;\n  transition:all 200ms ease;\n  -webkit-appearance:none;\n  -moz-appearance:none;\n  appearance:none;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none;\n  cursor:pointer;\n  overflow:hidden;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_action-button_button:hover{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActionButton{\n  height:auto;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_action-menu_label{\n  font-size:13px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerAction{\n  color:#4d4d4d;\n  margin-left:8px;\n  opacity:0.8;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerAction:hover,\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerAction:hover[href],\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerAction:focus[href]{\n  color:#4d4d4d;\n  text-decoration:none;\n  cursor:pointer;\n  opacity:1;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActionTitle{\n  display:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app_main{\n  position:absolute;\n  left:0;\n  top:0;\n  bottom:0;\n  right:0;\n  overflow:visible;\n  top:57px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_container .\\[1\\]_\\[2\\]_zimbra-client_login{\n  -webkit-transform:translateY(-50%);\n  transform:translateY(-50%);\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_container{\n  height:100%;\n  background-color:#0088c1;\n  background-size:cover;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login{\n  background-color:white;\n  border-radius:2px;\n  -webkit-box-shadow:0 4px 6px 0 rgba(0, 0, 0, .4);\n  box-shadow:0 4px 6px 0 rgba(0, 0, 0, .4);\n  margin:0 auto;\n  padding:40px;\n  position:relative;\n  top:50%;\n  width:340px;\n  z-index:1;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_form{\n  display:block;\n  margin:auto;\n  max-width:300px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_form label{\n  display:block;\n  margin-top:20px;\n  margin-left:1px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_client-logo_logo{\n  display:inline-block;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_form input{\n  display:block;\n  width:100%;\n  padding:10px;\n  font-size:100%;\n  border:1px solid #d9d9d9;\n  border-radius:2px;\n  outline:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_text-input_input{\n  padding:8px 12px;\n  -webkit-appearance:none;\n  -moz-appearance:none;\n  appearance:none;\n  border-radius:3px;\n  background-color:#fff;\n  border:solid 1px #d9d9d9;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_buttons{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  margin-top:15px;\n  -webkit-box-pack:justify;\n  -webkit-justify-content:space-between;\n  -ms-flex-pack:justify;\n  justify-content:space-between;\n}\n.\\[1\\]_\\[2\\]_blocks_button.\\[1\\]_\\[2\\]_blocks_button_primary:not(:disabled):hover.\\[1\\]_\\[2\\]_blocks_button_brand-primary,\n.\\[1\\]_\\[2\\]_blocks_button.\\[1\\]_\\[2\\]_blocks_button_primary:not(:disabled):focus.\\[1\\]_\\[2\\]_blocks_button_brand-primary{\n  background-color:#009adb;\n}\n.\\[1\\]_\\[2\\]_blocks_button.\\[1\\]_\\[2\\]_blocks_button_primary.\\[1\\]_\\[2\\]_blocks_button_brand-primary{\n  background-color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_blocks_button.\\[1\\]_\\[2\\]_blocks_button_regular{\n  padding:8px 23px;\n}\n.\\[1\\]_\\[2\\]_blocks_button.\\[1\\]_\\[2\\]_blocks_button_primary{\n  background-color:#0568ae;\n  color:#fff;\n}\n.\\[1\\]_\\[2\\]_blocks_button:not(:disabled):hover,\n.\\[1\\]_\\[2\\]_blocks_button:not(:disabled):focus{\n  background-color:#e5e5e5;\n  cursor:pointer;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_password-input_container{\n  position:relative;\n  display:inline-block;\n  width:100%;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_password-input_container button:focus,\n.\\[1\\]_\\[2\\]_zimbra-client_password-input_container button:hover{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_password-input_container button{\n  background:transparent;\n  border:none;\n  color:#999;\n  font-size:10px;\n  padding:1.25em;\n  position:absolute;\n  right:10px;\n  top:50%;\n  text-transform:uppercase;\n  -webkit-transform:translateY(-50%);\n  transform:translateY(-50%);\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_buttons button{\n  margin:0;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_footer{\n  position:absolute;\n  bottom:10px;\n  left:50%;\n  -webkit-transform:translateX(-50%);\n  transform:translateX(-50%);\n  color:white;\n  text-align:center;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_login_footer h6,\n.\\[1\\]_\\[2\\]_zimbra-client_login_footer small,\n.\\[1\\]_\\[2\\]_zimbra-client_login_footer li{\n  font-size:13px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_appMenu{\n  width:100%;\n  background-color:white;\n  overflow:visible;\n  border-bottom:solid 1px #d9d9d9;\n  position:relative;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_appMenu .\\[1\\]_\\[2\\]_zimbra-client_app-navigation_nav{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-flex-wrap:nowrap;\n  -ms-flex-wrap:nowrap;\n  flex-wrap:nowrap;\n  -webkit-box-align:stretch;\n  -webkit-align-items:stretch;\n  -ms-flex-align:stretch;\n  align-items:stretch;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_slot{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:stretch;\n  -webkit-align-items:stretch;\n  -ms-flex-align:stretch;\n  align-items:stretch;\n  margin-top:4px;\n}\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem:hover,\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem:focus,\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem.\\[1\\]_\\[2\\]_zimbra-client_menu-item_active{\n  color:black;\n  text-decoration:none;\n  border-bottom-color:#0088c1;\n}\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem:hover .\\[1\\]_\\[2\\]_zimbra-client_menu-item_icon,\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem:focus .\\[1\\]_\\[2\\]_zimbra-client_menu-item_icon,\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem.\\[1\\]_\\[2\\]_zimbra-client_menu-item_active .\\[1\\]_\\[2\\]_zimbra-client_menu-item_icon{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem{\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n  -ms-flex-align:center;\n  align-items:center;\n  position:relative;\n  -webkit-box-sizing:border-box;\n  box-sizing:border-box;\n  padding:8px 16px;\n  text-decoration:none;\n  color:#4d4d4d;\n  white-space:nowrap;\n  -webkit-appearance:none;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none;\n  cursor:pointer;\n  overflow:hidden;\n  border-bottom:4px solid transparent;\n}\na{\n  color:#0568ae;\n  text-decoration:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem .\\[1\\]_\\[2\\]_zimbra-client_menu-item_icon{\n  position:relative;\n  display:inline-block;\n  line-height:1;\n  font-size:16px;\n  color:#666;\n  margin-right:8px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem .\\[1\\]_\\[2\\]_zimbra-client_menu-item_icon .\\[1\\]_\\[2\\]_fa{\n  font-size:100%;\n}\n.\\[1\\]_\\[2\\]_blocks_icon_md{\n  font-size:24px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActionIcon{\n  font-size:28px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem .\\[1\\]_\\[2\\]_zimbra-client_menu-item_inner{\n  padding:0;\n  font-weight:inherit;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n  -ms-flex-align:center;\n  align-items:center;\n  width:100%;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabs{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:stretch;\n  -webkit-align-items:stretch;\n  -ms-flex-align:stretch;\n  align-items:stretch;\n  -webkit-box-flex:1;\n  -webkit-flex:auto;\n  -ms-flex:auto;\n  flex:auto;\n  min-width:0;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar{\n  position:absolute;\n  left:0;\n  top:0;\n  width:192px;\n  height:100%;\n  background-color:#f2f2f2;\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  border-right:solid 1px #d9d9d9;\n  overflow:auto;\n  overflow-x:hidden;\n  overflow-y:auto;\n  -webkit-overflow-scrolling:touch;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar .\\[1\\]_\\[2\\]_zimbra-client_sidebar_backdrop{\n  display:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar_wrap.\\[1\\]_\\[2\\]_zimbra-client_sidebar_inline .\\[1\\]_\\[2\\]_zimbra-client_sidebar .\\[1\\]_\\[2\\]_zimbra-client_sidebar_inner{\n  background:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar .\\[1\\]_\\[2\\]_zimbra-client_sidebar_inner{\n  position:absolute;\n  left:0;\n  top:0;\n  width:100%;\n  height:100%;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar.\\[1\\]_\\[2\\]_zimbra-client_sidebar_inner{\n  position:absolute;\n  left:0;\n  top:0;\n  width:100%;\n  height:100%;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar_wrap.\\[1\\]_\\[2\\]_zimbra-client_sidebar_inline + *{\n  margin-left:192px !important;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar .\\[1\\]_\\[2\\]_zimbra-client_sidebar_content{\n  width:100%;\n  position:relative;\n  overflow:hidden;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_sidebar_wrap{\n  position:static;\n  width:0;\n  height:0;\n  overflow:visible;\n}\n.\\[1\\]_\\[2\\]_blocks_container-size_containerSize{\n  position:static;\n  overflow:visible;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabMenuItemWrapper{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  border-left:solid 1px #d9d9d9;\n  width:142px;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tab{\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n  -ms-flex-align:center;\n  align-items:center;\n  width:100%;\n  height:100%;\n  line-height:normal;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabTitle{\n  overflow:hidden;\n  text-overflow:ellipsis;\n  -webkit-box-flex:1;\n  -webkit-flex:auto;\n  -ms-flex:auto;\n  flex:auto;\n  line-height:1.3;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabClose,\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabsCloseAllIcon{\n  font-size:18px;\n  outline:none;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabClose:hover{\n  display:block;\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabClose{\n  font-size:18px;\n  outline:none;\n  margin-left:2px;\n}\n.\\[1\\]_\\[2\\]_blocks_icon_sm{\n  font-size:16px;\n}\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem:hover,\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem:focus,\na[href].\\[1\\]_\\[2\\]_zimbra-client_menu-item_navItem.\\[1\\]_\\[2\\]_zimbra-client_menu-item_active{\n  color:black;\n  text-decoration:none;\n  border-bottom-color:#0088c1;\n}\na:hover[href],\na:focus[href]{\n  color:#033c64;\n  text-decoration:underline;\n}\na.\\[1\\]_\\[2\\]_zimbra-client_app-navigation_tabMenuItem{\n  -webkit-box-flex:0;\n  -webkit-flex:0 1 142px;\n  -ms-flex:0 1 142px;\n  flex:0 1 142px;\n  padding:8px 16px;\n  margin-top:4px;\n}\nspan[role="img"]{\n  vertical-align:middle;\n}\nlabel{\n  padding-bottom:6px;\n  color:#262626;\n}\nbutton,\nhtml [type="button"],\n[type="reset"],\n[type="submit"]{\n  -webkit-appearance:button;\n}\n.\\[1\\]_\\[2\\]_blocks_button{\n  border:solid 1px transparent;\n  border-radius:3px;\n  font-size:100%;\n  line-height:1;\n  margin:5px;\n  background-color:#f2f2f2;\n  color:#4d4d4d;\n}\nbutton{\n  cursor:pointer;\n  background:none;\n  border:none;\n}\nbutton:focus{\n  outline-width:0;\n}\nbutton,\ninput,\noptgroup,\nselect,\ntextarea{\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n}\nbutton,\nselect{\n  text-transform:none;\n}\nbutton,\ninput{\n  overflow:visible;\n}\nbutton,\ninput,\noptgroup,\nselect,\ntextarea{\n  font-family:sans-serif;\n  font-size:100%;\n  line-height:1.15;\n  margin:0;\n}\n[role="button"]{\n  cursor:pointer;\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActions{\n    padding-right:12px;\n  }\n  .\\[1\\]_\\[2\\]_zimbra-client_app_main.\\[1\\]_\\[2\\]_zimbra-client_app_noExternalHeader{\n    top:121px;\n  }\n  .\\[1\\]_\\[2\\]_zimbra-client_app_main{\n    top:145px;\n  }\n  .\\[1\\]_\\[2\\]_zimbra-client_sidebar .\\[1\\]_\\[2\\]_zimbra-client_sidebar_content{\n    height:100%;\n    display:-webkit-box;\n    display:-webkit-flex;\n    display:-ms-flexbox;\n    display:flex;\n    -webkit-box-orient:vertical;\n    -webkit-box-direction:normal;\n    -webkit-flex-direction:column;\n    -ms-flex-direction:column;\n    flex-direction:column;\n  }\n  .\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActionTitle{\n    display:-webkit-box;\n    display:-webkit-flex;\n    display:-ms-flexbox;\n    display:flex;\n    -webkit-box-align:center;\n    -webkit-align-items:center;\n    -ms-flex-align:center;\n    align-items:center;\n    font-size:14px;\n    font-weight:500;\n    line-height:1;\n  }\n  .\\[1\\]_\\[2\\]_zimbra-client_header-actions_headerActionIcon{\n    margin-right:4px;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_zimbra-client_header{\n    display:-webkit-box;\n    display:-webkit-flex;\n    display:-ms-flexbox;\n    display:flex;\n  }\n}\n', "", {
            version: 3,
            sources: [ "style.less" ],
            names: [],
            mappings: "AAUA;EACE,0BAA2B;EAC3B,iCAA4E;EAC5E,0MAAuY;EACvY,kBAAmB;EACnB,iBAAkB;AACpB;AACA;EAEE,qCAAsC;EACtC,UAAW;EACX,iBAAkB;EAClB,kBAAmB;EACnB,oCAAoB;UAApB,4BAAoB;EAApB,mBAAoB;EACpB,mBAAoB;EACpB,aAAc;EACd,qBAAsB;EAEtB,kCAAmC;EACnC,iCAAkC;AACpC;AACA;EACE,iBAAkB;AACpB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,2IAA8Q;AAEhR;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,wJAAuS;AAEzS;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,6IAAgR;AAElR;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,4JAAyS;AAE3S;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,2IAAoR;AAEtR;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,iJAAwR;AAE1R;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,iJAAkR;AAEpR;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,8JAA2S;AAE7S;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,6IAA8Q;AAEhR;AAEA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,eAAgB;EAChB,0JAAuS;AAEzS;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AAEA;EAEE,qBAAsB;EACtB,oBAAqB;EACrB,4BAA6B;EAC7B,6BAA8B;EAC9B,2BAA4B;EAC5B,qBAAsB;EACtB,sBAAuB;EAEvB,gCAAiC;EACjC,mCAAoC;EACpC,gBAAiB;EACjB,sBAAuB;EACvB,qBAAsB;EACtB,mBAAoB;EACpB,cAAe;EACf,oBAAqB;EACrB,sBAAuB;EACvB,uBAAwB;EACxB,0BAA2B;EAC3B,mBAAoB;EACpB,mBAAoB;EACpB,cAAe;EACf,sBAAuB;EACvB,2CAA6C;EAC7C,uBAAwB;EACxB,yBAA0B;EAC1B,wBAAyB;EACzB,2BAA4B;EAC5B,uBAAwB;EACxB,oBAAqB;EACrB,uBAAwB;EACxB,sBAAuB;EACvB,6DAA8D;EAC9D,qEAAsE;EACtE,oEAAqE;EACrE,kEAAmE;EACnE,2EAA4E;EAC5E,8BAA+B;EAC/B,8BAA+B;EAC/B,cAAe;EACf,oBAAqB;EACrB,uBAAwB;EACxB,yBAA0B;EAC1B,oBAAqB;EACrB,0BAA2B;EAC3B,iCAAkC;EAClC,uBAAwB;EACxB,0CAA4C;EAC5C,8BAA+B;EAC/B,mBAAoB;EACpB,2BAA4B;EAC5B,+BAAgC;EAChC,uCAAyC;EACzC,sCAAwC;EACxC,0BAA2B;EAC3B,iCAAkC;EAClC,sCAAuC;EACvC,8BAA+B;EAC/B,2BAA4B;EAC5B,iCAAkC;EAClC,4BAA6B;EAC7B,sBAAuB;EACvB,mCAAoC;EACpC,qCAAsC;EACtC,kCAAmC;EACnC,qCAAsC;EACtC,yBAA0B;EAC1B,+BAAgC;EAChC,uBAAwB;EACxB,uBAAwB;EACxB,uBAAwB;EACxB,uBAAwB;EACxB,uBAAwB;EACxB,2BAA4B;EAC5B,yBAA0B;EAC1B,wBAAyB;EACzB,6BAA8B;EAC9B,6BAA8B;EAE9B,+DAAgE;EAChE,4DAA6D;EAC7D,yEAA0E;EAC1E,yDAA0D;EAC1D,4BAA6B;EAC7B,6BAA8B;EAC9B,+BAAgC;EAChC,qBAAsB;EACtB,oBAAqB;EACrB,sBAAuB;EACvB,sBAAuB;EACvB,mBAAoB;EACpB,mBAAoB;EACpB,mBAAoB;EACpB,mBAAoB;EACpB,mBAAoB;EACpB,mBAAoB;EACpB,6BAA8B;EAC9B,2BAA4B;EAC5B,8BAA+B;EAC/B,0BAA2B;EAC3B,0BAA2B;EAC3B,wBAAyB;EACzB,8BAA+B;EAC/B,mBAAoB;EACpB,mBAAoB;EACpB,mBAAoB;EACpB,mBAAoB;EACpB,kBAAmB;EACnB,sBAAuB;EACvB,gBAAiB;EACjB,gBAAiB;EACjB,iBAAkB;EAClB,iBAAkB;EAClB,iBAAkB;EAElB,iBAAkB;EAClB,oBAAqB;EACrB,iBAAkB;EAClB,qBAAsB;EACtB,kBAAmB;EACnB,uBAAwB;EACxB,kBAAmB;EACnB,0BAA2B;EAC3B,qBAAsB;EACtB,sBAAuB;EACvB,sBAAuB;AACzB;AACA;EACE,gCAAiC;EACjC,WAAY;EACZ,gBAAiB;EACjB,eAAgB;EAChB,gBAAiB;EACjB,kDAAmD;AACrD;AACA;;EAEE,iBAAkB;EAClB,MAAO;EACP,KAAM;EACN,UAAW;EACX,WAAY;EACZ,qBAAsB;EACtB,2DAA4D;EAC5D,aAAc;EACd,eAAgB;EAChB,4CAA6C;AAC/C;AACA;EACE,iBAAkB;EAClB,MAAO;EACP,KAAM;EACN,UAAW;EACX,WAAY;EACZ,cAAe;EACf,cAAe;EACf,eAAgB;AAClB;AACA;;;EAGE,6BAA8B;EAC9B,qBAAsB;AACxB;AACA;;EAEE,uBAAwB;EACxB,eAAgB;AAClB;AACA;EACE,qCAAsC;EACtC,UAAW;EACX,iBAAkB;EAClB,kBAAmB;EACnB,oCAAqC;EACrC,4BAA6B;EAC7B,mBAAoB;EACpB,mBAAoB;EACpB,aAAc;EACd,qBAAsB;EACtB,kCAAmC;EACnC,iCAAkC;AACpC;AACA;EACE,wBAAyB;EACzB,+BAAgC;EAChC,qBAAsB;EACtB,uBAAwB;AAC1B;AACA;EACE,YAAa;EACb,wBAAyB;EACzB,0BAA2B;EAC3B,qBAAsB;EACtB,kBAAmB;EACnB,UAAW;EACX,gBAAiB;EACjB,WAAY;EACZ,wBAAyB;EACzB,aAAc;EACd,kBAAmB;EACnB,iBAAkB;EAClB,cAAe;EACf,SAAU;EACV,8CAAgD;EAChD,sCAAwC;EACxC,wBAAyB;EACzB,qCAAsC;EACtC,qBAAsB;EACtB,6BAA8B;AAChC;AACA;EACE,eAAgB;AAClB;AACA;EACE,WAAY;AACd;AACA;EACE,oBAAqB;AACvB;AACA;EACE,WAAY;AACd;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,kBAAmB;EACnB,cAAe;EACf,UAAW;EACX,MAAO;EACP,oBAAqB;EACrB,gCAAiC;EACjC,iBAAkB;EAClB,wBAAyB;EACzB,WAAY;EACZ,wBAAyB;EACzB,0BAA2B;EAC3B,qBAAsB;EACtB,kBAAmB;AACrB;AACA;EACE,kDAAmD;EACnD,kBAAmB;EACnB,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,wBAAyB;EACzB,0BAA2B;EAC3B,qBAAsB;EACtB,kBAAmB;AACrB;AACA;EACE,UAAW;EACX,sBAAuB;EACvB,gBAAiB;EACjB,+BAAgC;EAChC,iBAAkB;AACpB;AACA;EACE,oBAAqB;EACrB,cAAe;AACjB;AACA;EACE,sBAAuB;EACvB,WAAY;EACZ,UAAW;EACX,cAAe;EACf,oBAAqB;EACrB,SAAU;EACV,cAAe;AACjB;AACA;;EAEE,YAAa;EACb,aAAc;AAChB;AACA;EACE,oBAAqB;EACrB,gBAAiB;EACjB,yBAA0B;EAC1B,qBAAsB;EACtB,iBAAkB;AACpB;AACA;EACE,kDAAmD;EACnD,mBAAoB;EACpB,oBAAqB;EACrB,iBAAkB;EAClB,6BAA8B;EAC9B,qBAAsB;EACtB,cAAe;EACf,WAAY;EACZ,2BAA4B;EAC5B,QAAS;EACT,oBAAqB;EACrB,cAAe;EACf,aAAc;EACd,kBAAmB;EACnB,iCAAkC;EAClC,yBAA0B;EAC1B,uBAAwB;EACxB,oBAAqB;EACrB,eAAgB;EAChB,wBAAyB;EACzB,qBAAsB;EACtB,oBAAqB;EACrB,gBAAiB;EACjB,cAAe;EACf,eAAgB;AAClB;AACA;EACE,aAAc;AAChB;AACA;EACE,WAAY;AACd;AACA;EACE,cAAe;AACjB;AACA;EACE,aAAc;EACd,eAAgB;EAChB,WAAY;EACZ,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;AACf;AACA;;;EAGE,aAAc;EACd,oBAAqB;EACrB,cAAe;EACf,SAAU;AACZ;AACA;EACE,YAAa;AACf;AACA;EACE,iBAAkB;EAClB,MAAO;EACP,KAAM;EACN,QAAS;EACT,OAAQ;EACR,gBAAiB;EACjB,QAAS;AACX;AACA;EACE,kCAAmC;EACnC,0BAA2B;AAC7B;AACA;EACE,WAAY;EACZ,wBAAyB;EACzB,qBAAsB;AACxB;AACA;EACE,sBAAuB;EACvB,iBAAkB;EAClB,gDAAkD;EAClD,wCAA0C;EAC1C,aAAc;EACd,YAAa;EACb,iBAAkB;EAClB,OAAQ;EACR,WAAY;EACZ,SAAU;AACZ;AACA;EACE,aAAc;EACd,WAAY;EACZ,eAAgB;AAClB;AACA;EACE,aAAc;EACd,eAAgB;EAChB,eAAgB;AAClB;AACA;EACE,oBAAqB;AACvB;AACA;EACE,aAAc;EACd,UAAW;EACX,YAAa;EACb,cAAe;EACf,wBAAyB;EACzB,iBAAkB;EAClB,YAAa;AACf;AACA;EACE,gBAAiB;EACjB,uBAAwB;EACxB,oBAAqB;EACrB,eAAgB;EAChB,iBAAkB;EAClB,qBAAsB;EACtB,wBAAyB;AAC3B;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,eAAgB;EAChB,wBAAyB;EACzB,qCAAsC;EACtC,qBAAsB;EACtB,6BAA8B;AAChC;AACA;;EAEE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,gBAAiB;AACnB;AACA;EACE,wBAAyB;EACzB,UAAW;AACb;AACA;;EAEE,wBAAyB;EACzB,cAAe;AACjB;AACA;EACE,iBAAkB;EAClB,oBAAqB;EACrB,UAAW;AACb;AACA;;EAEE,aAAc;AAChB;AACA;EACE,sBAAuB;EACvB,WAAY;EACZ,UAAW;EACX,cAAe;EACf,cAAe;EACf,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,wBAAyB;EACzB,kCAAmC;EACnC,0BAA2B;AAC7B;AACA;EACE,QAAS;AACX;AACA;EACE,iBAAkB;EAClB,WAAY;EACZ,QAAS;EACT,kCAAmC;EACnC,0BAA2B;EAC3B,WAAY;EACZ,iBAAkB;AACpB;AACA;;;EAGE,cAAe;AACjB;AACA;EACE,UAAW;EACX,sBAAuB;EACvB,gBAAiB;EACjB,+BAAgC;EAChC,iBAAkB;AACpB;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,wBAAyB;EACzB,oBAAqB;EACrB,gBAAiB;EACjB,yBAA0B;EAC1B,2BAA4B;EAC5B,sBAAuB;EACvB,mBAAoB;AACtB;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,yBAA0B;EAC1B,2BAA4B;EAC5B,sBAAuB;EACvB,mBAAoB;EACpB,cAAe;AACjB;AACA;;;EAGE,WAAY;EACZ,oBAAqB;EACrB,2BAA4B;AAC9B;AACA;;;EAGE,aAAc;AAChB;AACA;EACE,kDAAmD;EACnD,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,wBAAyB;EACzB,0BAA2B;EAC3B,qBAAsB;EACtB,kBAAmB;EACnB,iBAAkB;EAClB,6BAA8B;EAC9B,qBAAsB;EACtB,gBAAiB;EACjB,oBAAqB;EACrB,aAAc;EACd,kBAAmB;EACnB,uBAAwB;EACxB,wBAAyB;EACzB,qBAAsB;EACtB,oBAAqB;EACrB,gBAAiB;EACjB,cAAe;EACf,eAAgB;EAChB,mCAAoC;AACtC;AACA;EACE,aAAc;EACd,oBAAqB;AACvB;AACA;EACE,iBAAkB;EAClB,oBAAqB;EACrB,aAAc;EACd,cAAe;EACf,UAAW;EACX,gBAAiB;AACnB;AACA;EACE,cAAe;AACjB;AACA;EACE,cAAe;AACjB;AACA;EACE,cAAe;AACjB;AACA;EACE,SAAU;EACV,mBAAoB;EACpB,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,wBAAyB;EACzB,0BAA2B;EAC3B,qBAAsB;EACtB,kBAAmB;EACnB,UAAW;AACb;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,yBAA0B;EAC1B,2BAA4B;EAC5B,sBAAuB;EACvB,mBAAoB;EACpB,kBAAmB;EACnB,iBAAkB;EAClB,aAAc;EACd,SAAU;EACV,WAAY;AACd;AACA;EACE,iBAAkB;EAClB,MAAO;EACP,KAAM;EACN,WAAY;EACZ,WAAY;EACZ,wBAAyB;EACzB,kDAAmD;EACnD,8BAA+B;EAC/B,aAAc;EACd,iBAAkB;EAClB,eAAgB;EAChB,gCAAiC;AACnC;AACA;EACE,YAAa;AACf;AACA;EACE,eAAgB;AAClB;AACA;EACE,iBAAkB;EAClB,MAAO;EACP,KAAM;EACN,UAAW;EACX,WAAY;AACd;AACA;EACE,iBAAkB;EAClB,MAAO;EACP,KAAM;EACN,UAAW;EACX,WAAY;AACd;AACA;EACE,4BAA6B;AAC/B;AACA;EACE,UAAW;EACX,iBAAkB;EAClB,eAAgB;AAClB;AACA;EACE,eAAgB;EAChB,OAAQ;EACR,QAAS;EACT,gBAAiB;AACnB;AACA;EACE,eAAgB;EAChB,gBAAiB;AACnB;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,6BAA8B;EAC9B,WAAY;AACd;AACA;EACE,mBAAoB;EACpB,oBAAqB;EACrB,mBAAoB;EACpB,YAAa;EACb,wBAAyB;EACzB,0BAA2B;EAC3B,qBAAsB;EACtB,kBAAmB;EACnB,UAAW;EACX,WAAY;EACZ,kBAAmB;AACrB;AACA;EACE,eAAgB;EAChB,sBAAuB;EACvB,kBAAmB;EACnB,iBAAkB;EAClB,aAAc;EACd,SAAU;EACV,eAAgB;AAClB;AACA;;EAEE,cAAe;EACf,YAAa;AACf;AACA;EACE,aAAc;EACd,aAAc;AAChB;AACA;EACE,cAAe;EACf,YAAa;EACb,eAAgB;AAClB;AACA;EACE,cAAe;AACjB;AACA;;;EAGE,WAAY;EACZ,oBAAqB;EACrB,2BAA4B;AAC9B;AACA;;EAEE,aAAc;EACd,yBAA0B;AAC5B;AACA;EACE,kBAAmB;EACnB,sBAAuB;EACvB,kBAAmB;EACnB,cAAe;EACf,gBAAiB;EACjB,cAAe;AACjB;AACA;EACE,qBAAsB;AACxB;AACA;EACE,kBAAmB;EACnB,aAAc;AAChB;AACA;;;;EAIE,yBAA0B;AAC5B;AACA;EACE,4BAA6B;EAC7B,iBAAkB;EAClB,cAAe;EACf,aAAc;EACd,UAAW;EACX,wBAAyB;EACzB,aAAc;AAChB;AACA;EACE,cAAe;EACf,eAAgB;EAChB,WAAY;AACd;AACA;EACE,eAAgB;AAClB;AACA;;;;;EAKE,kDAAmD;AACrD;AACA;;EAEE,mBAAoB;AACtB;AACA;;EAEE,gBAAiB;AACnB;AACA;;;;;EAKE,sBAAuB;EACvB,cAAe;EACf,gBAAiB;EACjB,QAAS;AACX;AACA;EACE,cAAe;AACjB;AACA;EACE;IACE,kBAAmB;EACrB;EACA;IACE,SAAU;EACZ;EACA;IACE,SAAU;EACZ;EACA;IACE,WAAY;IACZ,mBAAoB;IACpB,oBAAqB;IACrB,mBAAoB;IACpB,YAAa;IACb,2BAA4B;IAC5B,4BAA6B;IAC7B,6BAA8B;IAC9B,yBAA0B;IAC1B,qBAAsB;EACxB;EACA;IACE,mBAAoB;IACpB,oBAAqB;IACrB,mBAAoB;IACpB,YAAa;IACb,wBAAyB;IACzB,0BAA2B;IAC3B,qBAAsB;IACtB,kBAAmB;IACnB,cAAe;IACf,eAAgB;IAChB,aAAc;EAChB;EACA;IACE,gBAAiB;EACnB;AACF;AACA;EACE;IACE,mBAAoB;IACpB,oBAAqB;IACrB,mBAAoB;IACpB,YAAa;EACf;AACF",
            file: "style.less",
            sourcesContent: [ '/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n@font-face {\n  font-family: \'zimbra-icons\';\n  src: url(\'../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.eot?cplvdh\');\n  src: url(\'../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.eot?cplvdh#iefix\') format(\'embedded-opentype\'), url(\'../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.ttf?cplvdh\') format(\'truetype\'), url(\'../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.woff?cplvdh\') format(\'woff\'), url(\'../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.svg?cplvdh#zimbra-icons\') format(\'svg\');\n  font-weight: normal;\n  font-style: normal;\n}\n:global .zimbra-icon {\n  /* use !important to prevent issues with browser extensions that change fonts */\n  font-family: \'zimbra-icons\' !important;\n  speak: none;\n  font-style: normal;\n  font-weight: normal;\n  font-variant: normal;\n  text-transform: none;\n  line-height: 1;\n  vertical-align: middle;\n  /* Better Font Rendering =========== */\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n:global .zimbra-icon:before {\n  content: \'      �\';\n}\n:global .zimbra-icon-add-event:before {\n  content: "\\e900";\n}\n:global .zimbra-icon-folder-add:before {\n  content: "\\e901";\n}\n:global .zimbra-icon-add-note:before {\n  content: "\\e902";\n}\n:global .zimbra-icon-plus:before {\n  content: "\\e903";\n}\n:global .zimbra-icon-archive:before {\n  content: "\\e904";\n}\n:global .zimbra-icon-caret-down:before {\n  content: "\\e905";\n}\n:global .zimbra-icon-user-o:before {\n  content: "\\e906";\n}\n:global .zimbra-icon-user:before {\n  content: "\\e907";\n}\n:global .zimbra-icon-bold:before {\n  content: "\\e908";\n}\n:global .zimbra-icon-list-ul:before {\n  content: "\\e909";\n}\n:global .zimbra-icon-calendar-alt-o:before {\n  content: "\\e90a";\n}\n:global .zimbra-icon-calendar-o:before {\n  content: "\\e90b";\n}\n:global .zimbra-icon-align-center:before {\n  content: "\\e90c";\n}\n:global .zimbra-icon-chat:before {\n  content: "\\e90d";\n}\n:global .zimbra-icon-check-square:before {\n  content: "\\e90e";\n}\n:global .zimbra-icon-square-o:before {\n  content: "\\e90f";\n}\n:global .zimbra-icon-check:before {\n  content: "\\e910";\n}\n:global .zimbra-icon-close-circle:before {\n  content: "\\e911";\n}\n:global .zimbra-icon-close:before {\n  content: "\\e912";\n}\n:global .zimbra-icon-collapse-items:before {\n  content: "\\e913";\n}\n:global .zimbra-icon-angle-double-left:before {\n  content: "\\e914";\n}\n:global .zimbra-icon-pencil:before {\n  content: "\\e915";\n}\n:global .zimbra-icon-address-book:before {\n  content: "\\e916";\n}\n:global .zimbra-icon-arrows-alt-inverse:before {\n  content: "\\e917";\n}\n:global .zimbra-icon-file-word-o:before {\n  content: "\\e918";\n}\n:global .zimbra-icon-chevron-right:before {\n  content: "\\e919";\n}\n:global .zimbra-icon-download:before {\n  content: "\\e91a";\n}\n:global .zimbra-icon-angle-right:before {\n  content: "\\e91b";\n}\n:global .zimbra-icon-smile-o:before {\n  content: "\\e91c";\n}\n:global .zimbra-icon-expand-items:before {\n  content: "\\e91d";\n}\n:global .zimbra-icon-angle-double-right:before {\n  content: "\\e91e";\n}\n:global .zimbra-icon-facebook-official:before {\n  content: "\\e91f";\n}\n:global .zimbra-icon-mail-forward:before {\n  content: "\\e920";\n}\n:global .zimbra-icon-expand:before {\n  content: "\\e921";\n}\n:global .zimbra-icon-GIF:before {\n  content: "\\e922";\n}\n:global .zimbra-icon-grid:before {\n  content: "\\e923";\n}\n:global .zimbra-icon-question-circle:before {\n  content: "\\e924";\n}\n:global .zimbra-icon-home:before {\n  content: "\\e925";\n}\n:global .zimbra-icon-image:before {\n  content: "\\e926";\n}\n:global .zimbra-icon-arrows-alt:before {\n  content: "\\e927";\n}\n:global .zimbra-icon-indent:before {\n  content: "\\e928";\n}\n:global .zimbra-icon-italic:before {\n  content: "\\e929";\n}\n:global .zimbra-icon-align-left:before {\n  content: "\\e92a";\n}\n:global .zimbra-icon-link:before {\n  content: "\\e92b";\n}\n:global .zimbra-icon-mobile-phone:before {\n  content: "\\e92c";\n}\n:global .zimbra-icon-ellipsis-h:before {\n  content: "\\e92d";\n}\n:global .zimbra-icon-folder-move:before {\n  content: "\\e92e";\n}\n:global .zimbra-icon-angle-left:before {\n  content: "\\e92f";\n}\n:global .zimbra-icon-angle-down:before {\n  content: "\\e930";\n}\n:global .zimbra-icon-book:before {\n  content: "\\e931";\n}\n:global .zimbra-icon-list-ol:before {\n  content: "\\e932";\n}\n:global .zimbra-icon-external-link:before {\n  content: "\\e933";\n}\n:global .zimbra-icon-outdent:before {\n  content: "\\e934";\n}\n:global .zimbra-icon-file-pdf-o:before {\n  content: "\\e935";\n}\n:global .zimbra-icon-multimedia-active:before {\n  content: "\\e936";\n}\n:global .zimbra-icon-multimedia:before {\n  content: "\\e937";\n}\n:global .zimbra-icon-file-powerpoint-o:before {\n  content: "\\e938";\n}\n:global .zimbra-icon-print:before {\n  content: "\\e939";\n}\n:global .zimbra-icon-radio:before {\n  content: "\\e93a";\n}\n:global .zimbra-icon-radio-active:before {\n  content: "\\e93b";\n}\n:global .zimbra-icon-mail-reply-all:before {\n  content: "\\e93c";\n}\n:global .zimbra-icon-mail-reply:before {\n  content: "\\e93d";\n}\n:global .zimbra-icon-align-right:before {\n  content: "\\e93e";\n}\n:global .zimbra-icon-search:before {\n  content: "\\e93f";\n}\n:global .zimbra-icon-cog:before {\n  content: "\\e940";\n}\n:global .zimbra-icon-music:before {\n  content: "\\e941";\n}\n:global .zimbra-icon-shield:before {\n  content: "\\e942";\n}\n:global .zimbra-icon-star:before {\n  content: "\\e943";\n}\n:global .zimbra-icon-alarm:before {\n  content: "\\e944";\n}\n:global .zimbra-icon-arrow-left:before {\n  content: "\\e945";\n}\n:global .zimbra-icon-address-book-sync:before {\n  content: "\\e946";\n}\n:global .zimbra-icon-adn:before {\n  content: "\\e947";\n}\n:global .zimbra-icon-font:before {\n  content: "\\e948";\n}\n:global .zimbra-icon-trash:before {\n  content: "\\e949";\n}\n:global .zimbra-icon-twitter:before {\n  content: "\\e94a";\n}\n:global .zimbra-icon-underline:before {\n  content: "\\e94b";\n}\n:global .zimbra-icon-arrow-down:before {\n  content: "\\e94c";\n}\n:global .zimbra-icon-users:before {\n  content: "\\e94d";\n}\n:global .zimbra-icon-play-circle-o:before {\n  content: "\\e94e";\n}\n:global .zimbra-icon-file-excel-o:before {\n  content: "\\e94f";\n}\n:global .zimbra-icon-file-archive-o:before {\n  content: "\\e950";\n}\n:global .zimbra-icon-clock:before {\n  content: "\\e951";\n}\n:global .zimbra-icon-check-circle:before {\n  content: "\\e952";\n}\n:global .zimbra-icon-minus:before {\n  content: "\\e953";\n}\n:global .zimbra-icon-camera:before {\n  content: "\\e954";\n}\n:global .zimbra-icon-minus-square:before {\n  content: "\\e955";\n}\n:global .zimbra-icon-paperclip:before {\n  content: "\\e956";\n}\n:global .zimbra-icon-arrow-up:before {\n  content: "\\e957";\n}\n:global .zimbra-icon-bell:before {\n  content: "\\e958";\n}\n:global .zimbra-icon-calendar-range:before {\n  content: "\\e959";\n}\n:global .zimbra-icon-trash-forever:before {\n  content: "\\e95a";\n}\n:global .zimbra-icon-user-circle-o:before {\n  content: "\\e95b";\n}\n:global .zimbra-icon-add-contact:before {\n  content: "\\e95c";\n}\n:global .zimbra-icon-envelope:before {\n  content: "\\e95d";\n}\n:global .zimbra-icon-add-circle:before {\n  content: "\\e95e";\n}\n:global .zimbra-icon-text-options:before {\n  content: "\\e95f";\n}\n:global .zimbra-icon-assign-list:before {\n  content: "\\e960";\n}\n:global .zimbra-icon-bars:before {\n  content: "\\e961";\n}\n:global .zimbra-icon-restore:before {\n  content: "\\e962";\n}\n:global .zimbra-icon-remove-list:before {\n  content: "\\e963";\n}\n:global .zimbra-icon-lock:before {\n  content: "\\e964";\n}\n:global .zimbra-icon-repeat:before {\n  content: "\\e965";\n}\n:global .zimbra-icon-refresh:before {\n  content: "\\e966";\n}\n:global .zimbra-icon-chevron-left:before {\n  content: "\\e967";\n}\n:global .zimbra-icon-bell-slash:before {\n  content: "\\e968";\n}\n:global .zimbra-icon-warning:before {\n  content: "\\e969";\n}\n:global .zimbra-icon-encrypted:before {\n  content: "\\e96a";\n}\n:global .zimbra-icon-search-plus:before {\n  content: "\\e96b";\n}\n:global .zimbra-icon-search-minus:before {\n  content: "\\e96c";\n}\n:global .zimbra-icon-rotate_right:before {\n  content: "\\e96d";\n}\n:global .zimbra-icon-rotate_left:before {\n  content: "\\e96e";\n}\n:global .zimbra-icon-not-signed:before {\n  content: "\\e96f";\n}\n:global .zimbra-icon-signed:before {\n  content: "\\e970";\n}\n:global .zimbra-icon-cloud:before {\n  content: "\\e971";\n}\n:global .zimbra-icon-videocam:before {\n  content: "\\e972";\n}\n:global .zimbra-icon-location:before {\n  content: "\\e973";\n}\n:global .zimbra-icon-verified:before {\n  content: "\\e974";\n}\n:global .zimbra-icon-not-verified:before {\n  content: "\\e975";\n}\n:global .zimbra-icon-outline-user-circle-o:before {\n  content: "\\e976";\n}\n:global .zimbra-icon-web:before {\n  content: "\\e977";\n}\n:global .zimbra-icon-code:before {\n  content: "\\e978";\n}\n:global .zimbra-icon-check-square-o:before {\n  content: "\\e979";\n}\n/* roboto-100 - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: normal;\n  font-weight: 100;\n  src: local(\'Roboto Thin\'), local(\'Roboto-Thin\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-100italic - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: italic;\n  font-weight: 100;\n  src: local(\'Roboto Thin Italic\'), local(\'Roboto-ThinItalic\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100italic.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-100italic.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-300 - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: normal;\n  font-weight: 300;\n  src: local(\'Roboto Light\'), local(\'Roboto-Light\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-300italic - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: italic;\n  font-weight: 300;\n  src: local(\'Roboto Light Italic\'), local(\'Roboto-LightItalic\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300italic.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-300italic.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-regular - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: normal;\n  font-weight: 400;\n  src: local(\'Roboto\'), local(\'Roboto-Regular\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-regular.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-regular.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-italic - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: italic;\n  font-weight: 400;\n  src: local(\'Roboto Italic\'), local(\'Roboto-Italic\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-italic.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-italic.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-500 - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: normal;\n  font-weight: 500;\n  src: local(\'Roboto Medium\'), local(\'Roboto-Medium\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-500italic - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: italic;\n  font-weight: 500;\n  src: local(\'Roboto Medium Italic\'), local(\'Roboto-MediumItalic\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500italic.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-500italic.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-700 - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: normal;\n  font-weight: 700;\n  src: local(\'Roboto Bold\'), local(\'Roboto-Bold\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-700italic - latin */\n@font-face {\n  font-family: \'Roboto\';\n  font-style: italic;\n  font-weight: 700;\n  src: local(\'Roboto Bold Italic\'), local(\'Roboto-BoldItalic\'), url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700italic.woff2\') format(\'woff2\'), /* Chrome 26+, Opera 23+, Firefox 39+ */ url(\'../../../node_modules/@zimbra/x-ui/fonts/roboto-v18-latin-700italic.woff\') format(\'woff\');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n/* THIS FILE IS AUTOGENERATED - DO NOT MODIFY */\n:root {\n  /** Layout */\n  --toolbar-height: 49px;\n  --checkbox-size: 42px;\n  --mobile-toolbar-height: 57px;\n  --external-header-height: 24px;\n  --search-header-height: 72px;\n  --sidebar-width: 192px;\n  --rightbar-width: 192px;\n  /** Colors */\n  --login-background-color: #0088c1;\n  --login-inner-background-color: #fff;\n  --gray-base: #000;\n  --gray-darkest: #262626;\n  --gray-darker: #4d4d4d;\n  --gray-dark: #666666;\n  --gray: #777777;\n  --gray-light: #999999;\n  --gray-lighter: #d9d9d9;\n  --gray-lightest: #f2f2f2;\n  --gray-placeholder: #999999;\n  --warm-gray: #999999;\n  --off-white: #fafafa;\n  --gold: #ffb81c;\n  --gold-lighter: #ffc84f;\n  --translucent-white: rgba(255, 255, 255, 0.7);\n  --brand-primary: #0088c1;\n  --brand-secondary: #f15b24;\n  --brand-tertiary: #0568ae;\n  --brand-quarternary: #74d6ff;\n  --brand-success: #007a3e;\n  --brand-info: #5bc0de;\n  --brand-warning: #ffb81c;\n  --brand-danger: #cf2a2a;\n  --branding-font-family: "Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-regular: "Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-medium: "Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-bold: "Roboto", Helvetica, Arial, sans-serif;\n  --branding-font-family-medium-italic: "Roboto", Helvetica, Arial, sans-serif;\n  --color-light-positive: #00bd02;\n  --color-light-negative: #ff1f1f;\n  --body-bg: #fff;\n  --text-color: #4d4d4d;\n  --dialog-title-fg: black;\n  --background-gray: #f2f2f2;\n  --link-color: #0568ae;\n  --link-hover-color: #033c64;\n  --link-hover-decoration: underline;\n  --item-hover-bg: #ffffff;\n  --item-selected-bg: rgba(193, 237, 255, 0.5);\n  --border-color-primary: #d9d9d9;\n  --hr-border: #f2f2f2;\n  --placeholder-color: #999999;\n  --app-menu-active-color: #f2f2f2;\n  --list-active-bg: rgba(0, 136, 193, 0.15);\n  --list-hover-bg: rgba(0, 136, 193, 0.08);\n  --sidebar-bg-color: #f2f2f2;\n  --sidebar-header-bg-color: #f2f2f2;\n  --sidebar-primary-button-color: #0088c1;\n  --sidebar-shaded-color: #d9d9d9;\n  --rightbar-bg-color: #f2f2f2;\n  --read-pane-toolbar-color: #f2f2f2;\n  --read-pane-bg-color: #f2f2f2;\n  --border-color: #d9d9d9;\n  --favorite-indicator-active: #ffb81c;\n  --favorite-indicator-inactive: #777777;\n  --favorite-indicator-hover: #ffc84f;\n  --favorite-indicator-disabled: #d9d9d9;\n  --trash-indicator: #777777;\n  --trash-indicator-hover: #0568ae;\n  --file-type-doc: #0f73ff;\n  --file-type-ppt: #ff9937;\n  --file-type-pdf: #ff4c4e;\n  --file-type-xls: #0e9d58;\n  --file-type-zip: #ada293;\n  --file-type-default: #949cae;\n  --file-type-media: #BC0E67;\n  --file-type-code: #00B4CA;\n  --toast-success-color: #00d171;\n  --toast-failure-color: #cf2a2a;\n  /** Typography */\n  --font-family-sans-serif: "Roboto", Helvetica, Arial, sans-serif;\n  --font-family-serif: Georgia, "Times New Roman", Times, serif;\n  --font-family-monospace: Menlo, Monaco, Consolas, "Courier New", monospace;\n  --font-family-base: "Roboto", Helvetica, Arial, sans-serif;\n  --font-brand-primary: inherit;\n  --font-family-primary: inherit;\n  --font-family-secondary: inherit;\n  --font-size-base: 14px;\n  --font-size-med: 16px;\n  --font-size-large: 18px;\n  --font-size-small: 12px;\n  --font-size-h1: 36px;\n  --font-size-h2: 30px;\n  --font-size-h3: 24px;\n  --font-size-h4: 18px;\n  --font-size-h5: 14px;\n  --font-size-h6: 12px;\n  --line-height-base: 1.42857143;\n  --line-height-computed: 20px;\n  --headings-font-family: inherit;\n  --headings-font-weight: 300;\n  --headings-line-height: 1.1;\n  --headings-color: inherit;\n  --headings-small-color: #999999;\n  --icon-size-xs: 12px;\n  --icon-size-sm: 16px;\n  --icon-size-md: 24px;\n  --icon-size-lg: 32px;\n  --logo-height: 32px;\n  --logo-max-width: 200px;\n  --spacing-xs: 4px;\n  --spacing-sm: 8px;\n  --spacing-md: 16px;\n  --spacing-lg: 24px;\n  --spacing-xl: 32px;\n  /** Breakpoints */\n  --screen-xs: 480px;\n  --screen-phone: 480px;\n  --screen-sm: 769px;\n  --screen-tablet: 769px;\n  --screen-md: 1025px;\n  --screen-desktop: 1025px;\n  --screen-lg: 1300px;\n  --screen-lg-desktop: 1300px;\n  --screen-xs-max: 768px;\n  --screen-sm-max: 1024px;\n  --screen-md-max: 1299px;\n}\nbody {\n  -webkit-print-color-adjust: exact;\n  height: auto;\n  overflow: visible;\n  position: static;\n  position: initial;\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n}\nhtml,\nbody {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  background-color: #fff;\n  font: 14px/1.42857143 "Roboto", Helvetica, Arial, sans-serif;\n  color: #4d4d4d;\n  overflow: hidden;\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n}\n.zimbra-client_app {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  font-size: 13px;\n  contain: strict;\n  overflow: hidden;\n}\n*,\n*:before,\n*:after {\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n}\ninput[type="text"]:invalid,\ninput[type="email"]:invalid {\n  -webkit-box-shadow: none;\n  box-shadow: none;\n}\n.zimbra-icon {\n  font-family: \'zimbra-icons\' !important;\n  speak: none;\n  font-style: normal;\n  font-weight: normal;\n  -webkit-font-feature-settings: normal;\n  font-feature-settings: normal;\n  font-variant: normal;\n  text-transform: none;\n  line-height: 1;\n  vertical-align: middle;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n.zimbra-client_header.zimbra-client_header_headerSearch {\n  -webkit-box-pack: initial;\n  -webkit-justify-content: initial;\n  -ms-flex-pack: initial;\n  justify-content: initial;\n}\n.zimbra-client_header {\n  display: none;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  -ms-flex-align: center;\n  align-items: center;\n  width: 100%;\n  min-width: 1024px;\n  height: 72px;\n  background-color: #f2f2f2;\n  color: #4d4d4d;\n  white-space: nowrap;\n  position: relative;\n  padding: 0 16px;\n  z-index: 1;\n  -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n  -webkit-box-pack: justify;\n  -webkit-justify-content: space-between;\n  -ms-flex-pack: justify;\n  justify-content: space-between;\n}\n.zimbra-client_header_primaryLogo {\n  text-align: left;\n}\n.zimbra-client_header_primaryLogoInner {\n  width: 200px;\n}\n.zimbra-client_client-logo_logo {\n  display: inline-block;\n}\n.zimbra-client_search_headerSearch {\n  height: auto;\n}\n.zimbra-client_search_searchContainer {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-flex: 1;\n  -webkit-flex: 1;\n  -ms-flex: 1;\n  flex: 1;\n  -webkit-box-pack: end;\n  -webkit-justify-content: flex-end;\n  -ms-flex-pack: end;\n  justify-content: flex-end;\n  height: 100%;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  -ms-flex-align: center;\n  align-items: center;\n}\n.zimbra-client_header-actions_headerActions {\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  white-space: nowrap;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  -ms-flex-align: center;\n  align-items: center;\n}\n.zimbra-client_app-navigation_appMenu {\n  width: 100%;\n  background-color: white;\n  overflow: visible;\n  border-bottom: solid 1px #d9d9d9;\n  position: relative;\n}\n.blocks_popover_popover-container {\n  display: inline-block;\n  max-width: 100%;\n}\n.blocks_popover_popover-container .blocks_popover_button {\n  background: transparent;\n  border: none;\n  color: #000;\n  cursor: pointer;\n  display: inline-block;\n  padding: 0;\n  max-width: 100%;\n}\n.blocks_popover_popover-container .blocks_popover_button:focus,\n.blocks_popover_popover-container .blocks_popover_button:hover {\n  outline: none;\n  color: #0088c1;\n}\n.blocks_popover_popover-container .blocks_popover_button .blocks_popover_title {\n  display: inline-block;\n  font-weight: bold;\n  text-transform: capitalize;\n  vertical-align: middle;\n  text-align: center;\n}\n.zimbra-client_action-button_button {\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  font-weight: regular;\n  display: inline-block;\n  position: relative;\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n  padding: 0 14px;\n  height: 48px;\n  background: rgba(0, 0, 0, 0);\n  border: 0;\n  text-decoration: none;\n  font-size: 100%;\n  color: #4d4d4d;\n  white-space: nowrap;\n  -webkit-transition: all 200ms ease;\n  transition: all 200ms ease;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  appearance: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  cursor: pointer;\n  overflow: hidden;\n}\n.zimbra-client_action-button_button:hover {\n  color: #0088c1;\n}\n.zimbra-client_header-actions_headerActionButton {\n  height: auto;\n}\n.zimbra-client_action-menu_label {\n  font-size: 13px;\n}\n.zimbra-client_header-actions_headerAction {\n  color: #4d4d4d;\n  margin-left: 8px;\n  opacity: 0.8;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n}\n.zimbra-client_header-actions_headerAction:hover,\n.zimbra-client_header-actions_headerAction:hover[href],\n.zimbra-client_header-actions_headerAction:focus[href] {\n  color: #4d4d4d;\n  text-decoration: none;\n  cursor: pointer;\n  opacity: 1;\n}\n.zimbra-client_header-actions_headerActionTitle {\n  display: none;\n}\n.zimbra-client_app_main {\n  position: absolute;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  right: 0;\n  overflow: visible;\n  top: 57px;\n}\n.zimbra-client_login_container .zimbra-client_login {\n  -webkit-transform: translateY(-50%);\n  transform: translateY(-50%);\n}\n.zimbra-client_login_container {\n  height: 100%;\n  background-color: #0088c1;\n  background-size: cover;\n}\n.zimbra-client_login {\n  background-color: white;\n  border-radius: 2px;\n  -webkit-box-shadow: 0 4px 6px 0 rgba(0, 0, 0, 0.4);\n  box-shadow: 0 4px 6px 0 rgba(0, 0, 0, 0.4);\n  margin: 0 auto;\n  padding: 40px;\n  position: relative;\n  top: 50%;\n  width: 340px;\n  z-index: 1;\n}\n.zimbra-client_login_form {\n  display: block;\n  margin: auto;\n  max-width: 300px;\n}\n.zimbra-client_login_form label {\n  display: block;\n  margin-top: 20px;\n  margin-left: 1px;\n}\n.zimbra-client_client-logo_logo {\n  display: inline-block;\n}\n.zimbra-client_login_form input {\n  display: block;\n  width: 100%;\n  padding: 10px;\n  font-size: 100%;\n  border: 1px solid #d9d9d9;\n  border-radius: 2px;\n  outline: none;\n}\n.zimbra-client_text-input_input {\n  padding: 8px 12px;\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  appearance: none;\n  border-radius: 3px;\n  background-color: #fff;\n  border: solid 1px #d9d9d9;\n}\n.zimbra-client_login_buttons {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  margin-top: 15px;\n  -webkit-box-pack: justify;\n  -webkit-justify-content: space-between;\n  -ms-flex-pack: justify;\n  justify-content: space-between;\n}\n.blocks_button.blocks_button_primary:not(:disabled):hover.blocks_button_brand-primary,\n.blocks_button.blocks_button_primary:not(:disabled):focus.blocks_button_brand-primary {\n  background-color: #009adb;\n}\n.blocks_button.blocks_button_primary.blocks_button_brand-primary {\n  background-color: #0088c1;\n}\n.blocks_button.blocks_button_regular {\n  padding: 8px 23px;\n}\n.blocks_button.blocks_button_primary {\n  background-color: #0568ae;\n  color: #fff;\n}\n.blocks_button:not(:disabled):hover,\n.blocks_button:not(:disabled):focus {\n  background-color: #e5e5e5;\n  cursor: pointer;\n}\n.zimbra-client_password-input_container {\n  position: relative;\n  display: inline-block;\n  width: 100%;\n}\n.zimbra-client_password-input_container button:focus,\n.zimbra-client_password-input_container button:hover {\n  color: #0088c1;\n}\n.zimbra-client_password-input_container button {\n  background: transparent;\n  border: none;\n  color: #999;\n  font-size: 10px;\n  padding: 1.25em;\n  position: absolute;\n  right: 10px;\n  top: 50%;\n  text-transform: uppercase;\n  -webkit-transform: translateY(-50%);\n  transform: translateY(-50%);\n}\n.zimbra-client_login_buttons button {\n  margin: 0;\n}\n.zimbra-client_login_footer {\n  position: absolute;\n  bottom: 10px;\n  left: 50%;\n  -webkit-transform: translateX(-50%);\n  transform: translateX(-50%);\n  color: white;\n  text-align: center;\n}\n.zimbra-client_login_footer h6,\n.zimbra-client_login_footer small,\n.zimbra-client_login_footer li {\n  font-size: 13px;\n}\n.zimbra-client_app-navigation_appMenu {\n  width: 100%;\n  background-color: white;\n  overflow: visible;\n  border-bottom: solid 1px #d9d9d9;\n  position: relative;\n}\n.zimbra-client_app-navigation_appMenu .zimbra-client_app-navigation_nav {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-flex-wrap: nowrap;\n  -ms-flex-wrap: nowrap;\n  flex-wrap: nowrap;\n  -webkit-box-align: stretch;\n  -webkit-align-items: stretch;\n  -ms-flex-align: stretch;\n  align-items: stretch;\n}\n.zimbra-client_app-navigation_slot {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: stretch;\n  -webkit-align-items: stretch;\n  -ms-flex-align: stretch;\n  align-items: stretch;\n  margin-top: 4px;\n}\na[href].zimbra-client_menu-item_navItem:hover,\na[href].zimbra-client_menu-item_navItem:focus,\na[href].zimbra-client_menu-item_navItem.zimbra-client_menu-item_active {\n  color: black;\n  text-decoration: none;\n  border-bottom-color: #0088c1;\n}\na[href].zimbra-client_menu-item_navItem:hover .zimbra-client_menu-item_icon,\na[href].zimbra-client_menu-item_navItem:focus .zimbra-client_menu-item_icon,\na[href].zimbra-client_menu-item_navItem.zimbra-client_menu-item_active .zimbra-client_menu-item_icon {\n  color: #0088c1;\n}\n.zimbra-client_menu-item_navItem {\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  -ms-flex-align: center;\n  align-items: center;\n  position: relative;\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n  padding: 8px 16px;\n  text-decoration: none;\n  color: #4d4d4d;\n  white-space: nowrap;\n  -webkit-appearance: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  cursor: pointer;\n  overflow: hidden;\n  border-bottom: 4px solid transparent;\n}\na {\n  color: #0568ae;\n  text-decoration: none;\n}\n.zimbra-client_menu-item_navItem .zimbra-client_menu-item_icon {\n  position: relative;\n  display: inline-block;\n  line-height: 1;\n  font-size: 16px;\n  color: #666;\n  margin-right: 8px;\n}\n.zimbra-client_menu-item_navItem .zimbra-client_menu-item_icon .fa {\n  font-size: 100%;\n}\n.blocks_icon_md {\n  font-size: 24px;\n}\n.zimbra-client_header-actions_headerActionIcon {\n  font-size: 28px;\n}\n.zimbra-client_menu-item_navItem .zimbra-client_menu-item_inner {\n  padding: 0;\n  font-weight: inherit;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  -ms-flex-align: center;\n  align-items: center;\n  width: 100%;\n}\n.zimbra-client_app-navigation_tabs {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: stretch;\n  -webkit-align-items: stretch;\n  -ms-flex-align: stretch;\n  align-items: stretch;\n  -webkit-box-flex: 1;\n  -webkit-flex: auto;\n  -ms-flex: auto;\n  flex: auto;\n  min-width: 0;\n}\n.zimbra-client_sidebar {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 192px;\n  height: 100%;\n  background-color: #f2f2f2;\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  border-right: solid 1px #d9d9d9;\n  overflow: auto;\n  overflow-x: hidden;\n  overflow-y: auto;\n  -webkit-overflow-scrolling: touch;\n}\n.zimbra-client_sidebar .zimbra-client_sidebar_backdrop {\n  display: none;\n}\n.zimbra-client_sidebar_wrap.zimbra-client_sidebar_inline .zimbra-client_sidebar .zimbra-client_sidebar_inner {\n  background: none;\n}\n.zimbra-client_sidebar .zimbra-client_sidebar_inner {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n}\n.zimbra-client_sidebar.zimbra-client_sidebar_inner {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n}\n.zimbra-client_sidebar_wrap.zimbra-client_sidebar_inline + * {\n  margin-left: 192px !important;\n}\n.zimbra-client_sidebar .zimbra-client_sidebar_content {\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n}\n.zimbra-client_sidebar_wrap {\n  position: static;\n  width: 0;\n  height: 0;\n  overflow: visible;\n}\n.blocks_container-size_containerSize {\n  position: static;\n  overflow: visible;\n}\n.zimbra-client_app-navigation_tabMenuItemWrapper {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  border-left: solid 1px #d9d9d9;\n  width: 142px;\n}\n.zimbra-client_app-navigation_tab {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  -ms-flex-align: center;\n  align-items: center;\n  width: 100%;\n  height: 100%;\n  line-height: normal;\n}\n.zimbra-client_app-navigation_tabTitle {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  -webkit-box-flex: 1;\n  -webkit-flex: auto;\n  -ms-flex: auto;\n  flex: auto;\n  line-height: 1.3;\n}\n.zimbra-client_app-navigation_tabClose,\n.zimbra-client_app-navigation_tabsCloseAllIcon {\n  font-size: 18px;\n  outline: none;\n}\n.zimbra-client_app-navigation_tabClose:hover {\n  display: block;\n  color: #0088c1;\n}\n.zimbra-client_app-navigation_tabClose {\n  font-size: 18px;\n  outline: none;\n  margin-left: 2px;\n}\n.blocks_icon_sm {\n  font-size: 16px;\n}\na[href].zimbra-client_menu-item_navItem:hover,\na[href].zimbra-client_menu-item_navItem:focus,\na[href].zimbra-client_menu-item_navItem.zimbra-client_menu-item_active {\n  color: black;\n  text-decoration: none;\n  border-bottom-color: #0088c1;\n}\na:hover[href],\na:focus[href] {\n  color: #033c64;\n  text-decoration: underline;\n}\na.zimbra-client_app-navigation_tabMenuItem {\n  -webkit-box-flex: 0;\n  -webkit-flex: 0 1 142px;\n  -ms-flex: 0 1 142px;\n  flex: 0 1 142px;\n  padding: 8px 16px;\n  margin-top: 4px;\n}\nspan[role="img"] {\n  vertical-align: middle;\n}\nlabel {\n  padding-bottom: 6px;\n  color: #262626;\n}\nbutton,\nhtml [type="button"],\n[type="reset"],\n[type="submit"] {\n  -webkit-appearance: button;\n}\n.blocks_button {\n  border: solid 1px transparent;\n  border-radius: 3px;\n  font-size: 100%;\n  line-height: 1;\n  margin: 5px;\n  background-color: #f2f2f2;\n  color: #4d4d4d;\n}\nbutton {\n  cursor: pointer;\n  background: none;\n  border: none;\n}\nbutton:focus {\n  outline-width: 0;\n}\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n}\nbutton,\nselect {\n  text-transform: none;\n}\nbutton,\ninput {\n  overflow: visible;\n}\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: sans-serif;\n  font-size: 100%;\n  line-height: 1.15;\n  margin: 0;\n}\n[role="button"] {\n  cursor: pointer;\n}\n@media (min-width: 1025px) {\n  .zimbra-client_header-actions_headerActions {\n    padding-right: 12px;\n  }\n  .zimbra-client_app_main.zimbra-client_app_noExternalHeader {\n    top: 121px;\n  }\n  .zimbra-client_app_main {\n    top: 145px;\n  }\n  .zimbra-client_sidebar .zimbra-client_sidebar_content {\n    height: 100%;\n    display: -webkit-box;\n    display: -webkit-flex;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n    -webkit-flex-direction: column;\n    -ms-flex-direction: column;\n    flex-direction: column;\n  }\n  .zimbra-client_header-actions_headerActionTitle {\n    display: -webkit-box;\n    display: -webkit-flex;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n    -webkit-align-items: center;\n    -ms-flex-align: center;\n    align-items: center;\n    font-size: 14px;\n    font-weight: 500;\n    line-height: 1;\n  }\n  .zimbra-client_header-actions_headerActionIcon {\n    margin-right: 4px;\n  }\n}\n@media (min-width: 769px) {\n  .zimbra-client_header {\n    display: -webkit-box;\n    display: -webkit-flex;\n    display: -ms-flexbox;\n    display: flex;\n  }\n}\n' ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            "zimbra-client_app": "[1]_[2]_zimbra-client_app",
            "zimbra-icon": "[1]_[2]_zimbra-icon",
            "zimbra-client_header": "[1]_[2]_zimbra-client_header",
            "zimbra-client_header_headerSearch": "[1]_[2]_zimbra-client_header_headerSearch",
            "zimbra-client_header_primaryLogo": "[1]_[2]_zimbra-client_header_primaryLogo",
            "zimbra-client_header_primaryLogoInner": "[1]_[2]_zimbra-client_header_primaryLogoInner",
            "zimbra-client_client-logo_logo": "[1]_[2]_zimbra-client_client-logo_logo",
            "zimbra-client_search_headerSearch": "[1]_[2]_zimbra-client_search_headerSearch",
            "zimbra-client_search_searchContainer": "[1]_[2]_zimbra-client_search_searchContainer",
            "zimbra-client_header-actions_headerActions": "[1]_[2]_zimbra-client_header-actions_headerActions",
            "zimbra-client_app-navigation_appMenu": "[1]_[2]_zimbra-client_app-navigation_appMenu",
            "blocks_popover_popover-container": "[1]_[2]_blocks_popover_popover-container",
            blocks_popover_button: "[1]_[2]_blocks_popover_button",
            blocks_popover_title: "[1]_[2]_blocks_popover_title",
            "zimbra-client_action-button_button": "[1]_[2]_zimbra-client_action-button_button",
            "zimbra-client_header-actions_headerActionButton": "[1]_[2]_zimbra-client_header-actions_headerActionButton",
            "zimbra-client_action-menu_label": "[1]_[2]_zimbra-client_action-menu_label",
            "zimbra-client_header-actions_headerAction": "[1]_[2]_zimbra-client_header-actions_headerAction",
            "zimbra-client_header-actions_headerActionTitle": "[1]_[2]_zimbra-client_header-actions_headerActionTitle",
            "zimbra-client_app_main": "[1]_[2]_zimbra-client_app_main",
            "zimbra-client_login_container": "[1]_[2]_zimbra-client_login_container",
            "zimbra-client_login": "[1]_[2]_zimbra-client_login",
            "zimbra-client_login_form": "[1]_[2]_zimbra-client_login_form",
            "zimbra-client_text-input_input": "[1]_[2]_zimbra-client_text-input_input",
            "zimbra-client_login_buttons": "[1]_[2]_zimbra-client_login_buttons",
            blocks_button: "[1]_[2]_blocks_button",
            blocks_button_primary: "[1]_[2]_blocks_button_primary",
            "blocks_button_brand-primary": "[1]_[2]_blocks_button_brand-primary",
            blocks_button_regular: "[1]_[2]_blocks_button_regular",
            "zimbra-client_password-input_container": "[1]_[2]_zimbra-client_password-input_container",
            "zimbra-client_login_footer": "[1]_[2]_zimbra-client_login_footer",
            "zimbra-client_app-navigation_nav": "[1]_[2]_zimbra-client_app-navigation_nav",
            "zimbra-client_app-navigation_slot": "[1]_[2]_zimbra-client_app-navigation_slot",
            "zimbra-client_menu-item_navItem": "[1]_[2]_zimbra-client_menu-item_navItem",
            "zimbra-client_menu-item_active": "[1]_[2]_zimbra-client_menu-item_active",
            "zimbra-client_menu-item_icon": "[1]_[2]_zimbra-client_menu-item_icon",
            fa: "[1]_[2]_fa",
            blocks_icon_md: "[1]_[2]_blocks_icon_md",
            "zimbra-client_header-actions_headerActionIcon": "[1]_[2]_zimbra-client_header-actions_headerActionIcon",
            "zimbra-client_menu-item_inner": "[1]_[2]_zimbra-client_menu-item_inner",
            "zimbra-client_app-navigation_tabs": "[1]_[2]_zimbra-client_app-navigation_tabs",
            "zimbra-client_sidebar": "[1]_[2]_zimbra-client_sidebar",
            "zimbra-client_sidebar_backdrop": "[1]_[2]_zimbra-client_sidebar_backdrop",
            "zimbra-client_sidebar_wrap": "[1]_[2]_zimbra-client_sidebar_wrap",
            "zimbra-client_sidebar_inline": "[1]_[2]_zimbra-client_sidebar_inline",
            "zimbra-client_sidebar_inner": "[1]_[2]_zimbra-client_sidebar_inner",
            "zimbra-client_sidebar_content": "[1]_[2]_zimbra-client_sidebar_content",
            "blocks_container-size_containerSize": "[1]_[2]_blocks_container-size_containerSize",
            "zimbra-client_app-navigation_tabMenuItemWrapper": "[1]_[2]_zimbra-client_app-navigation_tabMenuItemWrapper",
            "zimbra-client_app-navigation_tab": "[1]_[2]_zimbra-client_app-navigation_tab",
            "zimbra-client_app-navigation_tabTitle": "[1]_[2]_zimbra-client_app-navigation_tabTitle",
            "zimbra-client_app-navigation_tabClose": "[1]_[2]_zimbra-client_app-navigation_tabClose",
            "zimbra-client_app-navigation_tabsCloseAllIcon": "[1]_[2]_zimbra-client_app-navigation_tabsCloseAllIcon",
            blocks_icon_sm: "[1]_[2]_blocks_icon_sm",
            "zimbra-client_app-navigation_tabMenuItem": "[1]_[2]_zimbra-client_app-navigation_tabMenuItem",
            "zimbra-client_app_noExternalHeader": "[1]_[2]_zimbra-client_app_noExternalHeader"
        };
    },
    "./src/interop/common/createPlugins.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createPlugins;
        }));
        function createPlugins(registerMenuSlot, addRoutesToApp, addComponentToSidebar) {
            var exports = {};
            var appName;
            exports.register = function(slug, component) {
                if (slug === "slot::chatapps-tab-item") {
                    appName = registerMenuSlot(component);
                }
                if (slug === "slot::routes") {
                    addRoutesToApp(component, appName);
                }
                if (slug === "slot::rightbar-50px") {
                    addComponentToSidebar(component, appName);
                }
            };
            return exports;
        }
    },
    "./src/interop/common/createStore.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createStore;
        }));
        var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/redux/es/redux.js");
        var _store_navigation_reducers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/common/store/navigation/reducers.js");
        function createStore() {
            var composeEnhancers = redux__WEBPACK_IMPORTED_MODULE_0__["compose"];
            if (false) {}
            return Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
                navigation: _store_navigation_reducers__WEBPACK_IMPORTED_MODULE_1__["default"]
            }), {}, composeEnhancers());
        }
    },
    "./src/interop/common/createZimletRedux.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createZimletRedux;
        }));
        var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/redux/es/redux.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function createZimletRedux(store) {
            var dynamicFromZimlets = {
                reducers: {},
                actions: {},
                selectors: {}
            };
            store.zimletRedux = {
                injectAsyncReducer: function injectAsyncReducer(namespace, asyncReducer) {
                    dynamicFromZimlets.reducers[namespace] = asyncReducer;
                    store.replaceReducer(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])(dynamicFromZimlets.reducers));
                },
                addActions: function addActions(namespace, actions) {
                    dynamicFromZimlets.actions[namespace] = actions;
                },
                addSelectors: function addSelectors(namespace, selectors) {
                    dynamicFromZimlets.selectors[namespace] = selectors;
                }
            };
            Object.defineProperty(store.zimletRedux, "actions", {
                get: function get() {
                    return _extends({}, dynamicFromZimlets.actions);
                }
            });
            Object.defineProperty(store.zimletRedux, "selectors", {
                get: function get() {
                    return _extends({}, dynamicFromZimlets.selectors);
                }
            });
            return store.zimletRedux;
        }
    },
    "./src/interop/common/store/navigation/actions.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "addTab", (function() {
            return addTab;
        }));
        __webpack_require__.d(__webpack_exports__, "removeTab", (function() {
            return removeTab;
        }));
        var redux_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/redux-actions/es/index.js");
        var addTab = Object(redux_actions__WEBPACK_IMPORTED_MODULE_0__["createAction"])("navigation add.tab");
        var removeTab = Object(redux_actions__WEBPACK_IMPORTED_MODULE_0__["createAction"])("navigation remove.tab");
    },
    "./src/interop/common/store/navigation/reducers.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "initialState", (function() {
            return initialState;
        }));
        var lodash_findIndex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/lodash/findIndex.js");
        var lodash_findIndex__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(lodash_findIndex__WEBPACK_IMPORTED_MODULE_0__);
        var redux_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/redux-actions/es/index.js");
        var _actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/common/store/navigation/actions.js");
        var _handleActions;
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        var initialState = {
            tabs: [],
            showAdvanced: false,
            searchQuery: ""
        };
        __webpack_exports__["default"] = Object(redux_actions__WEBPACK_IMPORTED_MODULE_1__["handleActions"])((_handleActions = {}, 
        _handleActions[_actions__WEBPACK_IMPORTED_MODULE_2__["addTab"]] = function(state, _ref) {
            var payload = _ref.payload;
            var index = lodash_findIndex__WEBPACK_IMPORTED_MODULE_0___default()(state.tabs, (function(t) {
                return t.id === payload.id && t.type === payload.type;
            }));
            var tabs = [].concat(state.tabs);
            if (index !== -1) {
                tabs.splice(index, 1, payload);
            } else {
                tabs = [].concat(state.tabs, [ payload ]);
            }
            return _extends({}, state, {
                tabs: tabs
            });
        }, _handleActions[_actions__WEBPACK_IMPORTED_MODULE_2__["removeTab"]] = function(state, _ref2) {
            var payload = _ref2.payload;
            return _extends({}, state, {
                tabs: state.tabs.filter((function(t) {
                    return !(t.id === payload.id && t.type === payload.type);
                }))
            });
        }, _handleActions), initialState);
    },
    "./src/interop/standalone/index.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createContext;
        }));
        var preact_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var _common_createPlugins__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/common/createPlugins.js");
        var _common_createZimletRedux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/common/createZimletRedux.js");
        var _zimbra__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/standalone/zimbra.js");
        var _plugins_menuHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/standalone/plugins/menuHandler.js");
        __webpack_require__.d(__webpack_exports__, "createMenuHandler", (function() {
            return _plugins_menuHandler__WEBPACK_IMPORTED_MODULE_4__["default"];
        }));
        var _plugins_appRouter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/standalone/plugins/appRouter.js");
        __webpack_require__.d(__webpack_exports__, "createAppRouter", (function() {
            return _plugins_appRouter__WEBPACK_IMPORTED_MODULE_5__["default"];
        }));
        var _common_createStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/interop/common/createStore.js");
        __webpack_require__.d(__webpack_exports__, "createStore", (function() {
            return _common_createStore__WEBPACK_IMPORTED_MODULE_6__["default"];
        }));
        var _i18n__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./src/interop/i18n.js");
        __webpack_require__.d(__webpack_exports__, "getTranslations", (function() {
            return _i18n__WEBPACK_IMPORTED_MODULE_7__["default"];
        }));
        __webpack_require__.d(__webpack_exports__, "setLocale", (function() {
            return _i18n__WEBPACK_IMPORTED_MODULE_7__["setLocale"];
        }));
        function createContext(store, registerMenuSlot, addRoutesToApp, teamApiClient) {
            return {
                plugins: Object(_common_createPlugins__WEBPACK_IMPORTED_MODULE_1__["default"])(registerMenuSlot, addRoutesToApp, (function() {
                    return void 0;
                })),
                zimletRedux: Object(_common_createZimletRedux__WEBPACK_IMPORTED_MODULE_2__["default"])(store),
                getAccount: function getAccount() {
                    return {
                        prefs: {}
                    };
                },
                zimbraOrigin: "",
                Link: preact_router__WEBPACK_IMPORTED_MODULE_0__["Link"],
                route: preact_router__WEBPACK_IMPORTED_MODULE_0__["route"],
                zimbra: Object(_zimbra__WEBPACK_IMPORTED_MODULE_3__["default"])(teamApiClient)
            };
        }
    },
    "./src/interop/standalone/plugins/appRouter.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createAppRouter;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var mitt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/mitt/dist/mitt.es.js");
        var preact_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var history__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/history/esm/history.js");
        var _routing__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/routing/index.js");
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        function createAppRouter(store, addTab, removeTab, isExternal) {
            if (isExternal === void 0) {
                isExternal = false;
            }
            var emitter = Object(mitt__WEBPACK_IMPORTED_MODULE_1__["default"])();
            var routerFns = [];
            function addRoutesToApp(routerFn) {
                routerFns = routerFns.concat(routerFn);
                emitter.emit("plugins::changed", "slot::routes");
            }
            var AppRouter = function(_Component) {
                _inheritsLoose(AppRouter, _Component);
                var _super = _createSuper(AppRouter);
                function AppRouter() {
                    var _this;
                    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                        args[_key] = arguments[_key];
                    }
                    _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                    _defineProperty(_assertThisInitialized(_this), "state", {
                        routerFns: routerFns
                    });
                    _defineProperty(_assertThisInitialized(_this), "_updateRoutes", (function(name) {
                        if (name === "slot::routes") {
                            _this.setState((function() {
                                return {
                                    routerFns: routerFns
                                };
                            }));
                        }
                    }));
                    return _this;
                }
                var _proto = AppRouter.prototype;
                _proto.getChildContext = function getChildContext() {
                    return {
                        history: this._history,
                        store: store,
                        addTab: addTab,
                        removeTab: removeTab
                    };
                };
                _proto.componentWillMount = function componentWillMount() {
                    emitter.on("plugins::changed", this._updateRoutes);
                };
                _proto.componentDidMount = function componentDidMount() {
                    emitter.on("plugins::changed", this._updateRoutes);
                };
                _proto.render = function render(props, state, context) {
                    var children = [];
                    for (var i = 0; i < state.routerFns.length; i++) {
                        children = children.concat(state.routerFns[i]());
                    }
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_router__WEBPACK_IMPORTED_MODULE_2__["Router"], {
                        history: isExternal === false ? Object(history__WEBPACK_IMPORTED_MODULE_3__["createHashHistory"])({
                            initialEntries: [ Object(_routing__WEBPACK_IMPORTED_MODULE_4__["getMainPath"])() ]
                        }) : Object(history__WEBPACK_IMPORTED_MODULE_3__["createMemoryHistory"])()
                    }, children);
                };
                return AppRouter;
            }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
            return {
                addRoutesToApp: addRoutesToApp,
                AppRouter: AppRouter
            };
        }
    },
    "./src/interop/standalone/plugins/menuHandler.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createMenuHandler;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var mitt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/mitt/dist/mitt.es.js");
        var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
        var _common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/common/store/navigation/actions.js");
        var _style_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/standalone/style.less");
        var _style_less__WEBPACK_IMPORTED_MODULE_4___default = __webpack_require__.n(_style_less__WEBPACK_IMPORTED_MODULE_4__);
        var _zimbra_client_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/index.js");
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        function createMenuHandler(store) {
            var emitter = Object(mitt__WEBPACK_IMPORTED_MODULE_1__["default"])();
            var slots = [];
            var tabs = [];
            store.subscribe((function() {
                tabs.length = 0;
                tabs.push.apply(tabs, store.getState().navigation.tabs);
                emitter.emit("tabs::changed", "slot::chatapps-tab-item");
            }));
            function registerMenuSlot(el) {
                slots.push(el);
                emitter.emit("plugins::changed", "slot::chatapps-tab-item");
            }
            function addTab(tab) {
                store.dispatch(Object(_common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__["addTab"])(tab));
            }
            function removeTab(tab) {
                store.dispatch(Object(_common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__["removeTab"])(tab));
            }
            var ZimletSlot = function(_Component) {
                _inheritsLoose(ZimletSlot, _Component);
                var _super = _createSuper(ZimletSlot);
                function ZimletSlot() {
                    var _this;
                    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                        args[_key] = arguments[_key];
                    }
                    _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                    _defineProperty(_assertThisInitialized(_this), "state", {
                        slots: slots
                    });
                    _defineProperty(_assertThisInitialized(_this), "_updateSlots", (function(name) {
                        if (name === "slot::chatapps-tab-item") {
                            _this.setState((function() {
                                return {
                                    slots: slots
                                };
                            }));
                        }
                    }));
                    return _this;
                }
                var _proto = ZimletSlot.prototype;
                _proto.componentWillMount = function componentWillMount() {
                    emitter.on("plugins::changed", this._updateSlots);
                };
                _proto.componentDidMount = function componentDidMount() {
                    emitter.on("plugins::changed", this._updateSlots);
                };
                _proto.render = function render(props, _ref, context) {
                    var _slots = _ref.slots;
                    var children = [];
                    for (var i = 0; i < _slots.length; i++) {
                        children.push(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_slots[i]));
                    }
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                        className: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_slot"]
                    }, children);
                };
                return ZimletSlot;
            }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
            var AppNavigationTabs = function(_Component2) {
                _inheritsLoose(AppNavigationTabs, _Component2);
                var _super2 = _createSuper(AppNavigationTabs);
                function AppNavigationTabs() {
                    var _this2;
                    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
                        args[_key2] = arguments[_key2];
                    }
                    _this2 = _Component2.call.apply(_Component2, [ this ].concat(args)) || this;
                    _defineProperty(_assertThisInitialized(_this2), "state", {
                        tabs: tabs
                    });
                    _defineProperty(_assertThisInitialized(_this2), "_updateTabs", (function(name) {
                        if (name === "slot::chatapps-tab-item") {
                            _this2.setState((function() {
                                return {
                                    tabs: tabs
                                };
                            }));
                        }
                    }));
                    return _this2;
                }
                var _proto2 = AppNavigationTabs.prototype;
                _proto2.componentWillMount = function componentWillMount() {
                    emitter.on("tabs::changed", this._updateTabs);
                };
                _proto2.componentDidMount = function componentDidMount() {
                    emitter.on("tabs::changed", this._updateTabs);
                };
                _proto2.render = function render(props, state, context) {
                    var children = [];
                    Object(lodash__WEBPACK_IMPORTED_MODULE_2__["forEach"])(state.tabs, (function(singleTab) {
                        children.push(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                            className: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_tabMenuItemWrapper"],
                            key: singleTab.id
                        }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_zimbra_client_components__WEBPACK_IMPORTED_MODULE_5__["MenuItem"], {
                            customClass: [ _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_menu-item_navItem"], _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_tabMenuItem"] ].join(" "),
                            activeClass: [ _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_menu-item_active"], _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_active"] ].join(" "),
                            match: singleTab.url,
                            href: singleTab.url,
                            innerClass: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_menu-item_inner"]
                        }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                            className: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_tab"]
                        }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                            className: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_tabTitle"]
                        }, singleTab.title), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_zimbra_client_components__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
                            name: "close",
                            size: "sm",
                            class: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_tabClose"],
                            onClick: function(_tab, _tabs, _emitter, _store, _removeTabAction) {
                                return function(ev) {
                                    ev.preventDefault();
                                    ev.stopPropagation();
                                    var index = Object(lodash__WEBPACK_IMPORTED_MODULE_2__["findIndex"])(_tabs, (function(tab) {
                                        return tab.id === _tab.id;
                                    }));
                                    if (index > -1) {
                                        _tabs.splice(index, 1);
                                        _emitter.emit("tabs::changed", "slot::chatapps-tab-item");
                                        _store.dispatch(_removeTabAction(_tab));
                                    }
                                };
                            }(singleTab, state.tabs, emitter, store, _common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__["removeTab"])
                        })))));
                    }));
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                        className: _style_less__WEBPACK_IMPORTED_MODULE_4___default.a["zimbra-client_app-navigation_tabs"]
                    }, children);
                };
                return AppNavigationTabs;
            }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
            return {
                registerMenuSlot: registerMenuSlot,
                ZimletSlot: ZimletSlot,
                AppNavigationTabs: AppNavigationTabs,
                addTab: addTab,
                removeTab: removeTab
            };
        }
    },
    "./src/interop/standalone/style.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/standalone/style.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/standalone/zimbra.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return zimbra;
        }));
        var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/rxjs/_esm5/operators/index.js");
        function zimbra(teamApiClient) {
            return {
                jsonRequest: function jsonRequest(requestName, body, options) {
                    switch (requestName) {
                      case "GetInfoRequest":
                        {
                            return new Promise((function(resolve, reject) {
                                if (false) {} else {
                                    teamApiClient.currentSession.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["skipWhile"])((function(loginData) {
                                        return loginData == null;
                                    })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["skipWhile"])((function(loginData) {
                                        return teamApiClient._authToken.cookie === "";
                                    })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["take"])(1)).subscribe((function(loginData) {
                                        var req2 = new XMLHttpRequest;
                                        req2.addEventListener("load", (function(ev) {
                                            var resp = JSON.parse(ev.target.response);
                                            try {
                                                resolve({
                                                    props: resp.Body.GetInfoResponse.props.prop
                                                });
                                            } catch (e) {
                                                reject();
                                            }
                                        }));
                                        req2.open("POST", "/service/soap/GetInfoRequest", true);
                                        req2.withCredentials = true;
                                        document.cookie = teamApiClient._authToken.cookie;
                                        req2.send(JSON.stringify({
                                            Body: {
                                                GetInfoRequest: {
                                                    _jsns: "urn:zimbraAccount"
                                                }
                                            },
                                            Header: {
                                                _jsns: "urn:zimbra",
                                                authToken: {
                                                    _content: teamApiClient._authToken.cookie.substring(14)
                                                }
                                            }
                                        }));
                                    }));
                                }
                            }));
                        }

                      case "ModifyPropertiesRequest":
                        {
                            return new Promise((function(resolve, reject) {
                                teamApiClient.currentSession.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["skipWhile"])((function(loginData) {
                                    return loginData == null;
                                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["skipWhile"])((function(loginData) {
                                    return teamApiClient._authToken.cookie === "";
                                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["take"])(1)).subscribe((function(loginData) {
                                    var req2 = new XMLHttpRequest;
                                    req2.addEventListener("load", (function(ev) {
                                        var resp = JSON.parse(ev.target.response);
                                        resolve({
                                            props: resp.Body.ModifyPropertiesResponse
                                        });
                                    }));
                                    req2.open("POST", "/service/soap/ModifyPropertiesRequest", true);
                                    req2.withCredentials = true;
                                    document.cookie = teamApiClient._authToken.cookie;
                                    req2.send(JSON.stringify({
                                        Body: {
                                            ModifyPropertiesRequest: {
                                                _jsns: "urn:zimbraAccount",
                                                prop: {
                                                    _content: body.prop._content,
                                                    zimlet: body.prop.zimlet,
                                                    name: body.prop.name
                                                }
                                            }
                                        },
                                        Header: {
                                            _jsns: "urn:zimbra",
                                            authToken: {
                                                _content: teamApiClient._authToken.cookie.substring(14)
                                            }
                                        }
                                    }));
                                }));
                            }));
                        }

                      default:
                        {
                            throw new Error;
                        }
                    }
                }
            };
        }
    }
} ]);
//# sourceMappingURL=12.bac8b54d.chunk.js.map