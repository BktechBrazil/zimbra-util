(window["com_zimbra_connect_classic_jsonp"] = window["com_zimbra_connect_classic_jsonp"] || []).push([ [ 11 ], {
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/zimbraClassic/components/Dwt.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, ".\\[1\\]_\\[2\\]_container{\n  width:100%;\n  height:100%;\n}\n.\\[1\\]_\\[2\\]_container *,\n.\\[1\\]_\\[2\\]_container *:before,\n.\\[1\\]_\\[2\\]_container *:after{\n  -webkit-box-sizing:border-box;\n  box-sizing:border-box;\n}\n", "", {
            version: 3,
            sources: [ "Dwt.less" ],
            names: [],
            mappings: "AAUA;EACE,UAAW;EACX,WAAY;AACd;AACA;;;EAGE,6BAA8B;EAC9B,qBAAsB;AACxB",
            file: "Dwt.less",
            sourcesContent: [ "/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n.container {\n  width: 100%;\n  height: 100%;\n}\n.container *,\n.container *:before,\n.container *:after {\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n}\n" ]
        } ]);
        exports.locals = {
            container: "[1]_[2]_container"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/zimbraClassic/style.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, "\n", "", {
            version: 3,
            sources: [],
            names: [],
            mappings: "",
            file: "style.less"
        } ]);
    },
    "./src/interop/common/createPlugins.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createPlugins;
        }));
        function createPlugins(registerMenuSlot, addRoutesToApp, addComponentToSidebar) {
            var exports = {};
            var appName;
            exports.register = function(slug, component) {
                if (slug === "slot::chatapps-tab-item") {
                    appName = registerMenuSlot(component);
                }
                if (slug === "slot::routes") {
                    addRoutesToApp(component, appName);
                }
                if (slug === "slot::rightbar-50px") {
                    addComponentToSidebar(component, appName);
                }
            };
            return exports;
        }
    },
    "./src/interop/common/createStore.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createStore;
        }));
        var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/redux/es/redux.js");
        var _store_navigation_reducers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/common/store/navigation/reducers.js");
        function createStore() {
            var composeEnhancers = redux__WEBPACK_IMPORTED_MODULE_0__["compose"];
            if (false) {}
            return Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
                navigation: _store_navigation_reducers__WEBPACK_IMPORTED_MODULE_1__["default"]
            }), {}, composeEnhancers());
        }
    },
    "./src/interop/common/createZimletRedux.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createZimletRedux;
        }));
        var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/redux/es/redux.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function createZimletRedux(store) {
            var dynamicFromZimlets = {
                reducers: {},
                actions: {},
                selectors: {}
            };
            store.zimletRedux = {
                injectAsyncReducer: function injectAsyncReducer(namespace, asyncReducer) {
                    dynamicFromZimlets.reducers[namespace] = asyncReducer;
                    store.replaceReducer(Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])(dynamicFromZimlets.reducers));
                },
                addActions: function addActions(namespace, actions) {
                    dynamicFromZimlets.actions[namespace] = actions;
                },
                addSelectors: function addSelectors(namespace, selectors) {
                    dynamicFromZimlets.selectors[namespace] = selectors;
                }
            };
            Object.defineProperty(store.zimletRedux, "actions", {
                get: function get() {
                    return _extends({}, dynamicFromZimlets.actions);
                }
            });
            Object.defineProperty(store.zimletRedux, "selectors", {
                get: function get() {
                    return _extends({}, dynamicFromZimlets.selectors);
                }
            });
            return store.zimletRedux;
        }
    },
    "./src/interop/common/store/navigation/actions.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "addTab", (function() {
            return addTab;
        }));
        __webpack_require__.d(__webpack_exports__, "removeTab", (function() {
            return removeTab;
        }));
        var redux_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/redux-actions/es/index.js");
        var addTab = Object(redux_actions__WEBPACK_IMPORTED_MODULE_0__["createAction"])("navigation add.tab");
        var removeTab = Object(redux_actions__WEBPACK_IMPORTED_MODULE_0__["createAction"])("navigation remove.tab");
    },
    "./src/interop/common/store/navigation/reducers.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "initialState", (function() {
            return initialState;
        }));
        var lodash_findIndex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/lodash/findIndex.js");
        var lodash_findIndex__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(lodash_findIndex__WEBPACK_IMPORTED_MODULE_0__);
        var redux_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/redux-actions/es/index.js");
        var _actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/common/store/navigation/actions.js");
        var _handleActions;
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        var initialState = {
            tabs: [],
            showAdvanced: false,
            searchQuery: ""
        };
        __webpack_exports__["default"] = Object(redux_actions__WEBPACK_IMPORTED_MODULE_1__["handleActions"])((_handleActions = {}, 
        _handleActions[_actions__WEBPACK_IMPORTED_MODULE_2__["addTab"]] = function(state, _ref) {
            var payload = _ref.payload;
            var index = lodash_findIndex__WEBPACK_IMPORTED_MODULE_0___default()(state.tabs, (function(t) {
                return t.id === payload.id && t.type === payload.type;
            }));
            var tabs = [].concat(state.tabs);
            if (index !== -1) {
                tabs.splice(index, 1, payload);
            } else {
                tabs = [].concat(state.tabs, [ payload ]);
            }
            return _extends({}, state, {
                tabs: tabs
            });
        }, _handleActions[_actions__WEBPACK_IMPORTED_MODULE_2__["removeTab"]] = function(state, _ref2) {
            var payload = _ref2.payload;
            return _extends({}, state, {
                tabs: state.tabs.filter((function(t) {
                    return !(t.id === payload.id && t.type === payload.type);
                }))
            });
        }, _handleActions), initialState);
    },
    "./src/interop/zimbraClassic/components/ComponentTabController.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "ComponentTabController", (function() {
            return ComponentTabController;
        }));
        var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/rxjs/_esm5/index.js");
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var ComponentTabController = function(_ZmController) {
            _inheritsLoose(ComponentTabController, _ZmController);
            var _super = _createSuper(ComponentTabController);
            function ComponentTabController(id, app) {
                var _this;
                _this = _ZmController.call(this, appCtxt.getShell(), app) || this;
                _defineProperty(_assertThisInitialized(_this), "mounted", new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](false));
                _this._id = id;
                return _this;
            }
            var _proto = ComponentTabController.prototype;
            _proto.getDefaultViewType = function getDefaultViewType() {
                return [ "tab", "preact", this._id ].join("_");
            };
            _proto._preHideCallback = function _preHideCallback() {
                _ZmController.prototype._preHideCallback.call(this);
                return true;
            };
            _proto._preUnloadCallback = function _preUnloadCallback() {
                _ZmController.prototype._preUnloadCallback.call(this);
                return true;
            };
            _proto._postHideCallback = function _postHideCallback() {
                this.mounted.next(false);
                _ZmController.prototype._postHideCallback.call(this);
                return true;
            };
            _proto._preShowCallback = function _preShowCallback() {
                _ZmController.prototype._preShowCallback.call(this);
                this.mounted.next(true);
                return true;
            };
            _proto._postRemoveCallback = function _postRemoveCallback() {
                _ZmController.prototype._postRemoveCallback.call(this);
                return true;
            };
            _proto._postShowCallback = function _postShowCallback() {
                _ZmController.prototype._postShowCallback.call(this);
                return true;
            };
            return ComponentTabController;
        }(ZmController);
    },
    "./src/interop/zimbraClassic/components/Dwt.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/zimbraClassic/components/Dwt.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/zimbraClassic/components/DwtPreactContainer.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return DwtPreactContainer;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var preact_context_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/preact-context-provider/dist/preact-context-provider.es.js");
        var _Dwt_less__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/zimbraClassic/components/Dwt.less");
        var _Dwt_less__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(_Dwt_less__WEBPACK_IMPORTED_MODULE_2__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var DwtPreactContainer = function(_DwtComposite) {
            _inheritsLoose(DwtPreactContainer, _DwtComposite);
            var _super = _createSuper(DwtPreactContainer);
            function DwtPreactContainer(params) {
                var _this;
                _this = _DwtComposite.call(this, _extends({}, params, {
                    className: "DwtComposite " + _Dwt_less__WEBPACK_IMPORTED_MODULE_2___default.a.container,
                    posStyle: Dwt.ABSOLUTE_STYLE
                })) || this;
                _defineProperty(_assertThisInitialized(_this), "preventContextMenu", (function(target) {
                    var superResult = _DwtComposite.prototype.preventContextMenu.call(_assertThisInitialized(_this), target);
                    return !(superResult === false || target.id === "team-conversation-input-text");
                }));
                _this._setAllowSelection();
                var BaseComponent = params.BaseComponent;
                if (params.mounted) {
                    _this._subcription = params.mounted.subscribe((function(mounted) {
                        if (mounted) {
                            _this._element = Object(preact__WEBPACK_IMPORTED_MODULE_0__["render"])(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_context_provider__WEBPACK_IMPORTED_MODULE_1__["default"], params.context, BaseComponent != null ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(BaseComponent, params.props) : Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", params.props)), _this.getHtmlElement());
                        } else {
                            _this._element = Object(preact__WEBPACK_IMPORTED_MODULE_0__["render"])(null, _this.getHtmlElement(), _this._element);
                        }
                    }));
                } else {
                    _this._element = Object(preact__WEBPACK_IMPORTED_MODULE_0__["render"])(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_context_provider__WEBPACK_IMPORTED_MODULE_1__["default"], params.context, BaseComponent != null ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(BaseComponent, params.props) : Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", params.props)), _this.getHtmlElement());
                }
                return _this;
            }
            var _proto = DwtPreactContainer.prototype;
            _proto.dispose = function dispose() {
                this._subcription.unsubscribe();
                _DwtComposite.prototype.dispose.call(this);
            };
            return DwtPreactContainer;
        }(DwtComposite);
    },
    "./src/interop/zimbraClassic/components/DwtTeamRouter.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return getDwtTeamRouter;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var preact_context_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/preact-context-provider/dist/preact-context-provider.es.js");
        var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/react-redux/es/index.js");
        var _Dwt_less__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/zimbraClassic/components/Dwt.less");
        var _Dwt_less__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(_Dwt_less__WEBPACK_IMPORTED_MODULE_3__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        function getDwtTeamRouter(AppRouter, store, addTab, removeTab) {
            var DwtTeamRouter = function(_DwtComposite) {
                _inheritsLoose(DwtTeamRouter, _DwtComposite);
                var _super = _createSuper(DwtTeamRouter);
                function DwtTeamRouter(params) {
                    var _this;
                    _this = _DwtComposite.call(this, _extends({}, params, {
                        className: "DwtComposite " + _Dwt_less__WEBPACK_IMPORTED_MODULE_3___default.a.container
                    })) || this;
                    _defineProperty(_assertThisInitialized(_this), "preventContextMenu", (function(target) {
                        var superResult = _DwtComposite.prototype.preventContextMenu.call(_assertThisInitialized(_this), target);
                        return !(superResult === false || target.id === "team-conversation-input-text");
                    }));
                    _this._setAllowSelection();
                    params.tabShown.subscribe((function(shown) {
                        if (shown) {
                            _this._content = Object(preact__WEBPACK_IMPORTED_MODULE_0__["render"])(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_context_provider__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                store: store,
                                addTab: addTab,
                                removeTab: removeTab
                            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(react_redux__WEBPACK_IMPORTED_MODULE_2__["Provider"], {
                                store: store
                            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AppRouter, null))), _this.getHtmlElement());
                        } else {
                            _this._content = Object(preact__WEBPACK_IMPORTED_MODULE_0__["render"])(null, _this.getHtmlElement(), _this._content);
                        }
                    }));
                    return _this;
                }
                return DwtTeamRouter;
            }(DwtComposite);
            return DwtTeamRouter;
        }
    },
    "./src/interop/zimbraClassic/getAccount.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return getAccount;
        }));
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function getAccount() {
            var getInfoResponse = appCtxt.getActiveAccount().settings.getInfoResponse;
            return {
                prefs: _extends({}, getInfoResponse.prefs._attrs),
                name: getInfoResponse.name
            };
        }
    },
    "./src/interop/zimbraClassic/index.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createContext;
        }));
        var preact_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var _style_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/zimbraClassic/style.less");
        var _style_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_style_less__WEBPACK_IMPORTED_MODULE_1__);
        var _common_createPlugins__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/common/createPlugins.js");
        var _common_createZimletRedux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/common/createZimletRedux.js");
        var _common_createStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/common/createStore.js");
        __webpack_require__.d(__webpack_exports__, "createStore", (function() {
            return _common_createStore__WEBPACK_IMPORTED_MODULE_4__["default"];
        }));
        var _getAccount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/zimbraClassic/getAccount.js");
        var _zimbra__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/interop/zimbraClassic/zimbra.js");
        var _plugins_sidebarHandler__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./src/interop/zimbraClassic/plugins/sidebarHandler.js");
        var _plugins_menuHandler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./src/interop/zimbraClassic/plugins/menuHandler.js");
        __webpack_require__.d(__webpack_exports__, "createMenuHandler", (function() {
            return _plugins_menuHandler__WEBPACK_IMPORTED_MODULE_8__["default"];
        }));
        var _plugins_appRouter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("./src/interop/zimbraClassic/plugins/appRouter.js");
        __webpack_require__.d(__webpack_exports__, "createAppRouter", (function() {
            return _plugins_appRouter__WEBPACK_IMPORTED_MODULE_9__["default"];
        }));
        var _i18n__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("./src/interop/i18n.js");
        __webpack_require__.d(__webpack_exports__, "getTranslations", (function() {
            return _i18n__WEBPACK_IMPORTED_MODULE_10__["default"];
        }));
        __webpack_require__.d(__webpack_exports__, "setLocale", (function() {
            return _i18n__WEBPACK_IMPORTED_MODULE_10__["setLocale"];
        }));
        __webpack_require__.d(__webpack_exports__, "showHideSidebar", (function() {
            return _plugins_sidebarHandler__WEBPACK_IMPORTED_MODULE_7__["showHideSidebar"];
        }));
        var _zimbraHacks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("./src/interop/zimbraClassic/zimbraHacks.js");
        __webpack_require__.d(__webpack_exports__, "applyZimbraHacks", (function() {
            return _zimbraHacks__WEBPACK_IMPORTED_MODULE_11__["default"];
        }));
        if (false) {}
        function createContext(store, registerMenuSlot, addRoutesToApp) {
            return {
                plugins: Object(_common_createPlugins__WEBPACK_IMPORTED_MODULE_2__["default"])(registerMenuSlot, addRoutesToApp, _plugins_sidebarHandler__WEBPACK_IMPORTED_MODULE_7__["default"]),
                zimletRedux: Object(_common_createZimletRedux__WEBPACK_IMPORTED_MODULE_3__["default"])(store),
                zimbraOrigin: "",
                getAccount: _getAccount__WEBPACK_IMPORTED_MODULE_5__["default"],
                Link: preact_router__WEBPACK_IMPORTED_MODULE_0__["Link"],
                route: preact_router__WEBPACK_IMPORTED_MODULE_0__["route"],
                zimbra: Object(_zimbra__WEBPACK_IMPORTED_MODULE_6__["default"])(),
                store: store
            };
        }
    },
    "./src/interop/zimbraClassic/plugins/appRouter.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createAppRouter;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var mitt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/mitt/dist/mitt.es.js");
        var preact_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var history__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/history/esm/history.js");
        var _components_DwtTeamRouter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/zimbraClassic/components/DwtTeamRouter.js");
        var _routing__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/routing/index.js");
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        function createAppRouter(store, addTab, removeTab) {
            var emitter = Object(mitt__WEBPACK_IMPORTED_MODULE_1__["default"])();
            var routerFns = [];
            var appName;
            function addRoutesToApp(routerFn, app) {
                appName = app;
                routerFns = routerFns.concat(routerFn);
                emitter.emit("plugins::changed", "slot::routes");
            }
            var AppRouter = function(_Component) {
                _inheritsLoose(AppRouter, _Component);
                var _super = _createSuper(AppRouter);
                function AppRouter() {
                    var _this;
                    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                        args[_key] = arguments[_key];
                    }
                    _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                    _defineProperty(_assertThisInitialized(_this), "_history", Object(history__WEBPACK_IMPORTED_MODULE_3__["createMemoryHistory"])({
                        initialEntries: [ Object(_routing__WEBPACK_IMPORTED_MODULE_5__["getLastUrlPath"])() ]
                    }));
                    _defineProperty(_assertThisInitialized(_this), "state", {
                        routerFns: routerFns
                    });
                    _defineProperty(_assertThisInitialized(_this), "_updateRoutes", (function(name) {
                        if (name === "slot::routes") {
                            _this.setState((function() {
                                return {
                                    routerFns: routerFns
                                };
                            }));
                        }
                    }));
                    return _this;
                }
                var _proto = AppRouter.prototype;
                _proto.getChildContext = function getChildContext() {
                    return {
                        history: this._history,
                        appName: appName
                    };
                };
                _proto.componentWillMount = function componentWillMount() {
                    emitter.on("plugins::changed", this._updateRoutes);
                };
                _proto.componentDidMount = function componentDidMount() {
                    emitter.on("plugins::changed", this._updateRoutes);
                };
                _proto.render = function render(props, state, context) {
                    var children = [];
                    for (var i = 0; i < state.routerFns.length; i++) {
                        children = children.concat(state.routerFns[i]());
                    }
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_router__WEBPACK_IMPORTED_MODULE_2__["Router"], {
                        history: this._history,
                        url: Object(_routing__WEBPACK_IMPORTED_MODULE_5__["getLastUrlPath"])()
                    }, children);
                };
                return AppRouter;
            }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
            return {
                addRoutesToApp: addRoutesToApp,
                DwtTeamRouter: Object(_components_DwtTeamRouter__WEBPACK_IMPORTED_MODULE_4__["default"])(AppRouter, store, addTab, removeTab)
            };
        }
    },
    "./src/interop/zimbraClassic/plugins/menuHandler.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return createMenuHandler;
        }));
        var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
        var _components_ComponentTabController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/zimbraClassic/components/ComponentTabController.js");
        var _components_DwtPreactContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/zimbraClassic/components/DwtPreactContainer.js");
        var _common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/common/store/navigation/actions.js");
        function createMenuHandler(store, zimletContext) {
            var apps = {};
            var appName = void 0;
            var tabControllers = {};
            var tabDataCache = {};
            var tabs = [];
            store.subscribe((function() {
                var storeTabs = store.getState().navigation.tabs;
                Object(lodash__WEBPACK_IMPORTED_MODULE_0__["forEach"])(tabs, (function(tab) {
                    if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["find"])(storeTabs, (function(stab) {
                        return stab.id === tab.id;
                    })) == null) {
                        _removeTab(tab);
                    }
                }));
                Object(lodash__WEBPACK_IMPORTED_MODULE_0__["forEach"])(storeTabs, (function(stab) {
                    if (Object(lodash__WEBPACK_IMPORTED_MODULE_0__["find"])(tabs, (function(tab) {
                        return stab.id === tab.id;
                    })) == null) {
                        _createTab(stab);
                    }
                }));
                tabs.length = 0;
                tabs.push.apply(tabs, storeTabs);
            }));
            function registerMenuSlot(el) {
                apps[el.label] = appName = zimletContext.createApp(el.label, el.icon, "", 5);
                if (el.count) el.count.subscribe((function(count) {
                    var controller = appCtxt.getAppController();
                    var appChooser = controller.getAppChooser();
                    var appButton = appChooser.getButton(apps[el.label]);
                    if (count > 0) {
                        appButton.setText(el.label + " (" + count + ")");
                        if (appCtxt.getCurrentAppName() !== apps[el.label]) appButton.addClassName("ZAlert");
                    } else {
                        appButton.setText("" + el.label);
                        appButton.delClassName("ZAlert");
                    }
                }));
                return appName;
            }
            function addTab(tab, BaseComponent, props, context) {
                if (tabDataCache.hasOwnProperty(tab.id)) {
                    appCtxt.getAppViewMgr().pushView(tab.id);
                    return;
                }
                tabDataCache[tab.id] = {
                    tab: tab,
                    BaseComponent: BaseComponent,
                    props: props,
                    context: context
                };
                store.dispatch(Object(_common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__["addTab"])(tab));
            }
            function removeTab(tab) {
                store.dispatch(Object(_common_store_navigation_actions__WEBPACK_IMPORTED_MODULE_3__["removeTab"])(tab));
                delete tabDataCache[tab.id];
            }
            function _createTab(tab) {
                var BaseComponent = tabDataCache[tab.id].BaseComponent;
                var props = tabDataCache[tab.id].props;
                var context = tabDataCache[tab.id].context;
                var app = appCtxt.getApp(appName);
                var callTabController;
                if (!tabControllers.hasOwnProperty(tab.id)) {
                    var _callbacks, _elements;
                    callTabController = tabControllers[tab.id] = new _components_ComponentTabController__WEBPACK_IMPORTED_MODULE_1__["ComponentTabController"](tab.id, app);
                    var container = new _components_DwtPreactContainer__WEBPACK_IMPORTED_MODULE_2__["default"]({
                        parent: appCtxt.getShell(),
                        mounted: callTabController.mounted,
                        BaseComponent: BaseComponent,
                        props: props,
                        context: context
                    });
                    app.createView({
                        callbacks: (_callbacks = {}, _callbacks[ZmAppViewMgr.CB_PRE_HIDE] = callTabController._preHideCallback.bind(callTabController), 
                        _callbacks[ZmAppViewMgr.CB_PRE_UNLOAD] = callTabController._preUnloadCallback.bind(callTabController), 
                        _callbacks[ZmAppViewMgr.CB_POST_HIDE] = callTabController._postHideCallback.bind(callTabController), 
                        _callbacks[ZmAppViewMgr.CB_POST_REMOVE] = callTabController._postRemoveCallback.bind(callTabController), 
                        _callbacks[ZmAppViewMgr.CB_PRE_SHOW] = callTabController._preShowCallback.bind(callTabController), 
                        _callbacks[ZmAppViewMgr.CB_POST_SHOW] = callTabController._postShowCallback.bind(callTabController), 
                        _callbacks),
                        controller: callTabController,
                        elements: (_elements = {}, _elements[ZmAppViewMgr.C_APP_CONTENT] = container, _elements),
                        hide: [ ZmAppViewMgr.C_TOOLBAR_TOP ].concat(ZmAppViewMgr.LEFT_NAV),
                        tabParams: {
                            hoverImage: "Close",
                            id: tab.id,
                            image: "CloseGray",
                            style: DwtLabel.IMAGE_RIGHT,
                            text: tab.title,
                            textPrecedence: 75
                        },
                        viewId: callTabController.getDefaultViewType(),
                        viewType: callTabController.getDefaultViewType()
                    });
                }
                app.pushView(tabControllers[tab.id].getDefaultViewType());
            }
            function _removeTab(tab) {
                if (tabDataCache.hasOwnProperty(tab.id)) {
                    delete tabDataCache[tab.id];
                }
                appCtxt.getAppViewMgr().stageView(appName);
                appCtxt.getAppViewMgr().popView(false, tabControllers[tab.id].getDefaultViewType());
            }
            return {
                registerMenuSlot: registerMenuSlot,
                addTab: addTab,
                removeTab: removeTab
            };
        }
    },
    "./src/interop/zimbraClassic/plugins/sidebarHandler.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return addComponentToSidebar;
        }));
        __webpack_require__.d(__webpack_exports__, "showHideSidebar", (function() {
            return showHideSidebar;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/rxjs/_esm5/index.js");
        var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/lodash/lodash.js");
        var lodash__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
        var _components_DwtPreactContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/zimbraClassic/components/DwtPreactContainer.js");
        var preact_context_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/preact-context-provider/dist/preact-context-provider.es.js");
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var isSidebarVisible = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](true);
        var DivComponentWrapper = function(_Component) {
            _inheritsLoose(DivComponentWrapper, _Component);
            var _super = _createSuper(DivComponentWrapper);
            function DivComponentWrapper() {
                var _this;
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                    args[_key] = arguments[_key];
                }
                _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                _defineProperty(_assertThisInitialized(_this), "state", {
                    mount: true
                });
                _defineProperty(_assertThisInitialized(_this), "_subscriptions", []);
                return _this;
            }
            var _proto = DivComponentWrapper.prototype;
            _proto.componentDidMount = function componentDidMount() {
                var _this2 = this;
                this._subscriptions.push(this.props.isSidebarVisible.subscribe((function(show) {
                    return _this2.setState((function() {
                        return {
                            mount: show
                        };
                    }));
                })));
            };
            _proto.componentWillUnmount = function componentWillUnmount() {
                Object(lodash__WEBPACK_IMPORTED_MODULE_2__["forEach"])(this._subscriptions, (function(subscription) {
                    subscription.unsubscribe();
                }));
                this._subscriptions = [];
            };
            _proto.render = function render(_ref, _ref2) {
                var children = _ref.children;
                var mount = _ref2.mount;
                if (mount) return children;
                return null;
            };
            return DivComponentWrapper;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
        function addComponentToSidebar(ComponentClass, appName) {
            Object(preact__WEBPACK_IMPORTED_MODULE_0__["render"])(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(DivComponentWrapper, {
                isSidebarVisible: isSidebarVisible
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_context_provider__WEBPACK_IMPORTED_MODULE_4__["default"], {
                appName: appName
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(ComponentClass, null))), document.getElementById("skin_container_sidebar_ad"));
            new _components_DwtPreactContainer__WEBPACK_IMPORTED_MODULE_3__["default"]({
                parent: appCtxt.getShell(),
                BaseComponent: WindowChatContainer
            });
        }
        var WindowChatContainer = function(_Component2) {
            _inheritsLoose(WindowChatContainer, _Component2);
            var _super2 = _createSuper(WindowChatContainer);
            function WindowChatContainer() {
                return _Component2.apply(this, arguments) || this;
            }
            var _proto2 = WindowChatContainer.prototype;
            _proto2.shouldComponentUpdate = function shouldComponentUpdate() {
                return false;
            };
            _proto2.render = function render() {
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                    id: "DwtWindowChatListContainer"
                });
            };
            return WindowChatContainer;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
        function showHideSidebar(show) {
            isSidebarVisible.next(show);
            var tdElement = document.getElementById("skin_td_sidebar_ad");
            var container = document.getElementById("skin_container_sidebar_ad");
            if (tdElement != null) {
                tdElement.className = show ? "skin_layout_cell" : "skin_outer_ad skin_layout_cell";
                tdElement.style.width = 50 + 10 + "px";
            }
            if (container != null) {
                container.style.paddingLeft = "6px";
                container.style.width = 50 + 2 + "px";
            }
            appCtxt.getShell()._currWinSize.x = 0;
            appCtxt.getShell()._currWinSize.y = 0;
            if (appCtxt.getShell().isListenerRegistered(DwtEvent.CONTROL)) {
                var controlEvent = DwtShell.controlEvent;
                controlEvent.reset();
                controlEvent.oldWidth = appCtxt.getShell()._currWinSize.x;
                controlEvent.oldHeight = appCtxt.getShell()._currWinSize.y;
                appCtxt.getShell()._currWinSize = Dwt.getWindowSize();
                controlEvent.newWidth = appCtxt.getShell()._currWinSize.x;
                controlEvent.newHeight = appCtxt.getShell()._currWinSize.y;
                appCtxt.getShell().notifyListeners(DwtEvent.CONTROL, controlEvent);
            } else {
                appCtxt.getShell()._currWinSize = Dwt.getWindowSize();
            }
            try {
                appCtxt.getCalManager().getCalViewController().getViewMgr().getCurrentView().updateTimeIndicator();
            } catch (ignore) {}
        }
    },
    "./src/interop/zimbraClassic/style.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/zimbraClassic/style.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/zimbraClassic/zimbra.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return zimbra;
        }));
        function zimbra() {
            return {
                jsonRequest: function jsonRequest(requestName, body, options) {
                    switch (requestName) {
                      case "GetInfoRequest":
                        {
                            return new Promise((function(resolve, reject) {
                                var callback = function callback(response) {
                                    if (response._isException === false) {
                                        resolve({
                                            props: response._data.GetInfoResponse.props.prop
                                        });
                                    } else {
                                        reject();
                                    }
                                };
                                var soapDoc = AjxSoapDoc.create("GetInfoRequest", "urn:zimbraAccount");
                                var params = {
                                    asyncMode: true,
                                    callback: callback,
                                    noAuthToken: true,
                                    sensitive: false,
                                    soapDoc: soapDoc
                                };
                                appCtxt.getAppController().sendRequest(params);
                            }));
                        }

                      case "ModifyPropertiesRequest":
                        {
                            return new Promise((function(resolve, reject) {
                                var callback = function callback(response) {
                                    if (response._isException === false) {
                                        resolve({});
                                    } else {
                                        reject();
                                    }
                                };
                                var soapDoc = AjxSoapDoc.create("ModifyPropertiesRequest", "urn:zimbraAccount");
                                var p = soapDoc.set("prop", body.prop._content);
                                p.setAttribute("zimlet", body.prop.zimlet);
                                p.setAttribute("name", body.prop.name);
                                var params = {
                                    asyncMode: true,
                                    callback: callback,
                                    noAuthToken: true,
                                    sensitive: false,
                                    soapDoc: soapDoc
                                };
                                appCtxt.getAppController().sendRequest(params);
                            }));
                        }

                      default:
                        {
                            throw new Error;
                        }
                    }
                }
            };
        }
    },
    "./src/interop/zimbraClassic/zimbraHacks.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return applyZimbraHacks;
        }));
        function applyZimbraHacks() {
            if (window.__zimbraUiHacksApplied) {
                return;
            }
            window.__zimbraUiHacksApplied = true;
            if (typeof window !== "undefined" && typeof window.DwtKeyMapMgr !== "undefined") {
                window.DwtKeyMapMgr.isInputElement = function(element) {
                    if (!element) {
                        return false;
                    }
                    var dm = element.ownerDocument ? element.ownerDocument.designMode : null;
                    if (dm && dm.toLowerCase() === "on") {
                        return true;
                    }
                    var tag = element.tagName.toUpperCase();
                    return tag === "INPUT" || tag === "TEXTAREA" || tag === "DIV" && element.contentEditable && element.contentEditable.toUpperCase() === "TRUE";
                };
            }
        }
    },
    "./src/routing/index.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "getMainPath", (function() {
            return getMainPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getLastUrlPath", (function() {
            return getLastUrlPath;
        }));
        __webpack_require__.d(__webpack_exports__, "setLastUrl", (function() {
            return setLastUrl;
        }));
        __webpack_require__.d(__webpack_exports__, "setLastUrlWithParams", (function() {
            return setLastUrlWithParams;
        }));
        __webpack_require__.d(__webpack_exports__, "lastUrl", (function() {
            return lastUrl;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToMainPath", (function() {
            return routeToMainPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getConversationPath", (function() {
            return getConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToConversationPath", (function() {
            return routeToConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getMeetingPath", (function() {
            return getMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToMeetingPath", (function() {
            return routeToMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToMeetingPathWithoutShowInfo", (function() {
            return routeToMeetingPathWithoutShowInfo;
        }));
        __webpack_require__.d(__webpack_exports__, "getMeetingPathWithoutShowInfo", (function() {
            return getMeetingPathWithoutShowInfo;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToInviteToGroupPath", (function() {
            return routeToInviteToGroupPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getSpacePath", (function() {
            return getSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToSpacePath", (function() {
            return routeToSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToInviteToSpacePath", (function() {
            return routeToInviteToSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "getChannelPath", (function() {
            return getChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToChannelPath", (function() {
            return routeToChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewConversationPath", (function() {
            return getNewConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewConversationPath", (function() {
            return routeToNewConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewConversationPathWithSearchParam", (function() {
            return routeToNewConversationPathWithSearchParam;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewConversationPathWithSearchParam", (function() {
            return getNewConversationPathWithSearchParam;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewGroupPath", (function() {
            return getNewGroupPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewGroupPath", (function() {
            return routeToNewGroupPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewSpacePath", (function() {
            return getNewSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewSpacePath", (function() {
            return routeToNewSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewChannelPath", (function() {
            return getNewChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewChannelPath", (function() {
            return routeToNewChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewInstantMeetingPath", (function() {
            return getNewInstantMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewInstantMeetingPath", (function() {
            return routeToNewInstantMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getLoginPath", (function() {
            return getLoginPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToLoginPath", (function() {
            return routeToLoginPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getLoadingPath", (function() {
            return getLoadingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToLoadingPath", (function() {
            return routeToLoadingPath;
        }));
        var preact_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/query-string/index.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_1__);
        var _paths__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/routing/paths.js");
        function addQueryParams(customParams) {
            if (customParams === void 0) {
                customParams = {};
            }
            customParams.dev = Object(query_string__WEBPACK_IMPORTED_MODULE_1__["parse"])(window.parent.location.search).dev;
            return "?" + Object(query_string__WEBPACK_IMPORTED_MODULE_1__["stringify"])(customParams);
        }
        function getMainPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MAIN + addQueryParams();
        }
        function getLastUrlPath() {
            if (lastUrl != null) {
                return lastUrl;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MAIN + addQueryParams();
        }
        function setLastUrl(url) {
            lastUrl = url;
        }
        function setLastUrlWithParams(url, customParams) {
            lastUrl = url + Object(query_string__WEBPACK_IMPORTED_MODULE_1__["stringify"])(customParams);
        }
        var lastUrl;
        function routeToMainPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getMainPath());
        }
        function getConversationPath(conversationId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().CONVERSATION.replace(":conversationId", encodeURIComponent(conversationId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToConversationPath(conversationId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getConversationPath(conversationId, showInfo));
        }
        function getMeetingPath(meetingId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MEETING.replace(":meetingId", encodeURIComponent(meetingId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToMeetingPath(meetingId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getMeetingPath(meetingId, showInfo));
        }
        function routeToMeetingPathWithoutShowInfo(meetingId) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getMeetingPathWithoutShowInfo(meetingId));
        }
        function getMeetingPathWithoutShowInfo(meetingId) {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MEETING.replace(":meetingId", encodeURIComponent(meetingId));
        }
        function routeToInviteToGroupPath(conversationId) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().INVITE.GROUP.replace(":conversationId", encodeURIComponent(conversationId)));
        }
        function getSpacePath(spaceId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().CHANNEL.replace(":spaceId", encodeURIComponent(spaceId)).replace(":channelId", encodeURIComponent(spaceId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToSpacePath(spaceId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getSpacePath(spaceId, showInfo));
        }
        function routeToInviteToSpacePath(spaceId) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().INVITE.SPACE.replace(":spaceId", encodeURIComponent(spaceId)).replace(":channelId", encodeURIComponent(spaceId)));
        }
        function getChannelPath(spaceId, channelId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().CHANNEL.replace(":spaceId", encodeURIComponent(spaceId)).replace(":channelId", encodeURIComponent(channelId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToChannelPath(spaceId, channelId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getChannelPath(spaceId, channelId, showInfo));
        }
        function getNewConversationPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.CONVERSATION + addQueryParams();
        }
        function routeToNewConversationPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewConversationPath());
        }
        function routeToNewConversationPathWithSearchParam(searchParam) {
            if (searchParam === void 0) {
                searchParam = "";
            }
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewConversationPathWithSearchParam(searchParam));
        }
        function getNewConversationPathWithSearchParam(searchParam) {
            if (searchParam === void 0) {
                searchParam = "";
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.CONVERSATION + addQueryParams({
                searchParam: searchParam
            });
        }
        function getNewGroupPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.GROUP + addQueryParams();
        }
        function routeToNewGroupPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewGroupPath());
        }
        function getNewSpacePath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.SPACE + addQueryParams();
        }
        function routeToNewSpacePath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewSpacePath());
        }
        function getNewChannelPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.CHANNEL + addQueryParams();
        }
        function routeToNewChannelPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewChannelPath());
        }
        function getNewInstantMeetingPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.INSTANTMEETING + addQueryParams();
        }
        function routeToNewInstantMeetingPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewInstantMeetingPath());
        }
        function getLoginPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().LOGIN + addQueryParams();
        }
        function routeToLoginPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getLoginPath());
        }
        function getLoadingPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().LOADING + addQueryParams();
        }
        function routeToLoadingPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getLoadingPath());
        }
    }
} ]);
//# sourceMappingURL=11.5efb4a92.chunk.js.map