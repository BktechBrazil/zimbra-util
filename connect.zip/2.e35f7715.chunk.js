(window["com_zimbra_connect_classic_jsonp"] = window["com_zimbra_connect_classic_jsonp"] || []).push([ [ 2 ], {
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionButton.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, '@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n.\\[1\\]_\\[2\\]_button{\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  font-weight:regular;\n  display:inline-block;\n  position:relative;\n  -webkit-box-sizing:border-box;\n          box-sizing:border-box;\n  padding:0 14px;\n  height:48px;\n  background:rgba(0, 0, 0, 0);\n  border:0;\n  text-decoration:none;\n  font-size:100%;\n  color:#4d4d4d;\n  white-space:nowrap;\n  -webkit-transition:all 200ms ease;\n  transition:all 200ms ease;\n  -webkit-appearance:none;\n     -moz-appearance:none;\n          appearance:none;\n  -webkit-user-select:none;\n     -moz-user-select:none;\n      -ms-user-select:none;\n          user-select:none;\n  cursor:pointer;\n  overflow:hidden;\n}\n.\\[1\\]_\\[2\\]_button:hover,\n.\\[1\\]_\\[2\\]_button:focus{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_button:disabled{\n  opacity:0.4;\n  cursor:default;\n}\n.\\[1\\]_\\[2\\]_button:disabled:hover{\n  color:#4d4d4d;\n}\n.\\[1\\]_\\[2\\]_button > .\\[1\\]_\\[2\\]_icon{\n  color:#0088c1;\n  position:relative;\n  vertical-align:middle;\n  display:inline-block;\n  line-height:1;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_monotone > .\\[1\\]_\\[2\\]_icon{\n  color:inherit;\n}\n.\\[1\\]_\\[2\\]_button > .\\[1\\]_\\[2\\]_icon + .\\[1\\]_\\[2\\]_text{\n  margin-left:6px;\n}\n', "", {
            version: 3,
            sources: [ "ActionButton.less" ],
            names: [],
            mappings: "AAAA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE,kDAAmD;EACnD,mBAAoB;EACpB,oBAAqB;EACrB,iBAAkB;EAClB,6BAAsB;UAAtB,qBAAsB;EACtB,cAAe;EACf,WAAY;EACZ,2BAA4B;EAC5B,QAAS;EACT,oBAAqB;EACrB,cAAe;EACf,aAAc;EACd,kBAAmB;EACnB,iCAA0B;EAA1B,yBAA0B;EAC1B,uBAAgB;KAAhB,oBAAgB;UAAhB,eAAgB;EAChB,wBAAiB;KAAjB,qBAAiB;MAAjB,oBAAiB;UAAjB,gBAAiB;EACjB,cAAe;EACf,eAAgB;AAClB;AACA;;EAEE,aAAc;AAChB;AACA;EACE,WAAY;EACZ,cAAe;AACjB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;EACd,iBAAkB;EAClB,qBAAsB;EACtB,oBAAqB;EACrB,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,eAAgB;AAClB",
            file: "ActionButton.less",
            sourcesContent: [ '@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n.button {\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  font-weight: regular;\n  display: inline-block;\n  position: relative;\n  box-sizing: border-box;\n  padding: 0 14px;\n  height: 48px;\n  background: rgba(0, 0, 0, 0);\n  border: 0;\n  text-decoration: none;\n  font-size: 100%;\n  color: #4d4d4d;\n  white-space: nowrap;\n  transition: all 200ms ease;\n  appearance: none;\n  user-select: none;\n  cursor: pointer;\n  overflow: hidden;\n}\n.button:hover,\n.button:focus {\n  color: #0088c1;\n}\n.button:disabled {\n  opacity: 0.4;\n  cursor: default;\n}\n.button:disabled:hover {\n  color: #4d4d4d;\n}\n.button > .icon {\n  color: #0088c1;\n  position: relative;\n  vertical-align: middle;\n  display: inline-block;\n  line-height: 1;\n}\n.button.monotone > .icon {\n  color: inherit;\n}\n.button > .icon + .text {\n  margin-left: 6px;\n}\n' ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            button: "[1]_[2]_button",
            icon: "[1]_[2]_icon",
            monotone: "[1]_[2]_monotone",
            text: "[1]_[2]_text"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionMenu.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, ".\\[1\\]_\\[2\\]_dropdown{\n  min-width:250px;\n}\n.\\[1\\]_\\[2\\]_label{\n  font-size:13px;\n}\n.\\[1\\]_\\[2\\]_smallLabel{\n  font-size:11px;\n}\n.\\[1\\]_\\[2\\]_toggle:disabled{\n  opacity:1;\n}\n", "", {
            version: 3,
            sources: [ "ActionMenu.less" ],
            names: [],
            mappings: "AAAA;EACE,eAAgB;AAClB;AACA;EACE,cAAe;AACjB;AACA;EACE,cAAe;AACjB;AACA;EACE,SAAU;AACZ",
            file: "ActionMenu.less",
            sourcesContent: [ ".dropdown {\n  min-width: 250px;\n}\n.label {\n  font-size: 13px;\n}\n.smallLabel {\n  font-size: 11px;\n}\n.toggle:disabled {\n  opacity: 1;\n}\n" ]
        } ]);
        exports.locals = {
            dropdown: "[1]_[2]_dropdown",
            label: "[1]_[2]_label",
            smallLabel: "[1]_[2]_smallLabel",
            toggle: "[1]_[2]_toggle"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionMenuGroup.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, "@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n.\\[1\\]_\\[2\\]_group{\n  padding:8px 0;\n  border-bottom:1px solid #d9d9d9;\n}\n.\\[1\\]_\\[2\\]_group:last-child{\n  border-bottom:0;\n}\n", "", {
            version: 3,
            sources: [ "ActionMenuGroup.less" ],
            names: [],
            mappings: "AAAA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE,aAAc;EACd,+BAAgC;AAClC;AACA;EACE,eAAgB;AAClB",
            file: "ActionMenuGroup.less",
            sourcesContent: [ "@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n.group {\n  padding: 8px 0;\n  border-bottom: 1px solid #d9d9d9;\n}\n.group:last-child {\n  border-bottom: 0;\n}\n" ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            group: "[1]_[2]_group"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionMenuItem.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, '@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n.\\[1\\]_\\[2\\]_item{\n  position:relative;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  padding:8px 32px;\n  line-height:1.3;\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  border:none;\n  min-width:150px;\n}\n.\\[1\\]_\\[2\\]_item .\\[1\\]_\\[2\\]_icon{\n  position:absolute;\n  left:4px;\n}\n.\\[1\\]_\\[2\\]_item.\\[1\\]_\\[2\\]_narrow{\n  padding-left:16px;\n  padding-right:16px;\n}\n.\\[1\\]_\\[2\\]_item.\\[1\\]_\\[2\\]_disabled:hover{\n  background:transparent;\n  border:none;\n  cursor:default;\n  text-decoration:none;\n}\n.\\[1\\]_\\[2\\]_item:not(.\\[1\\]_\\[2\\]_disabled):focus,\n.\\[1\\]_\\[2\\]_item:not(.\\[1\\]_\\[2\\]_disabled):hover{\n  border:none;\n  background:#f2f2f2;\n}\n', "", {
            version: 3,
            sources: [ "ActionMenuItem.less" ],
            names: [],
            mappings: "AAAA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE,iBAAkB;EAClB,mBAAa;EAAb,oBAAa;EAAb,mBAAa;EAAb,YAAa;EACb,gBAAiB;EACjB,eAAgB;EAChB,kDAAmD;EACnD,WAAY;EACZ,eAAgB;AAClB;AACA;EACE,iBAAkB;EAClB,QAAS;AACX;AACA;EACE,iBAAkB;EAClB,kBAAmB;AACrB;AACA;EACE,sBAAuB;EACvB,WAAY;EACZ,cAAe;EACf,oBAAqB;AACvB;AACA;;EAEE,WAAY;EACZ,kBAAmB;AACrB",
            file: "ActionMenuItem.less",
            sourcesContent: [ '@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n.item {\n  position: relative;\n  display: flex;\n  padding: 8px 32px;\n  line-height: 1.3;\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  border: none;\n  min-width: 150px;\n}\n.item .icon {\n  position: absolute;\n  left: 4px;\n}\n.item.narrow {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n.item.disabled:hover {\n  background: transparent;\n  border: none;\n  cursor: default;\n  text-decoration: none;\n}\n.item:not(.disabled):focus,\n.item:not(.disabled):hover {\n  border: none;\n  background: #f2f2f2;\n}\n' ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            item: "[1]_[2]_item",
            icon: "[1]_[2]_icon",
            narrow: "[1]_[2]_narrow",
            disabled: "[1]_[2]_disabled"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Button.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, "button{\n  cursor:pointer;\n  background:none;\n  border:none;\n  -webkit-user-select:none;\n     -moz-user-select:none;\n      -ms-user-select:none;\n          user-select:none;\n}\na[role='button']{\n  display:inline-block;\n  -webkit-user-select:none;\n     -moz-user-select:none;\n      -ms-user-select:none;\n          user-select:none;\n}\na[role='button']:hover,\na[role='button']:focus{\n  text-decoration:none;\n}\n.\\[1\\]_\\[2\\]_button{\n  border:solid 1px transparent;\n  border-radius:3px;\n  font-size:100%;\n  line-height:1;\n  margin:5px;\n  background-color:#f2f2f2;\n  color:#4d4d4d;\n  height:auto;\n}\n.\\[1\\]_\\[2\\]_button:disabled{\n  opacity:0.4;\n  pointer-events:none;\n}\n.\\[1\\]_\\[2\\]_button .\\[1\\]_\\[2\\]_icon{\n  display:inline-block;\n  vertical-align:top;\n}\n.\\[1\\]_\\[2\\]_button .\\[1\\]_\\[2\\]_icon.\\[1\\]_\\[2\\]_left{\n  margin-right:5px;\n}\n.\\[1\\]_\\[2\\]_button .\\[1\\]_\\[2\\]_icon.\\[1\\]_\\[2\\]_right{\n  margin-left:5px;\n}\n.\\[1\\]_\\[2\\]_button:not(:disabled):hover,\n.\\[1\\]_\\[2\\]_button:not(:disabled):focus{\n  background-color:#e5e5e5;\n  cursor:pointer;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary{\n  background-color:#0568ae;\n  color:#fff;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary.\\[1\\]_\\[2\\]_brand-primary{\n  background-color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary.\\[1\\]_\\[2\\]_brand-success{\n  background-color:#007a3e;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary.\\[1\\]_\\[2\\]_brand-info{\n  background-color:#5bc0de;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary.\\[1\\]_\\[2\\]_brand-warning{\n  background-color:#ffb81c;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary.\\[1\\]_\\[2\\]_brand-danger{\n  background-color:#cf2a2a;\n  color:#fff;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):hover,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):focus{\n  background-color:#0677c7;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-primary,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-primary{\n  background-color:#009adb;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-success,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-success{\n  background-color:#00944b;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-info,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-info{\n  background-color:#70c8e2;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-warning,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-warning{\n  background-color:#ffc036;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-danger,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_primary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-danger{\n  background-color:#d73b3b;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary{\n  background-color:transparent;\n  border-color:#0568ae;\n  color:#0568ae;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary.\\[1\\]_\\[2\\]_brand-primary{\n  color:#0088c1;\n  border-color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary.\\[1\\]_\\[2\\]_brand-success{\n  color:#007a3e;\n  border-color:#007a3e;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary.\\[1\\]_\\[2\\]_brand-info{\n  color:#5bc0de;\n  border-color:#5bc0de;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary.\\[1\\]_\\[2\\]_brand-warning{\n  color:#ffb81c;\n  border-color:#ffb81c;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary.\\[1\\]_\\[2\\]_brand-danger{\n  color:#cf2a2a;\n  border-color:#cf2a2a;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):hover,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):focus{\n  background-color:#0568ae;\n  color:#fff;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-primary,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-primary{\n  background-color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-success,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-success{\n  background-color:#007a3e;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-info,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-info{\n  background-color:#5bc0de;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-warning,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-warning{\n  background-color:#ffb81c;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):hover.\\[1\\]_\\[2\\]_brand-danger,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_secondary:not(:disabled):focus.\\[1\\]_\\[2\\]_brand-danger{\n  background-color:#cf2a2a;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating{\n  background-color:transparent;\n  border-color:transparent;\n  color:#0568ae;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating.\\[1\\]_\\[2\\]_brand-primary{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating.\\[1\\]_\\[2\\]_brand-success{\n  color:#007a3e;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating.\\[1\\]_\\[2\\]_brand-info{\n  color:#5bc0de;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating.\\[1\\]_\\[2\\]_brand-warning{\n  color:#ffb81c;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating.\\[1\\]_\\[2\\]_brand-danger{\n  color:#cf2a2a;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating:not(:disabled):hover,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating:not(:disabled):focus{\n  text-decoration:underline;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating:not(:disabled):hover .\\[1\\]_\\[2\\]_icon,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_floating:not(:disabled):focus .\\[1\\]_\\[2\\]_icon{\n  text-decoration:none;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_tertiary{\n  background-color:#fff;\n  color:#333333;\n  border-color:#fff;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_tertiary:not(:disabled):hover,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_tertiary:not(:disabled):focus{\n  background-color:#d9d9d9;\n  border-color:#d9d9d9;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_text{\n  border:0;\n  background-color:inherit;\n  color:#0568ae;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_text:hover,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_text:focus{\n  background-color:inherit;\n  color:inherit;\n  border:0;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText{\n  border:0;\n  background-color:inherit;\n  color:#0568ae;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText.\\[1\\]_\\[2\\]_brand-primary{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText.\\[1\\]_\\[2\\]_brand-success{\n  color:#007a3e;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText.\\[1\\]_\\[2\\]_brand-info{\n  color:#5bc0de;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText.\\[1\\]_\\[2\\]_brand-warning{\n  color:#ffb81c;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText.\\[1\\]_\\[2\\]_brand-danger{\n  color:#cf2a2a;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText:hover,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_coloredText:focus{\n  background-color:inherit;\n  color:inherit;\n  border:0;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_alignLeft{\n  margin-left:0;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_regular{\n  padding:8px 23px;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_regular.\\[1\\]_\\[2\\]_floating{\n  padding:8px;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_regular.\\[1\\]_\\[2\\]_text,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_regular.\\[1\\]_\\[2\\]_coloredText{\n  padding:0;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_large{\n  font-size:115%;\n  padding:12px 44px;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_large.\\[1\\]_\\[2\\]_floating{\n  padding:14px;\n}\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_large.\\[1\\]_\\[2\\]_text,\n.\\[1\\]_\\[2\\]_button.\\[1\\]_\\[2\\]_large.\\[1\\]_\\[2\\]_coloredText{\n  padding:0;\n}\n", "", {
            version: 3,
            sources: [ "Button.less" ],
            names: [],
            mappings: "AAUA;EACE,cAAe;EACf,eAAgB;EAChB,WAAY;EACZ,wBAAiB;KAAjB,qBAAiB;MAAjB,oBAAiB;UAAjB,gBAAiB;AACnB;AACA;EACE,oBAAqB;EACrB,wBAAiB;KAAjB,qBAAiB;MAAjB,oBAAiB;UAAjB,gBAAiB;AACnB;AACA;;EAEE,oBAAqB;AACvB;AACA;EACE,4BAA6B;EAC7B,iBAAkB;EAClB,cAAe;EACf,aAAc;EACd,UAAW;EACX,wBAAyB;EACzB,aAAc;EACd,WAAY;AACd;AACA;EACE,WAAY;EACZ,mBAAoB;AACtB;AACA;EACE,oBAAqB;EACrB,kBAAmB;AACrB;AACA;EACE,gBAAiB;AACnB;AACA;EACE,eAAgB;AAClB;AACA;;EAEE,wBAAyB;EACzB,cAAe;AACjB;AACA;EACE,wBAAyB;EACzB,UAAW;AACb;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;AAC3B;AACA;EACE,wBAAyB;EACzB,UAAW;AACb;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;EACE,4BAA6B;EAC7B,oBAAqB;EACrB,aAAc;AAChB;AACA;EACE,aAAc;EACd,oBAAqB;AACvB;AACA;EACE,aAAc;EACd,oBAAqB;AACvB;AACA;EACE,aAAc;EACd,oBAAqB;AACvB;AACA;EACE,aAAc;EACd,oBAAqB;AACvB;AACA;EACE,aAAc;EACd,oBAAqB;AACvB;AACA;;EAEE,wBAAyB;EACzB,UAAW;AACb;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;;EAEE,wBAAyB;AAC3B;AACA;EACE,4BAA6B;EAC7B,wBAAyB;EACzB,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;;EAEE,yBAA0B;AAC5B;AACA;;EAEE,oBAAqB;AACvB;AACA;EACE,qBAAsB;EACtB,aAAc;EACd,iBAAkB;AACpB;AACA;;EAEE,wBAAyB;EACzB,oBAAqB;AACvB;AACA;EACE,QAAS;EACT,wBAAyB;EACzB,aAAc;AAChB;AACA;;EAEE,wBAAyB;EACzB,aAAc;EACd,QAAS;AACX;AACA;EACE,QAAS;EACT,wBAAyB;EACzB,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;EACE,aAAc;AAChB;AACA;;EAEE,wBAAyB;EACzB,aAAc;EACd,QAAS;AACX;AACA;EACE,aAAc;AAChB;AACA;EACE,gBAAiB;AACnB;AACA;EACE,WAAY;AACd;AACA;;EAEE,SAAU;AACZ;AACA;EACE,cAAe;EACf,iBAAkB;AACpB;AACA;EACE,YAAa;AACf;AACA;;EAEE,SAAU;AACZ",
            file: "Button.less",
            sourcesContent: [ "/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\nbutton {\n  cursor: pointer;\n  background: none;\n  border: none;\n  user-select: none;\n}\na[role='button'] {\n  display: inline-block;\n  user-select: none;\n}\na[role='button']:hover,\na[role='button']:focus {\n  text-decoration: none;\n}\n.button {\n  border: solid 1px transparent;\n  border-radius: 3px;\n  font-size: 100%;\n  line-height: 1;\n  margin: 5px;\n  background-color: #f2f2f2;\n  color: #4d4d4d;\n  height: auto;\n}\n.button:disabled {\n  opacity: 0.4;\n  pointer-events: none;\n}\n.button .icon {\n  display: inline-block;\n  vertical-align: top;\n}\n.button .icon.left {\n  margin-right: 5px;\n}\n.button .icon.right {\n  margin-left: 5px;\n}\n.button:not(:disabled):hover,\n.button:not(:disabled):focus {\n  background-color: #e5e5e5;\n  cursor: pointer;\n}\n.button.primary {\n  background-color: #0568ae;\n  color: #fff;\n}\n.button.primary.brand-primary {\n  background-color: #0088c1;\n}\n.button.primary.brand-success {\n  background-color: #007a3e;\n}\n.button.primary.brand-info {\n  background-color: #5bc0de;\n}\n.button.primary.brand-warning {\n  background-color: #ffb81c;\n}\n.button.primary.brand-danger {\n  background-color: #cf2a2a;\n  color: #fff;\n}\n.button.primary:not(:disabled):hover,\n.button.primary:not(:disabled):focus {\n  background-color: #0677c7;\n}\n.button.primary:not(:disabled):hover.brand-primary,\n.button.primary:not(:disabled):focus.brand-primary {\n  background-color: #009adb;\n}\n.button.primary:not(:disabled):hover.brand-success,\n.button.primary:not(:disabled):focus.brand-success {\n  background-color: #00944b;\n}\n.button.primary:not(:disabled):hover.brand-info,\n.button.primary:not(:disabled):focus.brand-info {\n  background-color: #70c8e2;\n}\n.button.primary:not(:disabled):hover.brand-warning,\n.button.primary:not(:disabled):focus.brand-warning {\n  background-color: #ffc036;\n}\n.button.primary:not(:disabled):hover.brand-danger,\n.button.primary:not(:disabled):focus.brand-danger {\n  background-color: #d73b3b;\n}\n.button.secondary {\n  background-color: transparent;\n  border-color: #0568ae;\n  color: #0568ae;\n}\n.button.secondary.brand-primary {\n  color: #0088c1;\n  border-color: #0088c1;\n}\n.button.secondary.brand-success {\n  color: #007a3e;\n  border-color: #007a3e;\n}\n.button.secondary.brand-info {\n  color: #5bc0de;\n  border-color: #5bc0de;\n}\n.button.secondary.brand-warning {\n  color: #ffb81c;\n  border-color: #ffb81c;\n}\n.button.secondary.brand-danger {\n  color: #cf2a2a;\n  border-color: #cf2a2a;\n}\n.button.secondary:not(:disabled):hover,\n.button.secondary:not(:disabled):focus {\n  background-color: #0568ae;\n  color: #fff;\n}\n.button.secondary:not(:disabled):hover.brand-primary,\n.button.secondary:not(:disabled):focus.brand-primary {\n  background-color: #0088c1;\n}\n.button.secondary:not(:disabled):hover.brand-success,\n.button.secondary:not(:disabled):focus.brand-success {\n  background-color: #007a3e;\n}\n.button.secondary:not(:disabled):hover.brand-info,\n.button.secondary:not(:disabled):focus.brand-info {\n  background-color: #5bc0de;\n}\n.button.secondary:not(:disabled):hover.brand-warning,\n.button.secondary:not(:disabled):focus.brand-warning {\n  background-color: #ffb81c;\n}\n.button.secondary:not(:disabled):hover.brand-danger,\n.button.secondary:not(:disabled):focus.brand-danger {\n  background-color: #cf2a2a;\n}\n.button.floating {\n  background-color: transparent;\n  border-color: transparent;\n  color: #0568ae;\n}\n.button.floating.brand-primary {\n  color: #0088c1;\n}\n.button.floating.brand-success {\n  color: #007a3e;\n}\n.button.floating.brand-info {\n  color: #5bc0de;\n}\n.button.floating.brand-warning {\n  color: #ffb81c;\n}\n.button.floating.brand-danger {\n  color: #cf2a2a;\n}\n.button.floating:not(:disabled):hover,\n.button.floating:not(:disabled):focus {\n  text-decoration: underline;\n}\n.button.floating:not(:disabled):hover .icon,\n.button.floating:not(:disabled):focus .icon {\n  text-decoration: none;\n}\n.button.tertiary {\n  background-color: #fff;\n  color: #333333;\n  border-color: #fff;\n}\n.button.tertiary:not(:disabled):hover,\n.button.tertiary:not(:disabled):focus {\n  background-color: #d9d9d9;\n  border-color: #d9d9d9;\n}\n.button.text {\n  border: 0;\n  background-color: inherit;\n  color: #0568ae;\n}\n.button.text:hover,\n.button.text:focus {\n  background-color: inherit;\n  color: inherit;\n  border: 0;\n}\n.button.coloredText {\n  border: 0;\n  background-color: inherit;\n  color: #0568ae;\n}\n.button.coloredText.brand-primary {\n  color: #0088c1;\n}\n.button.coloredText.brand-success {\n  color: #007a3e;\n}\n.button.coloredText.brand-info {\n  color: #5bc0de;\n}\n.button.coloredText.brand-warning {\n  color: #ffb81c;\n}\n.button.coloredText.brand-danger {\n  color: #cf2a2a;\n}\n.button.coloredText:hover,\n.button.coloredText:focus {\n  background-color: inherit;\n  color: inherit;\n  border: 0;\n}\n.button.alignLeft {\n  margin-left: 0;\n}\n.button.regular {\n  padding: 8px 23px;\n}\n.button.regular.floating {\n  padding: 8px;\n}\n.button.regular.text,\n.button.regular.coloredText {\n  padding: 0;\n}\n.button.large {\n  font-size: 115%;\n  padding: 12px 44px;\n}\n.button.large.floating {\n  padding: 14px;\n}\n.button.large.text,\n.button.large.coloredText {\n  padding: 0;\n}\n" ]
        } ]);
        exports.locals = {
            button: "[1]_[2]_button",
            icon: "[1]_[2]_icon",
            left: "[1]_[2]_left",
            right: "[1]_[2]_right",
            primary: "[1]_[2]_primary",
            "brand-primary": "[1]_[2]_brand-primary",
            "brand-success": "[1]_[2]_brand-success",
            "brand-info": "[1]_[2]_brand-info",
            "brand-warning": "[1]_[2]_brand-warning",
            "brand-danger": "[1]_[2]_brand-danger",
            secondary: "[1]_[2]_secondary",
            floating: "[1]_[2]_floating",
            tertiary: "[1]_[2]_tertiary",
            text: "[1]_[2]_text",
            coloredText: "[1]_[2]_coloredText",
            alignLeft: "[1]_[2]_alignLeft",
            regular: "[1]_[2]_regular",
            large: "[1]_[2]_large"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ChoiceInput.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, "@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer{\n  display:inline-block;\n  position:relative;\n  vertical-align:middle;\n  width:13px;\n  height:13px;\n  min-width:13px;\n  margin-right:6px;\n  border-radius:2px;\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='checkbox'],\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='radio']{\n  opacity:0;\n  width:14px;\n  height:14px;\n  top:50%;\n  left:50%;\n  -webkit-transform:translate(-50%, -50%);\n          transform:translate(-50%, -50%);\n  position:absolute;\n  z-index:1;\n  -webkit-appearance:none;\n     -moz-appearance:none;\n          appearance:none;\n  cursor:pointer;\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='checkbox'] + i,\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='radio'] + i{\n  vertical-align:top;\n  font-size:12px;\n  font-style:normal;\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='checkbox'] + i:before,\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='radio'] + i:before{\n  content:\"\\30080\";\n  position:absolute;\n  display:block;\n  top:50%;\n  left:50%;\n  -webkit-transform:translate(-50%, -50%);\n          transform:translate(-50%, -50%);\n  font-family:'ZeXtras Icons';\n  margin-top:-1px;\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='checkbox']:checked + i:before,\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='radio']:checked + i:before{\n  color:#0088c1;\n  content:\"\\30079\";\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='checkbox']:indeterminate + i:before,\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='radio']:indeterminate + i:before{\n  color:#0088c1;\n  content:\"\\e955\";\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='checkbox'][disabled] + i,\n.\\[1\\]_\\[2\\]_choiceInputContainer input[type='radio'][disabled] + i{\n  opacity:0.5;\n  pointer-events:none;\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer[class*=radioInput] input[type='radio'] + i:before{\n  content:\"\\30062\";\n}\n.\\[1\\]_\\[2\\]_choiceInputContainer[class*=radioInput] input[type='radio']:checked + i:before{\n  content:\"\\30156\";\n}\n", "", {
            version: 3,
            sources: [ "ChoiceInput.less" ],
            names: [],
            mappings: "AAUA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,qBAAsB;EACtB,UAAW;EACX,WAAY;EACZ,cAAe;EACf,gBAAiB;EACjB,iBAAkB;AACpB;AACA;;EAEE,SAAU;EACV,UAAW;EACX,WAAY;EACZ,OAAQ;EACR,QAAS;EACT,uCAAgC;UAAhC,+BAAgC;EAChC,iBAAkB;EAClB,SAAU;EACV,uBAAgB;KAAhB,oBAAgB;UAAhB,eAAgB;EAChB,cAAe;AACjB;AACA;;EAEE,kBAAmB;EACnB,cAAe;EACf,iBAAkB;AACpB;AACA;;EAEE,gBAAiB;EACjB,iBAAkB;EAClB,aAAc;EACd,OAAQ;EACR,QAAS;EACT,uCAAgC;UAAhC,+BAAgC;EAChC,2BAA4B;EAC5B,eAAgB;AAClB;AACA;;EAEE,aAAc;EACd,gBAAiB;AACnB;AACA;;EAEE,aAAc;EACd,eAAgB;AAClB;AACA;;EAEE,WAAY;EACZ,mBAAoB;AACtB;AACA;EACE,gBAAiB;AACnB;AACA;EACE,gBAAiB;AACnB",
            file: "ChoiceInput.less",
            sourcesContent: [ "/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n.choiceInputContainer {\n  display: inline-block;\n  position: relative;\n  vertical-align: middle;\n  width: 13px;\n  height: 13px;\n  min-width: 13px;\n  margin-right: 6px;\n  border-radius: 2px;\n}\n.choiceInputContainer input[type='checkbox'],\n.choiceInputContainer input[type='radio'] {\n  opacity: 0;\n  width: 14px;\n  height: 14px;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  position: absolute;\n  z-index: 1;\n  appearance: none;\n  cursor: pointer;\n}\n.choiceInputContainer input[type='checkbox'] + i,\n.choiceInputContainer input[type='radio'] + i {\n  vertical-align: top;\n  font-size: 12px;\n  font-style: normal;\n}\n.choiceInputContainer input[type='checkbox'] + i:before,\n.choiceInputContainer input[type='radio'] + i:before {\n  content: \"\\30080\";\n  position: absolute;\n  display: block;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-family: 'ZeXtras Icons';\n  margin-top: -1px;\n}\n.choiceInputContainer input[type='checkbox']:checked + i:before,\n.choiceInputContainer input[type='radio']:checked + i:before {\n  color: #0088c1;\n  content: \"\\30079\";\n}\n.choiceInputContainer input[type='checkbox']:indeterminate + i:before,\n.choiceInputContainer input[type='radio']:indeterminate + i:before {\n  color: #0088c1;\n  content: \"\\e955\";\n}\n.choiceInputContainer input[type='checkbox'][disabled] + i,\n.choiceInputContainer input[type='radio'][disabled] + i {\n  opacity: 0.5;\n  pointer-events: none;\n}\n.choiceInputContainer[class*=radioInput] input[type='radio'] + i:before {\n  content: \"\\30062\";\n}\n.choiceInputContainer[class*=radioInput] input[type='radio']:checked + i:before {\n  content: \"\\30156\";\n}\n" ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            choiceInputContainer: "[1]_[2]_choiceInputContainer"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/CloseButton.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, ".\\[1\\]_\\[2\\]_close{\n  padding:0;\n}\n", "", {
            version: 3,
            sources: [ "CloseButton.less" ],
            names: [],
            mappings: "AAUA;EACE,SAAU;AACZ",
            file: "CloseButton.less",
            sourcesContent: [ "/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n.close {\n  padding: 0;\n}\n" ]
        } ]);
        exports.locals = {
            close: "[1]_[2]_close"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Icon.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        var getUrl = __webpack_require__("./node_modules/css-loader/dist/runtime/getUrl.js");
        var ___CSS_LOADER_URL___0___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.eot"));
        var ___CSS_LOADER_URL___1___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.ttf"));
        var ___CSS_LOADER_URL___2___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.woff"));
        var ___CSS_LOADER_URL___3___ = getUrl(__webpack_require__("./node_modules/@zimbra/x-ui/icons/zimbra-icons.svg"));
        exports.push([ module.i, "@font-face{\n  font-family:'zimbra-icons';\n  src:url(" + ___CSS_LOADER_URL___0___ + ");\n  src:url(" + ___CSS_LOADER_URL___0___ + ") format('embedded-opentype'), url(" + ___CSS_LOADER_URL___1___ + ") format('truetype'), url(" + ___CSS_LOADER_URL___2___ + ") format('woff'), url(" + ___CSS_LOADER_URL___3___ + ') format(\'svg\');\n  font-weight:normal;\n  font-style:normal;\n}\n.zimbra-icon{\n  font-family:\'zimbra-icons\' !important;\n  speak:none;\n  font-style:normal;\n  font-weight:normal;\n  -webkit-font-feature-settings:normal;\n          font-feature-settings:normal;\n  font-variant:normal;\n  text-transform:none;\n  line-height:1;\n  vertical-align:middle;\n  -webkit-font-smoothing:antialiased;\n  -moz-osx-font-smoothing:grayscale;\n}\n.zimbra-icon:before{\n  content:\'      �\';\n}\n.zimbra-icon-add-event:before{\n  content:"\\e900";\n}\n.zimbra-icon-folder-add:before{\n  content:"\\e901";\n}\n.zimbra-icon-add-note:before{\n  content:"\\e902";\n}\n.zimbra-icon-plus:before{\n  content:"\\e903";\n}\n.zimbra-icon-archive:before{\n  content:"\\e904";\n}\n.zimbra-icon-caret-down:before{\n  content:"\\e905";\n}\n.zimbra-icon-user-o:before{\n  content:"\\e906";\n}\n.zimbra-icon-user:before{\n  content:"\\e907";\n}\n.zimbra-icon-bold:before{\n  content:"\\e908";\n}\n.zimbra-icon-list-ul:before{\n  content:"\\e909";\n}\n.zimbra-icon-calendar-alt-o:before{\n  content:"\\e90a";\n}\n.zimbra-icon-calendar-o:before{\n  content:"\\e90b";\n}\n.zimbra-icon-align-center:before{\n  content:"\\e90c";\n}\n.zimbra-icon-chat:before{\n  content:"\\e90d";\n}\n.zimbra-icon-check-square:before{\n  content:"\\e90e";\n}\n.zimbra-icon-square-o:before{\n  content:"\\e90f";\n}\n.zimbra-icon-check:before{\n  content:"\\e910";\n}\n.zimbra-icon-close-circle:before{\n  content:"\\e911";\n}\n.zimbra-icon-close:before{\n  content:"\\e912";\n}\n.zimbra-icon-collapse-items:before{\n  content:"\\e913";\n}\n.zimbra-icon-angle-double-left:before{\n  content:"\\e914";\n}\n.zimbra-icon-pencil:before{\n  content:"\\e915";\n}\n.zimbra-icon-address-book:before{\n  content:"\\e916";\n}\n.zimbra-icon-arrows-alt-inverse:before{\n  content:"\\e917";\n}\n.zimbra-icon-file-word-o:before{\n  content:"\\e918";\n}\n.zimbra-icon-chevron-right:before{\n  content:"\\e919";\n}\n.zimbra-icon-download:before{\n  content:"\\e91a";\n}\n.zimbra-icon-angle-right:before{\n  content:"\\e91b";\n}\n.zimbra-icon-smile-o:before{\n  content:"\\e91c";\n}\n.zimbra-icon-expand-items:before{\n  content:"\\e91d";\n}\n.zimbra-icon-angle-double-right:before{\n  content:"\\e91e";\n}\n.zimbra-icon-facebook-official:before{\n  content:"\\e91f";\n}\n.zimbra-icon-mail-forward:before{\n  content:"\\e920";\n}\n.zimbra-icon-expand:before{\n  content:"\\e921";\n}\n.zimbra-icon-GIF:before{\n  content:"\\e922";\n}\n.zimbra-icon-grid:before{\n  content:"\\e923";\n}\n.zimbra-icon-question-circle:before{\n  content:"\\e924";\n}\n.zimbra-icon-home:before{\n  content:"\\e925";\n}\n.zimbra-icon-image:before{\n  content:"\\e926";\n}\n.zimbra-icon-arrows-alt:before{\n  content:"\\e927";\n}\n.zimbra-icon-indent:before{\n  content:"\\e928";\n}\n.zimbra-icon-italic:before{\n  content:"\\e929";\n}\n.zimbra-icon-align-left:before{\n  content:"\\e92a";\n}\n.zimbra-icon-link:before{\n  content:"\\e92b";\n}\n.zimbra-icon-mobile-phone:before{\n  content:"\\e92c";\n}\n.zimbra-icon-ellipsis-h:before{\n  content:"\\e92d";\n}\n.zimbra-icon-folder-move:before{\n  content:"\\e92e";\n}\n.zimbra-icon-angle-left:before{\n  content:"\\e92f";\n}\n.zimbra-icon-angle-down:before{\n  content:"\\e930";\n}\n.zimbra-icon-book:before{\n  content:"\\e931";\n}\n.zimbra-icon-list-ol:before{\n  content:"\\e932";\n}\n.zimbra-icon-external-link:before{\n  content:"\\e933";\n}\n.zimbra-icon-outdent:before{\n  content:"\\e934";\n}\n.zimbra-icon-file-pdf-o:before{\n  content:"\\e935";\n}\n.zimbra-icon-multimedia-active:before{\n  content:"\\e936";\n}\n.zimbra-icon-multimedia:before{\n  content:"\\e937";\n}\n.zimbra-icon-file-powerpoint-o:before{\n  content:"\\e938";\n}\n.zimbra-icon-print:before{\n  content:"\\e939";\n}\n.zimbra-icon-radio:before{\n  content:"\\e93a";\n}\n.zimbra-icon-radio-active:before{\n  content:"\\e93b";\n}\n.zimbra-icon-mail-reply-all:before{\n  content:"\\e93c";\n}\n.zimbra-icon-mail-reply:before{\n  content:"\\e93d";\n}\n.zimbra-icon-align-right:before{\n  content:"\\e93e";\n}\n.zimbra-icon-search:before{\n  content:"\\e93f";\n}\n.zimbra-icon-cog:before{\n  content:"\\e940";\n}\n.zimbra-icon-music:before{\n  content:"\\e941";\n}\n.zimbra-icon-shield:before{\n  content:"\\e942";\n}\n.zimbra-icon-star:before{\n  content:"\\e943";\n}\n.zimbra-icon-alarm:before{\n  content:"\\e944";\n}\n.zimbra-icon-arrow-left:before{\n  content:"\\e945";\n}\n.zimbra-icon-address-book-sync:before{\n  content:"\\e946";\n}\n.zimbra-icon-adn:before{\n  content:"\\e947";\n}\n.zimbra-icon-font:before{\n  content:"\\e948";\n}\n.zimbra-icon-trash:before{\n  content:"\\e949";\n}\n.zimbra-icon-twitter:before{\n  content:"\\e94a";\n}\n.zimbra-icon-underline:before{\n  content:"\\e94b";\n}\n.zimbra-icon-arrow-down:before{\n  content:"\\e94c";\n}\n.zimbra-icon-users:before{\n  content:"\\e94d";\n}\n.zimbra-icon-play-circle-o:before{\n  content:"\\e94e";\n}\n.zimbra-icon-file-excel-o:before{\n  content:"\\e94f";\n}\n.zimbra-icon-file-archive-o:before{\n  content:"\\e950";\n}\n.zimbra-icon-clock:before{\n  content:"\\e951";\n}\n.zimbra-icon-check-circle:before{\n  content:"\\e952";\n}\n.zimbra-icon-minus:before{\n  content:"\\e953";\n}\n.zimbra-icon-camera:before{\n  content:"\\e954";\n}\n.zimbra-icon-minus-square:before{\n  content:"\\e955";\n}\n.zimbra-icon-paperclip:before{\n  content:"\\e956";\n}\n.zimbra-icon-arrow-up:before{\n  content:"\\e957";\n}\n.zimbra-icon-bell:before{\n  content:"\\e958";\n}\n.zimbra-icon-calendar-range:before{\n  content:"\\e959";\n}\n.zimbra-icon-trash-forever:before{\n  content:"\\e95a";\n}\n.zimbra-icon-user-circle-o:before{\n  content:"\\e95b";\n}\n.zimbra-icon-add-contact:before{\n  content:"\\e95c";\n}\n.zimbra-icon-envelope:before{\n  content:"\\e95d";\n}\n.zimbra-icon-add-circle:before{\n  content:"\\e95e";\n}\n.zimbra-icon-text-options:before{\n  content:"\\e95f";\n}\n.zimbra-icon-assign-list:before{\n  content:"\\e960";\n}\n.zimbra-icon-bars:before{\n  content:"\\e961";\n}\n.zimbra-icon-restore:before{\n  content:"\\e962";\n}\n.zimbra-icon-remove-list:before{\n  content:"\\e963";\n}\n.zimbra-icon-lock:before{\n  content:"\\e964";\n}\n.zimbra-icon-repeat:before{\n  content:"\\e965";\n}\n.zimbra-icon-refresh:before{\n  content:"\\e966";\n}\n.zimbra-icon-chevron-left:before{\n  content:"\\e967";\n}\n.zimbra-icon-bell-slash:before{\n  content:"\\e968";\n}\n.zimbra-icon-warning:before{\n  content:"\\e969";\n}\n.zimbra-icon-encrypted:before{\n  content:"\\e96a";\n}\n.zimbra-icon-search-plus:before{\n  content:"\\e96b";\n}\n.zimbra-icon-search-minus:before{\n  content:"\\e96c";\n}\n.zimbra-icon-rotate_right:before{\n  content:"\\e96d";\n}\n.zimbra-icon-rotate_left:before{\n  content:"\\e96e";\n}\n.zimbra-icon-not-signed:before{\n  content:"\\e96f";\n}\n.zimbra-icon-signed:before{\n  content:"\\e970";\n}\n.zimbra-icon-cloud:before{\n  content:"\\e971";\n}\n.zimbra-icon-videocam:before{\n  content:"\\e972";\n}\n.zimbra-icon-location:before{\n  content:"\\e973";\n}\n.zimbra-icon-verified:before{\n  content:"\\e974";\n}\n.zimbra-icon-not-verified:before{\n  content:"\\e975";\n}\n.zimbra-icon-outline-user-circle-o:before{\n  content:"\\e976";\n}\n.zimbra-icon-web:before{\n  content:"\\e977";\n}\n.zimbra-icon-code:before{\n  content:"\\e978";\n}\n.zimbra-icon-check-square-o:before{\n  content:"\\e979";\n}\nspan[role="img"]{\n  vertical-align:middle;\n}\n.\\[1\\]_\\[2\\]_xs{\n  font-size:12px;\n}\n.\\[1\\]_\\[2\\]_sm{\n  font-size:16px;\n}\n.\\[1\\]_\\[2\\]_md{\n  font-size:24px;\n}\n.\\[1\\]_\\[2\\]_lg{\n  font-size:32px;\n}\n.\\[1\\]_\\[2\\]_img-xs{\n  width:12px;\n  height:12px;\n}\n.\\[1\\]_\\[2\\]_img-sm{\n  width:16px;\n  height:16px;\n}\n.\\[1\\]_\\[2\\]_img-md{\n  width:24px;\n  height:24px;\n}\n.\\[1\\]_\\[2\\]_img-lg{\n  width:32px;\n  height:32px;\n}\n', "", {
            version: 3,
            sources: [ "Icon.less" ],
            names: [],
            mappings: "AAAA;EACE,0BAA2B;EAC3B,iCAAkF;EAClF,0MAA+Z;EAC/Z,kBAAmB;EACnB,iBAAkB;AACpB;AACA;EAEE,qCAAsC;EACtC,UAAW;EACX,iBAAkB;EAClB,kBAAmB;EACnB,oCAAoB;UAApB,4BAAoB;EAApB,mBAAoB;EACpB,mBAAoB;EACpB,aAAc;EACd,qBAAsB;EAEtB,kCAAmC;EACnC,iCAAkC;AACpC;AACA;EACE,iBAAkB;AACpB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,eAAgB;AAClB;AACA;EACE,qBAAsB;AACxB;AACA;EACE,cAAe;AACjB;AACA;EACE,cAAe;AACjB;AACA;EACE,cAAe;AACjB;AACA;EACE,cAAe;AACjB;AACA;EACE,UAAW;EACX,WAAY;AACd;AACA;EACE,UAAW;EACX,WAAY;AACd;AACA;EACE,UAAW;EACX,WAAY;AACd;AACA;EACE,UAAW;EACX,WAAY;AACd",
            file: "Icon.less",
            sourcesContent: [ '@font-face {\n  font-family: \'zimbra-icons\';\n  src: url(\'../../../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.eot?cplvdh\');\n  src: url(\'../../../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.eot?cplvdh#iefix\') format(\'embedded-opentype\'), url(\'../../../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.ttf?cplvdh\') format(\'truetype\'), url(\'../../../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.woff?cplvdh\') format(\'woff\'), url(\'../../../../../node_modules/@zimbra/x-ui/icons/zimbra-icons.svg?cplvdh#zimbra-icons\') format(\'svg\');\n  font-weight: normal;\n  font-style: normal;\n}\n:global .zimbra-icon {\n  /* use !important to prevent issues with browser extensions that change fonts */\n  font-family: \'zimbra-icons\' !important;\n  speak: none;\n  font-style: normal;\n  font-weight: normal;\n  font-variant: normal;\n  text-transform: none;\n  line-height: 1;\n  vertical-align: middle;\n  /* Better Font Rendering =========== */\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n:global .zimbra-icon:before {\n  content: \'      �\';\n}\n:global .zimbra-icon-add-event:before {\n  content: "\\e900";\n}\n:global .zimbra-icon-folder-add:before {\n  content: "\\e901";\n}\n:global .zimbra-icon-add-note:before {\n  content: "\\e902";\n}\n:global .zimbra-icon-plus:before {\n  content: "\\e903";\n}\n:global .zimbra-icon-archive:before {\n  content: "\\e904";\n}\n:global .zimbra-icon-caret-down:before {\n  content: "\\e905";\n}\n:global .zimbra-icon-user-o:before {\n  content: "\\e906";\n}\n:global .zimbra-icon-user:before {\n  content: "\\e907";\n}\n:global .zimbra-icon-bold:before {\n  content: "\\e908";\n}\n:global .zimbra-icon-list-ul:before {\n  content: "\\e909";\n}\n:global .zimbra-icon-calendar-alt-o:before {\n  content: "\\e90a";\n}\n:global .zimbra-icon-calendar-o:before {\n  content: "\\e90b";\n}\n:global .zimbra-icon-align-center:before {\n  content: "\\e90c";\n}\n:global .zimbra-icon-chat:before {\n  content: "\\e90d";\n}\n:global .zimbra-icon-check-square:before {\n  content: "\\e90e";\n}\n:global .zimbra-icon-square-o:before {\n  content: "\\e90f";\n}\n:global .zimbra-icon-check:before {\n  content: "\\e910";\n}\n:global .zimbra-icon-close-circle:before {\n  content: "\\e911";\n}\n:global .zimbra-icon-close:before {\n  content: "\\e912";\n}\n:global .zimbra-icon-collapse-items:before {\n  content: "\\e913";\n}\n:global .zimbra-icon-angle-double-left:before {\n  content: "\\e914";\n}\n:global .zimbra-icon-pencil:before {\n  content: "\\e915";\n}\n:global .zimbra-icon-address-book:before {\n  content: "\\e916";\n}\n:global .zimbra-icon-arrows-alt-inverse:before {\n  content: "\\e917";\n}\n:global .zimbra-icon-file-word-o:before {\n  content: "\\e918";\n}\n:global .zimbra-icon-chevron-right:before {\n  content: "\\e919";\n}\n:global .zimbra-icon-download:before {\n  content: "\\e91a";\n}\n:global .zimbra-icon-angle-right:before {\n  content: "\\e91b";\n}\n:global .zimbra-icon-smile-o:before {\n  content: "\\e91c";\n}\n:global .zimbra-icon-expand-items:before {\n  content: "\\e91d";\n}\n:global .zimbra-icon-angle-double-right:before {\n  content: "\\e91e";\n}\n:global .zimbra-icon-facebook-official:before {\n  content: "\\e91f";\n}\n:global .zimbra-icon-mail-forward:before {\n  content: "\\e920";\n}\n:global .zimbra-icon-expand:before {\n  content: "\\e921";\n}\n:global .zimbra-icon-GIF:before {\n  content: "\\e922";\n}\n:global .zimbra-icon-grid:before {\n  content: "\\e923";\n}\n:global .zimbra-icon-question-circle:before {\n  content: "\\e924";\n}\n:global .zimbra-icon-home:before {\n  content: "\\e925";\n}\n:global .zimbra-icon-image:before {\n  content: "\\e926";\n}\n:global .zimbra-icon-arrows-alt:before {\n  content: "\\e927";\n}\n:global .zimbra-icon-indent:before {\n  content: "\\e928";\n}\n:global .zimbra-icon-italic:before {\n  content: "\\e929";\n}\n:global .zimbra-icon-align-left:before {\n  content: "\\e92a";\n}\n:global .zimbra-icon-link:before {\n  content: "\\e92b";\n}\n:global .zimbra-icon-mobile-phone:before {\n  content: "\\e92c";\n}\n:global .zimbra-icon-ellipsis-h:before {\n  content: "\\e92d";\n}\n:global .zimbra-icon-folder-move:before {\n  content: "\\e92e";\n}\n:global .zimbra-icon-angle-left:before {\n  content: "\\e92f";\n}\n:global .zimbra-icon-angle-down:before {\n  content: "\\e930";\n}\n:global .zimbra-icon-book:before {\n  content: "\\e931";\n}\n:global .zimbra-icon-list-ol:before {\n  content: "\\e932";\n}\n:global .zimbra-icon-external-link:before {\n  content: "\\e933";\n}\n:global .zimbra-icon-outdent:before {\n  content: "\\e934";\n}\n:global .zimbra-icon-file-pdf-o:before {\n  content: "\\e935";\n}\n:global .zimbra-icon-multimedia-active:before {\n  content: "\\e936";\n}\n:global .zimbra-icon-multimedia:before {\n  content: "\\e937";\n}\n:global .zimbra-icon-file-powerpoint-o:before {\n  content: "\\e938";\n}\n:global .zimbra-icon-print:before {\n  content: "\\e939";\n}\n:global .zimbra-icon-radio:before {\n  content: "\\e93a";\n}\n:global .zimbra-icon-radio-active:before {\n  content: "\\e93b";\n}\n:global .zimbra-icon-mail-reply-all:before {\n  content: "\\e93c";\n}\n:global .zimbra-icon-mail-reply:before {\n  content: "\\e93d";\n}\n:global .zimbra-icon-align-right:before {\n  content: "\\e93e";\n}\n:global .zimbra-icon-search:before {\n  content: "\\e93f";\n}\n:global .zimbra-icon-cog:before {\n  content: "\\e940";\n}\n:global .zimbra-icon-music:before {\n  content: "\\e941";\n}\n:global .zimbra-icon-shield:before {\n  content: "\\e942";\n}\n:global .zimbra-icon-star:before {\n  content: "\\e943";\n}\n:global .zimbra-icon-alarm:before {\n  content: "\\e944";\n}\n:global .zimbra-icon-arrow-left:before {\n  content: "\\e945";\n}\n:global .zimbra-icon-address-book-sync:before {\n  content: "\\e946";\n}\n:global .zimbra-icon-adn:before {\n  content: "\\e947";\n}\n:global .zimbra-icon-font:before {\n  content: "\\e948";\n}\n:global .zimbra-icon-trash:before {\n  content: "\\e949";\n}\n:global .zimbra-icon-twitter:before {\n  content: "\\e94a";\n}\n:global .zimbra-icon-underline:before {\n  content: "\\e94b";\n}\n:global .zimbra-icon-arrow-down:before {\n  content: "\\e94c";\n}\n:global .zimbra-icon-users:before {\n  content: "\\e94d";\n}\n:global .zimbra-icon-play-circle-o:before {\n  content: "\\e94e";\n}\n:global .zimbra-icon-file-excel-o:before {\n  content: "\\e94f";\n}\n:global .zimbra-icon-file-archive-o:before {\n  content: "\\e950";\n}\n:global .zimbra-icon-clock:before {\n  content: "\\e951";\n}\n:global .zimbra-icon-check-circle:before {\n  content: "\\e952";\n}\n:global .zimbra-icon-minus:before {\n  content: "\\e953";\n}\n:global .zimbra-icon-camera:before {\n  content: "\\e954";\n}\n:global .zimbra-icon-minus-square:before {\n  content: "\\e955";\n}\n:global .zimbra-icon-paperclip:before {\n  content: "\\e956";\n}\n:global .zimbra-icon-arrow-up:before {\n  content: "\\e957";\n}\n:global .zimbra-icon-bell:before {\n  content: "\\e958";\n}\n:global .zimbra-icon-calendar-range:before {\n  content: "\\e959";\n}\n:global .zimbra-icon-trash-forever:before {\n  content: "\\e95a";\n}\n:global .zimbra-icon-user-circle-o:before {\n  content: "\\e95b";\n}\n:global .zimbra-icon-add-contact:before {\n  content: "\\e95c";\n}\n:global .zimbra-icon-envelope:before {\n  content: "\\e95d";\n}\n:global .zimbra-icon-add-circle:before {\n  content: "\\e95e";\n}\n:global .zimbra-icon-text-options:before {\n  content: "\\e95f";\n}\n:global .zimbra-icon-assign-list:before {\n  content: "\\e960";\n}\n:global .zimbra-icon-bars:before {\n  content: "\\e961";\n}\n:global .zimbra-icon-restore:before {\n  content: "\\e962";\n}\n:global .zimbra-icon-remove-list:before {\n  content: "\\e963";\n}\n:global .zimbra-icon-lock:before {\n  content: "\\e964";\n}\n:global .zimbra-icon-repeat:before {\n  content: "\\e965";\n}\n:global .zimbra-icon-refresh:before {\n  content: "\\e966";\n}\n:global .zimbra-icon-chevron-left:before {\n  content: "\\e967";\n}\n:global .zimbra-icon-bell-slash:before {\n  content: "\\e968";\n}\n:global .zimbra-icon-warning:before {\n  content: "\\e969";\n}\n:global .zimbra-icon-encrypted:before {\n  content: "\\e96a";\n}\n:global .zimbra-icon-search-plus:before {\n  content: "\\e96b";\n}\n:global .zimbra-icon-search-minus:before {\n  content: "\\e96c";\n}\n:global .zimbra-icon-rotate_right:before {\n  content: "\\e96d";\n}\n:global .zimbra-icon-rotate_left:before {\n  content: "\\e96e";\n}\n:global .zimbra-icon-not-signed:before {\n  content: "\\e96f";\n}\n:global .zimbra-icon-signed:before {\n  content: "\\e970";\n}\n:global .zimbra-icon-cloud:before {\n  content: "\\e971";\n}\n:global .zimbra-icon-videocam:before {\n  content: "\\e972";\n}\n:global .zimbra-icon-location:before {\n  content: "\\e973";\n}\n:global .zimbra-icon-verified:before {\n  content: "\\e974";\n}\n:global .zimbra-icon-not-verified:before {\n  content: "\\e975";\n}\n:global .zimbra-icon-outline-user-circle-o:before {\n  content: "\\e976";\n}\n:global .zimbra-icon-web:before {\n  content: "\\e977";\n}\n:global .zimbra-icon-code:before {\n  content: "\\e978";\n}\n:global .zimbra-icon-check-square-o:before {\n  content: "\\e979";\n}\nspan[role="img"] {\n  vertical-align: middle;\n}\n.xs {\n  font-size: 12px;\n}\n.sm {\n  font-size: 16px;\n}\n.md {\n  font-size: 24px;\n}\n.lg {\n  font-size: 32px;\n}\n.img-xs {\n  width: 12px;\n  height: 12px;\n}\n.img-sm {\n  width: 16px;\n  height: 16px;\n}\n.img-md {\n  width: 24px;\n  height: 24px;\n}\n.img-lg {\n  width: 32px;\n  height: 32px;\n}\n' ]
        } ]);
        exports.locals = {
            xs: "[1]_[2]_xs",
            sm: "[1]_[2]_sm",
            md: "[1]_[2]_md",
            lg: "[1]_[2]_lg",
            "img-xs": "[1]_[2]_img-xs",
            "img-sm": "[1]_[2]_img-sm",
            "img-md": "[1]_[2]_img-md",
            "img-lg": "[1]_[2]_img-lg"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/MenuItem.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, '@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n.\\[1\\]_\\[2\\]_navItem{\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n      -ms-flex-align:center;\n          align-items:center;\n  position:relative;\n  -webkit-box-sizing:border-box;\n          box-sizing:border-box;\n  padding:8px 16px;\n  text-decoration:none;\n  color:#4d4d4d;\n  white-space:nowrap;\n  -webkit-appearance:none;\n  -webkit-user-select:none;\n     -moz-user-select:none;\n      -ms-user-select:none;\n          user-select:none;\n  cursor:pointer;\n  overflow:hidden;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_icon{\n  position:relative;\n  display:inline-block;\n  line-height:1;\n  font-size:16px;\n  color:#666666;\n  margin-right:8px;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_icon path{\n  fill:#0088c1;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_icon .fa{\n  font-size:100%;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_icon .blocks_icon{\n  position:relative;\n  top:-2px;\n  display:inline-block;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_icon .\\[1\\]_\\[2\\]_iconText{\n  position:absolute;\n  display:block;\n  left:0;\n  top:0;\n  width:100%;\n  text-align:center;\n  font-size:62%;\n  font-weight:bold;\n  line-height:29px;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_iconDisabled{\n  opacity:0.5;\n  cursor:default;\n}\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_iconRight > .\\[1\\]_\\[2\\]_inner{\n  margin-right:10px;\n}\n.\\[1\\]_\\[2\\]_navItem .\\[1\\]_\\[2\\]_inner{\n  padding:0;\n  font-weight:inherit;\n  display:-webkit-box;\n  display:-webkit-flex;\n  display:-ms-flexbox;\n  display:flex;\n  -webkit-box-align:center;\n  -webkit-align-items:center;\n      -ms-flex-align:center;\n          align-items:center;\n  width:100%;\n}\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_sidebarEnable{\n  border-left:4px solid transparent;\n  border-bottom:none;\n}\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_sidebarEnable:hover,\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_sidebarEnable:focus,\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_sidebarEnable.\\[1\\]_\\[2\\]_active{\n  text-decoration:none;\n  border-left-color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_sidebarEnable.\\[1\\]_\\[2\\]_active{\n  border-bottom:none;\n}\na[href].\\[1\\]_\\[2\\]_navItem:hover,\na[href].\\[1\\]_\\[2\\]_navItem:focus,\na[href].\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_active{\n  color:black;\n  text-decoration:none;\n  border-bottom-color:#0088c1;\n}\na[href].\\[1\\]_\\[2\\]_navItem:hover .\\[1\\]_\\[2\\]_icon,\na[href].\\[1\\]_\\[2\\]_navItem:focus .\\[1\\]_\\[2\\]_icon,\na[href].\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_active .\\[1\\]_\\[2\\]_icon{\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_navItem.\\[1\\]_\\[2\\]_disabled{\n  color:#999999;\n  cursor:default;\n}\n', "", {
            version: 3,
            sources: [ "MenuItem.less" ],
            names: [],
            mappings: "AAAA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE,kDAAmD;EACnD,mBAAa;EAAb,oBAAa;EAAb,mBAAa;EAAb,YAAa;EACb,wBAAmB;EAAnB,0BAAmB;MAAnB,qBAAmB;UAAnB,kBAAmB;EACnB,iBAAkB;EAClB,6BAAsB;UAAtB,qBAAsB;EACtB,gBAAiB;EACjB,oBAAqB;EACrB,aAAc;EACd,kBAAmB;EACnB,uBAAwB;EACxB,wBAAiB;KAAjB,qBAAiB;MAAjB,oBAAiB;UAAjB,gBAAiB;EACjB,cAAe;EACf,eAAgB;AAClB;AACA;EACE,iBAAkB;EAClB,oBAAqB;EACrB,aAAc;EACd,cAAe;EACf,aAAc;EACd,gBAAiB;AACnB;AACA;EACE,YAAa;AACf;AACA;EACE,cAAe;AACjB;AACA;EACE,iBAAkB;EAClB,QAAS;EACT,oBAAqB;AACvB;AACA;EACE,iBAAkB;EAClB,aAAc;EACd,MAAO;EACP,KAAM;EACN,UAAW;EACX,iBAAkB;EAClB,aAAc;EACd,gBAAiB;EACjB,gBAAiB;AACnB;AACA;EACE,WAAY;EACZ,cAAe;AACjB;AACA;EACE,iBAAkB;AACpB;AACA;EACE,SAAU;EACV,mBAAoB;EACpB,mBAAa;EAAb,oBAAa;EAAb,mBAAa;EAAb,YAAa;EACb,wBAAmB;EAAnB,0BAAmB;MAAnB,qBAAmB;UAAnB,kBAAmB;EACnB,UAAW;AACb;AACA;EACE,iCAAkC;EAClC,kBAAmB;AACrB;AACA;;;EAGE,oBAAqB;EACrB,yBAA0B;AAC5B;AACA;EACE,kBAAmB;AACrB;AACA;;;EAGE,WAAY;EACZ,oBAAqB;EACrB,2BAA4B;AAC9B;AACA;;;EAGE,aAAc;AAChB;AACA;EACE,aAAc;EACd,cAAe;AACjB",
            file: "MenuItem.less",
            sourcesContent: [ '@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n.navItem {\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  display: flex;\n  align-items: center;\n  position: relative;\n  box-sizing: border-box;\n  padding: 8px 16px;\n  text-decoration: none;\n  color: #4d4d4d;\n  white-space: nowrap;\n  -webkit-appearance: none;\n  user-select: none;\n  cursor: pointer;\n  overflow: hidden;\n}\n.navItem .icon {\n  position: relative;\n  display: inline-block;\n  line-height: 1;\n  font-size: 16px;\n  color: #666666;\n  margin-right: 8px;\n}\n.navItem .icon path {\n  fill: #0088c1;\n}\n.navItem .icon :global(.fa) {\n  font-size: 100%;\n}\n.navItem .icon :global(.blocks_icon) {\n  position: relative;\n  top: -2px;\n  display: inline-block;\n}\n.navItem .icon .iconText {\n  position: absolute;\n  display: block;\n  left: 0;\n  top: 0;\n  width: 100%;\n  text-align: center;\n  font-size: 62%;\n  font-weight: bold;\n  line-height: 29px;\n}\n.navItem .iconDisabled {\n  opacity: 0.5;\n  cursor: default;\n}\n.navItem.iconRight > .inner {\n  margin-right: 10px;\n}\n.navItem .inner {\n  padding: 0;\n  font-weight: inherit;\n  display: flex;\n  align-items: center;\n  width: 100%;\n}\n.navItem.sidebarEnable {\n  border-left: 4px solid transparent;\n  border-bottom: none;\n}\n.navItem.sidebarEnable:hover,\n.navItem.sidebarEnable:focus,\n.navItem.sidebarEnable.active {\n  text-decoration: none;\n  border-left-color: #0088c1;\n}\n.navItem.sidebarEnable.active {\n  border-bottom: none;\n}\na[href].navItem:hover,\na[href].navItem:focus,\na[href].navItem.active {\n  color: black;\n  text-decoration: none;\n  border-bottom-color: #0088c1;\n}\na[href].navItem:hover .icon,\na[href].navItem:focus .icon,\na[href].navItem.active .icon {\n  color: #0088c1;\n}\n.navItem.disabled {\n  color: #999999;\n  cursor: default;\n}\n' ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            navItem: "[1]_[2]_navItem",
            icon: "[1]_[2]_icon",
            iconText: "[1]_[2]_iconText",
            iconDisabled: "[1]_[2]_iconDisabled",
            iconRight: "[1]_[2]_iconRight",
            inner: "[1]_[2]_inner",
            sidebarEnable: "[1]_[2]_sidebarEnable",
            active: "[1]_[2]_active",
            disabled: "[1]_[2]_disabled"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ModalDialog.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, '.\\[1\\]_\\[2\\]_overlay{\n  background-color:rgba(217, 217, 217, .8);\n  position:fixed;\n  top:0;\n  left:0;\n  width:100vw;\n  height:100vh;\n  z-index:999;\n  margin:0;\n}\n.\\[1\\]_\\[2\\]_ModalDialog{\n  z-index:1000;\n  display:block;\n  position:absolute;\n  top:50%;\n  left:50%;\n  -webkit-transform:translate(-50%, -50%);\n          transform:translate(-50%, -50%);\n  width:432px;\n}\n.\\[1\\]_\\[2\\]_ModalDialogInner{\n  background:#fff;\n  border-radius:3px;\n  height:100%;\n  -webkit-box-shadow:0 4px 6px rgba(0, 0, 0, .36);\n          box-shadow:0 4px 6px rgba(0, 0, 0, .36);\n  cursor:default;\n  width:100%;\n}\n.\\[1\\]_\\[2\\]_header{\n  padding:0;\n  color:#4d4d4d;\n  text-align:center;\n  height:60px;\n  border-bottom:none;\n  background:none;\n}\n.\\[1\\]_\\[2\\]_header h2{\n  font-size:20px;\n  margin:0;\n  padding:22px 24px 0;\n  text-align:left;\n  color:black;\n  font-weight:normal;\n  white-space:nowrap;\n  text-overflow:ellipsis;\n  overflow:hidden;\n}\n.\\[1\\]_\\[2\\]_content{\n  position:relative;\n  padding:0 24px 76px;\n  font-family:"Roboto", Helvetica, Arial, sans-serif;\n  font-size:13px;\n  -webkit-font-smoothing:auto;\n  margin:5px 4px;\n}\n.\\[1\\]_\\[2\\]_footer{\n  position:absolute;\n  left:0;\n  bottom:0;\n  width:100%;\n  height:76px;\n  padding:20px 24px 24px;\n  display:block;\n  -webkit-box-sizing:border-box;\n  box-sizing:border-box;\n}\n.\\[1\\]_\\[2\\]_actionButton{\n  top:16px;\n  right:16px;\n  width:24px;\n  height:24px;\n  padding:0;\n  position:absolute;\n  margin:0;\n  z-index:1;\n}\n', "", {
            version: 3,
            sources: [ "ModalDialog.less" ],
            names: [],
            mappings: "AAUA;EACE,wCAA0C;EAC1C,cAAe;EACf,KAAM;EACN,MAAO;EACP,WAAY;EACZ,YAAa;EACb,WAAY;EACZ,QAAS;AACX;AACA;EACE,YAAa;EACb,aAAc;EACd,iBAAkB;EAClB,OAAQ;EACR,QAAS;EACT,uCAAgC;UAAhC,+BAAgC;EAChC,WAAY;AACd;AACA;EACE,eAAgB;EAChB,iBAAkB;EAClB,WAAY;EACZ,+CAAyC;UAAzC,uCAAyC;EACzC,cAAe;EACf,UAAW;AACb;AACA;EACE,SAAU;EACV,aAAc;EACd,iBAAkB;EAClB,WAAY;EACZ,kBAAmB;EACnB,eAAgB;AAClB;AACA;EACE,cAAe;EACf,QAAS;EACT,mBAAoB;EACpB,eAAgB;EAChB,WAAY;EACZ,kBAAmB;EACnB,kBAAmB;EACnB,sBAAuB;EACvB,eAAgB;AAClB;AACA;EACE,iBAAkB;EAClB,mBAAoB;EACpB,kDAAmD;EACnD,cAAe;EACf,2BAA4B;EAC5B,cAAe;AACjB;AACA;EACE,iBAAkB;EAClB,MAAO;EACP,QAAS;EACT,UAAW;EACX,WAAY;EACZ,sBAAuB;EACvB,aAAc;EACd,6BAA8B;EAC9B,qBAAsB;AACxB;AACA;EACE,QAAS;EACT,UAAW;EACX,UAAW;EACX,WAAY;EACZ,SAAU;EACV,iBAAkB;EAClB,QAAS;EACT,SAAU;AACZ",
            file: "ModalDialog.less",
            sourcesContent: [ '/*\n * **** BEGIN LICENSE BLOCK *****\n * Copyright (C) 2011-2019 ZeXtras\n *\n * The contents of this file are subject to the ZeXtras EULA;\n * you may not use this file except in compliance with the EULA.\n * You may obtain a copy of the EULA at\n * http://www.zextras.com/zextras-eula.html\n * **** END LICENSE BLOCK *****\n */\n.overlay {\n  background-color: rgba(217, 217, 217, 0.8);\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100vw;\n  height: 100vh;\n  z-index: 999;\n  margin: 0;\n}\n.ModalDialog {\n  z-index: 1000;\n  display: block;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: 432px;\n}\n.ModalDialogInner {\n  background: #fff;\n  border-radius: 3px;\n  height: 100%;\n  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.36);\n  cursor: default;\n  width: 100%;\n}\n.header {\n  padding: 0;\n  color: #4d4d4d;\n  text-align: center;\n  height: 60px;\n  border-bottom: none;\n  background: none;\n}\n.header h2 {\n  font-size: 20px;\n  margin: 0;\n  padding: 22px 24px 0;\n  text-align: left;\n  color: black;\n  font-weight: normal;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  overflow: hidden;\n}\n.content {\n  position: relative;\n  padding: 0 24px 76px;\n  font-family: "Roboto", Helvetica, Arial, sans-serif;\n  font-size: 13px;\n  -webkit-font-smoothing: auto;\n  margin: 5px 4px;\n}\n.footer {\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  width: 100%;\n  height: 76px;\n  padding: 20px 24px 24px;\n  display: block;\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n}\n.actionButton {\n  top: 16px;\n  right: 16px;\n  width: 24px;\n  height: 24px;\n  padding: 0;\n  position: absolute;\n  margin: 0;\n  z-index: 1;\n}\n' ]
        } ]);
        exports.locals = {
            overlay: "[1]_[2]_overlay",
            ModalDialog: "[1]_[2]_ModalDialog",
            ModalDialogInner: "[1]_[2]_ModalDialogInner",
            header: "[1]_[2]_header",
            content: "[1]_[2]_content",
            footer: "[1]_[2]_footer",
            actionButton: "[1]_[2]_actionButton"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Popover.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, '.\\[1\\]_\\[2\\]_popover-container{\n  display:inline-block;\n  max-width:100%;\n}\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button{\n  background:transparent;\n  border:none;\n  color:#000;\n  cursor:pointer;\n  display:inline-block;\n  padding:0;\n  max-width:100%;\n}\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button[href] > span:focus,\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button[href] > span:hover{\n  text-decoration:underline;\n}\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button:focus,\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button:hover{\n  outline:none;\n  color:#0088c1;\n}\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button[disabled="true"]{\n  pointer-events:none;\n}\n.\\[1\\]_\\[2\\]_popover-container .\\[1\\]_\\[2\\]_button .\\[1\\]_\\[2\\]_title{\n  display:inline-block;\n  font-weight:bold;\n  text-transform:capitalize;\n  vertical-align:middle;\n  text-align:center;\n}\n.\\[1\\]_\\[2\\]_popper{\n  background:#fff;\n  border:1px solid #d9d9d9;\n  border-radius:4px;\n  -webkit-box-shadow:0 4px 6px rgba(0, 0, 0, .36);\n          box-shadow:0 4px 6px rgba(0, 0, 0, .36);\n  list-style:none;\n  z-index:999;\n}\n.\\[1\\]_\\[2\\]_popper[data-x-out-of-boundaries]{\n  display:none;\n}\n.\\[1\\]_\\[2\\]_popper .\\[1\\]_\\[2\\]_dropdown{\n  position:relative;\n  z-index:1;\n}\n.\\[1\\]_\\[2\\]_popper .\\[1\\]_\\[2\\]_arrow,\n.\\[1\\]_\\[2\\]_popper .\\[1\\]_\\[2\\]_borderArrow{\n  width:0;\n  height:0;\n  border-style:solid;\n  position:absolute;\n  border-color:transparent;\n}\n.\\[1\\]_\\[2\\]_popper .\\[1\\]_\\[2\\]_arrow{\n  border-width:12px;\n}\n.\\[1\\]_\\[2\\]_popper .\\[1\\]_\\[2\\]_borderArrow{\n  border-width:13px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="top"][arrow] .\\[1\\]_\\[2\\]_arrow{\n  border-bottom-width:0;\n  border-top-color:#fff;\n  bottom:-12px;\n  margin:0 6.5px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="top"][arrow] .\\[1\\]_\\[2\\]_borderArrow{\n  border-bottom-width:0;\n  border-top-color:#d9d9d9;\n  bottom:-13px;\n  margin:0 6px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="bottom"][arrow] .\\[1\\]_\\[2\\]_arrow{\n  border-top-width:0;\n  border-bottom-color:#fff;\n  top:-12px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="bottom"][arrow] .\\[1\\]_\\[2\\]_borderArrow{\n  border-top-width:0;\n  border-bottom-color:#d9d9d9;\n  top:-13px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="right"][arrow] .\\[1\\]_\\[2\\]_arrow{\n  border-left-width:0;\n  border-right-color:#fff;\n  left:-12px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="right"][arrow] .\\[1\\]_\\[2\\]_borderArrow{\n  border-left-width:0;\n  border-right-color:#d9d9d9;\n  left:-13px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="left"][arrow] .\\[1\\]_\\[2\\]_arrow{\n  border-right-width:0;\n  border-left-color:#fff;\n  right:-12px;\n}\n.\\[1\\]_\\[2\\]_popper[data-placement^="left"][arrow] .\\[1\\]_\\[2\\]_borderArrow{\n  border-right-width:0;\n  border-left-color:#d9d9d9;\n  right:-13px;\n}\n', "", {
            version: 3,
            sources: [ "Popover.less" ],
            names: [],
            mappings: "AAAA;EACE,oBAAqB;EACrB,cAAe;AACjB;AACA;EACE,sBAAuB;EACvB,WAAY;EACZ,UAAW;EACX,cAAe;EACf,oBAAqB;EACrB,SAAU;EACV,cAAe;AACjB;AACA;;EAEE,yBAA0B;AAC5B;AACA;;EAEE,YAAa;EACb,aAAc;AAChB;AACA;EACE,mBAAoB;AACtB;AACA;EACE,oBAAqB;EACrB,gBAAiB;EACjB,yBAA0B;EAC1B,qBAAsB;EACtB,iBAAkB;AACpB;AACA;EACE,eAAgB;EAChB,wBAAyB;EACzB,iBAAkB;EAClB,+CAAyC;UAAzC,uCAAyC;EACzC,eAAgB;EAChB,WAAY;AACd;AACA;EACE,YAAa;AACf;AACA;EACE,iBAAkB;EAClB,SAAU;AACZ;AACA;;EAEE,OAAQ;EACR,QAAS;EACT,kBAAmB;EACnB,iBAAkB;EAClB,wBAAyB;AAC3B;AACA;EACE,iBAAkB;AACpB;AACA;EACE,iBAAkB;AACpB;AACA;EACE,qBAAsB;EACtB,qBAAsB;EACtB,YAAa;EACb,cAAsB;AACxB;AACA;EACE,qBAAsB;EACtB,wBAAyB;EACzB,YAAa;EACb,YAAsB;AACxB;AACA;EACE,kBAAmB;EACnB,wBAAyB;EACzB,SAAU;AACZ;AACA;EACE,kBAAmB;EACnB,2BAA4B;EAC5B,SAAU;AACZ;AACA;EACE,mBAAoB;EACpB,uBAAwB;EACxB,UAAW;AACb;AACA;EACE,mBAAoB;EACpB,0BAA2B;EAC3B,UAAW;AACb;AACA;EACE,oBAAqB;EACrB,sBAAuB;EACvB,WAAY;AACd;AACA;EACE,oBAAqB;EACrB,yBAA0B;EAC1B,WAAY;AACd",
            file: "Popover.less",
            sourcesContent: [ '.popover-container {\n  display: inline-block;\n  max-width: 100%;\n}\n.popover-container .button {\n  background: transparent;\n  border: none;\n  color: #000;\n  cursor: pointer;\n  display: inline-block;\n  padding: 0;\n  max-width: 100%;\n}\n.popover-container .button[href] > span:focus,\n.popover-container .button[href] > span:hover {\n  text-decoration: underline;\n}\n.popover-container .button:focus,\n.popover-container .button:hover {\n  outline: none;\n  color: #0088c1;\n}\n.popover-container .button[disabled="true"] {\n  pointer-events: none;\n}\n.popover-container .button .title {\n  display: inline-block;\n  font-weight: bold;\n  text-transform: capitalize;\n  vertical-align: middle;\n  text-align: center;\n}\n.popper {\n  background: #fff;\n  border: 1px solid #d9d9d9;\n  border-radius: 4px;\n  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.36);\n  list-style: none;\n  z-index: 999;\n}\n.popper[data-x-out-of-boundaries] {\n  display: none;\n}\n.popper .dropdown {\n  position: relative;\n  z-index: 1;\n}\n.popper .arrow,\n.popper .borderArrow {\n  width: 0;\n  height: 0;\n  border-style: solid;\n  position: absolute;\n  border-color: transparent;\n}\n.popper .arrow {\n  border-width: 12px;\n}\n.popper .borderArrow {\n  border-width: 13px;\n}\n.popper[data-placement^="top"][arrow] .arrow {\n  border-bottom-width: 0;\n  border-top-color: #fff;\n  bottom: -12px;\n  margin: 0 calc(13px/2);\n}\n.popper[data-placement^="top"][arrow] .borderArrow {\n  border-bottom-width: 0;\n  border-top-color: #d9d9d9;\n  bottom: -13px;\n  margin: 0 calc(12px/2);\n}\n.popper[data-placement^="bottom"][arrow] .arrow {\n  border-top-width: 0;\n  border-bottom-color: #fff;\n  top: -12px;\n}\n.popper[data-placement^="bottom"][arrow] .borderArrow {\n  border-top-width: 0;\n  border-bottom-color: #d9d9d9;\n  top: -13px;\n}\n.popper[data-placement^="right"][arrow] .arrow {\n  border-left-width: 0;\n  border-right-color: #fff;\n  left: -12px;\n}\n.popper[data-placement^="right"][arrow] .borderArrow {\n  border-left-width: 0;\n  border-right-color: #d9d9d9;\n  left: -13px;\n}\n.popper[data-placement^="left"][arrow] .arrow {\n  border-right-width: 0;\n  border-left-color: #fff;\n  right: -12px;\n}\n.popper[data-placement^="left"][arrow] .borderArrow {\n  border-right-width: 0;\n  border-left-color: #d9d9d9;\n  right: -13px;\n}\n' ]
        } ]);
        exports.locals = {
            "popover-container": "[1]_[2]_popover-container",
            button: "[1]_[2]_button",
            title: "[1]_[2]_title",
            popper: "[1]_[2]_popper",
            dropdown: "[1]_[2]_dropdown",
            arrow: "[1]_[2]_arrow",
            borderArrow: "[1]_[2]_borderArrow"
        };
    },
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Select.less": function(module, exports, __webpack_require__) {
        exports = module.exports = __webpack_require__("./node_modules/css-loader/dist/runtime/api.js")(true);
        exports.push([ module.i, "@media (max-width: 480px){\n  .\\[1\\]_\\[2\\]_hideBelowXs{\n    display:none !important;\n  }\n}\n@media (max-width: 768px){\n  .\\[1\\]_\\[2\\]_hideXsDown{\n    display:none !important;\n  }\n}\n@media (min-width: 480px){\n  .\\[1\\]_\\[2\\]_hideXsUp{\n    display:none !important;\n  }\n}\n@media (min-width: 769px){\n  .\\[1\\]_\\[2\\]_hideSmUp{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideSmDown{\n    display:none !important;\n  }\n}\n@media (max-width: 1024px){\n  .\\[1\\]_\\[2\\]_hideMdDown{\n    display:none !important;\n  }\n}\n@media (min-width: 1025px){\n  .\\[1\\]_\\[2\\]_hideMdUp{\n    display:none !important;\n  }\n}\n.\\[1\\]_\\[2\\]_container{\n  display:inline-block;\n  position:relative;\n  line-height:normal;\n}\n.\\[1\\]_\\[2\\]_container:not(.\\[1\\]_\\[2\\]_noArrow):before{\n  font-family:'zimbra-icons';\n  content:\"\\e930\";\n  position:absolute;\n  right:11px;\n  top:12px;\n  font-size:10px;\n}\n.\\[1\\]_\\[2\\]_container.\\[1\\]_\\[2\\]_fullWidth{\n  width:100%;\n}\n.\\[1\\]_\\[2\\]_container.\\[1\\]_\\[2\\]_fullWidth .\\[1\\]_\\[2\\]_select{\n  width:100%;\n}\n.\\[1\\]_\\[2\\]_select,\n.\\[1\\]_\\[2\\]_collapseLabel{\n  white-space:nowrap;\n  background-color:transparent;\n  padding:9px 34px 9px 12px;\n  border-radius:3px;\n  border:solid 1px #d9d9d9;\n  color:#262626;\n  position:relative;\n}\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_collapsable,\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_collapsable{\n  outline:none;\n  padding:0 25px 0 2px;\n}\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_bold,\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_bold{\n  font-weight:bold;\n}\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_noBorder,\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_noBorder{\n  border:0;\n}\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_noBorder:hover,\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_noBorder:hover,\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_noBorder:active,\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_noBorder:active,\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_noBorder:focus,\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_noBorder:focus{\n  background-color:#f2f2f2;\n}\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_inlineArrow:before{\n  font-family:'zimbra-icons';\n  content:\"\\e930\";\n  position:absolute;\n  right:11px;\n  top:1px;\n  font-size:9px;\n}\n.\\[1\\]_\\[2\\]_select{\n  -webkit-appearance:none;\n     -moz-appearance:none;\n          appearance:none;\n}\n.\\[1\\]_\\[2\\]_select::-ms-expand{\n  display:none;\n}\n.\\[1\\]_\\[2\\]_select.\\[1\\]_\\[2\\]_hidden{\n  opacity:0;\n}\n.\\[1\\]_\\[2\\]_collapseLabel{\n  line-height:14px;\n  position:absolute;\n  display:inline-block;\n  padding-right:25px;\n}\n.\\[1\\]_\\[2\\]_collapseLabel.\\[1\\]_\\[2\\]_hidden{\n  display:none;\n}\n", "", {
            version: 3,
            sources: [ "Select.less" ],
            names: [],
            mappings: "AAAA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE;IACE,uBAAwB;EAC1B;AACF;AACA;EACE,oBAAqB;EACrB,iBAAkB;EAClB,kBAAmB;AACrB;AACA;EACE,0BAA2B;EAC3B,eAAgB;EAChB,iBAAkB;EAClB,UAAW;EACX,QAAS;EACT,cAAe;AACjB;AACA;EACE,UAAW;AACb;AACA;EACE,UAAW;AACb;AACA;;EAEE,kBAAmB;EACnB,4BAA6B;EAC7B,yBAA0B;EAC1B,iBAAkB;EAClB,wBAAyB;EACzB,aAAc;EACd,iBAAkB;AACpB;AACA;;EAEE,YAAa;EACb,oBAAqB;AACvB;AACA;;EAEE,gBAAiB;AACnB;AACA;;EAEE,QAAS;AACX;AACA;;;;;;EAME,wBAAyB;AAC3B;AACA;EACE,0BAA2B;EAC3B,eAAgB;EAChB,iBAAkB;EAClB,UAAW;EACX,OAAQ;EACR,aAAc;AAChB;AACA;EACE,uBAAgB;KAAhB,oBAAgB;UAAhB,eAAgB;AAClB;AACA;EACE,YAAa;AACf;AACA;EACE,SAAU;AACZ;AACA;EACE,gBAAiB;EACjB,iBAAkB;EAClB,oBAAqB;EACrB,kBAAmB;AACrB;AACA;EACE,YAAa;AACf",
            file: "Select.less",
            sourcesContent: [ "@media (max-width: 480px) {\n  .hideBelowXs {\n    display: none !important;\n  }\n}\n@media (max-width: 768px) {\n  .hideXsDown {\n    display: none !important;\n  }\n}\n@media (min-width: 480px) {\n  .hideXsUp {\n    display: none !important;\n  }\n}\n@media (min-width: 769px) {\n  .hideSmUp {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideSmDown {\n    display: none !important;\n  }\n}\n@media (max-width: 1024px) {\n  .hideMdDown {\n    display: none !important;\n  }\n}\n@media (min-width: 1025px) {\n  .hideMdUp {\n    display: none !important;\n  }\n}\n.container {\n  display: inline-block;\n  position: relative;\n  line-height: normal;\n}\n.container:not(.noArrow):before {\n  font-family: 'zimbra-icons';\n  content: \"\\e930\";\n  position: absolute;\n  right: 11px;\n  top: 12px;\n  font-size: 10px;\n}\n.container.fullWidth {\n  width: 100%;\n}\n.container.fullWidth .select {\n  width: 100%;\n}\n.select,\n.collapseLabel {\n  white-space: nowrap;\n  background-color: transparent;\n  padding: 9px 34px 9px 12px;\n  border-radius: 3px;\n  border: solid 1px #d9d9d9;\n  color: #262626;\n  position: relative;\n}\n.select.collapsable,\n.collapseLabel.collapsable {\n  outline: none;\n  padding: 0 25px 0 2px;\n}\n.select.bold,\n.collapseLabel.bold {\n  font-weight: bold;\n}\n.select.noBorder,\n.collapseLabel.noBorder {\n  border: 0;\n}\n.select.noBorder:hover,\n.collapseLabel.noBorder:hover,\n.select.noBorder:active,\n.collapseLabel.noBorder:active,\n.select.noBorder:focus,\n.collapseLabel.noBorder:focus {\n  background-color: #f2f2f2;\n}\n.collapseLabel.inlineArrow:before {\n  font-family: 'zimbra-icons';\n  content: \"\\e930\";\n  position: absolute;\n  right: 11px;\n  top: 1px;\n  font-size: 9px;\n}\n.select {\n  appearance: none;\n}\n.select::-ms-expand {\n  display: none;\n}\n.select.hidden {\n  opacity: 0;\n}\n.collapseLabel {\n  line-height: 14px;\n  position: absolute;\n  display: inline-block;\n  padding-right: 25px;\n}\n.collapseLabel.hidden {\n  display: none;\n}\n" ]
        } ]);
        exports.locals = {
            hideBelowXs: "[1]_[2]_hideBelowXs",
            hideXsDown: "[1]_[2]_hideXsDown",
            hideXsUp: "[1]_[2]_hideXsUp",
            hideSmUp: "[1]_[2]_hideSmUp",
            hideSmDown: "[1]_[2]_hideSmDown",
            hideMdDown: "[1]_[2]_hideMdDown",
            hideMdUp: "[1]_[2]_hideMdUp",
            container: "[1]_[2]_container",
            noArrow: "[1]_[2]_noArrow",
            fullWidth: "[1]_[2]_fullWidth",
            select: "[1]_[2]_select",
            collapseLabel: "[1]_[2]_collapseLabel",
            collapsable: "[1]_[2]_collapsable",
            bold: "[1]_[2]_bold",
            noBorder: "[1]_[2]_noBorder",
            inlineArrow: "[1]_[2]_inlineArrow",
            hidden: "[1]_[2]_hidden"
        };
    },
    "./src/interop/assets/icons sync \\.svg$": function(module, exports, __webpack_require__) {
        var map = {
            "./email-placeholder.svg": "./src/interop/assets/icons/email-placeholder.svg"
        };
        function webpackContext(req) {
            var id = webpackContextResolve(req);
            return __webpack_require__(id);
        }
        function webpackContextResolve(req) {
            if (!__webpack_require__.o(map, req)) {
                var e = new Error("Cannot find module '" + req + "'");
                e.code = "MODULE_NOT_FOUND";
                throw e;
            }
            return map[req];
        }
        webpackContext.keys = function webpackContextKeys() {
            return Object.keys(map);
        };
        webpackContext.resolve = webpackContextResolve;
        module.exports = webpackContext;
        webpackContext.id = "./src/interop/assets/icons sync \\.svg$";
    },
    "./src/interop/assets/icons/email-placeholder.svg": function(module, exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "91c1e6d1d002e34a8dbdaf9c2f50b403.svg";
    },
    "./src/interop/shims/@zimbra-client/components/ActionButton.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/prop-types/index.js");
        var prop_types__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
        var _ActionButton_less__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionButton.less");
        var _ActionButton_less__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(_ActionButton_less__WEBPACK_IMPORTED_MODULE_2__);
        var _Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        var ActionButton = function ActionButton(_ref) {
            var children = _ref.children, className = _ref.className, iconClass = _ref.iconClass, cls = _ref["class"], monotone = _ref.monotone, icon = _ref.icon, iconOnly = _ref.iconOnly, iconSize = _ref.iconSize, rest = _objectWithoutPropertiesLoose(_ref, [ "children", "className", "iconClass", "class", "monotone", "icon", "iconOnly", "iconSize" ]);
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("button", _extends({}, rest, {
                class: [ _ActionButton_less__WEBPACK_IMPORTED_MODULE_2___default.a.button, monotone && _ActionButton_less__WEBPACK_IMPORTED_MODULE_2___default.a.monotone, className, cls ].join(" ")
            }), icon && (typeof icon === "string" ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Icon__WEBPACK_IMPORTED_MODULE_3__["default"], {
                name: icon,
                class: [ _ActionButton_less__WEBPACK_IMPORTED_MODULE_2___default.a.icon, iconClass ].join(" "),
                size: iconSize || "md"
            }) : icon), !iconOnly && children && children[0] && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                class: _ActionButton_less__WEBPACK_IMPORTED_MODULE_2___default.a.text
            }, children));
        };
        __webpack_exports__["default"] = ActionButton;
    },
    "./src/interop/shims/@zimbra-client/components/ActionButton.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionButton.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/ActionMenu.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "DropDownWrapper", (function() {
            return DropDownWrapper;
        }));
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return ActionMenu;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/prop-types/index.js");
        var prop_types__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
        var _ActionMenu_less__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionMenu.less");
        var _ActionMenu_less__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(_ActionMenu_less__WEBPACK_IMPORTED_MODULE_2__);
        var _Popover_less__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Popover.less");
        var _Popover_less__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(_Popover_less__WEBPACK_IMPORTED_MODULE_3__);
        var _Popover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Popover.js");
        var _Icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        var _ActionButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionButton.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        function DropDownWrapper(_ref) {
            var closeDropdown = _ref.closeDropdown, children = _ref.children;
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                onClick: closeDropdown
            }, children);
        }
        var ActionMenu = function(_Component) {
            _inheritsLoose(ActionMenu, _Component);
            var _super = _createSuper(ActionMenu);
            function ActionMenu() {
                var _this;
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                    args[_key] = arguments[_key];
                }
                _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                _defineProperty(_assertThisInitialized(_this), "state", {
                    active: false
                });
                _defineProperty(_assertThisInitialized(_this), "handleCloseDropdwon", (function() {
                    _this.setState({
                        active: false
                    });
                }));
                _defineProperty(_assertThisInitialized(_this), "handleToggleDropdown", (function() {
                    var active = !_this.state.active;
                    _this.setState({
                        active: active
                    });
                    _this.props.onToggle(active);
                }));
                _defineProperty(_assertThisInitialized(_this), "hideWhenDisabled", (function(disabled) {
                    _this.state.active && disabled && _this.setState({
                        active: false
                    });
                }));
                return _this;
            }
            var _proto = ActionMenu.prototype;
            _proto.componentWillMount = function componentWillMount() {
                this.hideWhenDisabled(this.props.disabled);
            };
            _proto.componentWillReceiveProps = function componentWillReceiveProps(_ref2) {
                var disabled = _ref2.disabled;
                this.hideWhenDisabled(disabled);
            };
            _proto.render = function render(_ref3, _ref4) {
                var _this2 = this;
                var label = _ref3.label, icon = _ref3.icon, iconOnly = _ref3.iconOnly, children = _ref3.children, disabled = _ref3.disabled, arrow = _ref3.arrow, corners = _ref3.corners, renderLabel = _ref3.renderLabel, popoverClass = _ref3.popoverClass, toggleClass = _ref3.toggleClass, actionButtonClass = _ref3.actionButtonClass, iconClass = _ref3.iconClass, iconSize = _ref3.iconSize, arrowSize = _ref3.arrowSize, monotone = _ref3.monotone, title = _ref3.title, rest = _objectWithoutPropertiesLoose(_ref3, [ "label", "icon", "iconOnly", "children", "disabled", "arrow", "corners", "renderLabel", "popoverClass", "toggleClass", "actionButtonClass", "iconClass", "iconSize", "arrowSize", "monotone", "title" ]);
                var active = _ref4.active;
                children = Object(preact__WEBPACK_IMPORTED_MODULE_0__["toChildArray"])(children);
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Popover__WEBPACK_IMPORTED_MODULE_4__["default"], _extends({}, rest, {
                    active: active,
                    disabled: disabled,
                    text: typeof renderLabel === "function" ? renderLabel({
                        toggle: this.handleToggleDropdown
                    }) : renderLabel || Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_ActionButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        className: actionButtonClass,
                        iconClass: iconClass,
                        icon: icon,
                        iconSize: iconSize,
                        disabled: disabled,
                        monotone: monotone,
                        title: title
                    }, (!iconOnly || arrow !== false) && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                        class: _ActionMenu_less__WEBPACK_IMPORTED_MODULE_2___default.a.text
                    }, !iconOnly && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                        class: _ActionMenu_less__WEBPACK_IMPORTED_MODULE_2___default.a.label
                    }, label), arrow !== false && [ " ", Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Icon__WEBPACK_IMPORTED_MODULE_5__["default"], {
                        name: "angle-down",
                        size: arrowSize
                    }) ])),
                    onToggle: this.handleToggleDropdown,
                    anchor: rest.anchor || "start",
                    corners: corners || "bottom",
                    classes: {
                        toggleClass: toggleClass,
                        containerClass: [ _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.popover, rest["class"] ].join(" ")
                    },
                    class: [ _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.popover, rest["class"] ].join(" "),
                    toggleClass: _ActionMenu_less__WEBPACK_IMPORTED_MODULE_2___default.a.toggle,
                    popoverClass: [ _ActionMenu_less__WEBPACK_IMPORTED_MODULE_2___default.a.dropdown, popoverClass ].join(" ")
                }), active && children.map((function(child) {
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["cloneElement"])(child, {
                        closeDropdown: _this2.handleCloseDropdwon
                    });
                })));
            };
            return ActionMenu;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
        _defineProperty(ActionMenu, "defaultProps", {
            onToggle: function onToggle() {},
            arrowSize: "xs"
        });
    },
    "./src/interop/shims/@zimbra-client/components/ActionMenu.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionMenu.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/ActionMenuGroup.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _ActionMenuGroup_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionMenuGroup.less");
        var _ActionMenuGroup_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_ActionMenuGroup_less__WEBPACK_IMPORTED_MODULE_1__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        var ActionMenuGroup = function ActionMenuGroup(_ref) {
            var children = _ref.children, rest = _objectWithoutPropertiesLoose(_ref, [ "children" ]);
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", _extends({}, rest, {
                class: [ _ActionMenuGroup_less__WEBPACK_IMPORTED_MODULE_1___default.a.group, rest["class"] ].join(" ")
            }), children);
        };
        __webpack_exports__["default"] = ActionMenuGroup;
    },
    "./src/interop/shims/@zimbra-client/components/ActionMenuGroup.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionMenuGroup.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/ActionMenuItem.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return ActionMenuItem;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionMenuItem.less");
        var _ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1__);
        var _MenuItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/MenuItem.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function stopPropagation(e) {
            e.stopPropagation();
        }
        function ActionMenuItem(_ref) {
            var cls = _ref["class"], className = _ref.className, iconClass = _ref.iconClass, onClick = _ref.onClick, narrow = _ref.narrow, rest = _objectWithoutPropertiesLoose(_ref, [ "class", "className", "iconClass", "onClick", "narrow" ]);
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_MenuItem__WEBPACK_IMPORTED_MODULE_2__["default"], _extends({}, rest, {
                class: [ _ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1___default.a.item, className, cls, narrow && _ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1___default.a.narrow, rest.disabled && _ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1___default.a.disabled ].join(" "),
                iconClass: [ _ActionMenuItem_less__WEBPACK_IMPORTED_MODULE_1___default.a.icon, iconClass ].join(" "),
                onClick: rest.disabled ? stopPropagation : onClick
            }));
        }
    },
    "./src/interop/shims/@zimbra-client/components/ActionMenuItem.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ActionMenuItem.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/Button.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return Button;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _Button_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Button.less");
        var _Button_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_Button_less__WEBPACK_IMPORTED_MODULE_1__);
        var _Icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        var preact_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function Button(_ref) {
            var styleType = _ref.styleType, _ref$size = _ref.size, size = _ref$size === void 0 ? "regular" : _ref$size, _ref$brand = _ref.brand, brand = _ref$brand === void 0 ? "" : _ref$brand, _ref$iconPosition = _ref.iconPosition, iconPosition = _ref$iconPosition === void 0 ? "left" : _ref$iconPosition, icon = _ref.icon, iconName = _ref.iconName, children = _ref.children, alignLeft = _ref.alignLeft, className = _ref.className, props = _objectWithoutPropertiesLoose(_ref, [ "styleType", "size", "brand", "iconPosition", "icon", "iconName", "children", "alignLeft", "className" ]);
            icon = iconName || typeof icon === "string" ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Icon__WEBPACK_IMPORTED_MODULE_2__["default"], {
                name: iconName || icon,
                class: [ _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a.icon, _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a[iconPosition] ].join(" ")
            }) : icon;
            var ComponentClass = "button";
            if (props.href) {
                ComponentClass = preact_router__WEBPACK_IMPORTED_MODULE_3__["Link"];
                props.role = "button";
            } else if (!props.type) props.type = "button";
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(ComponentClass, _extends({}, props, {
                className: [ _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a.button, styleType && _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a[styleType], _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a[size], brand && _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a["brand-" + brand], alignLeft && _Button_less__WEBPACK_IMPORTED_MODULE_1___default.a.alignLeft ].join(" ")
            }), iconPosition === "left" && icon, children, iconPosition === "right" && icon);
        }
    },
    "./src/interop/shims/@zimbra-client/components/Button.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Button.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/ChoiceInput.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return ChoiceInput;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _ChoiceInput_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ChoiceInput.less");
        var _ChoiceInput_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_ChoiceInput_less__WEBPACK_IMPORTED_MODULE_1__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function ChoiceInput(_ref) {
            var _ref$inlineStyle = _ref.inlineStyle, inlineStyle = _ref$inlineStyle === void 0 ? "" : _ref$inlineStyle, _ref$type = _ref.type, type = _ref$type === void 0 ? "checkbox" : _ref$type, _ref$containerClass = _ref.containerClass, containerClass = _ref$containerClass === void 0 ? "" : _ref$containerClass, elementClass = _ref["class"], props = _objectWithoutPropertiesLoose(_ref, [ "inlineStyle", "type", "containerClass", "class" ]);
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                className: [ _ChoiceInput_less__WEBPACK_IMPORTED_MODULE_1___default.a.choiceInputContainer, type === "radio" && "radioInput", containerClass ].join(" "),
                style: inlineStyle
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("input", _extends({}, props, {
                type: type,
                className: [ type === "radio" ? _ChoiceInput_less__WEBPACK_IMPORTED_MODULE_1___default.a.radio : _ChoiceInput_less__WEBPACK_IMPORTED_MODULE_1___default.a.checkbox, elementClass ].join(" ")
            })), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("i", null));
        }
    },
    "./src/interop/shims/@zimbra-client/components/ChoiceInput.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ChoiceInput.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/ClickOutsideDetector.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return ClickOutsideDetector;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var ClickOutsideDetector = function(_Component) {
            _inheritsLoose(ClickOutsideDetector, _Component);
            var _super = _createSuper(ClickOutsideDetector);
            function ClickOutsideDetector() {
                var _this;
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                    args[_key] = arguments[_key];
                }
                _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                _defineProperty(_assertThisInitialized(_this), "handleKeyDown", (function(e) {
                    var _this$props = _this.props, onClickOutside = _this$props.onClickOutside, disableEscape = _this$props.disableEscape;
                    if (e.keyCode === 27 && typeof onClickOutside === "function" && !disableEscape) {
                        onClickOutside(e);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "isMouseClickInBaseRect", (function(_ref) {
                    var clientX = _ref.clientX, clientY = _ref.clientY;
                    var _this$base$getBoundin = _this.base.getBoundingClientRect(), left = _this$base$getBoundin.left, top = _this$base$getBoundin.top, width = _this$base$getBoundin.width, height = _this$base$getBoundin.height;
                    if (typeof clientX === "undefined" || typeof clientY === "undefined") {
                        return true;
                    }
                    return clientX >= left && clientX <= left + width && clientY >= top && clientY <= top + height;
                }));
                _defineProperty(_assertThisInitialized(_this), "handleClick", (function(e) {
                    var target = e.target;
                    var onClickOutside = _this.props.onClickOutside;
                    if (typeof _this.base !== "undefined" && !_this.base.contains(target) && typeof onClickOutside === "function" && !_this.isMouseClickInBaseRect(e)) {
                        onClickOutside(e);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "handleBlur", (function(e) {
                    var onClickOutside = _this.props.onClickOutside;
                    if (document && document.activeElement && document.activeElement.nodeName === "IFRAME" && !_this.base.contains(document.activeElement) && typeof onClickOutside === "function") {
                        onClickOutside(e);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "events", (function(onOrOff) {
                    var fn = onOrOff === true ? addEventListener : removeEventListener;
                    fn("click", _this.handleClick, true);
                    fn("touchstart", _this.handleClick, true);
                    fn("keydown", _this.handleKeyDown, true);
                    fn("blur", _this.handleBlur, true);
                    fn("contextmenu", _this.handleClick, true);
                }));
                return _this;
            }
            var _proto = ClickOutsideDetector.prototype;
            _proto.componentDidMount = function componentDidMount() {
                this.events(true);
            };
            _proto.componentWillUnmount = function componentWillUnmount() {
                this.events(false);
            };
            _proto.render = function render(_ref2) {
                var children = _ref2.children;
                return children;
            };
            return ClickOutsideDetector;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
    },
    "./src/interop/shims/@zimbra-client/components/CloseButton.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return CloseButton;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var preact_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/preact-i18n/dist/preact-i18n.esm.js");
        var _CloseButton_less__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/CloseButton.less");
        var _CloseButton_less__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(_CloseButton_less__WEBPACK_IMPORTED_MODULE_2__);
        var _Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function CloseButton(props) {
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_i18n__WEBPACK_IMPORTED_MODULE_1__["Localizer"], null, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("button", _extends({
                "aria-label": Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_i18n__WEBPACK_IMPORTED_MODULE_1__["Text"], {
                    id: "buttons.close"
                })
            }, props, {
                className: [ _CloseButton_less__WEBPACK_IMPORTED_MODULE_2___default.a.close, props["class"] ].join(" ")
            }), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Icon__WEBPACK_IMPORTED_MODULE_3__["default"], {
                name: "close"
            })));
        }
    },
    "./src/interop/shims/@zimbra-client/components/CloseButton.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/CloseButton.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/Icon.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return Icon;
        }));
        __webpack_require__.d(__webpack_exports__, "FontAwesome", (function() {
            return FontAwesome;
        }));
        __webpack_require__.d(__webpack_exports__, "ClientIcon", (function() {
            return ClientIcon;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _Icon_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.less");
        var _Icon_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_Icon_less__WEBPACK_IMPORTED_MODULE_1__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        var FA_PREFIX = "fa:";
        var CLIENT_PREFIX = "client:";
        function Icon(_ref) {
            var name = _ref.name, _ref$size = _ref.size, size = _ref$size === void 0 ? "md" : _ref$size, props = _objectWithoutPropertiesLoose(_ref, [ "name", "size" ]);
            if (name && name.indexOf(FA_PREFIX) === 0) {
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(FontAwesome, _extends({
                    name: name.substr(FA_PREFIX.length),
                    size: size
                }, props));
            }
            if (name && name.indexOf(CLIENT_PREFIX) === 0) {
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(ClientIcon, _extends({
                    name: name.substr(CLIENT_PREFIX.length),
                    size: size
                }, props));
            }
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", _extends({
                role: "img"
            }, props, {
                class: [ "zimbra-icon", name && "zimbra-icon-" + name, _Icon_less__WEBPACK_IMPORTED_MODULE_1___default.a[size], props["class"], props.className ].join(" "),
                tabIndex: props.onClick ? "0" : false
            }));
        }
        function FontAwesome(_ref2) {
            var name = _ref2.name, _ref2$size = _ref2.size, size = _ref2$size === void 0 ? "md" : _ref2$size, props = _objectWithoutPropertiesLoose(_ref2, [ "name", "size" ]);
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", _extends({
                role: "img"
            }, props, {
                class: [ "fa", name && "fa-" + name, _Icon_less__WEBPACK_IMPORTED_MODULE_1___default.a[size], props["class"], props.className ].join(" "),
                tabIndex: props.onClick ? "0" : false
            }));
        }
        var clientIconRequire = __webpack_require__("./src/interop/assets/icons sync \\.svg$");
        function ClientIcon(_ref3) {
            var name = _ref3.name, _ref3$size = _ref3.size, size = _ref3$size === void 0 ? "md" : _ref3$size, props = _objectWithoutPropertiesLoose(_ref3, [ "name", "size" ]);
            return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("img", _extends({}, props, {
                src: clientIconRequire("./" + name + ".svg"),
                class: [ _Icon_less__WEBPACK_IMPORTED_MODULE_1___default.a["img-" + size], props["class"], props.className ].join(" "),
                tabIndex: props.onClick ? "0" : false
            }));
        }
    },
    "./src/interop/shims/@zimbra-client/components/Icon.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Icon.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/MenuItem.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return MenuItem;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var preact_router_match__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/preact-router/match.js");
        var preact_router_match__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(preact_router_match__WEBPACK_IMPORTED_MODULE_1__);
        var preact_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var escape_string_regexp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/escape-string-regexp/index.js");
        var escape_string_regexp__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(escape_string_regexp__WEBPACK_IMPORTED_MODULE_3__);
        var _Icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        var _MenuItem_less__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/MenuItem.less");
        var _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default = __webpack_require__.n(_MenuItem_less__WEBPACK_IMPORTED_MODULE_5__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function MenuItem(_ref) {
            var customClass = _ref.customClass, activeClass = _ref.activeClass, iconClass = _ref.iconClass, innerClass = _ref.innerClass, match = _ref.match, icon = _ref.icon, _ref$iconPosition = _ref.iconPosition, iconPosition = _ref$iconPosition === void 0 ? "left" : _ref$iconPosition, _ref$isExternal = _ref.isExternal, isExternal = _ref$isExternal === void 0 ? false : _ref$isExternal, iconText = _ref.iconText, responsive = _ref.responsive, children = _ref.children, sidebarEnable = _ref.sidebarEnable, href = _ref.href, props = _objectWithoutPropertiesLoose(_ref, [ "customClass", "activeClass", "iconClass", "innerClass", "match", "icon", "iconPosition", "isExternal", "iconText", "responsive", "children", "sidebarEnable", "href" ]);
            if (match && typeof match === "string") {
                match = new RegExp("^" + escape_string_regexp__WEBPACK_IMPORTED_MODULE_3___default()(match) + (match.endsWith("/") ? "?" : ""));
            }
            var childElement = Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                className: [ iconClass || _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.icon, props.disabled && _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.iconDisabled ].join(" ")
            }, typeof icon === "string" ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Icon__WEBPACK_IMPORTED_MODULE_4__["default"], {
                name: icon
            }) : icon, iconText && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                className: _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.iconText
            }, iconText)), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                className: [ _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.inner, innerClass ].join(" ")
            }, children));
            var classList = [ !customClass && _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.navItem, icon && (iconPosition === "right" ? _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.iconRight : _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.iconLeft), customClass !== true && customClass, props["class"], responsive && _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.responsive, props.disabled && _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.disabled, sidebarEnable && _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.sidebarEnable ].join(" ");
            return href ? isExternal ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("a", {
                target: "_blank",
                rel: "noopener noreferrer",
                href: href,
                className: classList
            }, childElement) : Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_router_match__WEBPACK_IMPORTED_MODULE_1__["Match"], {
                path: href
            }, (function(_ref2) {
                var matches = _ref2.matches, url = _ref2.url;
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_router__WEBPACK_IMPORTED_MODULE_2__["Link"], _extends({}, props, {
                    href: href,
                    className: [ (matches || match && match.test(url)) && [ _MenuItem_less__WEBPACK_IMPORTED_MODULE_5___default.a.active, activeClass ].join(" "), classList ].join(" ")
                }), childElement);
            })) : Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", _extends({}, props, {
                className: classList
            }), childElement);
        }
    },
    "./src/interop/shims/@zimbra-client/components/MenuItem.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/MenuItem.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/ModalDialog.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return ModalDialog;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var preact_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/preact-i18n/dist/preact-i18n.esm.js");
        var preact_compat__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/preact/compat/dist/compat.module.js");
        var _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ModalDialog.less");
        var _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(_ModalDialog_less__WEBPACK_IMPORTED_MODULE_3__);
        var _CloseButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/CloseButton.js");
        var _Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Button.js");
        function ModalDialog(_ref) {
            var children = _ref.children, title = _ref.title, buttons = _ref.buttons, onClose = _ref.onClose, cancelButton = _ref.cancelButton, onAction = _ref.onAction, pending = _ref.pending, disablePrimary = _ref.disablePrimary, actionLabel = _ref.actionLabel, cancelLabel = _ref.cancelLabel, innerClass = _ref.innerClass;
            function stopPropagation(ev) {
                ev.stopPropagation();
            }
            var body = __TEAM_IS_STANDALONE_APP || __TEAM_IS_CLASSIC_ZIMLET ? document.body : window.parent.document.body;
            return Object(preact_compat__WEBPACK_IMPORTED_MODULE_2__["createPortal"])(Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.overlay,
                onClick: onClose
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                role: "dialog",
                className: _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.ModalDialog,
                onClick: stopPropagation
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: [ _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.ModalDialogInner, innerClass ].join(" ")
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("header", {
                className: _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.header
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("h2", null, typeof title === "string" ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_i18n__WEBPACK_IMPORTED_MODULE_1__["Text"], {
                id: title
            }, title) : title), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_CloseButton__WEBPACK_IMPORTED_MODULE_4__["default"], {
                onClick: onClose,
                class: _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.actionButton
            })), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                className: _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.content
            }, children), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("footer", {
                className: _ModalDialog_less__WEBPACK_IMPORTED_MODULE_3___default.a.footer
            }, buttons !== false && (buttons || Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Button__WEBPACK_IMPORTED_MODULE_5__["default"], {
                styleType: "primary",
                brand: "primary",
                onClick: onAction,
                disabled: pending || disablePrimary
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_i18n__WEBPACK_IMPORTED_MODULE_1__["Text"], {
                id: actionLabel
            }, actionLabel))), cancelButton !== false && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Button__WEBPACK_IMPORTED_MODULE_5__["default"], {
                onClick: onClose
            }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(preact_i18n__WEBPACK_IMPORTED_MODULE_1__["Text"], {
                id: cancelLabel || buttons && buttons.cancel || "buttons.cancel"
            }, cancelLabel || "Cancel")))))), body);
        }
    },
    "./src/interop/shims/@zimbra-client/components/ModalDialog.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/ModalDialog.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/Popover.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return Popover;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var preact_compat__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/preact/compat/dist/compat.module.js");
        var react_popper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/react-popper/lib/esm/index.js");
        var _Popover_less__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Popover.less");
        var _Popover_less__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(_Popover_less__WEBPACK_IMPORTED_MODULE_3__);
        var _Icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        var _ClickOutsideDetector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ClickOutsideDetector.js");
        var _utils_call_with__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/interop/utils/call-with.js");
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var Popover = function(_Component) {
            _inheritsLoose(Popover, _Component);
            var _super = _createSuper(Popover);
            function Popover() {
                var _this;
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                    args[_key] = arguments[_key];
                }
                _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                _defineProperty(_assertThisInitialized(_this), "state", {
                    active: _this.props.active || false
                });
                _defineProperty(_assertThisInitialized(_this), "focusAfterToggle", (function() {
                    !_this.state.active && _this.props.focusAfterClosing && _this.buttonRef.focus();
                }));
                _defineProperty(_assertThisInitialized(_this), "togglePopover", (function() {
                    var active = !_this.state.active;
                    _this.setState({
                        active: active
                    }, _this.focusAfterToggle);
                    _this.props.onToggle && _this.props.onToggle(active);
                }));
                _defineProperty(_assertThisInitialized(_this), "closePopover", (function(e) {
                    if (e && e.target && _this.buttonRef.contains(e.target)) {
                        e.stopPropagation();
                    }
                    if (_this.state.active) {
                        _this.setState({
                            active: false
                        }, _this.focusAfterToggle);
                        _this.props.onToggle && _this.props.onToggle(false);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "openPopover", (function() {
                    if (!_this.state.active) {
                        _this.setState({
                            active: true
                        }, _this.focusAfterToggle);
                        _this.props.onToggle && _this.props.onToggle(true);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "handleMouseEnterTarget", (function() {
                    _this.hoverTarget = true;
                    _this.handleMouseEnter();
                }));
                _defineProperty(_assertThisInitialized(_this), "handleMouseEnterChild", (function() {
                    _this.hoverChild = true;
                    _this.handleMouseEnter();
                }));
                _defineProperty(_assertThisInitialized(_this), "handleMouseEnter", (function() {
                    if (_this.timer) {
                        clearTimeout(_this.timer);
                        delete _this.timer;
                    }
                    if (!_this.state.active) {
                        _this.timer = setTimeout((function() {
                            return (_this.hoverTarget || _this.hoverChild) && _this.openPopover();
                        }), _this.props.hoverDuration);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "handleMouseLeaveTarget", (function() {
                    _this.hoverTarget = false;
                    _this.handleMouseLeave();
                }));
                _defineProperty(_assertThisInitialized(_this), "handleMouseLeaveChild", (function() {
                    _this.hoverChild = false;
                    _this.handleMouseLeave();
                }));
                _defineProperty(_assertThisInitialized(_this), "handleMouseLeave", (function() {
                    if (_this.timer) {
                        clearTimeout(_this.timer);
                        delete _this.timer;
                    }
                    if (_this.state.active) {
                        _this.timer = setTimeout((function() {
                            return !(_this.hoverTarget || _this.hoverChild) && _this.closePopover();
                        }), _this.props.hoverDuration);
                    }
                }));
                _defineProperty(_assertThisInitialized(_this), "getClasses", (function() {
                    var _this$props = _this.props, popoverClass = _this$props.popoverClass, toggleClass = _this$props.toggleClass, titleClass = _this$props.titleClass, containerClass = _this$props.containerClass, classes = _this$props.classes;
                    return _extends({
                        popoverClass: popoverClass,
                        toggleClass: toggleClass,
                        titleClass: titleClass,
                        containerClass: containerClass
                    }, classes);
                }));
                _defineProperty(_assertThisInitialized(_this), "chainReferences", (function(refFn, c) {
                    return refFn(_this.buttonRef = c);
                }));
                _defineProperty(_assertThisInitialized(_this), "renderReference", (function(_ref) {
                    var ref = _ref.ref;
                    var handler = _this.props.useMouseDownEvents ? {
                        onMouseDown: _this.togglePopover
                    } : {
                        onClick: _this.togglePopover
                    };
                    var _this$props2 = _this.props, disabled = _this$props2.disabled, icon = _this$props2.icon, iconPosition = _this$props2.iconPosition, target = _this$props2.target, text = _this$props2.text, tooltip = _this$props2.tooltip, hoverDuration = _this$props2.hoverDuration;
                    var classes = _this.getClasses();
                    if (typeof icon === "string") {
                        icon = Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_Icon__WEBPACK_IMPORTED_MODULE_4__["default"], {
                            name: icon
                        });
                    }
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", _extends({
                        ref: Object(_utils_call_with__WEBPACK_IMPORTED_MODULE_6__["callWith"])(_this.chainReferences, ref, true),
                        role: "button",
                        "aria-haspopup": "true",
                        "aria-expanded": String(Boolean(_this.state.active)),
                        className: [ classes.toggleClass, _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.button ].join(" ")
                    }, handler, {
                        onMouseEnter: hoverDuration && _this.handleMouseEnterTarget,
                        onMouseLeave: hoverDuration && _this.handleMouseLeaveTarget,
                        onDrag: _this.closePopover,
                        disabled: disabled,
                        title: tooltip
                    }), iconPosition === "left" && icon, text && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
                        className: [ _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.title, classes.titleClass ].join(" ")
                    }, text), target, iconPosition !== "left" && icon);
                }));
                return _this;
            }
            var _proto = Popover.prototype;
            _proto.componentWillReceiveProps = function componentWillReceiveProps(_ref2) {
                var active = _ref2.active;
                typeof active === "boolean" && this.props.active !== active && this.setState({
                    active: active
                }, this.focusAfterToggle);
            };
            _proto.render = function render(_ref3, _ref4) {
                var placement = _ref3.placement, boundariesElement = _ref3.boundariesElement, children = _ref3.children, classes = _ref3.classes, disabled = _ref3.disabled, hoverDuration = _ref3.hoverDuration, popoverClass = _ref3.popoverClass, toggleClass = _ref3.toggleClass, titleClass = _ref3.titleClass, containerClass = _ref3.containerClass, icon = _ref3.icon, iconPosition = _ref3.iconPosition, text = _ref3.text, target = _ref3.target, arrow = _ref3.arrow, anchor = _ref3.anchor, corners = _ref3.corners, tooltip = _ref3.tooltip, href = _ref3.href, onDropdownClick = _ref3.onDropdownClick, useMouseDownEvents = _ref3.useMouseDownEvents, into = _ref3.into, props = _objectWithoutPropertiesLoose(_ref3, [ "placement", "boundariesElement", "children", "classes", "disabled", "hoverDuration", "popoverClass", "toggleClass", "titleClass", "containerClass", "icon", "iconPosition", "text", "target", "arrow", "anchor", "corners", "tooltip", "href", "onDropdownClick", "useMouseDownEvents", "into" ]);
                var active = _ref4.active;
                delete props.onToggle;
                delete props.active;
                classes = this.getClasses();
                if (anchor === "center") anchor = false;
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(react_popper__WEBPACK_IMPORTED_MODULE_2__["Manager"], null, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", _extends({}, props, {
                    className: [ _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a["popover-container"], classes.containerClass, props["class"] ].join(" ")
                }), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(react_popper__WEBPACK_IMPORTED_MODULE_2__["Reference"], null, this.renderReference), active && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(ActivePopper, {
                    arrow: arrow,
                    classes: classes,
                    onDropdownClick: onDropdownClick,
                    onMouseEnter: hoverDuration && this.handleMouseEnterChild,
                    onMouseLeave: hoverDuration && this.handleMouseLeaveChild,
                    onClickOutside: this.closePopover,
                    placement: placement,
                    anchor: anchor,
                    boundariesElement: boundariesElement
                }, children)));
            };
            return Popover;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
        _defineProperty(Popover, "defaultProps", {
            anchor: "start",
            onDropdownClick: function onDropdownClick() {},
            corners: "all",
            placement: "bottom",
            boundariesElement: "window",
            useMouseDownEvents: false,
            classes: {}
        });
        var ActivePopper = function(_Component2) {
            _inheritsLoose(ActivePopper, _Component2);
            var _super2 = _createSuper(ActivePopper);
            function ActivePopper() {
                var _this2;
                for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
                    args[_key2] = arguments[_key2];
                }
                _this2 = _Component2.call.apply(_Component2, [ this ].concat(args)) || this;
                _defineProperty(_assertThisInitialized(_this2), "renderPopper", (function(_ref5) {
                    var ref = _ref5.ref, style = _ref5.style, placement = _ref5.placement, scheduleUpdate = _ref5.scheduleUpdate, arrowProps = _ref5.arrowProps;
                    var _this2$props = _this2.props, arrow = _this2$props.arrow, children = _this2$props.children, classes = _this2$props.classes, onDropdownClick = _this2$props.onDropdownClick, onMouseEnter = _this2$props.onMouseEnter, onMouseLeave = _this2$props.onMouseLeave;
                    var childArray = Object(preact__WEBPACK_IMPORTED_MODULE_0__["toChildArray"])(children);
                    var newArrowProps, borderArrowProps;
                    if (arrow) {
                        var _extends2;
                        var inversePlacement = placement === "left" ? "right" : placement === "right" ? "left" : placement === "top" ? "bottom" : "top";
                        style = _extends({}, style, (_extends2 = {}, _extends2["margin-" + inversePlacement] = "13px", 
                        _extends2));
                        var arrowMargins = placement === "left" || placement === "right" ? [ "6.5px 0", "6px 0" ] : [ "0 6.5px", "0 6px" ];
                        newArrowProps = _extends({}, arrowProps, {
                            style: _extends({}, arrowProps.style, {
                                margin: arrowMargins[0]
                            })
                        });
                        borderArrowProps = _extends({}, arrowProps, {
                            style: _extends({}, arrowProps.style, {
                                margin: arrowMargins[1]
                            })
                        });
                    }
                    return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                        arrow: !!arrow,
                        ref: ref,
                        style: style,
                        "data-placement": placement,
                        className: [ _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.popper, classes.popoverClass ].join(" "),
                        onMouseEnter: onMouseEnter,
                        onMouseLeave: onMouseLeave
                    }, childArray.length && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                        className: _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.dropdown,
                        onClick: onDropdownClick
                    }, childArray.map((function(c) {
                        return c ? Object(preact__WEBPACK_IMPORTED_MODULE_0__["cloneElement"])(c, {
                            scheduleUpdate: scheduleUpdate
                        }) : c;
                    }))), arrow && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", _extends({}, borderArrowProps, {
                        className: _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.borderArrow
                    })), arrow && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", _extends({}, newArrowProps, {
                        className: _Popover_less__WEBPACK_IMPORTED_MODULE_3___default.a.arrow
                    })));
                }));
                return _this2;
            }
            var _proto2 = ActivePopper.prototype;
            _proto2.render = function render(_ref6) {
                var arrow = _ref6.arrow, placement = _ref6.placement, anchor = _ref6.anchor, boundariesElement = _ref6.boundariesElement, _ref6$into = _ref6.into, into = _ref6$into === void 0 ? document.body : _ref6$into, onClickOutside = _ref6.onClickOutside;
                var content = Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_ClickOutsideDetector__WEBPACK_IMPORTED_MODULE_5__["default"], {
                    onClickOutside: onClickOutside
                }, Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])(react_popper__WEBPACK_IMPORTED_MODULE_2__["Popper"], {
                    arrow: arrow,
                    placement: "" + placement + (anchor ? "-" + anchor : ""),
                    modifiers: {
                        preventOverflow: {
                            boundariesElement: boundariesElement
                        }
                    }
                }, this.renderPopper));
                return !into ? content : Object(preact_compat__WEBPACK_IMPORTED_MODULE_1__["createPortal"])(content, into);
            };
            return ActivePopper;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
    },
    "./src/interop/shims/@zimbra-client/components/Popover.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Popover.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/Select.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "default", (function() {
            return Select;
        }));
        var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact/dist/preact.module.js");
        var _Select_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Select.less");
        var _Select_less__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_Select_less__WEBPACK_IMPORTED_MODULE_1__);
        function _extends() {
            _extends = Object.assign || function(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i];
                    for (var key in source) {
                        if (Object.prototype.hasOwnProperty.call(source, key)) {
                            target[key] = source[key];
                        }
                    }
                }
                return target;
            };
            return _extends.apply(this, arguments);
        }
        function _objectWithoutPropertiesLoose(source, excluded) {
            if (source == null) return {};
            var target = {};
            var sourceKeys = Object.keys(source);
            var key, i;
            for (i = 0; i < sourceKeys.length; i++) {
                key = sourceKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                target[key] = source[key];
            }
            return target;
        }
        function _createSuper(Derived) {
            return function() {
                var Super = _getPrototypeOf(Derived), result;
                if (_isNativeReflectConstruct()) {
                    var NewTarget = _getPrototypeOf(this).constructor;
                    result = Reflect.construct(Super, arguments, NewTarget);
                } else {
                    result = Super.apply(this, arguments);
                }
                return _possibleConstructorReturn(this, result);
            };
        }
        function _possibleConstructorReturn(self, call) {
            if (call && (typeof call === "object" || typeof call === "function")) {
                return call;
            }
            return _assertThisInitialized(self);
        }
        function _assertThisInitialized(self) {
            if (self === void 0) {
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            }
            return self;
        }
        function _isNativeReflectConstruct() {
            if (typeof Reflect === "undefined" || !Reflect.construct) return false;
            if (Reflect.construct.sham) return false;
            if (typeof Proxy === "function") return true;
            try {
                Date.prototype.toString.call(Reflect.construct(Date, [], (function() {})));
                return true;
            } catch (e) {
                return false;
            }
        }
        function _getPrototypeOf(o) {
            _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
                return o.__proto__ || Object.getPrototypeOf(o);
            };
            return _getPrototypeOf(o);
        }
        function _inheritsLoose(subClass, superClass) {
            subClass.prototype = Object.create(superClass.prototype);
            subClass.prototype.constructor = subClass;
            subClass.__proto__ = superClass;
        }
        function _defineProperty(obj, key, value) {
            if (key in obj) {
                Object.defineProperty(obj, key, {
                    value: value,
                    enumerable: true,
                    configurable: true,
                    writable: true
                });
            } else {
                obj[key] = value;
            }
            return obj;
        }
        var Select = function(_Component) {
            _inheritsLoose(Select, _Component);
            var _super = _createSuper(Select);
            function Select() {
                var _this;
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                    args[_key] = arguments[_key];
                }
                _this = _Component.call.apply(_Component, [ this ].concat(args)) || this;
                _defineProperty(_assertThisInitialized(_this), "state", {
                    selectedLabel: "",
                    isOpen: false
                });
                _defineProperty(_assertThisInitialized(_this), "handleClick", (function() {
                    var nextIsOpen = !_this.state.isOpen;
                    _this.setState({
                        isOpen: nextIsOpen
                    });
                }));
                _defineProperty(_assertThisInitialized(_this), "updateLabel", (function() {
                    if (_this.props.collapseLabel) {
                        setTimeout((function() {
                            _this.setState({
                                selectedLabel: _this.select.options[_this.select.selectedIndex].text
                            });
                        }), 0);
                    }
                }));
                return _this;
            }
            var _proto = Select.prototype;
            _proto.componentDidMount = function componentDidMount() {
                this.updateLabel();
            };
            _proto.componentWillUpdate = function componentWillUpdate(nextProps) {
                if (nextProps.value !== this.props.value) {
                    this.setState({
                        isOpen: false
                    });
                }
            };
            _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
                if (this.props.value !== prevProps.value) {
                    this.updateLabel();
                }
            };
            _proto.render = function render(_ref, _ref2) {
                var _this2 = this;
                var noBorder = _ref.noBorder, noArrow = _ref.noArrow, inlineArrow = _ref.inlineArrow, bold = _ref.bold, collapseLabel = _ref.collapseLabel, fullWidth = _ref.fullWidth, cls = _ref["class"], disabled = _ref.disabled, rest = _objectWithoutPropertiesLoose(_ref, [ "noBorder", "noArrow", "inlineArrow", "bold", "collapseLabel", "fullWidth", "class", "disabled" ]);
                var isOpen = _ref2.isOpen, selectedLabel = _ref2.selectedLabel;
                return Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                    class: [ _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.container, fullWidth && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.fullWidth, inlineArrow && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.noArrow ].join(" ")
                }, collapseLabel && Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("div", {
                    class: [ _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.collapseLabel, collapseLabel && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.collapsable, noBorder && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.noBorder, noArrow && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.noArrow, bold && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.bold, isOpen && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.hidden, inlineArrow && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.inlineArrow, cls ].join(" "),
                    onClick: this.handleClick
                }, selectedLabel), Object(preact__WEBPACK_IMPORTED_MODULE_0__["createElement"])("select", _extends({}, rest, {
                    class: [ _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.select, collapseLabel && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.collapsable, collapseLabel && !isOpen && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.hidden, noBorder && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.noBorder, noArrow && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.noArrow, bold && _Select_less__WEBPACK_IMPORTED_MODULE_1___default.a.bold, cls ].join(" "),
                    ref: function ref(_ref3) {
                        return _this2.select = _ref3;
                    },
                    disabled: disabled
                })));
            };
            return Select;
        }(preact__WEBPACK_IMPORTED_MODULE_0__["Component"]);
    },
    "./src/interop/shims/@zimbra-client/components/Select.less": function(module, exports, __webpack_require__) {
        var api = __webpack_require__("./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
        var content = __webpack_require__("./node_modules/css-loader/dist/cjs.js?!./node_modules/resolve-url-loader/index.js!./node_modules/postcss-loader/src/index.js?!./node_modules/less-loader/dist/cjs.js!./src/interop/shims/@zimbra-client/components/Select.less");
        content = content.__esModule ? content.default : content;
        if (typeof content === "string") {
            content = [ [ module.i, content, "" ] ];
        }
        var options = {};
        options.insert = "head";
        options.singleton = false;
        var update = api(module.i, content, options);
        var exported = content.locals ? content.locals : {};
        module.exports = exported;
    },
    "./src/interop/shims/@zimbra-client/components/index.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        var _ActionButton__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionButton.js");
        __webpack_require__.d(__webpack_exports__, "ActionButton", (function() {
            return _ActionButton__WEBPACK_IMPORTED_MODULE_0__["default"];
        }));
        var _ActionMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionMenu.js");
        __webpack_require__.d(__webpack_exports__, "ActionMenu", (function() {
            return _ActionMenu__WEBPACK_IMPORTED_MODULE_1__["default"];
        }));
        __webpack_require__.d(__webpack_exports__, "DropDownWrapper", (function() {
            return _ActionMenu__WEBPACK_IMPORTED_MODULE_1__["DropDownWrapper"];
        }));
        var _ActionMenuGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionMenuGroup.js");
        __webpack_require__.d(__webpack_exports__, "ActionMenuGroup", (function() {
            return _ActionMenuGroup__WEBPACK_IMPORTED_MODULE_2__["default"];
        }));
        var _ActionMenuItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ActionMenuItem.js");
        __webpack_require__.d(__webpack_exports__, "ActionMenuItem", (function() {
            return _ActionMenuItem__WEBPACK_IMPORTED_MODULE_3__["default"];
        }));
        var _Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Button.js");
        __webpack_require__.d(__webpack_exports__, "Button", (function() {
            return _Button__WEBPACK_IMPORTED_MODULE_4__["default"];
        }));
        var _ChoiceInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ChoiceInput.js");
        __webpack_require__.d(__webpack_exports__, "ChoiceInput", (function() {
            return _ChoiceInput__WEBPACK_IMPORTED_MODULE_5__["default"];
        }));
        var _ClickOutsideDetector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ClickOutsideDetector.js");
        __webpack_require__.d(__webpack_exports__, "ClickOutsideDetector", (function() {
            return _ClickOutsideDetector__WEBPACK_IMPORTED_MODULE_6__["default"];
        }));
        var _CloseButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/CloseButton.js");
        __webpack_require__.d(__webpack_exports__, "CloseButton", (function() {
            return _CloseButton__WEBPACK_IMPORTED_MODULE_7__["default"];
        }));
        var _Icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Icon.js");
        __webpack_require__.d(__webpack_exports__, "Icon", (function() {
            return _Icon__WEBPACK_IMPORTED_MODULE_8__["default"];
        }));
        var _MenuItem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/MenuItem.js");
        __webpack_require__.d(__webpack_exports__, "MenuItem", (function() {
            return _MenuItem__WEBPACK_IMPORTED_MODULE_9__["default"];
        }));
        var _ModalDialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/ModalDialog.js");
        __webpack_require__.d(__webpack_exports__, "ModalDialog", (function() {
            return _ModalDialog__WEBPACK_IMPORTED_MODULE_10__["default"];
        }));
        var _Popover__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Popover.js");
        __webpack_require__.d(__webpack_exports__, "Popover", (function() {
            return _Popover__WEBPACK_IMPORTED_MODULE_11__["default"];
        }));
        var _Select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("./src/interop/shims/@zimbra-client/components/Select.js");
        __webpack_require__.d(__webpack_exports__, "Select", (function() {
            return _Select__WEBPACK_IMPORTED_MODULE_12__["default"];
        }));
    },
    "./src/interop/utils/call-with.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "callWith", (function() {
            return callWith;
        }));
        function callWith(fn, arg, passCallingArgs) {
            if (!fn) return;
            var cache = fn.__callWithCache || (fn.__callWithCache = []);
            for (var i = cache.length; i--; ) {
                var cached = cache[i];
                if (cached.arg === arg) return cached.proxy;
            }
            var proxy = passCallingArgs ? function() {
                for (var _len = arguments.length, rest = new Array(_len), _key = 0; _key < _len; _key++) {
                    rest[_key] = arguments[_key];
                }
                return fn.apply(void 0, [ arg ].concat(rest));
            } : function() {
                return fn(arg);
            };
            cache.push({
                arg: arg,
                proxy: proxy
            });
            return proxy;
        }
    },
    "./src/routing/index.js": function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        __webpack_require__.d(__webpack_exports__, "getMainPath", (function() {
            return getMainPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getLastUrlPath", (function() {
            return getLastUrlPath;
        }));
        __webpack_require__.d(__webpack_exports__, "setLastUrl", (function() {
            return setLastUrl;
        }));
        __webpack_require__.d(__webpack_exports__, "setLastUrlWithParams", (function() {
            return setLastUrlWithParams;
        }));
        __webpack_require__.d(__webpack_exports__, "lastUrl", (function() {
            return lastUrl;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToMainPath", (function() {
            return routeToMainPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getConversationPath", (function() {
            return getConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToConversationPath", (function() {
            return routeToConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getMeetingPath", (function() {
            return getMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToMeetingPath", (function() {
            return routeToMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToMeetingPathWithoutShowInfo", (function() {
            return routeToMeetingPathWithoutShowInfo;
        }));
        __webpack_require__.d(__webpack_exports__, "getMeetingPathWithoutShowInfo", (function() {
            return getMeetingPathWithoutShowInfo;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToInviteToGroupPath", (function() {
            return routeToInviteToGroupPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getSpacePath", (function() {
            return getSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToSpacePath", (function() {
            return routeToSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToInviteToSpacePath", (function() {
            return routeToInviteToSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "getChannelPath", (function() {
            return getChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToChannelPath", (function() {
            return routeToChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewConversationPath", (function() {
            return getNewConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewConversationPath", (function() {
            return routeToNewConversationPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewConversationPathWithSearchParam", (function() {
            return routeToNewConversationPathWithSearchParam;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewConversationPathWithSearchParam", (function() {
            return getNewConversationPathWithSearchParam;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewGroupPath", (function() {
            return getNewGroupPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewGroupPath", (function() {
            return routeToNewGroupPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewSpacePath", (function() {
            return getNewSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewSpacePath", (function() {
            return routeToNewSpacePath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewChannelPath", (function() {
            return getNewChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewChannelPath", (function() {
            return routeToNewChannelPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getNewInstantMeetingPath", (function() {
            return getNewInstantMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToNewInstantMeetingPath", (function() {
            return routeToNewInstantMeetingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getLoginPath", (function() {
            return getLoginPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToLoginPath", (function() {
            return routeToLoginPath;
        }));
        __webpack_require__.d(__webpack_exports__, "getLoadingPath", (function() {
            return getLoadingPath;
        }));
        __webpack_require__.d(__webpack_exports__, "routeToLoadingPath", (function() {
            return routeToLoadingPath;
        }));
        var preact_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/preact-router/dist/preact-router.es.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/query-string/index.js");
        var query_string__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(query_string__WEBPACK_IMPORTED_MODULE_1__);
        var _paths__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/routing/paths.js");
        function addQueryParams(customParams) {
            if (customParams === void 0) {
                customParams = {};
            }
            customParams.dev = Object(query_string__WEBPACK_IMPORTED_MODULE_1__["parse"])(window.parent.location.search).dev;
            return "?" + Object(query_string__WEBPACK_IMPORTED_MODULE_1__["stringify"])(customParams);
        }
        function getMainPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MAIN + addQueryParams();
        }
        function getLastUrlPath() {
            if (lastUrl != null) {
                return lastUrl;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MAIN + addQueryParams();
        }
        function setLastUrl(url) {
            lastUrl = url;
        }
        function setLastUrlWithParams(url, customParams) {
            lastUrl = url + Object(query_string__WEBPACK_IMPORTED_MODULE_1__["stringify"])(customParams);
        }
        var lastUrl;
        function routeToMainPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getMainPath());
        }
        function getConversationPath(conversationId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().CONVERSATION.replace(":conversationId", encodeURIComponent(conversationId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToConversationPath(conversationId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getConversationPath(conversationId, showInfo));
        }
        function getMeetingPath(meetingId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MEETING.replace(":meetingId", encodeURIComponent(meetingId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToMeetingPath(meetingId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getMeetingPath(meetingId, showInfo));
        }
        function routeToMeetingPathWithoutShowInfo(meetingId) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getMeetingPathWithoutShowInfo(meetingId));
        }
        function getMeetingPathWithoutShowInfo(meetingId) {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().MEETING.replace(":meetingId", encodeURIComponent(meetingId));
        }
        function routeToInviteToGroupPath(conversationId) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().INVITE.GROUP.replace(":conversationId", encodeURIComponent(conversationId)));
        }
        function getSpacePath(spaceId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().CHANNEL.replace(":spaceId", encodeURIComponent(spaceId)).replace(":channelId", encodeURIComponent(spaceId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToSpacePath(spaceId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getSpacePath(spaceId, showInfo));
        }
        function routeToInviteToSpacePath(spaceId) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().INVITE.SPACE.replace(":spaceId", encodeURIComponent(spaceId)).replace(":channelId", encodeURIComponent(spaceId)));
        }
        function getChannelPath(spaceId, channelId, showInfo) {
            if (showInfo === void 0) {
                showInfo = false;
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().CHANNEL.replace(":spaceId", encodeURIComponent(spaceId)).replace(":channelId", encodeURIComponent(channelId)) + addQueryParams({
                info: showInfo
            });
        }
        function routeToChannelPath(spaceId, channelId, showInfo) {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getChannelPath(spaceId, channelId, showInfo));
        }
        function getNewConversationPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.CONVERSATION + addQueryParams();
        }
        function routeToNewConversationPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewConversationPath());
        }
        function routeToNewConversationPathWithSearchParam(searchParam) {
            if (searchParam === void 0) {
                searchParam = "";
            }
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewConversationPathWithSearchParam(searchParam));
        }
        function getNewConversationPathWithSearchParam(searchParam) {
            if (searchParam === void 0) {
                searchParam = "";
            }
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.CONVERSATION + addQueryParams({
                searchParam: searchParam
            });
        }
        function getNewGroupPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.GROUP + addQueryParams();
        }
        function routeToNewGroupPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewGroupPath());
        }
        function getNewSpacePath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.SPACE + addQueryParams();
        }
        function routeToNewSpacePath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewSpacePath());
        }
        function getNewChannelPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.CHANNEL + addQueryParams();
        }
        function routeToNewChannelPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewChannelPath());
        }
        function getNewInstantMeetingPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().NEW.INSTANTMEETING + addQueryParams();
        }
        function routeToNewInstantMeetingPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getNewInstantMeetingPath());
        }
        function getLoginPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().LOGIN + addQueryParams();
        }
        function routeToLoginPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getLoginPath());
        }
        function getLoadingPath() {
            return Object(_paths__WEBPACK_IMPORTED_MODULE_2__["getPaths"])().LOADING + addQueryParams();
        }
        function routeToLoadingPath() {
            Object(preact_router__WEBPACK_IMPORTED_MODULE_0__["route"])(getLoadingPath());
        }
    }
} ]);
//# sourceMappingURL=2.e35f7715.chunk.js.map