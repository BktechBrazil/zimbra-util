AjxTemplate.register("com_zimbra_signature_zimlet.templates.signature#Main", 
function(name, params, data, buffer) {
	var _hasBuffer = Boolean(buffer);
	data = (typeof data == "string" ? { id: data } : data) || {};
	buffer = buffer || [];
	var _i = buffer.length;

	buffer[_i++] = "<table cellpadding=\"2\" cellspacing=\"0\" border=\"0\" width=\"100%\"><tr><td><b>Nome completo:</b></td><td><input type=\"text\" name=\"signature_name_prop\" /></td></tr><tr><td><b>Cargo:</b></td><td><input type=\"text\" name=\"signature_cargo_prop\" /></td></tr><tr><td><b>Setor/Coordenação/Diretoria:</b></td><td><input type=\"text\" name=\"signature_setor_prop\" /></td></tr> <tr><td><b>Sigla do Setor:</b></td><td><input type=\"text\" name=\"signature_sigla_prop\" /></td></tr> <tr><td><b>Telefones:</b></td><td><input type=\"text\" name=\"signature_fone_prop\" /></td></tr><tr><td><b>E-mail:</b></td><td><input type=\"text\" name=\"signature_mail_prop\" /></td></tr><tr><td><b>Endereço:</b></td><td>&nbsp;</td></tr><tr><td><b>Bloco:</b></td><td><select name=\"signature_bloco_prop\"><option value=\"\" >Selecione o Bloco</option><option>A</option><option>B</option><option>C</option><option>D</option></select></td></tr><tr><td><b>Andar:</b></td><td><select name=\"signature_andar_prop\"><option value=\"\" >Selecione o Andar</option><option>Garagem</option><option>1º Subsolo</option><option>2º Subsolo</option><option>Térreo</option><option>1º Andar</option><option>2º Andar</option></select></td></tr><tr><td><b>Sala:</b></td><td><input type=\"text\" name=\"signature_sala_prop\" /></td></tr></tr><tr><td><b>CEP:</b></td><td><select name=\"signature_cep_prop\"><option value=\"\" >Selecione o CEP</option><option>71605-160</option><option>71605-170</option><option>71605-180</option><option>71605-190</option></select></td></tr></table><h4 style=\"display:block; width:100%; text-align:center;\">Orientações</h4><p style=\"font-size:10px;\"><em><strong>Veja abaixo a lista de CEPs correspondente a cada bloco e selecione o bloco de sua lotação.</strong></em></p><table cellpadding=\"2\" cellspacing=\"6\" border=\"0\"><tr><td><strong>Bloco A:</strong> CEP: 71605-160<br /><strong>Bloco C:</strong> CEP: 71605-180<br /></td><td style=\"padding-left: 10px;\"><strong>Bloco B:</strong> CEP: 71605-170<br /><strong>Bloco D:</strong> CEP: 71605-190<br /></td></tr></table><br /><p>Pré-visualização</p><div id=\"signature-preview\"></div>";

	return _hasBuffer ? buffer.length : buffer.join("");
},
{
	"id": "Main"
}, true);
AjxPackage.define("com_zimbra_signature_zimlet.templates.signature");
AjxTemplate.register("com_zimbra_signature_zimlet.templates.signature", AjxTemplate.getTemplate("com_zimbra_signature_zimlet.templates.signature#Main"), AjxTemplate.getParams("com_zimbra_signature_zimlet.templates.signature#Main"));