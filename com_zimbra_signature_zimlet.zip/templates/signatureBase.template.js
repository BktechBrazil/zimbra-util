AjxTemplate.register("com_zimbra_signature_zimlet.templates.signatureBase#Main", 
function(name, params, data, buffer) {
	var _hasBuffer = Boolean(buffer);
	data = (typeof data == "string" ? { id: data } : data) || {};
	buffer = buffer || [];
	var _i = buffer.length;

	buffer[_i++] = "<div><table><tr><td><img style=\"padding-top: 5px;\" src=\"";
	buffer[_i++] = data.image;
	buffer[_i++] = "\" alt=\"Logo Prefeitura de Manaus\"></td><td style=\"font-family:Tahoma;\"><p style=\"font-size:11pt;font-weight:bold;margin:0;padding:0 10px;color:#00A5AE;\">";
	buffer[_i++] = data.name;
	buffer[_i++] = "</p><p style=\"font-size:11pt;margin:0;padding:2px 10px 1px;color:#41AF64;\">";
	buffer[_i++] = data.allocation;
	buffer[_i++] = "</p><p style=\"font-size:11pt;margin:0;padding:2px 10px 1px;color:#41AF64;\">";
	buffer[_i++] = data.department;
	buffer[_i++] = "</p><p style=\"margin:0;padding:2px 10px 1px;\"><a style=\"font-size:11pt; color:#2E57A4 !important; text-decoration: underline;\" href=\"mailto:";
	buffer[_i++] = data.correio;
	buffer[_i++] = "\">"
	buffer[_i++] = data.correio;
	buffer[_i++] = "</a></p><p style=\"margin:0;padding:2px 10px 1px;\"><a style=\"font-size: 11pt; color:#2E57A4 !important; text-decoration: underline;\" href=\"https://www.manaus.am.gov.br\">https://www.manaus.am.gov.br</a></p></td></tr></table></div>";

	return _hasBuffer ? buffer.length : buffer.join("");
},
{
	"id": "Main"
}, true);
AjxPackage.define("com_zimbra_signature_zimlet.templates.signatureBase");
AjxTemplate.register("com_zimbra_signature_zimlet.templates.signatureBase", AjxTemplate.getTemplate("com_zimbra_signature_zimlet.templates.signatureBase#Main"), AjxTemplate.getParams("com_zimbra_signature_zimlet.templates.signatureBase#Main"));