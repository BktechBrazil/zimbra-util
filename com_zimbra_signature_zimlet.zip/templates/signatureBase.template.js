AjxTemplate.register("com_zimbra_signature_zimlet.templates.signatureBase#Main", 
function(name, params, data, buffer) {
	var _hasBuffer = Boolean(buffer);
	data = (typeof data == "string" ? { id: data } : data) || {};
	buffer = buffer || [];
	var _i = buffer.length;
	
	buffer[_i++] = "<div><p><img src=\"";
	buffer[_i++] =  data.image ;
	buffer[_i++] = "\" alt=\"\"></p><p id=\"fonteNome\" style=\"font-family: sans-serif; font-size: 11px; font-weight: bold; margin: 0; padding: 0\">";
	buffer[_i++] = data.name;
	buffer[_i++] = "</p><p id=\"fonteCargo\" style=\"font-family: sans-serif; font-size: 10px; font-weight: bold; margin: 0; padding: 0\">";
	buffer[_i++] = data.cargo;	
	buffer[_i++] = "</p><p style=\"font-family: sans-serif; font-size: 10px; margin: 0; padding: 0\">";
	buffer[_i++] = data.setor;
	buffer[_i++] = "</p><p style=\"font-family: sans-serif; font-size: 10px; margin: 0; padding: 0; text-transform: uppercase\">";
	buffer[_i++] = data.sigla;
	buffer[_i++] = "</p><br /><p style=\"color: #005a95; font-family: sans-serif; font-size: 10px; font-weight: bold; margin: 0; padding: 0\">+55 61 ";
	buffer[_i++] = data.fone;
	buffer[_i++] = "</p><p style=\"color: #005a95; font-family: sans-serif; font-size: 10px; font-style: italic; margin: 0; padding: 0; text-transform: lowercase\">";
	buffer[_i++] = data.mail;
	buffer[_i++] = "</p><br /><p style=\"font-family: sans-serif; font-size: 10px; margin: 0; padding: 0\">SHIS QI 01, Conj. B, Bl. ";
	buffer[_i++] = data.bloco;
	buffer[_i++] = ", ";
	buffer[_i++] = data.andar;
	buffer[_i++] = " Sl. ";
	buffer[_i++] = data.sala;
	buffer[_i++] = "<br />Edifício Santos Dumont<br />Lago Sul, Brasília - DF&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";	
	buffer[_i++] = data.cep;
	buffer[_i++] = "</p></div>";

	return _hasBuffer ? buffer.length : buffer.join("");
},
{
	"id": "Main"
}, true);
AjxPackage.define("com_zimbra_signature_zimlet.templates.signatureBase");
AjxTemplate.register("com_zimbra_signature_zimlet.templates.signatureBase", AjxTemplate.getTemplate("com_zimbra_signature_zimlet.templates.signatureBase#Main"), AjxTemplate.getParams("com_zimbra_signature_zimlet.templates.signatureBase#Main"));

