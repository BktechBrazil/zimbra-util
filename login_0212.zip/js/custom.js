// JavaScript Document

$(document).ready(function(){

	var numberOfImages=5;

	var imageNum = Math.round(Math.random()*(numberOfImages-1))+1;

	var imgPath=('/public/img/'+imageNum+'.jpg');

	$('body').css('background-image', ('url("'+imgPath+'")'));

});
