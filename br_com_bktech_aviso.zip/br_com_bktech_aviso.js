function br_com_bktech_eula_HandlerObject() {
}

br_com_bktech_eula_HandlerObject.prototype = new ZmZimletBase();
br_com_bktech_eula_HandlerObject.prototype.constructor = br_com_bktech_eula_HandlerObject;

/**
 * Simplify handler object
 *
 */
var EULAZimlet = br_com_bktech_eula_HandlerObject;

/**
 * Initializes the zimlet.
 */
EULAZimlet.prototype.init =
function() {
   var hasAccepted = this.getUserProperty("accepted");
   if(!hasAccepted)
   {
      //disable escape key and such
      EULAZimlet.originalOnkeydown = document.onkeydown;
      document.onkeydown = function(evt) {
         console.log('Key disabled because of EULAZimlet.prototype.init');
      };
      
      AjxPackage.require({name:"MailCore", callback:new AjxCallback(this, this._applyRequestHeaders)});
      this._dialog = new ZmDialog( { title:'AVISO', parent:this.getShell(), standardButtons:[DwtDialog.CANCEL_BUTTON,DwtDialog.OK_BUTTON], disposeOnPopDown:true } );
      this._dialog.setContent('<div style="height:80vh;width:100vh"><iframe style="width:100%; height:100%" src="'+this.getResource("eula.html")+'">');
      this._dialog.setButtonListener(DwtDialog.OK_BUTTON, new AjxListener(this, this._okBtnListner));
      this._dialog.setButtonListener(DwtDialog.CANCEL_BUTTON, new AjxListener(this, this._cancelBtn));
      this._dialog._setAllowSelection();
      this._dialog.popup();
      this._dialog._button[2].setText('CIENTE');
   }
};

/* This method is called when the dialog "CANCEL" button is clicked
 */
EULAZimlet.prototype._cancelBtn =
function() {
   window.location='/?loginOp=logout';
};

/* This method is called when the dialog "ACCEPT" button is clicked
 */
EULAZimlet.prototype._okBtnListner =
function() {
   document.onkeydown = EULAZimlet.originalOnkeydown;
   this.setUserProperty("accepted", "true", true);
   try{
      this._dialog.setContent('');
      this._dialog.popdown();
   } catch (err) { }
};